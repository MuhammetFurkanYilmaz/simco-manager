const REPO_OWNER = "MuhammetFurkanYilmaz";
const REPO_NAME = "simco-manager";
function parseVersion(version) {
  const parts = String(version || "").replace(/^v/i, "").split(".");
  return [Number(parts[0] || 0), Number(parts[1] || 0), Number(parts[2] || 0)];
}
function compareVersions(a, b) {
  const [aMajor, aMinor, aPatch] = parseVersion(a);
  const [bMajor, bMinor, bPatch] = parseVersion(b);
  if (aMajor !== bMajor) return aMajor - bMajor;
  if (aMinor !== bMinor) return aMinor - bMinor;
  return aPatch - bPatch;
}
function minorKey(version) {
  const parts = String(version || "").split(".");
  const major = parts[0] || "0";
  const minor = parts[1] || "0";
  return `${major}.${minor}`;
}
function releasePageUrl(version) {
  const v = String(version || "").trim();
  return `https://github.com/${REPO_OWNER}/${REPO_NAME}/releases/tag/v${encodeURIComponent(v)}`;
}
function stripMarkdown(s) {
  let out = String(s || "");
  out = out.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
  out = out.replace(/https?:\/\/\S+/gi, "");
  out = out.replace(/[`*_>#]/g, "");
  out = out.replace(/\s+/g, " ").trim();
  return out;
}
function humanizeHighlight(s) {
  let out = stripMarkdown(s);
  out = out.replace(/\s+by\s+@?[a-z0-9_-]+/gi, "");
  out = out.replace(/\s+in\s*$/i, "");
  out = out.replace(/\s*\(#?\d+\)\s*$/i, "");
  const m = out.match(/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (m) {
    const type = m[1].toLowerCase();
    const rest = m[3];
    const prefix = type === "feat" ? "New" : type === "fix" ? "Fixed" : type === "perf" ? "Improved" : type === "docs" ? "Updated" : null;
    if (prefix) out = `${prefix}: ${rest}`;
  }
  out = out.replace(/\s+/g, " ").trim();
  return out;
}
function extractHighlights(markdownBody, { limit = 5 } = {}) {
  const body = String(markdownBody || "");
  const lines = body.split(/\r?\n/);
  const highlights = [];
  let inCode = false;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (line.startsWith("```")) {
      inCode = !inCode;
      continue;
    }
    if (inCode) continue;
    if (!line) continue;
    if (/^#+\s+/.test(line)) continue;
    const bulletMatch = line.match(/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (bulletMatch) {
      const cleaned = humanizeHighlight(bulletMatch[2]);
      if (cleaned) highlights.push(cleaned);
    }
    if (highlights.length >= limit) break;
  }
  return highlights.slice(0, limit);
}
function collectHighlightsFromReleases(releases, fromVersion, toVersion, { limit = 10 } = {}) {
  const filtered = (Array.isArray(releases) ? releases : []).filter((r) => !(r == null ? void 0 : r.prerelease)).map((r) => ({ ...r, tag_name: String((r == null ? void 0 : r.tag_name) || "") })).filter((r) => /^v?\d+\.\d+\.\d+$/.test(r.tag_name)).filter((r) => compareVersions(r.tag_name, fromVersion) > 0).filter((r) => compareVersions(r.tag_name, toVersion) <= 0).sort((a, b) => compareVersions(a.tag_name, b.tag_name));
  const highlights = [];
  for (const rel of filtered) {
    const items = extractHighlights(rel.body, { limit });
    for (const item of items) {
      highlights.push(item);
      if (highlights.length >= limit) return highlights;
    }
  }
  return highlights.slice(0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map();
const rateLimitByDomain = /* @__PURE__ */ new Map();
const rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function normalizeDomain$1(domain) {
  return String(domain || "default").trim().toLowerCase();
}
function makeError(message, extra = {}) {
  const err = new Error(message);
  Object.assign(err, extra);
  return err;
}
function buildInflightKey(domain, coalesceKey, url, method) {
  if (coalesceKey) return `${domain}:${coalesceKey}`;
  return `${domain}:${method}:${url}`;
}
function getRateLimitStatus(domain = "default") {
  const d = normalizeDomain$1(domain);
  const blockedUntil = Number(rateLimitByDomain.get(d) || 0);
  const remainingMs = Math.max(0, blockedUntil - Date.now());
  return {
    blocked: remainingMs > 0,
    remainingMs,
    blockedUntil
  };
}
async function parseResponse(res, responseType) {
  if (responseType === "response") return res;
  if (responseType === "text") return res.text();
  if (responseType === "blob") return res.blob();
  if (responseType === "arrayBuffer") return res.arrayBuffer();
  return res.json();
}
async function doRequest(domain, spec, attempt = 0) {
  const {
    url,
    method = "GET",
    headers,
    body,
    credentials = "include",
    signal,
    responseType = "json",
    retries = 0,
    retryDelayMs = 0,
    retryStatuses = [408, 425, 429, 500, 502, 503, 504],
    rateLimitCooldownMs = 0,
    timeoutMs = 0
  } = spec;
  const rate = getRateLimitStatus(domain);
  if (rate.blocked) {
    throw makeError(`RATE_LIMIT_COOLDOWN:${Math.ceil(rate.remainingMs / 1e3)}`, {
      code: "RATE_LIMIT_COOLDOWN",
      domain,
      remainingMs: rate.remainingMs,
      status: 429
    });
  }
  const controller = timeoutMs > 0 ? new AbortController() : null;
  const timeoutId = controller && timeoutMs > 0 ? setTimeout(
    () => controller.abort(makeError("Request timeout", { code: "TIMEOUT", domain })),
    timeoutMs
  ) : null;
  const mergedSignal = controller ? controller.signal : signal;
  try {
    const res = await fetch(url, {
      method,
      headers,
      body,
      credentials,
      signal: mergedSignal
    });
    if (res.status === 429 && rateLimitCooldownMs > 0) {
      const hits = (rateLimitHitCount.get(domain) || 0) + 1;
      rateLimitHitCount.set(domain, hits);
      const cooldown = hits <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain.set(domain, Date.now() + cooldown);
    }
    if (!res.ok) {
      const canRetry = attempt < retries && retryStatuses.includes(res.status);
      if (canRetry) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(domain, spec, attempt + 1);
      }
      throw makeError(`HTTP ${res.status}`, {
        code: "HTTP_ERROR",
        domain,
        status: res.status
      });
    }
    rateLimitHitCount.delete(domain);
    return parseResponse(res, responseType);
  } catch (error) {
    const isAbort = (error == null ? void 0 : error.name) === "AbortError";
    const canRetry = !isAbort && attempt < retries;
    if (canRetry) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(domain, spec, attempt + 1);
    }
    if (error instanceof Error && error.code) throw error;
    throw makeError(String((error == null ? void 0 : error.message) || error || "Request failed"), {
      code: isAbort ? "ABORTED" : "NETWORK_ERROR",
      domain,
      status: Number((error == null ? void 0 : error.status) || 0) || null,
      cause: error
    });
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}
async function request(domain, spec) {
  const d = normalizeDomain$1(domain);
  const inflightKey = buildInflightKey(d, spec == null ? void 0 : spec.coalesceKey, spec == null ? void 0 : spec.url, (spec == null ? void 0 : spec.method) || "GET");
  if ((spec == null ? void 0 : spec.coalesce) && inflightByKey.has(inflightKey)) {
    return inflightByKey.get(inflightKey);
  }
  const p = doRequest(d, spec || {}).finally(() => {
    inflightByKey.delete(inflightKey);
  });
  if (spec == null ? void 0 : spec.coalesce) {
    inflightByKey.set(inflightKey, p);
  }
  return p;
}
const STATE = {
  // auth
  auth: {
    companyId: null,
    realmId: null,
    productionModifier: null,
    salesModifier: null,
    loaded: false,
    loading: false,
    error: null
  },
  // level info (from auth-data)
  levelInfo: {
    level: null,
    experience: null,
    experienceToNextLevel: null
  }
};
function applyAuthData(data) {
  const c = data == null ? void 0 : data.authCompany;
  STATE.auth.companyId = (c == null ? void 0 : c.companyId) ?? null;
  STATE.auth.realmId = (c == null ? void 0 : c.realmId) ?? null;
  STATE.auth.productionModifier = (c == null ? void 0 : c.productionModifier) ?? null;
  STATE.auth.salesModifier = (c == null ? void 0 : c.salesModifier) ?? null;
  STATE.auth.loaded = true;
  const li = data == null ? void 0 : data.levelInfo;
  STATE.levelInfo.level = (li == null ? void 0 : li.level) ?? null;
  STATE.levelInfo.experience = (li == null ? void 0 : li.experience) ?? null;
  STATE.levelInfo.experienceToNextLevel = (li == null ? void 0 : li.experienceToNextLevel) ?? null;
}
async function loadAuthDataOnce({ force = false } = {}) {
  if (!force && STATE.auth.loaded || STATE.auth.loading) {
    return;
  }
  STATE.auth.loading = true;
  STATE.auth.error = null;
  try {
    const data = await request("auth", {
      url: "https://www.simcompanies.com/api/v3/companies/auth-data/",
      credentials: "include",
      responseType: "json",
      retries: 1,
      retryDelayMs: 250
    });
    applyAuthData(data);
  } catch (e) {
    STATE.auth.error = String((e == null ? void 0 : e.message) || e);
  } finally {
    STATE.auth.loading = false;
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set(["scoped", "company", "global"]);
function normalizeScopeMode(scopeMode) {
  if (VALID_SCOPE_MODES.has(scopeMode)) return scopeMode;
  return "scoped";
}
function numericOrNull(value) {
  if (value === null || value === void 0 || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
function resolveScopeSync(scopeMode = "scoped") {
  var _a, _b;
  const mode = normalizeScopeMode(scopeMode);
  const companyId = numericOrNull((_a = STATE.auth) == null ? void 0 : _a.companyId);
  const realmId = numericOrNull((_b = STATE.auth) == null ? void 0 : _b.realmId);
  if (mode === "global") {
    return {
      mode,
      companyId,
      realmId,
      hasScope: true,
      scopeKey: "global"
    };
  }
  if (mode === "company") {
    return {
      mode,
      companyId,
      realmId,
      hasScope: Number.isFinite(companyId),
      scopeKey: Number.isFinite(companyId) ? String(companyId) : null
    };
  }
  const hasScope = Number.isFinite(companyId) && Number.isFinite(realmId);
  return {
    mode,
    companyId,
    realmId,
    hasScope,
    scopeKey: hasScope ? `${companyId}-${realmId}` : null
  };
}
async function resolveScope(scopeMode = "scoped", { refreshAuth = false } = {}) {
  const mode = normalizeScopeMode(scopeMode);
  if (refreshAuth && mode !== "global") {
    await loadAuthDataOnce();
  }
  return resolveScopeSync(mode);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return false;
  }
}
function hasChromeStorage() {
  var _a;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome.storage) == null ? void 0 : _a.local);
  } catch {
    return false;
  }
}
function parseJson(raw) {
  if (raw == null) return null;
  if (typeof raw === "object") return raw;
  try {
    return JSON.parse(String(raw));
  } catch {
    return null;
  }
}
function toStorageRaw(backend, value) {
  if (backend === "chrome") return value;
  return JSON.stringify(value);
}
function isEnvelopeValid(envelope) {
  return Boolean(envelope && typeof envelope === "object" && Number.isFinite(Number(envelope.v)));
}
function isExpired(envelope, ttlOverrideMs = null, now = Date.now()) {
  const ts = Number((envelope == null ? void 0 : envelope.ts) || 0);
  const ttlFromEnvelope = Number(envelope == null ? void 0 : envelope.ttlMs);
  const ttl = Number.isFinite(ttlFromEnvelope) ? ttlFromEnvelope : Number.isFinite(Number(ttlOverrideMs)) ? Number(ttlOverrideMs) : null;
  if (!Number.isFinite(ts) || ts <= 0) return false;
  if (!Number.isFinite(ttl) || ttl <= 0) return false;
  return ts + ttl < now;
}
function normalizeBackend(backend) {
  return backend === "chrome" ? "chrome" : "local";
}
function normalizePrefix(prefix) {
  const p = String(prefix || DEFAULT_PREFIX).trim();
  return p.length > 0 ? p : DEFAULT_PREFIX;
}
function normalizeDomain(domain) {
  return String(domain || "unknown").trim().replace(/\s+/g, "-").toLowerCase();
}
function buildStorageKey({ domain, version, scopeKey, prefix = DEFAULT_PREFIX }) {
  return `${normalizePrefix(prefix)}:${normalizeDomain(domain)}:v${Number(version)}:${scopeKey}`;
}
async function chromeGet(keys) {
  if (!hasChromeStorage()) return {};
  const api = chrome.storage.local;
  try {
    const result = api.get(keys);
    if (result && typeof result.then === "function") {
      return result;
    }
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.get(keys, (items) => resolve(items || {}));
    } catch {
      resolve({});
    }
  });
}
async function chromeSet(items) {
  if (!hasChromeStorage()) return false;
  const api = chrome.storage.local;
  try {
    const result = api.set(items);
    if (result && typeof result.then === "function") {
      await result;
      return true;
    }
    return true;
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.set(items, () => resolve(true));
    } catch {
      resolve(false);
    }
  });
}
async function chromeRemove(keys) {
  if (!hasChromeStorage()) return false;
  const api = chrome.storage.local;
  try {
    const result = api.remove(keys);
    if (result && typeof result.then === "function") {
      await result;
      return true;
    }
    return true;
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.remove(keys, () => resolve(true));
    } catch {
      resolve(false);
    }
  });
}
async function getRaw(backend, key) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }
  const data = await chromeGet(key);
  return (data == null ? void 0 : data[key]) ?? null;
}
function localGetItemSync(key) {
  if (!hasLocalStorage()) return null;
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function localSetItemSync(key, value) {
  if (!hasLocalStorage()) return false;
  try {
    localStorage.setItem(key, String(value));
    return true;
  } catch {
    return false;
  }
}
function localRemoveItemSync(key) {
  if (!hasLocalStorage()) return false;
  try {
    localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
function localListByPrefixSync(prefix = "") {
  if (!hasLocalStorage()) return [];
  const out = [];
  const p = String(prefix || "");
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (!key || p && !key.startsWith(p)) continue;
      out.push({ key, value: localStorage.getItem(key) });
    }
  } catch {
    return [];
  }
  return out;
}
async function setRaw(backend, key, value) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return false;
    try {
      localStorage.setItem(key, String(value));
      return true;
    } catch {
      return false;
    }
  }
  return chromeSet({ [key]: value });
}
async function removeRaw(backend, key) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return false;
    try {
      localStorage.removeItem(key);
      return true;
    } catch {
      return false;
    }
  }
  return chromeRemove(key);
}
async function listByPrefix({ backend = "local", prefix = "" } = {}) {
  const b = normalizeBackend(backend);
  const p = String(prefix || "");
  if (b === "local") {
    if (!hasLocalStorage()) return [];
    const out = [];
    try {
      for (let i = 0; i < localStorage.length; i += 1) {
        const key = localStorage.key(i);
        if (!key || p && !key.startsWith(p)) continue;
        out.push({ key, value: localStorage.getItem(key) });
      }
    } catch {
      return [];
    }
    return out;
  }
  const all = await chromeGet(null);
  return Object.entries(all || {}).filter(([key]) => p ? key.startsWith(p) : true).map(([key, value]) => ({ key, value }));
}
async function get({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true
} = {}) {
  var _a;
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return null;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  const raw = await getRaw(backend, key);
  if (raw == null) return null;
  const envelope = parseJson(raw);
  if (!isEnvelopeValid(envelope)) {
    await removeRaw(backend, key);
    return null;
  }
  const envVersion = Number(envelope.v);
  if (envVersion !== Number(version)) {
    if (envVersion < Number(version)) {
      await removeRaw(backend, key);
    }
    return null;
  }
  if (isExpired(envelope, ttlMs)) {
    await removeRaw(backend, key);
    return null;
  }
  const expectedScopeKey = scopeInfo.scopeKey;
  const actualScopeKey = String(((_a = envelope == null ? void 0 : envelope.scope) == null ? void 0 : _a.scopeKey) || "");
  if (expectedScopeKey && actualScopeKey && expectedScopeKey !== actualScopeKey) {
    await removeRaw(backend, key);
    return null;
  }
  return envelope.data ?? null;
}
async function set({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true,
  data
} = {}) {
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return false;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  const envelope = {
    v: Number(version),
    ts: Date.now(),
    ttlMs: Number.isFinite(Number(ttlMs)) ? Number(ttlMs) : null,
    scope: {
      mode: scopeInfo.mode,
      scopeKey: scopeInfo.scopeKey,
      companyId: scopeInfo.companyId,
      realmId: scopeInfo.realmId
    },
    data
  };
  return setRaw(backend, key, toStorageRaw(normalizeBackend(backend), envelope));
}
async function remove({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  refreshAuth = true
} = {}) {
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return false;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  return removeRaw(backend, key);
}
async function migrate({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true,
  readLegacy,
  cleanupLegacy = true
} = {}) {
  const existing = await get({
    domain,
    version,
    scope,
    backend,
    prefix,
    ttlMs,
    refreshAuth
  });
  if (existing !== null && existing !== void 0) {
    return { data: existing, migrated: false };
  }
  if (typeof readLegacy !== "function") {
    return { data: null, migrated: false };
  }
  const legacy = await readLegacy({ getRaw, setRaw, removeRaw, listByPrefix, parseJson });
  const legacyData = legacy == null ? void 0 : legacy.data;
  if (legacyData === null || legacyData === void 0) {
    return { data: null, migrated: false };
  }
  await set({
    domain,
    version,
    scope,
    backend,
    prefix,
    ttlMs,
    refreshAuth,
    data: legacyData
  });
  if (cleanupLegacy && typeof (legacy == null ? void 0 : legacy.cleanup) === "function") {
    await legacy.cleanup();
  }
  return { data: legacyData, migrated: true };
}
const storage = {
  get,
  set,
  remove,
  listByPrefix,
  migrate,
  buildStorageKey,
  getRaw,
  setRaw,
  removeRaw,
  localSync: {
    getItem: localGetItemSync,
    setItem: localSetItemSync,
    removeItem: localRemoveItemSync,
    listByPrefix: localListByPrefixSync
  }
};
const MIN_DOMAIN_VERSION = {
  "cashflow-finance": 2,
  "buildings-cache": 1,
  "market-alerts": 1,
  "whats-new": 1,
  "xp-widget-visible": 1,
  "contract-discount": 1,
  "upgrade-discount": 1,
  "upgrade-multiplier": 1
};
const LEGACY_GLOBAL_KEYS = ["scx-buildings", "scx-buildings-ts"];
let migrationsRan = false;
function parseDomainAndVersion(key) {
  const parts = String(key || "").split(":");
  if (parts.length < 4) return null;
  if (parts[0] !== "scx") return null;
  const domain = parts[1];
  const versionPart = parts[2] || "";
  if (!versionPart.startsWith("v")) return null;
  const v = Number(versionPart.slice(1));
  if (!Number.isFinite(v)) return null;
  return { domain, version: v };
}
async function cleanupVersionedEnvelopes(backend) {
  const items = await storage.listByPrefix({ backend, prefix: "scx:" });
  for (const item of items) {
    const parsedKey = parseDomainAndVersion(item.key);
    if (!parsedKey) continue;
    const minV = Number(MIN_DOMAIN_VERSION[parsedKey.domain] || 1);
    if (parsedKey.version < minV) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    if (item.value == null) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    const envelope = typeof item.value === "string" ? (() => {
      try {
        return JSON.parse(item.value || "null");
      } catch {
        return null;
      }
    })() : item.value;
    if (!envelope || typeof envelope !== "object" || !Number.isFinite(Number(envelope.v))) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    if (Number(envelope.v) < minV) {
      await storage.removeRaw(backend, item.key);
    }
  }
}
async function cleanupLegacyGlobalKeys() {
  for (const key of LEGACY_GLOBAL_KEYS) {
    await storage.removeRaw("local", key);
    await storage.removeRaw("chrome", key);
  }
}
async function runDataMigrations({ force = false } = {}) {
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes("local");
  await cleanupVersionedEnvelopes("chrome");
  await cleanupLegacyGlobalKeys();
  migrationsRan = true;
}
let initialized = false;
async function initializeDataPlatform({ force = false } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ force });
  initialized = true;
}
async function scrapeCooperRetail(params, sender) {
  return new Promise((resolve, reject) => {
    let popupWindowId = null;
    const listener = (msg, senderWindow, sendResponse) => {
      if (popupWindowId !== null && senderWindow.tab && senderWindow.tab.windowId !== popupWindowId) return;
      if (msg.type === "COOPER_IFRAME_RESULT") {
        cleanup();
        if (msg.error) {
          reject(new Error(msg.error));
        } else {
          if (msg.data && msg.data.length === 0) {
            resolve([]);
          } else {
            resolve(msg.data);
          }
        }
      }
    };
    chrome.runtime.onMessage.addListener(listener);
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("Timeout waiting for CooperInc window to return data."));
    }, 25e3);
    const cleanup = () => {
      clearTimeout(timeout);
      chrome.runtime.onMessage.removeListener(listener);
      if (popupWindowId !== null) {
        chrome.windows.remove(popupWindowId).catch(() => {
        });
      }
    };
    const queryStr = encodeURIComponent(JSON.stringify(params));
    const url = "https://cooperinc.xyz/retail?scx_params=" + queryStr;
    chrome.windows.create({
      url,
      type: "popup",
      width: 1,
      height: 1,
      left: 9999,
      top: 9999,
      focused: false
    }).then((win) => {
      popupWindowId = win.id;
    }).catch((err) => {
      cleanup();
      reject(err);
    });
  });
}
const DOMAIN = "building-alarms";
const VERSION = 1;
async function getActiveAlarms() {
  const res = await storage.get({
    domain: DOMAIN,
    version: VERSION,
    scope: "global",
    backend: "chrome"
  });
  return (res == null ? void 0 : res.alarms) || [];
}
async function saveActiveAlarms(alarms) {
  await storage.set({
    domain: DOMAIN,
    version: VERSION,
    scope: "global",
    backend: "chrome",
    data: { alarms }
  });
}
let addAlarmQueue = Promise.resolve();
function addAlarm(alarmId, buildingName, buildingId, finishTimeMs, translatedMessage) {
  addAlarmQueue = addAlarmQueue.then(async () => {
    const alarms = await getActiveAlarms();
    const filtered = alarms.filter((a) => {
      if (buildingId && a.buildingId) {
        return a.buildingId !== buildingId;
      }
      return a.alarmId !== alarmId;
    });
    filtered.push({ alarmId, buildingName, buildingId, finishTimeMs, translatedMessage });
    await saveActiveAlarms(filtered);
  }).catch(console.error);
  return addAlarmQueue;
}
async function removeAlarm(alarmId) {
  const alarms = await getActiveAlarms();
  const filtered = alarms.filter((a) => a.alarmId !== alarmId);
  if (alarms.length !== filtered.length) {
    await saveActiveAlarms(filtered);
  }
}
async function clearExpiredAlarms() {
  const alarms = await getActiveAlarms();
  const now = Date.now();
  const filtered = alarms.filter((a) => a.finishTimeMs > now);
  if (alarms.length !== filtered.length) {
    await saveActiveAlarms(filtered);
  }
}
const KEY_WHATS_NEW = "scx-whats-new";
const KEY_LAST_MINOR = "scx-whats-new-last-notified-minor";
const KEY_LAST_VERSION = "scx-whats-new-last-version";
const STORAGE_DOMAIN_WHATS_NEW = "whats-new";
const STORAGE_DOMAIN_WHATS_NEW_META = "whats-new-meta";
const STORAGE_VERSION = 1;
async function setWhatsNew(payload) {
  await storage.set({
    domain: STORAGE_DOMAIN_WHATS_NEW,
    version: STORAGE_VERSION,
    scope: "global",
    backend: "chrome",
    refreshAuth: false,
    data: payload
  });
  await storage.set({
    domain: STORAGE_DOMAIN_WHATS_NEW_META,
    version: STORAGE_VERSION,
    scope: "global",
    backend: "chrome",
    refreshAuth: false,
    data: {
      minorKey: payload.minorKey,
      lastVersion: payload.lastVersion
    }
  });
  await storage.removeRaw("chrome", KEY_WHATS_NEW);
  await storage.removeRaw("chrome", KEY_LAST_MINOR);
  await storage.removeRaw("chrome", KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  return request("github-releases", {
    url: "https://api.github.com/repos/MuhammetFurkanYilmaz/simco-manager/releases?per_page=100",
    credentials: "omit",
    responseType: "json",
    retries: 1,
    retryDelayMs: 300
  });
}
chrome.runtime.onInstalled.addListener(async (details) => {
  await initializeDataPlatform();
  if (details.reason === "update" && details.previousVersion) {
    const currentVersion = chrome.runtime.getManifest().version;
    if (currentVersion !== details.previousVersion) {
      try {
        const response = await fetchAllReleases();
        let highlights = [];
        const url = releasePageUrl(currentVersion);
        if (response && Array.isArray(response)) {
          highlights = collectHighlightsFromReleases(response, details.previousVersion, currentVersion);
        }
        await setWhatsNew({
          show: true,
          version: currentVersion,
          url,
          highlights,
          error: !response || !Array.isArray(response),
          minorKey: minorKey(currentVersion),
          lastVersion: currentVersion
        });
      } catch (err) {
        console.error("Failed to fetch release notes:", err);
        await setWhatsNew({
          show: true,
          version: currentVersion,
          url: releasePageUrl(currentVersion),
          highlights: [],
          error: true,
          minorKey: minorKey(currentVersion),
          lastVersion: currentVersion
        });
      }
    }
  }
});
let cooperDataCache = {};
let cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(realmId) {
  const now = Date.now();
  if (cooperDataCache[realmId] && cooperDataCacheTs[realmId] && now - cooperDataCacheTs[realmId] < COOPER_CACHE_TTL) {
    return cooperDataCache[realmId];
  }
  const cooperRealm = `r${realmId + 1}`;
  const response = await fetch(`https://cooperinc.xyz/api/initial-data?realm=${cooperRealm}`);
  if (!response.ok) {
    throw new Error(`Cooper API error: ${response.status}`);
  }
  const data = await response.json();
  cooperDataCache[realmId] = data;
  cooperDataCacheTs[realmId] = now;
  return data;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "FETCH_COOPER_DATA") {
    fetchCooperData(message.realmId).then((data) => sendResponse({ success: true, data })).catch((error) => sendResponse({ success: false, error: error.message }));
    return true;
  }
  if (message.type === "SCRAPE_COOPER_RETAIL") {
    scrapeCooperRetail(message.params).then((data) => sendResponse({ success: true, data })).catch(
      (error) => sendResponse({ success: false, error: error.message })
    );
    return true;
  }
  if (message.type === "SET_BUILDING_ALARM") {
    const { buildingName, buildingId, finishTimeMs, translatedMessage } = message.data;
    const alarmId = `scx-alarm-${Date.now()}-${Math.floor(Math.random() * 1e3)}`;
    chrome.alarms.create(alarmId, { when: finishTimeMs });
    addAlarm(alarmId, buildingName, buildingId, finishTimeMs, translatedMessage).catch(console.error);
    sendResponse({ success: true, alarmId });
    return true;
  }
  if (message.type === "CANCEL_BUILDING_ALARM") {
    const { alarmId } = message.data;
    chrome.alarms.clear(alarmId);
    removeAlarm(alarmId).catch(console.error);
    sendResponse({ success: true });
    return true;
  }
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name.startsWith("scx-alarm-")) {
    const alarms = await getActiveAlarms();
    const activeAlarm = alarms.find((a) => a.alarmId === alarm.name);
    const buildingName = activeAlarm ? activeAlarm.buildingName : "A building";
    const msg = (activeAlarm == null ? void 0 : activeAlarm.translatedMessage) || `${buildingName} has finished production!`;
    chrome.notifications.create(alarm.name, {
      type: "basic",
      iconUrl: "icons/48.png",
      title: "SimCo Manager",
      message: msg,
      priority: 2
    });
    await removeAlarm(alarm.name);
  }
});
chrome.alarms.create("scx-cleanup-alarms", { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "scx-cleanup-alarms") {
    clearExpiredAlarms().catch(console.error);
  }
});
