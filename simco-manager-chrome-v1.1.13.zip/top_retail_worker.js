self.onmessage = async (e) => {
  const { action, products, adminOverhead, salesBonus, economyPhase, simulateError } = e.data;
  if (action === "calculate") {
    if (simulateError) {
      self.postMessage({ error: "Simulated worker error" });
      return;
    }
    try {
      const admin = adminOverhead !== void 0 ? adminOverhead : 0;
      const sales = salesBonus !== void 0 ? salesBonus : 0;
      const phase = economyPhase || "Normal";
      const clampedAdmin = Math.max(0, Math.min(admin, 200));
      const clampedSales = Math.max(0, Math.min(sales, 50));
      const phaseMultiplier = phase.toLowerCase() === "recession" ? 0.9 : phase.toLowerCase() === "boom" ? 1.12 : 1;
      const results = [];
      for (const prod of products) {
        for (let q = 0; q <= 9; q++) {
          const quality = q;
          const saturation = prod.saturation <= 0 || prod.saturation == null ? 0.1 : Math.max(0.1, Math.min(prod.saturation, 5));
          const qualityFactor = 1 + quality * 0.05;
          const baseTurnover = 100;
          const unitsPerDay = baseTurnover / saturation * qualityFactor * phaseMultiplier * (1 + clampedSales / 100);
          const unitsPerHr = unitsPerDay / 24;
          const sellingPrice = prod.averagePrice || prod.cost * 1.5;
          const profitPerUnit = sellingPrice - prod.cost;
          const grossRevPerDay = unitsPerDay * sellingPrice;
          const adminCostPerDay = grossRevPerDay * (clampedAdmin / 100);
          const profitPerDay = unitsPerDay * profitPerUnit - adminCostPerDay;
          if (profitPerDay < 0) {
            continue;
          }
          results.push({
            productId: prod.productId,
            productName: prod.productName || `Product ${prod.productId}`,
            quality,
            price: parseFloat(sellingPrice.toFixed(2)),
            cost: parseFloat(prod.cost.toFixed(2)),
            profitPerUnit: parseFloat(profitPerUnit.toFixed(2)),
            profitPerDay: Math.round(profitPerDay),
            grossRevPerDay: Math.round(grossRevPerDay),
            unitsPerHr: parseFloat(unitsPerHr.toFixed(1)),
            unitsPerDay: Math.round(unitsPerDay),
            pphpl: profitPerDay
          });
        }
      }
      results.sort((a, b) => b.pphpl - a.pphpl);
      self.postMessage({ action: "result", results });
    } catch (err) {
      self.postMessage({ error: err.message });
    }
  }
};
