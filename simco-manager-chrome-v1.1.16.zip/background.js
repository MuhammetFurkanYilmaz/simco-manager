const _0x3c9eef = _0xa495;
(function(_0x1293bd, _0x40639e) {
  const _0x43eb38 = _0xa495, _0x2d5483 = _0x1293bd();
  while (!![]) {
    try {
      const _0x2ae371 = parseInt(_0x43eb38(261)) / 1 * (parseInt(_0x43eb38(190)) / 2) + -parseInt(_0x43eb38(232)) / 3 + parseInt(_0x43eb38(194)) / 4 + parseInt(_0x43eb38(284)) / 5 * (-parseInt(_0x43eb38(247)) / 6) + parseInt(_0x43eb38(260)) / 7 + -parseInt(_0x43eb38(316)) / 8 + parseInt(_0x43eb38(308)) / 9;
      if (_0x2ae371 === _0x40639e) break;
      else _0x2d5483["push"](_0x2d5483["shift"]());
    } catch (_0x573f03) {
      _0x2d5483["push"](_0x2d5483["shift"]());
    }
  }
})(_0xc32d, 285394);
const REPO_OWNER = _0x3c9eef(258), REPO_NAME = "simco-manager";
function parseVersion(_0x330bdb) {
  const _0x30e9ea = String(_0x330bdb || "")["replace"](/^v/i, "")["split"](".");
  return [Number(_0x30e9ea[0] || 0), Number(_0x30e9ea[1] || 0), Number(_0x30e9ea[2] || 0)];
}
function compareVersions(_0x2f8b09, _0x1a1c7d) {
  const [_0x28bb6d, _0x57244d, _0x2d0c34] = parseVersion(_0x2f8b09), [_0x219a70, _0x14b76f, _0x41079c] = parseVersion(_0x1a1c7d);
  if (_0x28bb6d !== _0x219a70) return _0x28bb6d - _0x219a70;
  if (_0x57244d !== _0x14b76f) return _0x57244d - _0x14b76f;
  return _0x2d0c34 - _0x41079c;
}
function minorKey(_0x1fe997) {
  const _0x22e454 = String(_0x1fe997 || "")["split"]("."), _0x206cce = _0x22e454[0] || "0", _0x35d1f3 = _0x22e454[1] || "0";
  return _0x206cce + "." + _0x35d1f3;
}
function releasePageUrl(_0x50f381) {
  const _0x766724 = _0x3c9eef, _0x428713 = String(_0x50f381 || "")[_0x766724(225)]();
  return _0x766724(240) + REPO_OWNER + "/" + REPO_NAME + _0x766724(273) + encodeURIComponent(_0x428713);
}
function stripMarkdown(_0x250583) {
  const _0x3a546f = _0x3c9eef;
  let _0x418d69 = String(_0x250583 || "");
  return _0x418d69 = _0x418d69[_0x3a546f(210)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x418d69 = _0x418d69["replace"](/https?:\/\/\S+/gi, ""), _0x418d69 = _0x418d69[_0x3a546f(210)](/[`*_>#]/g, ""), _0x418d69 = _0x418d69["replace"](/\s+/g, " ")[_0x3a546f(225)](), _0x418d69;
}
function humanizeHighlight(_0x587aad) {
  const _0x58afdd = _0x3c9eef;
  let _0x3714e4 = stripMarkdown(_0x587aad);
  _0x3714e4 = _0x3714e4[_0x58afdd(210)](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x3714e4 = _0x3714e4[_0x58afdd(210)](/\s+in\s*$/i, ""), _0x3714e4 = _0x3714e4[_0x58afdd(210)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x40d707 = _0x3714e4[_0x58afdd(264)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x40d707) {
    const _0x2f88bb = _0x40d707[1][_0x58afdd(292)](), _0x47a14a = _0x40d707[3], _0x7d7f93 = _0x2f88bb === _0x58afdd(322) ? "New" : _0x2f88bb === "fix" ? "Fixed" : _0x2f88bb === _0x58afdd(318) ? _0x58afdd(310) : _0x2f88bb === _0x58afdd(235) ? _0x58afdd(291) : null;
    if (_0x7d7f93) _0x3714e4 = _0x7d7f93 + ": " + _0x47a14a;
  }
  return _0x3714e4 = _0x3714e4[_0x58afdd(210)](/\s+/g, " ")[_0x58afdd(225)](), _0x3714e4;
}
function extractHighlights(_0x396f90, { limit = 5 } = {}) {
  const _0x544730 = _0x3c9eef, _0x49776f = String(_0x396f90 || ""), _0x283bb0 = _0x49776f[_0x544730(167)](/\r?\n/), _0x2f9818 = [];
  let _0x59bc7a = ![];
  for (const _0x423b6a of _0x283bb0) {
    const _0x419962 = _0x423b6a["trim"]();
    if (_0x419962["startsWith"](_0x544730(176))) {
      _0x59bc7a = !_0x59bc7a;
      continue;
    }
    if (_0x59bc7a) continue;
    if (!_0x419962) continue;
    if (/^#+\s+/[_0x544730(214)](_0x419962)) continue;
    const _0x437696 = _0x419962[_0x544730(264)](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x437696) {
      const _0x5f9098 = humanizeHighlight(_0x437696[2]);
      if (_0x5f9098) _0x2f9818[_0x544730(309)](_0x5f9098);
    }
    if (_0x2f9818[_0x544730(306)] >= limit) break;
  }
  return _0x2f9818["slice"](0, limit);
}
function collectHighlightsFromReleases(_0x2670d5, _0x555628, _0x19feaa, { limit = 10 } = {}) {
  const _0x23069d = _0x3c9eef, _0x4f4d44 = (Array[_0x23069d(252)](_0x2670d5) ? _0x2670d5 : [])[_0x23069d(259)]((_0x42191e) => !(_0x42191e == null ? void 0 : _0x42191e[_0x23069d(242)]))[_0x23069d(296)]((_0x1e3756) => ({ ..._0x1e3756, "tag_name": String((_0x1e3756 == null ? void 0 : _0x1e3756[_0x23069d(172)]) || "") }))["filter"]((_0x1b59e7) => /^v?\d+\.\d+\.\d+$/[_0x23069d(214)](_0x1b59e7[_0x23069d(172)]))[_0x23069d(259)]((_0x13bf6a) => compareVersions(_0x13bf6a["tag_name"], _0x555628) > 0)["filter"]((_0x5d4293) => compareVersions(_0x5d4293[_0x23069d(172)], _0x19feaa) <= 0)["sort"]((_0x5dc363, _0x11c474) => compareVersions(_0x5dc363[_0x23069d(172)], _0x11c474[_0x23069d(172)])), _0x4df8c2 = [];
  for (const _0x1deaa5 of _0x4f4d44) {
    const _0x58f3d3 = extractHighlights(_0x1deaa5[_0x23069d(246)], { "limit": limit });
    for (const _0x2beaa2 of _0x58f3d3) {
      _0x4df8c2[_0x23069d(309)](_0x2beaa2);
      if (_0x4df8c2[_0x23069d(306)] >= limit) return _0x4df8c2;
    }
  }
  return _0x4df8c2[_0x23069d(280)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x3ad9b7) {
  return new Promise((_0x5e2b38) => setTimeout(_0x5e2b38, _0x3ad9b7));
}
function normalizeDomain$1(_0x19d655) {
  const _0x34860c = _0x3c9eef;
  return String(_0x19d655 || _0x34860c(198))[_0x34860c(225)]()[_0x34860c(292)]();
}
function makeError(_0x25ddf2, _0x2a89b7 = {}) {
  const _0x4a9e27 = _0x3c9eef, _0x2e37ac = new Error(_0x25ddf2);
  return Object[_0x4a9e27(186)](_0x2e37ac, _0x2a89b7), _0x2e37ac;
}
function buildInflightKey(_0xcf4d78, _0x1f6ff9, _0x7ecdcc, _0x152fb8) {
  if (_0x1f6ff9) return _0xcf4d78 + ":" + _0x1f6ff9;
  return _0xcf4d78 + ":" + _0x152fb8 + ":" + _0x7ecdcc;
}
function getRateLimitStatus(_0x53cb84 = _0x3c9eef(198)) {
  const _0x317776 = _0x3c9eef, _0x194ceb = normalizeDomain$1(_0x53cb84), _0x419257 = Number(rateLimitByDomain["get"](_0x194ceb) || 0), _0x8faa81 = Math[_0x317776(185)](0, _0x419257 - Date["now"]());
  return { "blocked": _0x8faa81 > 0, "remainingMs": _0x8faa81, "blockedUntil": _0x419257 };
}
async function parseResponse(_0x4eb605, _0x16774b) {
  const _0xdb1f79 = _0x3c9eef;
  if (_0x16774b === "response") return _0x4eb605;
  if (_0x16774b === "text") return _0x4eb605[_0xdb1f79(290)]();
  if (_0x16774b === _0xdb1f79(234)) return _0x4eb605[_0xdb1f79(234)]();
  if (_0x16774b === _0xdb1f79(161)) return _0x4eb605[_0xdb1f79(161)]();
  return _0x4eb605[_0xdb1f79(256)]();
}
async function doRequest(_0x437525, _0x415ce0, _0x4c6a78 = 0) {
  const _0x3d0e6d = _0x3c9eef, { url: _0x4ed1cf, method = _0x3d0e6d(294), headers: _0x33e9f4, body: _0xbe8623, credentials = "include", signal: _0x132f06, responseType = _0x3d0e6d(256), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x415ce0, _0x2361e9 = getRateLimitStatus(_0x437525);
  if (_0x2361e9["blocked"]) throw makeError(_0x3d0e6d(189) + Math[_0x3d0e6d(248)](_0x2361e9[_0x3d0e6d(282)] / 1e3), { "code": _0x3d0e6d(177), "domain": _0x437525, "remainingMs": _0x2361e9[_0x3d0e6d(282)], "status": 429 });
  const _0x4ecb2b = timeoutMs > 0 ? new AbortController() : null, _0x402f5e = _0x4ecb2b && timeoutMs > 0 ? setTimeout(() => _0x4ecb2b[_0x3d0e6d(159)](makeError(_0x3d0e6d(321), { "code": _0x3d0e6d(236), "domain": _0x437525 })), timeoutMs) : null, _0x16f74a = _0x4ecb2b ? _0x4ecb2b[_0x3d0e6d(302)] : _0x132f06;
  try {
    const _0x5d0c52 = await fetch(_0x4ed1cf, { "method": method, "headers": _0x33e9f4, "body": _0xbe8623, "credentials": credentials, "signal": _0x16f74a });
    if (_0x5d0c52[_0x3d0e6d(271)] === 429 && rateLimitCooldownMs > 0) {
      const _0x42e237 = (rateLimitHitCount["get"](_0x437525) || 0) + 1;
      rateLimitHitCount[_0x3d0e6d(218)](_0x437525, _0x42e237);
      const _0x47a763 = _0x42e237 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x3d0e6d(218)](_0x437525, Date[_0x3d0e6d(208)]() + _0x47a763);
    }
    if (!_0x5d0c52["ok"]) {
      const _0x1573bb = _0x4c6a78 < retries && retryStatuses[_0x3d0e6d(187)](_0x5d0c52[_0x3d0e6d(271)]);
      if (_0x1573bb) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x437525, _0x415ce0, _0x4c6a78 + 1);
      }
      throw makeError(_0x3d0e6d(314) + _0x5d0c52["status"], { "code": _0x3d0e6d(230), "domain": _0x437525, "status": _0x5d0c52[_0x3d0e6d(271)] });
    }
    return rateLimitHitCount[_0x3d0e6d(311)](_0x437525), parseResponse(_0x5d0c52, responseType);
  } catch (_0x1d3245) {
    const _0x1f96f6 = (_0x1d3245 == null ? void 0 : _0x1d3245[_0x3d0e6d(203)]) === _0x3d0e6d(215), _0x5a23df = !_0x1f96f6 && _0x4c6a78 < retries;
    if (_0x5a23df) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x437525, _0x415ce0, _0x4c6a78 + 1);
    }
    if (_0x1d3245 instanceof Error && _0x1d3245[_0x3d0e6d(223)]) throw _0x1d3245;
    throw makeError(String((_0x1d3245 == null ? void 0 : _0x1d3245[_0x3d0e6d(182)]) || _0x1d3245 || _0x3d0e6d(196)), { "code": _0x1f96f6 ? "ABORTED" : _0x3d0e6d(163), "domain": _0x437525, "status": Number((_0x1d3245 == null ? void 0 : _0x1d3245[_0x3d0e6d(271)]) || 0) || null, "cause": _0x1d3245 });
  } finally {
    if (_0x402f5e) clearTimeout(_0x402f5e);
  }
}
async function request(_0x2f19b0, _0x34de54) {
  const _0x19b8b8 = _0x3c9eef, _0x2aa862 = normalizeDomain$1(_0x2f19b0), _0x1a775e = buildInflightKey(_0x2aa862, _0x34de54 == null ? void 0 : _0x34de54[_0x19b8b8(278)], _0x34de54 == null ? void 0 : _0x34de54[_0x19b8b8(320)], (_0x34de54 == null ? void 0 : _0x34de54[_0x19b8b8(279)]) || _0x19b8b8(294));
  if ((_0x34de54 == null ? void 0 : _0x34de54[_0x19b8b8(222)]) && inflightByKey["has"](_0x1a775e)) return inflightByKey[_0x19b8b8(288)](_0x1a775e);
  const _0x387686 = doRequest(_0x2aa862, _0x34de54 || {})[_0x19b8b8(263)](() => {
    inflightByKey["delete"](_0x1a775e);
  });
  return (_0x34de54 == null ? void 0 : _0x34de54[_0x19b8b8(222)]) && inflightByKey[_0x19b8b8(218)](_0x1a775e, _0x387686), _0x387686;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x5d70d1) {
  const _0x48b4a9 = _0x3c9eef, _0x41422a = _0x5d70d1 == null ? void 0 : _0x5d70d1["authCompany"];
  STATE[_0x48b4a9(207)][_0x48b4a9(202)] = (_0x41422a == null ? void 0 : _0x41422a[_0x48b4a9(202)]) ?? null, STATE[_0x48b4a9(207)][_0x48b4a9(162)] = (_0x41422a == null ? void 0 : _0x41422a[_0x48b4a9(162)]) ?? null, STATE[_0x48b4a9(207)][_0x48b4a9(217)] = (_0x41422a == null ? void 0 : _0x41422a["productionModifier"]) ?? null, STATE[_0x48b4a9(207)][_0x48b4a9(209)] = (_0x41422a == null ? void 0 : _0x41422a[_0x48b4a9(209)]) ?? null, STATE[_0x48b4a9(207)][_0x48b4a9(183)] = !![];
  const _0x37da4f = _0x5d70d1 == null ? void 0 : _0x5d70d1[_0x48b4a9(166)];
  STATE["levelInfo"][_0x48b4a9(299)] = (_0x37da4f == null ? void 0 : _0x37da4f[_0x48b4a9(299)]) ?? null, STATE["levelInfo"][_0x48b4a9(192)] = (_0x37da4f == null ? void 0 : _0x37da4f[_0x48b4a9(192)]) ?? null, STATE["levelInfo"][_0x48b4a9(262)] = (_0x37da4f == null ? void 0 : _0x37da4f["experienceToNextLevel"]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x125ddb = _0x3c9eef;
  if (!force && STATE["auth"]["loaded"] || STATE[_0x125ddb(207)][_0x125ddb(254)]) return;
  STATE["auth"][_0x125ddb(254)] = !![], STATE["auth"]["error"] = null;
  try {
    const _0x3fade6 = await request(_0x125ddb(207), { "url": _0x125ddb(173), "credentials": "include", "responseType": "json", "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x3fade6);
  } catch (_0x42c3e1) {
    STATE[_0x125ddb(207)][_0x125ddb(315)] = String((_0x42c3e1 == null ? void 0 : _0x42c3e1[_0x125ddb(182)]) || _0x42c3e1);
  } finally {
    STATE[_0x125ddb(207)][_0x125ddb(254)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x3c9eef(178), _0x3c9eef(165), _0x3c9eef(193)]);
function normalizeScopeMode(_0x1ebdbb) {
  const _0x3c231f = _0x3c9eef;
  if (VALID_SCOPE_MODES[_0x3c231f(275)](_0x1ebdbb)) return _0x1ebdbb;
  return _0x3c231f(178);
}
function numericOrNull(_0x4519f4) {
  const _0x565e13 = _0x3c9eef;
  if (_0x4519f4 === null || _0x4519f4 === void 0 || _0x4519f4 === "") return null;
  const _0x5eb4af = Number(_0x4519f4);
  return Number[_0x565e13(164)](_0x5eb4af) ? _0x5eb4af : null;
}
function resolveScopeSync(_0x1426a9 = _0x3c9eef(178)) {
  var _a, _b;
  const _0x27a133 = _0x3c9eef, _0xbcdfab = normalizeScopeMode(_0x1426a9), _0xbb24dd = numericOrNull((_a = STATE[_0x27a133(207)]) == null ? void 0 : _a[_0x27a133(202)]), _0x182322 = numericOrNull((_b = STATE[_0x27a133(207)]) == null ? void 0 : _b[_0x27a133(162)]);
  if (_0xbcdfab === _0x27a133(193)) return { "mode": _0xbcdfab, "companyId": _0xbb24dd, "realmId": _0x182322, "hasScope": !![], "scopeKey": _0x27a133(193) };
  if (_0xbcdfab === "company") return { "mode": _0xbcdfab, "companyId": _0xbb24dd, "realmId": _0x182322, "hasScope": Number[_0x27a133(164)](_0xbb24dd), "scopeKey": Number[_0x27a133(164)](_0xbb24dd) ? String(_0xbb24dd) : null };
  const _0x1cb1f9 = Number[_0x27a133(164)](_0xbb24dd) && Number[_0x27a133(164)](_0x182322);
  return { "mode": _0xbcdfab, "companyId": _0xbb24dd, "realmId": _0x182322, "hasScope": _0x1cb1f9, "scopeKey": _0x1cb1f9 ? _0xbb24dd + "-" + _0x182322 : null };
}
async function resolveScope(_0x49c09b = _0x3c9eef(178), { refreshAuth = ![] } = {}) {
  const _0x4ace09 = _0x3c9eef, _0x30ce3f = normalizeScopeMode(_0x49c09b);
  return refreshAuth && _0x30ce3f !== _0x4ace09(193) && await loadAuthDataOnce(), resolveScopeSync(_0x30ce3f);
}
const DEFAULT_PREFIX = _0x3c9eef(201);
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x12e72d = _0x3c9eef;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome[_0x12e72d(317)]) == null ? void 0 : _a["local"]);
  } catch {
    return ![];
  }
}
function parseJson(_0x565c0b) {
  const _0x115f7b = _0x3c9eef;
  if (_0x565c0b == null) return null;
  if (typeof _0x565c0b === _0x115f7b(250)) return _0x565c0b;
  try {
    return JSON[_0x115f7b(175)](String(_0x565c0b));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x30dfe9, _0x54fd53) {
  const _0x1cc566 = _0x3c9eef;
  if (_0x30dfe9 === "chrome") return _0x54fd53;
  return JSON[_0x1cc566(184)](_0x54fd53);
}
function _0xa495(_0x595879, _0x2bf4f0) {
  _0x595879 = _0x595879 - 156;
  const _0xc32dd9 = _0xc32d();
  let _0xa49574 = _0xc32dd9[_0x595879];
  if (_0xa495["wSJsrV"] === void 0) {
    var _0x47b897 = function(_0x64f519) {
      const _0xe3da45 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x330bdb = "", _0x30e9ea = "";
      for (let _0x2f8b09 = 0, _0x1a1c7d, _0x28bb6d, _0x57244d = 0; _0x28bb6d = _0x64f519["charAt"](_0x57244d++); ~_0x28bb6d && (_0x1a1c7d = _0x2f8b09 % 4 ? _0x1a1c7d * 64 + _0x28bb6d : _0x28bb6d, _0x2f8b09++ % 4) ? _0x330bdb += String["fromCharCode"](255 & _0x1a1c7d >> (-2 * _0x2f8b09 & 6)) : 0) {
        _0x28bb6d = _0xe3da45["indexOf"](_0x28bb6d);
      }
      for (let _0x2d0c34 = 0, _0x219a70 = _0x330bdb["length"]; _0x2d0c34 < _0x219a70; _0x2d0c34++) {
        _0x30e9ea += "%" + ("00" + _0x330bdb["charCodeAt"](_0x2d0c34)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x30e9ea);
    };
    _0xa495["qwPIfN"] = _0x47b897, _0xa495["sTZmRY"] = {}, _0xa495["wSJsrV"] = !![];
  }
  const _0x326a90 = _0xc32dd9[0], _0x227cbb = _0x595879 + _0x326a90, _0x54bc6d = _0xa495["sTZmRY"][_0x227cbb];
  return !_0x54bc6d ? (_0xa49574 = _0xa495["qwPIfN"](_0xa49574), _0xa495["sTZmRY"][_0x227cbb] = _0xa49574) : _0xa49574 = _0x54bc6d, _0xa49574;
}
function isEnvelopeValid(_0x461623) {
  const _0x566c81 = _0x3c9eef;
  return Boolean(_0x461623 && typeof _0x461623 === _0x566c81(250) && Number[_0x566c81(164)](Number(_0x461623["v"])));
}
function isExpired(_0x49361f, _0x56e99b = null, _0x542bfc = Date[_0x3c9eef(208)]()) {
  const _0x43a2cf = _0x3c9eef, _0x5df2b8 = Number((_0x49361f == null ? void 0 : _0x49361f["ts"]) || 0), _0x183083 = Number(_0x49361f == null ? void 0 : _0x49361f[_0x43a2cf(211)]), _0x121171 = Number[_0x43a2cf(164)](_0x183083) ? _0x183083 : Number[_0x43a2cf(164)](Number(_0x56e99b)) ? Number(_0x56e99b) : null;
  if (!Number[_0x43a2cf(164)](_0x5df2b8) || _0x5df2b8 <= 0) return ![];
  if (!Number[_0x43a2cf(164)](_0x121171) || _0x121171 <= 0) return ![];
  return _0x5df2b8 + _0x121171 < _0x542bfc;
}
function normalizeBackend(_0x26e540) {
  const _0x281a43 = _0x3c9eef;
  return _0x26e540 === _0x281a43(274) ? "chrome" : _0x281a43(200);
}
function normalizePrefix(_0x46df79) {
  const _0x4fadae = _0x3c9eef, _0x5ab0f5 = String(_0x46df79 || DEFAULT_PREFIX)[_0x4fadae(225)]();
  return _0x5ab0f5[_0x4fadae(306)] > 0 ? _0x5ab0f5 : DEFAULT_PREFIX;
}
function normalizeDomain(_0xad54da) {
  const _0x4fa55f = _0x3c9eef;
  return String(_0xad54da || _0x4fa55f(231))["trim"]()["replace"](/\s+/g, "-")[_0x4fa55f(292)]();
}
function buildStorageKey({ domain: _0x261ef4, version: _0x39a5ae, scopeKey: _0x36bd52, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x261ef4) + ":v" + Number(_0x39a5ae) + ":" + _0x36bd52;
}
async function chromeGet(_0x11cd05) {
  const _0x5d4067 = _0x3c9eef;
  if (!hasChromeStorage()) return {};
  const _0x3102ee = chrome[_0x5d4067(317)]["local"];
  try {
    const _0xea8212 = _0x3102ee[_0x5d4067(288)](_0x11cd05);
    if (_0xea8212 && typeof _0xea8212["then"] === _0x5d4067(257)) return _0xea8212;
  } catch {
  }
  return new Promise((_0xbb5389) => {
    const _0x4b2bd6 = _0x5d4067;
    try {
      _0x3102ee[_0x4b2bd6(288)](_0x11cd05, (_0x4d3f38) => _0xbb5389(_0x4d3f38 || {}));
    } catch {
      _0xbb5389({});
    }
  });
}
async function chromeSet(_0x5862ba) {
  const _0x2bd603 = _0x3c9eef;
  if (!hasChromeStorage()) return ![];
  const _0x558c27 = chrome[_0x2bd603(317)][_0x2bd603(200)];
  try {
    const _0xadfba9 = _0x558c27["set"](_0x5862ba);
    if (_0xadfba9 && typeof _0xadfba9[_0x2bd603(293)] === _0x2bd603(257)) return await _0xadfba9, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x1cb3f5) => {
    const _0x3d660f = _0x2bd603;
    try {
      _0x558c27[_0x3d660f(218)](_0x5862ba, () => _0x1cb3f5(!![]));
    } catch {
      _0x1cb3f5(![]);
    }
  });
}
async function chromeRemove(_0x3514fd) {
  const _0x1a08b5 = _0x3c9eef;
  if (!hasChromeStorage()) return ![];
  const _0x5a7990 = chrome["storage"]["local"];
  try {
    const _0x5e3f23 = _0x5a7990[_0x1a08b5(298)](_0x3514fd);
    if (_0x5e3f23 && typeof _0x5e3f23[_0x1a08b5(293)] === _0x1a08b5(257)) return await _0x5e3f23, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x46c892) => {
    const _0x30b0cc = _0x1a08b5;
    try {
      _0x5a7990[_0x30b0cc(298)](_0x3514fd, () => _0x46c892(!![]));
    } catch {
      _0x46c892(![]);
    }
  });
}
async function getRaw(_0x19c82e, _0x3acc2f) {
  const _0x13b5ba = _0x3c9eef, _0x3de2c9 = normalizeBackend(_0x19c82e);
  if (_0x3de2c9 === _0x13b5ba(200)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x13b5ba(229)](_0x3acc2f);
    } catch {
      return null;
    }
  }
  const _0x1267c6 = await chromeGet(_0x3acc2f);
  return (_0x1267c6 == null ? void 0 : _0x1267c6[_0x3acc2f]) ?? null;
}
function localGetItemSync(_0x5d0790) {
  const _0x3a74a3 = _0x3c9eef;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x3a74a3(229)](_0x5d0790);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x9ee1b8, _0x3de007) {
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage["setItem"](_0x9ee1b8, String(_0x3de007)), !![];
  } catch {
    return ![];
  }
}
function _0xc32d() {
  const _0x1b18b6 = ["ywjVCNq", "l21HCMTLDc92D2fWCW", "yxjYyxLcDwzMzxi", "CMvHBg1jza", "tKvuv09ss19fuLjpuG", "AxngAw5PDgu", "y29TCgfUEq", "Bgv2zwXjBMzV", "C3bSAxq", "yNvPBgrPBMDjza", "B25bBgfYBq", "CMvHC29U", "BNvSBa", "DgfNx25HBwu", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "z2L0AhvIlxjLBgvHC2vZ", "CgfYC2u", "ygbG", "uKfurv9msu1jvf9dt09mre9xtG", "C2nVCgvK", "z2v0twfUAwzLC3q", "ywXHCM1jza", "D2LUzg93swq", "BwvZC2fNzq", "Bg9HzgvK", "C3rYAw5NAwz5", "Bwf4", "yxnZAwDU", "Aw5JBhvKzxm", "D2HHDhmTBMv3lw1LDge", "uKfurv9msu1jvf9dt09mre9xtJO", "mJK1ogTqqwH6wG", "C2n4lwnSzwfUDxaTywXHCM1Z", "zxHWzxjPzw5Jzq", "z2XVyMfS", "mtm4mZK2mhH2qKTXsa", "C2n4lwfSyxjTlq", "uMvXDwvZDcbMywLSzwq", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "zgvMyxvSDa", "CMvTB3zLsxrLBq", "Bg9JywW", "C2n4", "y29TCgfUEuLK", "BMfTzq", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "Ahr0Chm6lY9HCgKUz2L0AhvIlMnVBs9YzxbVCY9nDwHHBw1LDez1CMTHBLLPBg1HEI9ZAw1JBY1Tyw5Hz2vYl3jLBgvHC2vZp3bLCL9WywDLpteWma", "CNvUDgLTzq", "yxv0Aa", "BM93", "C2fSzxnnB2rPzMLLCG", "CMvWBgfJzq", "DhrStxm", "C2LTy290B29SCW", "DMfSDwu", "DgvZDa", "qwjVCNrfCNjVCG", "rKvuq0HFq09puevsx0rbvee", "ChjVzhvJDgLVBK1VzgLMAwvY", "C2v0", "yNvPBgrPBMDoyw1L", "A2v5", "zw50CMLLCW", "y29HBgvZy2u", "y29Kzq", "DgfI", "DhjPBq", "l3n0yxrZl2j1AwXKAw5NCW", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "ChjLDMLVDxnwzxjZAw9U", "z2v0sxrLBq", "sfruuf9fuLjpuG", "Dw5RBM93BG", "nZqWnejVz0fcua", "D2LUzg93CW", "yMXVyG", "zg9JCW", "veLnru9vva", "CMvTB3zLuMf3", "CMvZB2X2zq", "D2HHDhmTBMv3", "Ahr0Chm6lY9NAxrODwiUy29TlW", "y2f0y2G", "ChjLCMvSzwfZzq", "BM90AwzPy2f0Aw9UCW", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "B25nzxnZywDL", "yM9KEq", "mtqWmZrVsNzgzuO", "y2vPBa", "q29VCgvYiefqssbLCNjVCJOG", "B2jQzwn0", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "AxnbCNjHEq", "B25jBNn0ywXSzwq", "Bg9HzgLUzW", "B21PDa", "ANnVBG", "zNvUy3rPB24", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "zMLSDgvY", "mtqWmJq1meHSuuD1ra", "mMrUyxzOqq", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "zMLUywXSEq", "Bwf0y2G", "C3rYAw5N", "zgf0yq", "u0vux0jvsuXesu5hx0fmqvjn", "C2n4lwj1AwXKAw5NCW", "C2n4lxDOyxrZlw5LDW", "ywrKtgLZDgvUzxi", "C3rHDhvZ", "l3bOyxnLCW", "l3jLBgvHC2vZl3rHzY92", "y2HYB21L", "AgfZ", "C2nVCgu", "y2XLyw51Ca", "y29HBgvZy2vlzxK", "Bwv0Ag9K", "C2XPy2u", "rKvuq0HFu0Lnq09ut09mu19tvefuu19cvuLmreLor1m", "CMvTywLUAw5Ntxm", "C2n4lwj1AwXKAw5NCY10CW", "mteZnvzZwfb0wq", "BgLZDej5uhjLzML4", "Bw9Kzq", "ywXHCM1Z", "z2v0", "AwnVBNmVndGUCg5N", "Dgv4Da", "vxbKyxrLza", "Dg9mB3DLCKnHC2u", "DgHLBG", "r0vu", "yNvPBgrPBMCTywXHCM1Z", "BwfW", "DhjHBNnSyxrLze1LC3nHz2u", "CMvTB3zL", "Bgv2zwW", "Cg9WDxa", "qsbIDwLSzgLUzW", "C2LNBMfS", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l3jLDgfPBd9Zy3HFCgfYyw1Zpq", "D2vSy29Tzs1TzxnZywDL", "DhLWzq", "BgvUz3rO", "y3jLyxrL", "ndqZnJa0nLrcywPutG", "ChvZAa", "sw1WCM92zwq", "zgvSzxrL", "q09puevsx0LguKfnrv9srvnvtfq", "CgfYyw1Z", "sfruuca", "zxjYB3i", "mtC4nZaXnLviqun3uW", "C3rVCMfNzq", "CgvYzG", "C3rHCNrZv2L0Aa", "DxjS", "uMvXDwvZDcb0Aw1LB3v0", "zMvHDa", "DMvYC2LVBG", "rMfPBgvKihrVigzLDgnOihjLBgvHC2uGBM90zxm6", "C2nVCgvlzxK"];
  _0xc32d = function() {
    return _0x1b18b6;
  };
  return _0xc32d();
}
function localRemoveItemSync(_0xf8f766) {
  const _0x5899c6 = _0x3c9eef;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x5899c6(199)](_0xf8f766), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x28355f = "") {
  const _0x4366ce = _0x3c9eef;
  if (!hasLocalStorage()) return [];
  const _0x36b633 = [], _0x993335 = String(_0x28355f || "");
  try {
    for (let _0x4b3444 = 0; _0x4b3444 < localStorage[_0x4366ce(306)]; _0x4b3444 += 1) {
      const _0x18ee82 = localStorage[_0x4366ce(220)](_0x4b3444);
      if (!_0x18ee82 || _0x993335 && !_0x18ee82[_0x4366ce(319)](_0x993335)) continue;
      _0x36b633[_0x4366ce(309)]({ "key": _0x18ee82, "value": localStorage[_0x4366ce(229)](_0x18ee82) });
    }
  } catch {
    return [];
  }
  return _0x36b633;
}
async function setRaw(_0x2dd7d2, _0x48e17d, _0x5746af) {
  const _0x16cc4c = _0x3c9eef, _0x4c032a = normalizeBackend(_0x2dd7d2);
  if (_0x4c032a === _0x16cc4c(200)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x48e17d, String(_0x5746af)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x48e17d]: _0x5746af });
}
async function removeRaw(_0x452bf8, _0x495b60) {
  const _0x1fa08f = _0x3c9eef, _0x344854 = normalizeBackend(_0x452bf8);
  if (_0x344854 === _0x1fa08f(200)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["removeItem"](_0x495b60), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x495b60);
}
async function listByPrefix({ backend = "local", prefix = "" } = {}) {
  const _0x1729d0 = _0x3c9eef, _0x40fd95 = normalizeBackend(backend), _0x203b8f = String(prefix || "");
  if (_0x40fd95 === _0x1729d0(200)) {
    if (!hasLocalStorage()) return [];
    const _0x370eba = [];
    try {
      for (let _0x8c61e = 0; _0x8c61e < localStorage["length"]; _0x8c61e += 1) {
        const _0xc88d9f = localStorage[_0x1729d0(220)](_0x8c61e);
        if (!_0xc88d9f || _0x203b8f && !_0xc88d9f["startsWith"](_0x203b8f)) continue;
        _0x370eba["push"]({ "key": _0xc88d9f, "value": localStorage[_0x1729d0(229)](_0xc88d9f) });
      }
    } catch {
      return [];
    }
    return _0x370eba;
  }
  const _0x2b0714 = await chromeGet(null);
  return Object[_0x1729d0(221)](_0x2b0714 || {})[_0x1729d0(259)](([_0x3a5559]) => _0x203b8f ? _0x3a5559[_0x1729d0(319)](_0x203b8f) : !![])[_0x1729d0(296)](([_0x819835, _0x216154]) => ({ "key": _0x819835, "value": _0x216154 }));
}
async function get({ domain: _0x455d88, version: _0xaab5f, scope = _0x3c9eef(178), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x23d17e = _0x3c9eef, _0x25bd62 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x25bd62["hasScope"] || !_0x25bd62[_0x23d17e(158)]) return null;
  const _0x571452 = buildStorageKey({ "domain": _0x455d88, "version": _0xaab5f, "scopeKey": _0x25bd62[_0x23d17e(158)], "prefix": prefix }), _0x5a096b = await getRaw(backend, _0x571452);
  if (_0x5a096b == null) return null;
  const _0x4d379f = parseJson(_0x5a096b);
  if (!isEnvelopeValid(_0x4d379f)) return await removeRaw(backend, _0x571452), null;
  const _0x3a60de = Number(_0x4d379f["v"]);
  if (_0x3a60de !== Number(_0xaab5f)) return _0x3a60de < Number(_0xaab5f) && await removeRaw(backend, _0x571452), null;
  if (isExpired(_0x4d379f, ttlMs)) return await removeRaw(backend, _0x571452), null;
  const _0x248dc9 = _0x25bd62["scopeKey"], _0x277408 = String(((_a = _0x4d379f == null ? void 0 : _0x4d379f[_0x23d17e(276)]) == null ? void 0 : _a[_0x23d17e(158)]) || "");
  if (_0x248dc9 && _0x277408 && _0x248dc9 !== _0x277408) return await removeRaw(backend, _0x571452), null;
  return _0x4d379f[_0x23d17e(266)] ?? null;
}
async function set({ domain: _0x31e7f6, version: _0x462d6a, scope = "scoped", backend = _0x3c9eef(200), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x5c6346 } = {}) {
  const _0x5d2333 = _0x3c9eef, _0x45aba8 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x45aba8["hasScope"] || !_0x45aba8[_0x5d2333(158)]) return ![];
  const _0x4d57e9 = buildStorageKey({ "domain": _0x31e7f6, "version": _0x462d6a, "scopeKey": _0x45aba8[_0x5d2333(158)], "prefix": prefix }), _0x250937 = { "v": Number(_0x462d6a), "ts": Date[_0x5d2333(208)](), "ttlMs": Number[_0x5d2333(164)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x45aba8[_0x5d2333(286)], "scopeKey": _0x45aba8["scopeKey"], "companyId": _0x45aba8[_0x5d2333(202)], "realmId": _0x45aba8[_0x5d2333(162)] }, "data": _0x5c6346 };
  return setRaw(backend, _0x4d57e9, toStorageRaw(normalizeBackend(backend), _0x250937));
}
async function remove({ domain: _0x26e4da, version: _0x14640b, scope = "scoped", backend = _0x3c9eef(200), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x3b0ed1 = _0x3c9eef, _0x5ecd66 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5ecd66["hasScope"] || !_0x5ecd66[_0x3b0ed1(158)]) return ![];
  const _0x1116b4 = buildStorageKey({ "domain": _0x26e4da, "version": _0x14640b, "scopeKey": _0x5ecd66[_0x3b0ed1(158)], "prefix": prefix });
  return removeRaw(backend, _0x1116b4);
}
async function migrate({ domain: _0x31132c, version: _0x26183f, scope = _0x3c9eef(178), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0xfb4a87, cleanupLegacy = !![] } = {}) {
  const _0x41ae21 = _0x3c9eef, _0x540512 = await get({ "domain": _0x31132c, "version": _0x26183f, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x540512 !== null && _0x540512 !== void 0) return { "data": _0x540512, "migrated": ![] };
  if (typeof _0xfb4a87 !== _0x41ae21(257)) return { "data": null, "migrated": ![] };
  const _0x583e31 = await _0xfb4a87({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x4e0260 = _0x583e31 == null ? void 0 : _0x583e31[_0x41ae21(266)];
  if (_0x4e0260 === null || _0x4e0260 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x31132c, "version": _0x26183f, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x4e0260 }), cleanupLegacy && typeof (_0x583e31 == null ? void 0 : _0x583e31[_0x41ae21(277)]) === "function" && await _0x583e31[_0x41ae21(277)](), { "data": _0x4e0260, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x3c9eef(268), _0x3c9eef(283)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x4a8ac1) {
  const _0x22c951 = _0x3c9eef, _0x5a42f1 = String(_0x4a8ac1 || "")[_0x22c951(167)](":");
  if (_0x5a42f1[_0x22c951(306)] < 4) return null;
  if (_0x5a42f1[0] !== "scx") return null;
  const _0xcaeb65 = _0x5a42f1[1], _0x5436bd = _0x5a42f1[2] || "";
  if (!_0x5436bd[_0x22c951(319)]("v")) return null;
  const _0x4a2b43 = Number(_0x5436bd["slice"](1));
  if (!Number["isFinite"](_0x4a2b43)) return null;
  return { "domain": _0xcaeb65, "version": _0x4a2b43 };
}
async function cleanupVersionedEnvelopes(_0x361a14) {
  const _0x14d4bd = _0x3c9eef, _0x56d67b = await storage[_0x14d4bd(285)]({ "backend": _0x361a14, "prefix": "scx:" });
  for (const _0x549159 of _0x56d67b) {
    const _0x44cddf = parseDomainAndVersion(_0x549159["key"]);
    if (!_0x44cddf) continue;
    const _0x1c0bd1 = Number(MIN_DOMAIN_VERSION[_0x44cddf["domain"]] || 1);
    if (_0x44cddf[_0x14d4bd(156)] < _0x1c0bd1) {
      await storage[_0x14d4bd(237)](_0x361a14, _0x549159[_0x14d4bd(220)]);
      continue;
    }
    if (_0x549159[_0x14d4bd(213)] == null) {
      await storage[_0x14d4bd(237)](_0x361a14, _0x549159["key"]);
      continue;
    }
    const _0x1f43b2 = typeof _0x549159[_0x14d4bd(213)] === _0x14d4bd(265) ? (() => {
      const _0x70d2fd = _0x14d4bd;
      try {
        return JSON[_0x70d2fd(175)](_0x549159["value"] || _0x70d2fd(171));
      } catch {
        return null;
      }
    })() : _0x549159["value"];
    if (!_0x1f43b2 || typeof _0x1f43b2 !== "object" || !Number["isFinite"](Number(_0x1f43b2["v"]))) {
      await storage[_0x14d4bd(237)](_0x361a14, _0x549159[_0x14d4bd(220)]);
      continue;
    }
    Number(_0x1f43b2["v"]) < _0x1c0bd1 && await storage[_0x14d4bd(237)](_0x361a14, _0x549159[_0x14d4bd(220)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x4de6da = _0x3c9eef;
  for (const _0x49b28f of LEGACY_GLOBAL_KEYS) {
    await storage[_0x4de6da(237)](_0x4de6da(200), _0x49b28f), await storage["removeRaw"]("chrome", _0x49b28f);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x7cd764 = _0x3c9eef;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x7cd764(200)), await cleanupVersionedEnvelopes(_0x7cd764(274)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x2f404b, _0x12b24) {
  return new Promise((_0x5474a1, _0x51d036) => {
    const _0x4906af = _0xa495;
    let _0x175ec1 = null;
    const _0x3fa186 = (_0x2763b2, _0x53978f, _0xe3e1a8) => {
      const _0x320201 = _0xa495;
      if (_0x175ec1 !== null && _0x53978f[_0x320201(224)] && _0x53978f[_0x320201(224)][_0x320201(181)] !== _0x175ec1) return;
      _0x2763b2[_0x320201(305)] === _0x320201(312) && (_0x4eec1a(), _0x2763b2[_0x320201(315)] ? _0x51d036(new Error(_0x2763b2[_0x320201(315)])) : _0x2763b2[_0x320201(266)] && _0x2763b2["data"][_0x320201(306)] === 0 ? _0x5474a1([]) : _0x5474a1(_0x2763b2["data"]));
    };
    chrome["runtime"][_0x4906af(245)][_0x4906af(270)](_0x3fa186);
    const _0x22b904 = setTimeout(() => {
      const _0x2bcd1b = _0x4906af;
      _0x4eec1a(), _0x51d036(new Error(_0x2bcd1b(204)));
    }, 25e3), _0x4eec1a = () => {
      const _0x26c057 = _0x4906af;
      clearTimeout(_0x22b904), chrome["runtime"][_0x26c057(245)]["removeListener"](_0x3fa186), _0x175ec1 !== null && chrome[_0x26c057(233)][_0x26c057(298)](_0x175ec1)[_0x26c057(241)](() => {
      });
    }, _0x5497f7 = encodeURIComponent(JSON[_0x4906af(184)](_0x2f404b)), _0x4377df = _0x4906af(303) + _0x5497f7;
    chrome[_0x4906af(233)]["create"]({ "url": _0x4377df, "type": _0x4906af(300), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x4906af(293)]((_0xd8cd5c) => {
      _0x175ec1 = _0xd8cd5c["id"];
    })["catch"]((_0x10295a) => {
      _0x4eec1a(), _0x51d036(_0x10295a);
    });
  });
}
const DOMAIN = _0x3c9eef(295), VERSION = 1;
async function getActiveAlarms() {
  const _0x1605e8 = _0x3c9eef, _0x4745f5 = await storage[_0x1605e8(288)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x1605e8(193), "backend": _0x1605e8(274) });
  return (_0x4745f5 == null ? void 0 : _0x4745f5[_0x1605e8(287)]) || [];
}
async function saveActiveAlarms(_0x3f2c23) {
  const _0x368000 = _0x3c9eef;
  await storage[_0x368000(218)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x368000(193), "backend": "chrome", "data": { "alarms": _0x3f2c23 } });
}
let addAlarmQueue = Promise[_0x3c9eef(238)]();
function addAlarm(_0x23aa36, _0x5f32ce, _0x53a7fc, _0x77c1dc, _0x3bcc9e) {
  const _0x285ac1 = _0x3c9eef;
  return addAlarmQueue = addAlarmQueue[_0x285ac1(293)](async () => {
    const _0x30e344 = _0x285ac1, _0x221547 = await getActiveAlarms(), _0x530e73 = _0x221547["filter"]((_0x55f89c) => {
      const _0x6a818b = _0xa495;
      if (_0x53a7fc && _0x55f89c[_0x6a818b(168)]) return _0x55f89c["buildingId"] !== _0x53a7fc;
      return _0x55f89c[_0x6a818b(180)] !== _0x23aa36;
    });
    _0x530e73[_0x30e344(309)]({ "alarmId": _0x23aa36, "buildingName": _0x5f32ce, "buildingId": _0x53a7fc, "finishTimeMs": _0x77c1dc, "translatedMessage": _0x3bcc9e }), await saveActiveAlarms(_0x530e73);
  })[_0x285ac1(241)](console[_0x285ac1(315)]), addAlarmQueue;
}
async function removeAlarm(_0x41b2e8) {
  const _0x34de44 = _0x3c9eef, _0x43f7f2 = await getActiveAlarms(), _0x257460 = _0x43f7f2[_0x34de44(259)]((_0x4a8866) => _0x4a8866[_0x34de44(180)] !== _0x41b2e8);
  _0x43f7f2["length"] !== _0x257460[_0x34de44(306)] && await saveActiveAlarms(_0x257460);
}
async function clearExpiredAlarms() {
  const _0x4cfed4 = _0x3c9eef, _0x5c5c3f = await getActiveAlarms(), _0x18f573 = Date["now"](), _0x157b1e = _0x5c5c3f["filter"]((_0xcffa0d) => _0xcffa0d["finishTimeMs"] > _0x18f573);
  _0x5c5c3f[_0x4cfed4(306)] !== _0x157b1e[_0x4cfed4(306)] && await saveActiveAlarms(_0x157b1e);
}
const KEY_WHATS_NEW = _0x3c9eef(269), KEY_LAST_MINOR = "scx-whats-new-last-notified-minor", KEY_LAST_VERSION = _0x3c9eef(227), STORAGE_DOMAIN_WHATS_NEW = _0x3c9eef(239), STORAGE_DOMAIN_WHATS_NEW_META = _0x3c9eef(188), STORAGE_VERSION = 1;
async function setWhatsNew(_0x4b7652) {
  const _0x2ee711 = _0x3c9eef;
  await storage[_0x2ee711(218)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": _0x2ee711(193), "backend": _0x2ee711(274), "refreshAuth": ![], "data": _0x4b7652 }), await storage["set"]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x2ee711(193), "backend": _0x2ee711(274), "refreshAuth": ![], "data": { "minorKey": _0x4b7652["minorKey"], "lastVersion": _0x4b7652["lastVersion"] } }), await storage[_0x2ee711(237)](_0x2ee711(274), KEY_WHATS_NEW), await storage[_0x2ee711(237)]("chrome", KEY_LAST_MINOR), await storage["removeRaw"]("chrome", KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x4078d7 = _0x3c9eef;
  return request(_0x4078d7(174), { "url": _0x4078d7(205), "credentials": "omit", "responseType": "json", "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x3c9eef(206)][_0x3c9eef(253)][_0x3c9eef(270)](async (_0x22b1f7) => {
  const _0x4afecc = _0x3c9eef;
  await initializeDataPlatform();
  _0x22b1f7[_0x4afecc(170)] === "install" && await storage[_0x4afecc(218)]({ "domain": _0x4afecc(304), "version": 1, "scope": _0x4afecc(193), "backend": _0x4afecc(274), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x22b1f7["reason"] === "update" && _0x22b1f7[_0x4afecc(228)]) {
    const _0x272ee5 = chrome[_0x4afecc(206)][_0x4afecc(179)]()["version"];
    if (_0x272ee5 !== _0x22b1f7["previousVersion"]) try {
      const _0x5814f4 = await fetchAllReleases();
      let _0x2f8ba4 = [];
      const _0x48a4a1 = releasePageUrl(_0x272ee5);
      _0x5814f4 && Array["isArray"](_0x5814f4) && (_0x2f8ba4 = collectHighlightsFromReleases(_0x5814f4, _0x22b1f7[_0x4afecc(228)], _0x272ee5)), await setWhatsNew({ "show": !![], "version": _0x272ee5, "url": _0x48a4a1, "highlights": _0x2f8ba4, "error": !_0x5814f4 || !Array["isArray"](_0x5814f4), "minorKey": minorKey(_0x272ee5), "lastVersion": _0x272ee5 });
    } catch (_0x5d97ab) {
      console[_0x4afecc(315)](_0x4afecc(157), _0x5d97ab), await setWhatsNew({ "show": !![], "version": _0x272ee5, "url": releasePageUrl(_0x272ee5), "highlights": [], "error": !![], "minorKey": minorKey(_0x272ee5), "lastVersion": _0x272ee5 });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x3d1b0b) {
  const _0x110df4 = _0x3c9eef, _0x570147 = Date[_0x110df4(208)]();
  if (cooperDataCache[_0x3d1b0b] && cooperDataCacheTs[_0x3d1b0b] && _0x570147 - cooperDataCacheTs[_0x3d1b0b] < COOPER_CACHE_TTL) return cooperDataCache[_0x3d1b0b];
  const _0x26694e = "r" + (_0x3d1b0b + 1), _0x5e1c20 = await fetch(_0x110df4(197) + _0x26694e);
  if (!_0x5e1c20["ok"]) throw new Error(_0x110df4(249) + _0x5e1c20[_0x110df4(271)]);
  const _0x5385d2 = await _0x5e1c20[_0x110df4(256)]();
  return cooperDataCache[_0x3d1b0b] = _0x5385d2, cooperDataCacheTs[_0x3d1b0b] = _0x570147, _0x5385d2;
}
chrome[_0x3c9eef(206)][_0x3c9eef(245)]["addListener"]((_0x3b6f9d, _0x29cfa1, _0xf2d500) => {
  const _0x24ecd2 = _0x3c9eef;
  if (_0x3b6f9d["type"] === _0x24ecd2(216)) return fetchCooperData(_0x3b6f9d["realmId"])["then"]((_0x1078d7) => _0xf2d500({ "success": !![], "data": _0x1078d7 }))[_0x24ecd2(241)]((_0x1036c2) => _0xf2d500({ "success": ![], "error": _0x1036c2[_0x24ecd2(182)] })), !![];
  if (_0x3b6f9d["type"] === "FETCH_SIMCOTOOLS_VWAP") {
    const _0x33abe8 = _0x3b6f9d[_0x24ecd2(162)], _0x1ba29d = _0x24ecd2(244) + _0x33abe8 + _0x24ecd2(160);
    return request("simcotools", { "url": _0x1ba29d, "method": _0x24ecd2(294), "credentials": _0x24ecd2(255), "responseType": _0x24ecd2(256), "retries": 2, "retryDelayMs": 1e3 })[_0x24ecd2(293)]((_0x320766) => _0xf2d500({ "success": !![], "data": _0x320766 }))["catch"]((_0x25cd03) => _0xf2d500({ "success": ![], "error": _0x25cd03[_0x24ecd2(182)] || String(_0x25cd03) })), !![];
  }
  if (_0x3b6f9d["type"] === "FETCH_SIMCOTOOLS_EXECUTIVES") {
    const { realmId: _0x172db1, queryParams: _0x5bdd8e, headers: _0x515317 } = _0x3b6f9d, _0x26b7c4 = "https://api.simcotools.com/v1/realms/" + _0x172db1 + "/executives?" + _0x5bdd8e;
    return request(_0x24ecd2(212), { "url": _0x26b7c4, "method": _0x24ecd2(294), "headers": _0x515317, "credentials": _0x24ecd2(255), "responseType": _0x24ecd2(256), "retries": 2, "retryDelayMs": 1e3 })[_0x24ecd2(293)]((_0x1b5ad0) => _0xf2d500({ "success": !![], "data": _0x1b5ad0 }))[_0x24ecd2(241)]((_0x44d6a9) => _0xf2d500({ "success": ![], "error": _0x44d6a9["message"] || String(_0x44d6a9) })), !![];
  }
  if (_0x3b6f9d[_0x24ecd2(305)] === _0x24ecd2(281)) {
    const { realmId: _0x13e247, headers: _0x304175 } = _0x3b6f9d, _0x2c06df = _0x24ecd2(244) + _0x13e247 + _0x24ecd2(226);
    return request(_0x24ecd2(212), { "url": _0x2c06df, "method": _0x24ecd2(294), "headers": _0x304175, "credentials": "omit", "responseType": _0x24ecd2(256), "retries": 2, "retryDelayMs": 1e3 })[_0x24ecd2(293)]((_0x54b65c) => _0xf2d500({ "success": !![], "data": _0x54b65c }))[_0x24ecd2(241)]((_0x4f699d) => _0xf2d500({ "success": ![], "error": _0x4f699d[_0x24ecd2(182)] || String(_0x4f699d) })), !![];
  }
  if (_0x3b6f9d[_0x24ecd2(305)] === "FETCH_SIMCOTOOLS_PHASES") {
    const { realmId: _0x4ec34e, headers: _0x14d6f8 } = _0x3b6f9d, _0x79abce = _0x24ecd2(244) + _0x4ec34e + _0x24ecd2(272);
    return request("simcotools", { "url": _0x79abce, "method": _0x24ecd2(294), "headers": _0x14d6f8, "credentials": _0x24ecd2(255), "responseType": _0x24ecd2(256), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x44d7c4) => _0xf2d500({ "success": !![], "data": _0x44d7c4 }))[_0x24ecd2(241)]((_0x22056f) => _0xf2d500({ "success": ![], "error": _0x22056f[_0x24ecd2(182)] || String(_0x22056f) })), !![];
  }
  if (_0x3b6f9d[_0x24ecd2(305)] === "SCRAPE_COOPER_RETAIL") return scrapeCooperRetail(_0x3b6f9d[_0x24ecd2(313)])[_0x24ecd2(293)]((_0x5d9f11) => _0xf2d500({ "success": !![], "data": _0x5d9f11 }))[_0x24ecd2(241)]((_0x2963b3) => _0xf2d500({ "success": ![], "error": _0x2963b3["message"] })), !![];
  if (_0x3b6f9d[_0x24ecd2(305)] === _0x24ecd2(267)) {
    const { buildingName: _0x1ad3bc, buildingId: _0x52bc74, finishTimeMs: _0xf7b1c4, translatedMessage: _0x193da9 } = _0x3b6f9d[_0x24ecd2(266)], _0x4d1792 = _0x24ecd2(195) + Date[_0x24ecd2(208)]() + "-" + Math["floor"](Math["random"]() * 1e3);
    return chrome[_0x24ecd2(287)][_0x24ecd2(307)](_0x4d1792, { "when": _0xf7b1c4 }), addAlarm(_0x4d1792, _0x1ad3bc, _0x52bc74, _0xf7b1c4, _0x193da9)[_0x24ecd2(241)](console["error"]), _0xf2d500({ "success": !![], "alarmId": _0x4d1792 }), !![];
  }
  if (_0x3b6f9d[_0x24ecd2(305)] === "CANCEL_BUILDING_ALARM") {
    const { alarmId: _0x1a77f6 } = _0x3b6f9d[_0x24ecd2(266)];
    return chrome[_0x24ecd2(287)]["clear"](_0x1a77f6), removeAlarm(_0x1a77f6)[_0x24ecd2(241)](console[_0x24ecd2(315)]), _0xf2d500({ "success": !![] }), !![];
  }
}), chrome[_0x3c9eef(287)][_0x3c9eef(169)][_0x3c9eef(270)](async (_0x1562f9) => {
  const _0x253a83 = _0x3c9eef;
  if (_0x1562f9[_0x253a83(203)][_0x253a83(319)](_0x253a83(195))) {
    const _0x180aee = await getActiveAlarms(), _0x457aad = _0x180aee["find"]((_0x2a4ea9) => _0x2a4ea9["alarmId"] === _0x1562f9[_0x253a83(203)]), _0x3d5ff5 = _0x457aad ? _0x457aad[_0x253a83(219)] : _0x253a83(301), _0x4024c0 = (_0x457aad == null ? void 0 : _0x457aad[_0x253a83(297)]) || _0x3d5ff5 + _0x253a83(251);
    chrome[_0x253a83(243)][_0x253a83(307)](_0x1562f9[_0x253a83(203)], { "type": "basic", "iconUrl": _0x253a83(289), "title": "SimCo Manager", "message": _0x4024c0, "priority": 2 }), await removeAlarm(_0x1562f9[_0x253a83(203)]);
  }
}), chrome[_0x3c9eef(287)][_0x3c9eef(307)](_0x3c9eef(191), { "periodInMinutes": 60 }), chrome["alarms"][_0x3c9eef(169)][_0x3c9eef(270)]((_0x31831b) => {
  const _0x34bdc9 = _0x3c9eef;
  _0x31831b[_0x34bdc9(203)] === _0x34bdc9(191) && clearExpiredAlarms()[_0x34bdc9(241)](console[_0x34bdc9(315)]);
});
