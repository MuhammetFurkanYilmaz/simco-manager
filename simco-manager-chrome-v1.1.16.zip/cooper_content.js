(function(_0x1d9a2d, _0x54b10b) {
  var _0x4e3a8f = _0x3ab0, _0x13d524 = _0x1d9a2d();
  while (!![]) {
    try {
      var _0x1d102c = parseInt(_0x4e3a8f(418)) / 1 + parseInt(_0x4e3a8f(424)) / 2 + -parseInt(_0x4e3a8f(421)) / 3 * (-parseInt(_0x4e3a8f(422)) / 4) + parseInt(_0x4e3a8f(423)) / 5 + -parseInt(_0x4e3a8f(426)) / 6 * (-parseInt(_0x4e3a8f(419)) / 7) + parseInt(_0x4e3a8f(420)) / 8 + -parseInt(_0x4e3a8f(425)) / 9;
      if (_0x1d102c === _0x54b10b) break;
      else _0x13d524["push"](_0x13d524["shift"]());
    } catch (_0x1a7823) {
      _0x13d524["push"](_0x13d524["shift"]());
    }
  }
})(_0x273c, 766396);
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function _0x273c() {
  var _0x3bcd27 = ["ndG1nteZn051vLjcua", "otiWntC3nMX3BffOrG", "mZa5m0XjrwjQyW", "mJmWogjqq0DbBG", "mZm0mdaXnxbzAvbNsW", "mty2nZe5oefvyKPfBG", "mZq3nJu0odHoEhf1Cfy", "nK9Pyvvnra", "nJG4ndi2y2LdrLn4"];
  _0x273c = function() {
    return _0x3bcd27;
  };
  return _0x273c();
}
function _0x3ab0(_0x36b4b6, _0x82e9e7) {
  _0x36b4b6 = _0x36b4b6 - 418;
  var _0x273cd4 = _0x273c();
  var _0x3ab0cd = _0x273cd4[_0x36b4b6];
  if (_0x3ab0["cuLQhs"] === void 0) {
    var _0x4b7f7e = function(_0x4aebbd) {
      var _0x4678ce = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x469dc3 = "", _0x451a45 = "";
      for (var _0x499e4d = 0, _0x423167, _0x4477a3, _0x454366 = 0; _0x4477a3 = _0x4aebbd["charAt"](_0x454366++); ~_0x4477a3 && (_0x423167 = _0x499e4d % 4 ? _0x423167 * 64 + _0x4477a3 : _0x4477a3, _0x499e4d++ % 4) ? _0x469dc3 += String["fromCharCode"](255 & _0x423167 >> (-2 * _0x499e4d & 6)) : 0) {
        _0x4477a3 = _0x4678ce["indexOf"](_0x4477a3);
      }
      for (var _0x537b95 = 0, _0x712116 = _0x469dc3["length"]; _0x537b95 < _0x712116; _0x537b95++) {
        _0x451a45 += "%" + ("00" + _0x469dc3["charCodeAt"](_0x537b95)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x451a45);
    };
    _0x3ab0["XGeusn"] = _0x4b7f7e, _0x3ab0["rYPkQr"] = {}, _0x3ab0["cuLQhs"] = !![];
  }
  var _0x5e197d = _0x273cd4[0], _0x1bbbb1 = _0x36b4b6 + _0x5e197d, _0x31f76e = _0x3ab0["rYPkQr"][_0x1bbbb1];
  return !_0x31f76e ? (_0x3ab0cd = _0x3ab0["XGeusn"](_0x3ab0cd), _0x3ab0["rYPkQr"][_0x1bbbb1] = _0x3ab0cd) : _0x3ab0cd = _0x31f76e, _0x3ab0cd;
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
