(function(_0xd2f6a2, _0x57cd25) {
  const _0x4f7cb1 = _0x251a, _0x23eb55 = _0xd2f6a2();
  while (!![]) {
    try {
      const _0x43b1f8 = -parseInt(_0x4f7cb1(153)) / 1 * (-parseInt(_0x4f7cb1(150)) / 2) + -parseInt(_0x4f7cb1(170)) / 3 * (parseInt(_0x4f7cb1(160)) / 4) + -parseInt(_0x4f7cb1(173)) / 5 + parseInt(_0x4f7cb1(166)) / 6 * (parseInt(_0x4f7cb1(151)) / 7) + -parseInt(_0x4f7cb1(161)) / 8 + -parseInt(_0x4f7cb1(180)) / 9 * (parseInt(_0x4f7cb1(164)) / 10) + parseInt(_0x4f7cb1(174)) / 11;
      if (_0x43b1f8 === _0x57cd25) break;
      else _0x23eb55["push"](_0x23eb55["shift"]());
    } catch (_0x38af62) {
      _0x23eb55["push"](_0x23eb55["shift"]());
    }
  }
})(_0x484a, 802155), self["onmessage"] = async (_0x347e88) => {
  const _0x1c2fca = _0x251a, { action: _0x260014, products: _0x19d979, adminOverhead: _0x3266d5, salesBonus: _0x30e105, economyPhase: _0x119464, simulateError: _0x3cc940 } = _0x347e88[_0x1c2fca(176)];
  if (_0x260014 === _0x1c2fca(178)) {
    if (_0x3cc940) {
      self["postMessage"]({ "error": _0x1c2fca(159) });
      return;
    }
    try {
      const _0x4c94e5 = _0x3266d5 !== void 0 ? _0x3266d5 : 0, _0x4ed5f0 = _0x30e105 !== void 0 ? _0x30e105 : 0, _0x21bb8c = _0x119464 || _0x1c2fca(163), _0x4297d8 = Math[_0x1c2fca(152)](0, Math["min"](_0x4c94e5, 200)), _0x592140 = Math[_0x1c2fca(152)](0, Math[_0x1c2fca(157)](_0x4ed5f0, 50)), _0x229305 = _0x21bb8c["toLowerCase"]() === _0x1c2fca(154) ? 0.9 : _0x21bb8c[_0x1c2fca(165)]() === _0x1c2fca(169) ? 1.12 : 1, _0x16db5b = [];
      for (const _0x1faa58 of _0x19d979) {
        for (let _0x271b38 = 0; _0x271b38 <= 9; _0x271b38++) {
          const _0x1874bb = _0x271b38, _0x1fe3af = _0x1faa58[_0x1c2fca(168)] <= 0 || _0x1faa58[_0x1c2fca(168)] == null ? 0.1 : Math[_0x1c2fca(152)](0.1, Math[_0x1c2fca(157)](_0x1faa58[_0x1c2fca(168)], 5)), _0x337849 = 1 + _0x1874bb * 0.05, _0x1706f3 = 100, _0x19de39 = _0x1706f3 / _0x1fe3af * _0x337849 * _0x229305 * (1 + _0x592140 / 100), _0x8f7865 = _0x19de39 / 24, _0x317417 = _0x1faa58["averagePrice"] || _0x1faa58["cost"] * 1.5, _0x4fe07d = _0x317417 - _0x1faa58["cost"], _0x2f64a4 = _0x19de39 * _0x317417, _0x5e8fc = _0x2f64a4 * (_0x4297d8 / 100), _0xbd8b87 = _0x19de39 * _0x4fe07d - _0x5e8fc;
          if (_0xbd8b87 < 0) continue;
          _0x16db5b["push"]({ "productId": _0x1faa58["productId"], "productName": _0x1faa58[_0x1c2fca(158)] || _0x1c2fca(162) + _0x1faa58["productId"], "quality": _0x1874bb, "price": parseFloat(_0x317417[_0x1c2fca(172)](2)), "cost": parseFloat(_0x1faa58[_0x1c2fca(167)][_0x1c2fca(172)](2)), "profitPerUnit": parseFloat(_0x4fe07d["toFixed"](2)), "profitPerDay": Math[_0x1c2fca(177)](_0xbd8b87), "grossRevPerDay": Math[_0x1c2fca(177)](_0x2f64a4), "unitsPerHr": parseFloat(_0x8f7865[_0x1c2fca(172)](1)), "unitsPerDay": Math[_0x1c2fca(177)](_0x19de39), "pphpl": _0xbd8b87 });
        }
      }
      _0x16db5b[_0x1c2fca(155)]((_0x2b10bd, _0x4b79d9) => _0x4b79d9[_0x1c2fca(156)] - _0x2b10bd["pphpl"]), self[_0x1c2fca(175)]({ "action": _0x1c2fca(171), "results": _0x16db5b });
    } catch (_0x47498c) {
      self[_0x1c2fca(175)]({ "error": _0x47498c[_0x1c2fca(179)] });
    }
  }
};
function _0x251a(_0x5663a1, _0x4f41fd) {
  _0x5663a1 = _0x5663a1 - 150;
  const _0x484a2d = _0x484a();
  let _0x251a34 = _0x484a2d[_0x5663a1];
  if (_0x251a["CYPCgH"] === void 0) {
    var _0x2ccdc8 = function(_0x43b14e) {
      const _0x3595ee = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x347e88 = "", _0x260014 = "";
      for (let _0x19d979 = 0, _0x3266d5, _0x30e105, _0x119464 = 0; _0x30e105 = _0x43b14e["charAt"](_0x119464++); ~_0x30e105 && (_0x3266d5 = _0x19d979 % 4 ? _0x3266d5 * 64 + _0x30e105 : _0x30e105, _0x19d979++ % 4) ? _0x347e88 += String["fromCharCode"](255 & _0x3266d5 >> (-2 * _0x19d979 & 6)) : 0) {
        _0x30e105 = _0x3595ee["indexOf"](_0x30e105);
      }
      for (let _0x3cc940 = 0, _0x4c94e5 = _0x347e88["length"]; _0x3cc940 < _0x4c94e5; _0x3cc940++) {
        _0x260014 += "%" + ("00" + _0x347e88["charCodeAt"](_0x3cc940)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x260014);
    };
    _0x251a["tZBXFW"] = _0x2ccdc8, _0x251a["lMOqdX"] = {}, _0x251a["CYPCgH"] = !![];
  }
  const _0x50c6dd = _0x484a2d[0], _0x9cb6d3 = _0x5663a1 + _0x50c6dd, _0x22d5e9 = _0x251a["lMOqdX"][_0x9cb6d3];
  return !_0x22d5e9 ? (_0x251a34 = _0x251a["tZBXFW"](_0x251a34), _0x251a["lMOqdX"][_0x9cb6d3] = _0x251a34) : _0x251a34 = _0x22d5e9, _0x251a34;
}
function _0x484a() {
  const _0x6451ca = ["CM91BMq", "y2fSy3vSyxrL", "BwvZC2fNzq", "mJu5mtffsKzntva", "nJq2mdrSsxbZsxi", "mJyZmtCXm2Ldte1NtG", "Bwf4", "ne9eswvKva", "CMvJzxnZAw9U", "C29YDa", "ChbOCgW", "BwLU", "ChjVzhvJDe5HBwu", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "mteYEgvcDhDU", "nZyYnJe2meXOrg1Lua", "uhjVzhvJDca", "tM9YBwfS", "mtqXmhHerefUzG", "Dg9mB3DLCKnHC2u", "mtjvz3bNz1m", "y29ZDa", "C2f0DxjHDgLVBG", "yM9VBq", "mtuYnZy5EvfYtxDM", "CMvZDwX0", "Dg9gAxHLza", "mJaWmdi4me15uMrbEq", "mZqXnJC1mtHrv0Luweq", "Cg9ZDe1LC3nHz2u", "zgf0yq"];
  _0x484a = function() {
    return _0x6451ca;
  };
  return _0x484a();
}
