const _0x4b8502 = _0x1e9d;
(function(_0x5c7d54, _0x31e8cf) {
  const _0x502a18 = _0x1e9d, _0x291038 = _0x5c7d54();
  while (!![]) {
    try {
      const _0x293146 = -parseInt(_0x502a18(435)) / 1 + parseInt(_0x502a18(346)) / 2 * (parseInt(_0x502a18(303)) / 3) + -parseInt(_0x502a18(406)) / 4 + -parseInt(_0x502a18(287)) / 5 * (parseInt(_0x502a18(413)) / 6) + parseInt(_0x502a18(376)) / 7 * (parseInt(_0x502a18(343)) / 8) + parseInt(_0x502a18(348)) / 9 + parseInt(_0x502a18(295)) / 10 * (parseInt(_0x502a18(324)) / 11);
      if (_0x293146 === _0x31e8cf) break;
      else _0x291038["push"](_0x291038["shift"]());
    } catch (_0x62aa0d) {
      _0x291038["push"](_0x291038["shift"]());
    }
  }
})(_0x3170, 922806);
const REPO_OWNER = _0x4b8502(337), REPO_NAME = _0x4b8502(377);
function parseVersion(_0x294499) {
  const _0x3f55f7 = _0x4b8502, _0x3e3407 = String(_0x294499 || "")[_0x3f55f7(283)](/^v/i, "")[_0x3f55f7(327)](".");
  return [Number(_0x3e3407[0] || 0), Number(_0x3e3407[1] || 0), Number(_0x3e3407[2] || 0)];
}
function compareVersions(_0x206eb4, _0x4ae0df) {
  const [_0x4cc600, _0x2233c5, _0x571e35] = parseVersion(_0x206eb4), [_0x1c71d5, _0x1f2512, _0x83efb9] = parseVersion(_0x4ae0df);
  if (_0x4cc600 !== _0x1c71d5) return _0x4cc600 - _0x1c71d5;
  if (_0x2233c5 !== _0x1f2512) return _0x2233c5 - _0x1f2512;
  return _0x571e35 - _0x83efb9;
}
function _0x3170() {
  const _0x27ec4d = ["ywrKtgLZDgvUzxi", "DgfI", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "zxjYB3i", "vxbKyxrLza", "DgHLBG", "CMvWBgfJzq", "CMvTB3zLuMf3", "C2XPy2u", "CgvYzG", "nurnv0Pdyq", "CMvTB3zL", "Bwv0Ag9K", "DhjPBq", "Bg9JywW", "y2vPBa", "BMfTzq", "qujpuLrfra", "mJqWnJCWy0DAwwL3", "yNvPBgrPBMDoyw1L", "l2v4zwn1DgL2zxm/", "C2n4lxDOyxrZlw5LDW", "C3rHDhvZ", "l3n0yxrZl2j1AwXKAw5NCW", "Dw5KzwzPBMvK", "zxHWzxjPzw5Jzq", "mte0Ewngrg9l", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "l21HCMTLDc92D2fWCW", "Bwf0y2G", "DxjS", "uKfurv9msu1jvf9dt09mre9xtJO", "z2v0", "AwnVBNmVndGUCg5N", "C3rVCMfNzq", "BgfZDfzLCNnPB24", "BgvUz3rO", "zMXVB3i", "yMXVyG", "D2vSy29Tzs1TzxnZywDL", "AgfZu2nVCgu", "BgLZDej5uhjLzML4", "ywjVCNq", "Bg9HzgvK", "y2f0y2G", "yNvPBgrPBMDjza", "mZe5D1nTCLLf", "yxnZAwDU", "CgfYC2u", "C3bSAxq", "B2jQzwn0", "DhLWzq", "Aw5JBhvKzq", "Ahr0Chm6lY9HCgKUz2L0AhvIlMnVBs9YzxbVCY9nDwHHBw1LDez1CMTHBLLPBg1HEI9ZAw1JBY1Tyw5Hz2vYl3jLBgvHC2vZp3bLCL9WywDLpteWma", "BM93", "yNvPBgrPBMCTywXHCM1Z", "DMvYC2LVBG", "ChjLCMvSzwfZzq", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "C2nVCgvK", "Bgv2zwW", "C2n4lwnSzwfUDxaTywXHCM1Z", "qwjVCNrfCNjVCG", "C3rYAw5N", "oez2rgXtwq", "uMvXDwvZDcbMywLSzwq", "C2nVCgu", "odq3mJjUrhnuwNO", "A2v5", "mJi0mZG0nhvyEuTHvG", "C2nVCgvlzxK", "Ahr0Chm6lY9NAxrODwiUy29TlW", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "zMLUAxnOvgLTzu1Z", "B25bBgfYBq", "C3rYAw5NAwz5", "D2HHDhmTBMv3lw1LDge", "CMvZB2X2zq", "DgvZDa", "yMfZAwm", "B25jBNn0ywXSzwq", "Bwf4", "B21PDa", "ChjLDMLVDxnwzxjZAw9U", "CMvHC29U", "u0nsqvbfx0npt1bfuL9srvrbsuW", "y29HBgvZy2u", "yMXVy2TLza", "Dgv4Da", "y3jLyxrL", "ygbG", "y29TCgfUEuLK", "BNvSBa", "C2n4", "zgf0yq", "DhjHBNnSyxrLze1LC3nHz2u", "yxjYyxLcDwzMzxi", "mta3mteZotnPs291yNu", "C2LTy28TBwfUywDLCG", "Bgv2zwXjBMzV", "q29VCgvYiefqssbLCNjVCJOG", "zML4", "CMvHBg1jza", "C2fSzxnnB2rPzMLLCG", "q09puevsx0LguKfnrv9srvnvtfq", "yxv0Aa", "AxngAw5PDgu", "z2v0twfUAwzLC3q", "CMfUzg9T", "DhrStxm", "C2v0sxrLBq", "yM9KEq", "D2LUzg93CW", "rKvuq0HFu0Lnq09ut09mu19qseftrvm", "CMvZCg9UC2u", "zMLSDgvY", "yxv0AenVBxbHBNK", "sw1WCM92zwq", "zw50CMLLCW", "ChjVzhvJDgLVBK1VzgLMAwvY", "z2XVyMfS", "Aw5ZDgfSBa", "CMvTB3zLtgLZDgvUzxi", "zNvUy3rPB24", "C29YDa", "C2LTy290B29SCW", "z2L0AhvIlxjLBgvHC2vZ", "nJi3odC0og94EezKtq", "sfruuca", "uMvXDwvZDcb0Aw1LB3v0", "DgfNx25HBwu", "C2n4lwfSyxjTlq", "zg9JCW", "C2v0", "nJC4nJqYnLfUzNPuAW", "zgvSzxrL", "veLnru9vva", "y2HYB21L", "ywXHCM1Z", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "uKfurv9msu1jvf9dt09mre9xtG", "y29Kzq", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "r0vu", "CgfYyw1Z", "DxbKyxrL", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "CMvTywLUAw5Ntxm", "B25nzxnZywDL", "tMv3", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "CMvTB3zLsxrLBq", "AxnbCNjHEq", "z2v0sxrLBq", "ChvZAa", "BM90AwzPy2f0Aw9UCW", "ndyZnJeYy0fPvKjN", "ANnVBG", "y29TCgfUEq", "l3jLBgvHC2vZl3rHzY92", "BwvZC2fNzq", "C2n4lwj1AwXKAw5NCY10CW", "CNvUDgLTzq", "Bg9HzgLUzW", "DMfSDwu", "C3rHCNrZv2L0Aa", "AgfZ", "BwfW", "y2XLyw51Ca", "ywXHCM1jza"];
  _0x3170 = function() {
    return _0x27ec4d;
  };
  return _0x3170();
}
function minorKey(_0x9f4670) {
  const _0x5b9abe = _0x4b8502, _0x31f5aa = String(_0x9f4670 || "")[_0x5b9abe(327)]("."), _0x1b2bf0 = _0x31f5aa[0] || "0", _0x186bb5 = _0x31f5aa[1] || "0";
  return _0x1b2bf0 + "." + _0x186bb5;
}
function releasePageUrl(_0x245507) {
  const _0x1b8fec = _0x4b8502, _0x5f4e39 = String(_0x245507 || "")[_0x1b8fec(290)]();
  return _0x1b8fec(350) + REPO_OWNER + "/" + REPO_NAME + _0x1b8fec(438) + encodeURIComponent(_0x5f4e39);
}
function stripMarkdown(_0x3bc97a) {
  const _0x38ca0e = _0x4b8502;
  let _0x299e9f = String(_0x3bc97a || "");
  return _0x299e9f = _0x299e9f[_0x38ca0e(283)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x299e9f = _0x299e9f[_0x38ca0e(283)](/https?:\/\/\S+/gi, ""), _0x299e9f = _0x299e9f[_0x38ca0e(283)](/[`*_>#]/g, ""), _0x299e9f = _0x299e9f[_0x38ca0e(283)](/\s+/g, " ")[_0x38ca0e(290)](), _0x299e9f;
}
function humanizeHighlight(_0x44fff5) {
  const _0x44dcb5 = _0x4b8502;
  let _0x13bb1f = stripMarkdown(_0x44fff5);
  _0x13bb1f = _0x13bb1f[_0x44dcb5(283)](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x13bb1f = _0x13bb1f[_0x44dcb5(283)](/\s+in\s*$/i, ""), _0x13bb1f = _0x13bb1f[_0x44dcb5(283)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x44301e = _0x13bb1f[_0x44dcb5(307)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x44301e) {
    const _0xd00798 = _0x44301e[1]["toLowerCase"](), _0x53feb6 = _0x44301e[3], _0x25c533 = _0xd00798 === "feat" ? _0x44dcb5(428) : _0xd00798 === _0x44dcb5(380) ? "Fixed" : _0xd00798 === _0x44dcb5(286) ? _0x44dcb5(396) : _0xd00798 === _0x44dcb5(411) ? _0x44dcb5(281) : null;
    if (_0x25c533) _0x13bb1f = _0x25c533 + ": " + _0x53feb6;
  }
  return _0x13bb1f = _0x13bb1f["replace"](/\s+/g, " ")[_0x44dcb5(290)](), _0x13bb1f;
}
function extractHighlights(_0x5ef5e2, { limit = 5 } = {}) {
  const _0x310de0 = _0x4b8502, _0x50d040 = String(_0x5ef5e2 || ""), _0x479695 = _0x50d040[_0x310de0(327)](/\r?\n/), _0x493e78 = [];
  let _0x256597 = ![];
  for (const _0x5b5d10 of _0x479695) {
    const _0x2ca58c = _0x5b5d10[_0x310de0(290)]();
    if (_0x2ca58c[_0x310de0(444)](_0x310de0(369))) {
      _0x256597 = !_0x256597;
      continue;
    }
    if (_0x256597) continue;
    if (!_0x2ca58c) continue;
    if (/^#+\s+/[_0x310de0(357)](_0x2ca58c)) continue;
    const _0x533872 = _0x2ca58c["match"](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x533872) {
      const _0x3eba2e = humanizeHighlight(_0x533872[2]);
      if (_0x3eba2e) _0x493e78["push"](_0x3eba2e);
    }
    if (_0x493e78[_0x310de0(314)] >= limit) break;
  }
  return _0x493e78[_0x310de0(285)](0, limit);
}
function collectHighlightsFromReleases(_0x3be801, _0x23d379, _0x5208e5, { limit = 10 } = {}) {
  const _0x5b6d63 = _0x4b8502, _0x422c69 = (Array[_0x5b6d63(431)](_0x3be801) ? _0x3be801 : [])[_0x5b6d63(394)]((_0x379613) => !(_0x379613 == null ? void 0 : _0x379613[_0x5b6d63(335)]))[_0x5b6d63(446)]((_0x2dc9a8) => ({ ..._0x2dc9a8, "tag_name": String((_0x2dc9a8 == null ? void 0 : _0x2dc9a8[_0x5b6d63(409)]) || "") }))[_0x5b6d63(394)]((_0x21de41) => /^v?\d+\.\d+\.\d+$/["test"](_0x21de41[_0x5b6d63(409)]))[_0x5b6d63(394)]((_0x4d8ac5) => compareVersions(_0x4d8ac5[_0x5b6d63(409)], _0x23d379) > 0)[_0x5b6d63(394)]((_0x2934cf) => compareVersions(_0x2934cf["tag_name"], _0x5208e5) <= 0)[_0x5b6d63(403)]((_0x39043f, _0x5d9b3a) => compareVersions(_0x39043f[_0x5b6d63(409)], _0x5d9b3a["tag_name"])), _0x24aee4 = [];
  for (const _0x1255a7 of _0x422c69) {
    const _0x22e199 = extractHighlights(_0x1255a7[_0x5b6d63(390)], { "limit": limit });
    for (const _0x5d508a of _0x22e199) {
      _0x24aee4["push"](_0x5d508a);
      if (_0x24aee4[_0x5b6d63(314)] >= limit) return _0x24aee4;
    }
  }
  return _0x24aee4["slice"](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x25741c) {
  return new Promise((_0x2f69bd) => setTimeout(_0x2f69bd, _0x25741c));
}
function normalizeDomain$1(_0x346731) {
  return String(_0x346731 || "default")["trim"]()["toLowerCase"]();
}
function makeError(_0x4230a6, _0x3c42d4 = {}) {
  const _0x411ac1 = _0x4b8502, _0x1f3e14 = new Error(_0x4230a6);
  return Object[_0x411ac1(325)](_0x1f3e14, _0x3c42d4), _0x1f3e14;
}
function buildInflightKey(_0x466ee2, _0x24b8ac, _0x5c8796, _0x35d38e) {
  if (_0x24b8ac) return _0x466ee2 + ":" + _0x24b8ac;
  return _0x466ee2 + ":" + _0x35d38e + ":" + _0x5c8796;
}
function getRateLimitStatus(_0x4038a3 = "default") {
  const _0x33f632 = _0x4b8502, _0x1b52a1 = normalizeDomain$1(_0x4038a3), _0x487b9f = Number(rateLimitByDomain[_0x33f632(310)](_0x1b52a1) || 0), _0x14a732 = Math[_0x33f632(360)](0, _0x487b9f - Date[_0x33f632(332)]());
  return { "blocked": _0x14a732 > 0, "remainingMs": _0x14a732, "blockedUntil": _0x487b9f };
}
async function parseResponse(_0x3d4866, _0xa6c0eb) {
  const _0x8fa69b = _0x4b8502;
  if (_0xa6c0eb === _0x8fa69b(393)) return _0x3d4866;
  if (_0xa6c0eb === _0x8fa69b(367)) return _0x3d4866[_0x8fa69b(367)]();
  if (_0xa6c0eb === _0x8fa69b(316)) return _0x3d4866[_0x8fa69b(316)]();
  if (_0xa6c0eb === _0x8fa69b(375)) return _0x3d4866[_0x8fa69b(375)]();
  return _0x3d4866[_0x8fa69b(436)]();
}
async function doRequest(_0x5bed1d, _0x1d2f57, _0x22281c = 0) {
  const _0xbd65e7 = _0x4b8502, { url: _0x103bbb, method = _0xbd65e7(422), headers: _0x2e239c, body: _0x3c0ff1, credentials = _0xbd65e7(330), signal: _0x58d9eb, responseType = "json", retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x1d2f57, _0x3d3c9c = getRateLimitStatus(_0x5bed1d);
  if (_0x3d3c9c[_0xbd65e7(366)]) throw makeError(_0xbd65e7(309) + Math[_0xbd65e7(292)](_0x3d3c9c[_0xbd65e7(426)] / 1e3), { "code": _0xbd65e7(419), "domain": _0x5bed1d, "remainingMs": _0x3d3c9c["remainingMs"], "status": 429 });
  const _0x388b47 = timeoutMs > 0 ? new AbortController() : null, _0x508f12 = _0x388b47 && timeoutMs > 0 ? setTimeout(() => _0x388b47[_0xbd65e7(320)](makeError(_0xbd65e7(408), { "code": _0xbd65e7(415), "domain": _0x5bed1d })), timeoutMs) : null, _0x30daa2 = _0x388b47 ? _0x388b47["signal"] : _0x58d9eb;
  try {
    const _0x59a6e5 = await fetch(_0x103bbb, { "method": method, "headers": _0x2e239c, "body": _0x3c0ff1, "credentials": credentials, "signal": _0x30daa2 });
    if (_0x59a6e5[_0xbd65e7(299)] === 429 && rateLimitCooldownMs > 0) {
      const _0x4f70a3 = (rateLimitHitCount[_0xbd65e7(310)](_0x5bed1d) || 0) + 1;
      rateLimitHitCount["set"](_0x5bed1d, _0x4f70a3);
      const _0x320e77 = _0x4f70a3 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0xbd65e7(412)](_0x5bed1d, Date[_0xbd65e7(332)]() + _0x320e77);
    }
    if (!_0x59a6e5["ok"]) {
      const _0x21df4f = _0x22281c < retries && retryStatuses["includes"](_0x59a6e5["status"]);
      if (_0x21df4f) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x5bed1d, _0x1d2f57, _0x22281c + 1);
      }
      throw makeError(_0xbd65e7(407) + _0x59a6e5[_0xbd65e7(299)], { "code": "HTTP_ERROR", "domain": _0x5bed1d, "status": _0x59a6e5[_0xbd65e7(299)] });
    }
    return rateLimitHitCount[_0xbd65e7(414)](_0x5bed1d), parseResponse(_0x59a6e5, responseType);
  } catch (_0x46b831) {
    const _0x162f06 = (_0x46b831 == null ? void 0 : _0x46b831["name"]) === _0xbd65e7(341), _0x56d38c = !_0x162f06 && _0x22281c < retries;
    if (_0x56d38c) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x5bed1d, _0x1d2f57, _0x22281c + 1);
    }
    if (_0x46b831 instanceof Error && _0x46b831[_0xbd65e7(420)]) throw _0x46b831;
    throw makeError(String((_0x46b831 == null ? void 0 : _0x46b831[_0xbd65e7(439)]) || _0x46b831 || _0xbd65e7(344)), { "code": _0x162f06 ? _0xbd65e7(294) : "NETWORK_ERROR", "domain": _0x5bed1d, "status": Number((_0x46b831 == null ? void 0 : _0x46b831[_0xbd65e7(299)]) || 0) || null, "cause": _0x46b831 });
  } finally {
    if (_0x508f12) clearTimeout(_0x508f12);
  }
}
async function request(_0x169952, _0x1c22c5) {
  const _0x153fd7 = _0x4b8502, _0x54d323 = normalizeDomain$1(_0x169952), _0x54dd7e = buildInflightKey(_0x54d323, _0x1c22c5 == null ? void 0 : _0x1c22c5["coalesceKey"], _0x1c22c5 == null ? void 0 : _0x1c22c5[_0x153fd7(308)], (_0x1c22c5 == null ? void 0 : _0x1c22c5[_0x153fd7(289)]) || _0x153fd7(422));
  if ((_0x1c22c5 == null ? void 0 : _0x1c22c5[_0x153fd7(365)]) && inflightByKey[_0x153fd7(445)](_0x54dd7e)) return inflightByKey["get"](_0x54dd7e);
  const _0x1fa5f0 = doRequest(_0x54d323, _0x1c22c5 || {})["finally"](() => {
    const _0x32a7c4 = _0x153fd7;
    inflightByKey[_0x32a7c4(414)](_0x54dd7e);
  });
  return (_0x1c22c5 == null ? void 0 : _0x1c22c5[_0x153fd7(365)]) && inflightByKey[_0x153fd7(412)](_0x54dd7e, _0x1fa5f0), _0x1fa5f0;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x4540c9) {
  const _0x339f70 = _0x4b8502, _0x2664eb = _0x4540c9 == null ? void 0 : _0x4540c9[_0x339f70(395)];
  STATE[_0x339f70(384)][_0x339f70(370)] = (_0x2664eb == null ? void 0 : _0x2664eb[_0x339f70(370)]) ?? null, STATE["auth"][_0x339f70(381)] = (_0x2664eb == null ? void 0 : _0x2664eb[_0x339f70(381)]) ?? null, STATE[_0x339f70(384)][_0x339f70(398)] = (_0x2664eb == null ? void 0 : _0x2664eb[_0x339f70(398)]) ?? null, STATE[_0x339f70(384)][_0x339f70(382)] = (_0x2664eb == null ? void 0 : _0x2664eb[_0x339f70(382)]) ?? null, STATE[_0x339f70(384)][_0x339f70(321)] = !![];
  const _0x41b00d = _0x4540c9 == null ? void 0 : _0x4540c9["levelInfo"];
  STATE[_0x339f70(378)]["level"] = (_0x41b00d == null ? void 0 : _0x41b00d[_0x339f70(339)]) ?? null, STATE["levelInfo"][_0x339f70(302)] = (_0x41b00d == null ? void 0 : _0x41b00d[_0x339f70(302)]) ?? null, STATE[_0x339f70(378)][_0x339f70(279)] = (_0x41b00d == null ? void 0 : _0x41b00d[_0x339f70(279)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x1294b7 = _0x4b8502;
  if (!force && STATE[_0x1294b7(384)][_0x1294b7(321)] || STATE[_0x1294b7(384)][_0x1294b7(442)]) return;
  STATE["auth"][_0x1294b7(442)] = !![], STATE[_0x1294b7(384)][_0x1294b7(280)] = null;
  try {
    const _0xe7c39 = await request("auth", { "url": _0x1294b7(429), "credentials": "include", "responseType": _0x1294b7(436), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0xe7c39);
  } catch (_0x3e51f7) {
    STATE[_0x1294b7(384)][_0x1294b7(280)] = String((_0x3e51f7 == null ? void 0 : _0x3e51f7[_0x1294b7(439)]) || _0x3e51f7);
  } finally {
    STATE["auth"][_0x1294b7(442)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set(["scoped", "company", _0x4b8502(399)]);
function normalizeScopeMode(_0x495015) {
  const _0x3af75f = _0x4b8502;
  if (VALID_SCOPE_MODES[_0x3af75f(445)](_0x495015)) return _0x495015;
  return _0x3af75f(338);
}
function numericOrNull(_0x2dc2e6) {
  const _0x493061 = _0x4b8502;
  if (_0x2dc2e6 === null || _0x2dc2e6 === void 0 || _0x2dc2e6 === "") return null;
  const _0x4a2013 = Number(_0x2dc2e6);
  return Number[_0x493061(385)](_0x4a2013) ? _0x4a2013 : null;
}
function resolveScopeSync(_0xa3a001 = _0x4b8502(338)) {
  var _a, _b;
  const _0x2d96d4 = _0x4b8502, _0x59d887 = normalizeScopeMode(_0xa3a001), _0x30e4f1 = numericOrNull((_a = STATE[_0x2d96d4(384)]) == null ? void 0 : _a["companyId"]), _0x874c0c = numericOrNull((_b = STATE[_0x2d96d4(384)]) == null ? void 0 : _b[_0x2d96d4(381)]);
  if (_0x59d887 === _0x2d96d4(399)) return { "mode": _0x59d887, "companyId": _0x30e4f1, "realmId": _0x874c0c, "hasScope": !![], "scopeKey": _0x2d96d4(399) };
  if (_0x59d887 === _0x2d96d4(437)) return { "mode": _0x59d887, "companyId": _0x30e4f1, "realmId": _0x874c0c, "hasScope": Number[_0x2d96d4(385)](_0x30e4f1), "scopeKey": Number["isFinite"](_0x30e4f1) ? String(_0x30e4f1) : null };
  const _0x563c8a = Number[_0x2d96d4(385)](_0x30e4f1) && Number[_0x2d96d4(385)](_0x874c0c);
  return { "mode": _0x59d887, "companyId": _0x30e4f1, "realmId": _0x874c0c, "hasScope": _0x563c8a, "scopeKey": _0x563c8a ? _0x30e4f1 + "-" + _0x874c0c : null };
}
async function resolveScope(_0x12f6ec = _0x4b8502(338), { refreshAuth = ![] } = {}) {
  const _0x330864 = normalizeScopeMode(_0x12f6ec);
  return refreshAuth && _0x330864 !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x330864);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  const _0x107d25 = _0x4b8502;
  try {
    return typeof localStorage !== _0x107d25(301) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x2f01aa = _0x4b8502;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome["storage"]) == null ? void 0 : _a[_0x2f01aa(291)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x30cc66) {
  const _0x2c3f1f = _0x4b8502;
  if (_0x30cc66 == null) return null;
  if (typeof _0x30cc66 === "object") return _0x30cc66;
  try {
    return JSON[_0x2c3f1f(326)](String(_0x30cc66));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x57103f, _0x436d14) {
  const _0x17cdc1 = _0x4b8502;
  if (_0x57103f === _0x17cdc1(416)) return _0x436d14;
  return JSON[_0x17cdc1(354)](_0x436d14);
}
function isEnvelopeValid(_0x299420) {
  const _0x33f102 = _0x4b8502;
  return Boolean(_0x299420 && typeof _0x299420 === "object" && Number[_0x33f102(385)](Number(_0x299420["v"])));
}
function isExpired(_0x56fe3c, _0x16393a = null, _0x3266c9 = Date[_0x4b8502(332)]()) {
  const _0x138bb4 = _0x4b8502, _0x28b350 = Number((_0x56fe3c == null ? void 0 : _0x56fe3c["ts"]) || 0), _0x4d7209 = Number(_0x56fe3c == null ? void 0 : _0x56fe3c[_0x138bb4(388)]), _0x1a54ba = Number[_0x138bb4(385)](_0x4d7209) ? _0x4d7209 : Number[_0x138bb4(385)](Number(_0x16393a)) ? Number(_0x16393a) : null;
  if (!Number["isFinite"](_0x28b350) || _0x28b350 <= 0) return ![];
  if (!Number[_0x138bb4(385)](_0x1a54ba) || _0x1a54ba <= 0) return ![];
  return _0x28b350 + _0x1a54ba < _0x3266c9;
}
function normalizeBackend(_0x4c67a9) {
  const _0x3cec20 = _0x4b8502;
  return _0x4c67a9 === _0x3cec20(416) ? _0x3cec20(416) : "local";
}
function normalizePrefix(_0x5888e4) {
  const _0x4aabca = _0x4b8502, _0x33b38a = String(_0x5888e4 || DEFAULT_PREFIX)[_0x4aabca(290)]();
  return _0x33b38a[_0x4aabca(314)] > 0 ? _0x33b38a : DEFAULT_PREFIX;
}
function normalizeDomain(_0x4be903) {
  const _0x2320e7 = _0x4b8502;
  return String(_0x4be903 || "unknown")[_0x2320e7(290)]()["replace"](/\s+/g, "-")["toLowerCase"]();
}
function buildStorageKey({ domain: _0x23a5de, version: _0x5d812c, scopeKey: _0x16dc5a, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x23a5de) + ":v" + Number(_0x5d812c) + ":" + _0x16dc5a;
}
async function chromeGet(_0x3ee226) {
  const _0x1465f6 = _0x4b8502;
  if (!hasChromeStorage()) return {};
  const _0x416e5c = chrome[_0x1465f6(312)][_0x1465f6(291)];
  try {
    const _0x414210 = _0x416e5c[_0x1465f6(310)](_0x3ee226);
    if (_0x414210 && typeof _0x414210[_0x1465f6(282)] === _0x1465f6(402)) return _0x414210;
  } catch {
  }
  return new Promise((_0x46773c) => {
    const _0x5756a1 = _0x1465f6;
    try {
      _0x416e5c[_0x5756a1(310)](_0x3ee226, (_0x27acb4) => _0x46773c(_0x27acb4 || {}));
    } catch {
      _0x46773c({});
    }
  });
}
async function chromeSet(_0x225cc6) {
  const _0x141b6f = _0x4b8502;
  if (!hasChromeStorage()) return ![];
  const _0x35b86 = chrome[_0x141b6f(312)][_0x141b6f(291)];
  try {
    const _0x389d9e = _0x35b86[_0x141b6f(412)](_0x225cc6);
    if (_0x389d9e && typeof _0x389d9e[_0x141b6f(282)] === _0x141b6f(402)) return await _0x389d9e, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x5d1098) => {
    const _0xa1d719 = _0x141b6f;
    try {
      _0x35b86[_0xa1d719(412)](_0x225cc6, () => _0x5d1098(!![]));
    } catch {
      _0x5d1098(![]);
    }
  });
}
async function chromeRemove(_0x1e41b5) {
  const _0x5ec695 = _0x4b8502;
  if (!hasChromeStorage()) return ![];
  const _0x32d1c7 = chrome[_0x5ec695(312)][_0x5ec695(291)];
  try {
    const _0x1d1974 = _0x32d1c7[_0x5ec695(288)](_0x1e41b5);
    if (_0x1d1974 && typeof _0x1d1974["then"] === _0x5ec695(402)) return await _0x1d1974, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x246c07) => {
    const _0x2191de = _0x5ec695;
    try {
      _0x32d1c7[_0x2191de(288)](_0x1e41b5, () => _0x246c07(!![]));
    } catch {
      _0x246c07(![]);
    }
  });
}
async function getRaw(_0x35ba4e, _0x519d90) {
  const _0x2ab54a = _0x4b8502, _0xe42bb9 = normalizeBackend(_0x35ba4e);
  if (_0xe42bb9 === _0x2ab54a(291)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x2ab54a(432)](_0x519d90);
    } catch {
      return null;
    }
  }
  const _0x30e482 = await chromeGet(_0x519d90);
  return (_0x30e482 == null ? void 0 : _0x30e482[_0x519d90]) ?? null;
}
function localGetItemSync(_0x4c5257) {
  const _0x15543b = _0x4b8502;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x15543b(432)](_0x4c5257);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x48e791, _0x7a2fac) {
  const _0xa8efb5 = _0x4b8502;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0xa8efb5(389)](_0x48e791, String(_0x7a2fac)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x1dd222) {
  const _0x546d09 = _0x4b8502;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x546d09(430)](_0x1dd222), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x4e7f94 = "") {
  const _0x7042eb = _0x4b8502;
  if (!hasLocalStorage()) return [];
  const _0x25b983 = [], _0x257ea3 = String(_0x4e7f94 || "");
  try {
    for (let _0x305eb9 = 0; _0x305eb9 < localStorage[_0x7042eb(314)]; _0x305eb9 += 1) {
      const _0x1019bd = localStorage[_0x7042eb(347)](_0x305eb9);
      if (!_0x1019bd || _0x257ea3 && !_0x1019bd[_0x7042eb(444)](_0x257ea3)) continue;
      _0x25b983[_0x7042eb(433)]({ "key": _0x1019bd, "value": localStorage[_0x7042eb(432)](_0x1019bd) });
    }
  } catch {
    return [];
  }
  return _0x25b983;
}
async function setRaw(_0x3107f9, _0x5ccb27, _0x575dd0) {
  const _0x1fc89f = _0x4b8502, _0xb79c69 = normalizeBackend(_0x3107f9);
  if (_0xb79c69 === _0x1fc89f(291)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x5ccb27, String(_0x575dd0)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x5ccb27]: _0x575dd0 });
}
async function removeRaw(_0x23988b, _0x226e6b) {
  const _0x2a8807 = _0x4b8502, _0x49a237 = normalizeBackend(_0x23988b);
  if (_0x49a237 === _0x2a8807(291)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x2a8807(430)](_0x226e6b), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x226e6b);
}
async function listByPrefix({ backend = "local", prefix = "" } = {}) {
  const _0x38e4b0 = _0x4b8502, _0x58b1a0 = normalizeBackend(backend), _0x457965 = String(prefix || "");
  if (_0x58b1a0 === "local") {
    if (!hasLocalStorage()) return [];
    const _0x26f19 = [];
    try {
      for (let _0x32d5f0 = 0; _0x32d5f0 < localStorage[_0x38e4b0(314)]; _0x32d5f0 += 1) {
        const _0x36b03d = localStorage[_0x38e4b0(347)](_0x32d5f0);
        if (!_0x36b03d || _0x457965 && !_0x36b03d[_0x38e4b0(444)](_0x457965)) continue;
        _0x26f19["push"]({ "key": _0x36b03d, "value": localStorage["getItem"](_0x36b03d) });
      }
    } catch {
      return [];
    }
    return _0x26f19;
  }
  const _0x340753 = await chromeGet(null);
  return Object[_0x38e4b0(397)](_0x340753 || {})[_0x38e4b0(394)](([_0x903a28]) => _0x457965 ? _0x903a28[_0x38e4b0(444)](_0x457965) : !![])[_0x38e4b0(446)](([_0x278eb1, _0x4c7d72]) => ({ "key": _0x278eb1, "value": _0x4c7d72 }));
}
async function get({ domain: _0x53f29c, version: _0x355901, scope = _0x4b8502(338), backend = _0x4b8502(291), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x46d9e2 = _0x4b8502, _0x3795e3 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x3795e3["hasScope"] || !_0x3795e3[_0x46d9e2(349)]) return null;
  const _0x275287 = buildStorageKey({ "domain": _0x53f29c, "version": _0x355901, "scopeKey": _0x3795e3[_0x46d9e2(349)], "prefix": prefix }), _0x4c31a1 = await getRaw(backend, _0x275287);
  if (_0x4c31a1 == null) return null;
  const _0x32a076 = parseJson(_0x4c31a1);
  if (!isEnvelopeValid(_0x32a076)) return await removeRaw(backend, _0x275287), null;
  const _0x564f2e = Number(_0x32a076["v"]);
  if (_0x564f2e !== Number(_0x355901)) return _0x564f2e < Number(_0x355901) && await removeRaw(backend, _0x275287), null;
  if (isExpired(_0x32a076, ttlMs)) return await removeRaw(backend, _0x275287), null;
  const _0x1c184b = _0x3795e3[_0x46d9e2(349)], _0x3440f3 = String(((_a = _0x32a076 == null ? void 0 : _0x32a076[_0x46d9e2(345)]) == null ? void 0 : _a["scopeKey"]) || "");
  if (_0x1c184b && _0x3440f3 && _0x1c184b !== _0x3440f3) return await removeRaw(backend, _0x275287), null;
  return _0x32a076["data"] ?? null;
}
async function set({ domain: _0x4c40f2, version: _0x25e499, scope = _0x4b8502(338), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x41a598 } = {}) {
  const _0x57d224 = _0x4b8502, _0x3ef964 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x3ef964[_0x57d224(318)] || !_0x3ef964[_0x57d224(349)]) return ![];
  const _0x49f4f5 = buildStorageKey({ "domain": _0x4c40f2, "version": _0x25e499, "scopeKey": _0x3ef964[_0x57d224(349)], "prefix": prefix }), _0x48ccf6 = { "v": Number(_0x25e499), "ts": Date[_0x57d224(332)](), "ttlMs": Number["isFinite"](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x3ef964["mode"], "scopeKey": _0x3ef964[_0x57d224(349)], "companyId": _0x3ef964[_0x57d224(370)], "realmId": _0x3ef964[_0x57d224(381)] }, "data": _0x41a598 };
  return setRaw(backend, _0x49f4f5, toStorageRaw(normalizeBackend(backend), _0x48ccf6));
}
async function remove({ domain: _0x4aa0e6, version: _0x1d7ea7, scope = _0x4b8502(338), backend = _0x4b8502(291), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x194a45 = _0x4b8502, _0x1f2fba = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x1f2fba[_0x194a45(318)] || !_0x1f2fba[_0x194a45(349)]) return ![];
  const _0x288536 = buildStorageKey({ "domain": _0x4aa0e6, "version": _0x1d7ea7, "scopeKey": _0x1f2fba[_0x194a45(349)], "prefix": prefix });
  return removeRaw(backend, _0x288536);
}
async function migrate({ domain: _0x94d96e, version: _0x33c124, scope = _0x4b8502(338), backend = _0x4b8502(291), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x1baa20, cleanupLegacy = !![] } = {}) {
  const _0x1cf830 = _0x4b8502, _0x456a3b = await get({ "domain": _0x94d96e, "version": _0x33c124, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x456a3b !== null && _0x456a3b !== void 0) return { "data": _0x456a3b, "migrated": ![] };
  if (typeof _0x1baa20 !== _0x1cf830(402)) return { "data": null, "migrated": ![] };
  const _0x343c70 = await _0x1baa20({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x1863f5 = _0x343c70 == null ? void 0 : _0x343c70[_0x1cf830(373)];
  if (_0x1863f5 === null || _0x1863f5 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x94d96e, "version": _0x33c124, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x1863f5 }), cleanupLegacy && typeof (_0x343c70 == null ? void 0 : _0x343c70[_0x1cf830(447)]) === _0x1cf830(402) && await _0x343c70[_0x1cf830(447)](), { "data": _0x1863f5, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = ["scx-buildings", _0x4b8502(440)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x453038) {
  const _0x4b4e80 = _0x4b8502, _0x3098a3 = String(_0x453038 || "")[_0x4b4e80(327)](":");
  if (_0x3098a3["length"] < 4) return null;
  if (_0x3098a3[0] !== _0x4b4e80(372)) return null;
  const _0x16782e = _0x3098a3[1], _0x2e08ae = _0x3098a3[2] || "";
  if (!_0x2e08ae[_0x4b4e80(444)]("v")) return null;
  const _0x5c2bb3 = Number(_0x2e08ae[_0x4b4e80(285)](1));
  if (!Number["isFinite"](_0x5c2bb3)) return null;
  return { "domain": _0x16782e, "version": _0x5c2bb3 };
}
async function cleanupVersionedEnvelopes(_0x3b7495) {
  const _0xb26e47 = _0x4b8502, _0x5d2822 = await storage[_0xb26e47(319)]({ "backend": _0x3b7495, "prefix": "scx:" });
  for (const _0x424e29 of _0x5d2822) {
    const _0x1d339c = parseDomainAndVersion(_0x424e29[_0xb26e47(347)]);
    if (!_0x1d339c) continue;
    const _0x15abad = Number(MIN_DOMAIN_VERSION[_0x1d339c["domain"]] || 1);
    if (_0x1d339c[_0xb26e47(334)] < _0x15abad) {
      await storage[_0xb26e47(284)](_0x3b7495, _0x424e29[_0xb26e47(347)]);
      continue;
    }
    if (_0x424e29[_0xb26e47(443)] == null) {
      await storage[_0xb26e47(284)](_0x3b7495, _0x424e29["key"]);
      continue;
    }
    const _0x39e306 = typeof _0x424e29[_0xb26e47(443)] === _0xb26e47(342) ? (() => {
      const _0x14d50e = _0xb26e47;
      try {
        return JSON[_0x14d50e(326)](_0x424e29[_0x14d50e(443)] || _0x14d50e(371));
      } catch {
        return null;
      }
    })() : _0x424e29[_0xb26e47(443)];
    if (!_0x39e306 || typeof _0x39e306 !== _0xb26e47(328) || !Number[_0xb26e47(385)](Number(_0x39e306["v"]))) {
      await storage["removeRaw"](_0x3b7495, _0x424e29["key"]);
      continue;
    }
    Number(_0x39e306["v"]) < _0x15abad && await storage[_0xb26e47(284)](_0x3b7495, _0x424e29[_0xb26e47(347)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x58eded = _0x4b8502;
  for (const _0x7f9126 of LEGACY_GLOBAL_KEYS) {
    await storage[_0x58eded(284)](_0x58eded(291), _0x7f9126), await storage[_0x58eded(284)](_0x58eded(416), _0x7f9126);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes("local"), await cleanupVersionedEnvelopes("chrome"), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x16feca, _0x867bed) {
  return new Promise((_0x1b09e8, _0x19404f) => {
    const _0x2571de = _0x1e9d;
    let _0xd9a083 = null;
    const _0x552ddd = (_0x267cc3, _0x423cb4, _0x334cd9) => {
      const _0x3877a4 = _0x1e9d;
      if (_0xd9a083 !== null && _0x423cb4[_0x3877a4(278)] && _0x423cb4[_0x3877a4(278)]["windowId"] !== _0xd9a083) return;
      _0x267cc3[_0x3877a4(329)] === _0x3877a4(383) && (_0x54c5fe(), _0x267cc3[_0x3877a4(280)] ? _0x19404f(new Error(_0x267cc3["error"])) : _0x267cc3[_0x3877a4(373)] && _0x267cc3[_0x3877a4(373)][_0x3877a4(314)] === 0 ? _0x1b09e8([]) : _0x1b09e8(_0x267cc3[_0x3877a4(373)]));
    };
    chrome["runtime"][_0x2571de(427)]["addListener"](_0x552ddd);
    const _0x12ca7d = setTimeout(() => {
      const _0x243f58 = _0x2571de;
      _0x54c5fe(), _0x19404f(new Error(_0x243f58(304)));
    }, 25e3), _0x54c5fe = () => {
      const _0x3cdf46 = _0x2571de;
      clearTimeout(_0x12ca7d), chrome[_0x3cdf46(441)][_0x3cdf46(427)][_0x3cdf46(401)](_0x552ddd), _0xd9a083 !== null && chrome[_0x3cdf46(391)]["remove"](_0xd9a083)[_0x3cdf46(322)](() => {
      });
    }, _0x144d79 = encodeURIComponent(JSON[_0x2571de(354)](_0x16feca)), _0x49bc96 = "https://cooperinc.xyz/retail?scx_params=" + _0x144d79;
    chrome[_0x2571de(391)]["create"]({ "url": _0x49bc96, "type": "popup", "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x2571de(282)]((_0x5d03e6) => {
      _0xd9a083 = _0x5d03e6["id"];
    })[_0x2571de(322)]((_0x427d37) => {
      _0x54c5fe(), _0x19404f(_0x427d37);
    });
  });
}
const DOMAIN = _0x4b8502(333), VERSION = 1;
async function getActiveAlarms() {
  const _0x5ed6eb = _0x4b8502, _0x14b55f = await storage[_0x5ed6eb(310)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x5ed6eb(399), "backend": "chrome" });
  return (_0x14b55f == null ? void 0 : _0x14b55f[_0x5ed6eb(417)]) || [];
}
async function saveActiveAlarms(_0x28f993) {
  const _0x43bd77 = _0x4b8502;
  await storage[_0x43bd77(412)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x43bd77(399), "backend": _0x43bd77(416), "data": { "alarms": _0x28f993 } });
}
let addAlarmQueue = Promise[_0x4b8502(356)]();
function addAlarm(_0xb90c29, _0x2cca0d, _0x55b731, _0x339bcc, _0x115a1e) {
  const _0xae090 = _0x4b8502;
  return addAlarmQueue = addAlarmQueue["then"](async () => {
    const _0x106230 = _0x1e9d, _0x5ef72b = await getActiveAlarms(), _0x170a2d = _0x5ef72b[_0x106230(394)]((_0x1b27b2) => {
      const _0xb1ac1f = _0x106230;
      if (_0x55b731 && _0x1b27b2[_0xb1ac1f(323)]) return _0x1b27b2[_0xb1ac1f(323)] !== _0x55b731;
      return _0x1b27b2[_0xb1ac1f(448)] !== _0xb90c29;
    });
    _0x170a2d[_0x106230(433)]({ "alarmId": _0xb90c29, "buildingName": _0x2cca0d, "buildingId": _0x55b731, "finishTimeMs": _0x339bcc, "translatedMessage": _0x115a1e }), await saveActiveAlarms(_0x170a2d);
  })["catch"](console[_0xae090(280)]), addAlarmQueue;
}
async function removeAlarm(_0x3eb312) {
  const _0x39210d = _0x4b8502, _0x17a8cb = await getActiveAlarms(), _0x197ee3 = _0x17a8cb[_0x39210d(394)]((_0x139be8) => _0x139be8[_0x39210d(448)] !== _0x3eb312);
  _0x17a8cb["length"] !== _0x197ee3[_0x39210d(314)] && await saveActiveAlarms(_0x197ee3);
}
async function clearExpiredAlarms() {
  const _0x362af5 = _0x4b8502, _0x42ad1e = await getActiveAlarms(), _0x205b23 = Date[_0x362af5(332)](), _0x3e000e = _0x42ad1e[_0x362af5(394)]((_0x223ae9) => _0x223ae9[_0x362af5(352)] > _0x205b23);
  _0x42ad1e[_0x362af5(314)] !== _0x3e000e[_0x362af5(314)] && await saveActiveAlarms(_0x3e000e);
}
const KEY_WHATS_NEW = _0x4b8502(298), KEY_LAST_MINOR = _0x4b8502(351), KEY_LAST_VERSION = _0x4b8502(421), STORAGE_DOMAIN_WHATS_NEW = "whats-new", STORAGE_DOMAIN_WHATS_NEW_META = _0x4b8502(355), STORAGE_VERSION = 1;
async function setWhatsNew(_0x284610) {
  const _0x461199 = _0x4b8502;
  await storage[_0x461199(412)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": _0x461199(399), "backend": _0x461199(416), "refreshAuth": ![], "data": _0x284610 }), await storage[_0x461199(412)]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x461199(399), "backend": _0x461199(416), "refreshAuth": ![], "data": { "minorKey": _0x284610["minorKey"], "lastVersion": _0x284610[_0x461199(313)] } }), await storage[_0x461199(284)]("chrome", KEY_WHATS_NEW), await storage[_0x461199(284)]("chrome", KEY_LAST_MINOR), await storage["removeRaw"]("chrome", KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x5d2b90 = _0x4b8502;
  return request(_0x5d2b90(405), { "url": _0x5d2b90(331), "credentials": _0x5d2b90(361), "responseType": _0x5d2b90(436), "retries": 1, "retryDelayMs": 300 });
}
function _0x1e9d(_0x390d7b, _0x32b102) {
  _0x390d7b = _0x390d7b - 277;
  const _0x31705a = _0x3170();
  let _0x1e9d51 = _0x31705a[_0x390d7b];
  if (_0x1e9d["VhMRyv"] === void 0) {
    var _0x2113cd = function(_0x415db1) {
      const _0x4c8a5a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x294499 = "", _0x3e3407 = "";
      for (let _0x206eb4 = 0, _0x4ae0df, _0x4cc600, _0x2233c5 = 0; _0x4cc600 = _0x415db1["charAt"](_0x2233c5++); ~_0x4cc600 && (_0x4ae0df = _0x206eb4 % 4 ? _0x4ae0df * 64 + _0x4cc600 : _0x4cc600, _0x206eb4++ % 4) ? _0x294499 += String["fromCharCode"](255 & _0x4ae0df >> (-2 * _0x206eb4 & 6)) : 0) {
        _0x4cc600 = _0x4c8a5a["indexOf"](_0x4cc600);
      }
      for (let _0x571e35 = 0, _0x1c71d5 = _0x294499["length"]; _0x571e35 < _0x1c71d5; _0x571e35++) {
        _0x3e3407 += "%" + ("00" + _0x294499["charCodeAt"](_0x571e35)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x3e3407);
    };
    _0x1e9d["VpBEqZ"] = _0x2113cd, _0x1e9d["XQlCce"] = {}, _0x1e9d["VhMRyv"] = !![];
  }
  const _0x58aed7 = _0x31705a[0], _0xb612dd = _0x390d7b + _0x58aed7, _0x29e93e = _0x1e9d["XQlCce"][_0xb612dd];
  return !_0x29e93e ? (_0x1e9d51 = _0x1e9d["VpBEqZ"](_0x1e9d51), _0x1e9d["XQlCce"][_0xb612dd] = _0x1e9d51) : _0x1e9d51 = _0x29e93e, _0x1e9d51;
}
chrome[_0x4b8502(441)][_0x4b8502(359)][_0x4b8502(277)](async (_0x12e3e6) => {
  const _0x171756 = _0x4b8502;
  await initializeDataPlatform();
  _0x12e3e6["reason"] === _0x171756(400) && await storage[_0x171756(412)]({ "domain": _0x171756(317), "version": 1, "scope": _0x171756(399), "backend": _0x171756(416), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x12e3e6[_0x171756(363)] === _0x171756(424) && _0x12e3e6[_0x171756(362)]) {
    const _0x48d23f = chrome[_0x171756(441)][_0x171756(386)]()["version"];
    if (_0x48d23f !== _0x12e3e6[_0x171756(362)]) try {
      const _0x3ad8c5 = await fetchAllReleases();
      let _0x29f3a6 = [];
      const _0x356cd8 = releasePageUrl(_0x48d23f);
      _0x3ad8c5 && Array[_0x171756(431)](_0x3ad8c5) && (_0x29f3a6 = collectHighlightsFromReleases(_0x3ad8c5, _0x12e3e6[_0x171756(362)], _0x48d23f)), await setWhatsNew({ "show": !![], "version": _0x48d23f, "url": _0x356cd8, "highlights": _0x29f3a6, "error": !_0x3ad8c5 || !Array["isArray"](_0x3ad8c5), "minorKey": minorKey(_0x48d23f), "lastVersion": _0x48d23f });
    } catch (_0x50a6d7) {
      console[_0x171756(280)]("Failed to fetch release notes:", _0x50a6d7), await setWhatsNew({ "show": !![], "version": _0x48d23f, "url": releasePageUrl(_0x48d23f), "highlights": [], "error": !![], "minorKey": minorKey(_0x48d23f), "lastVersion": _0x48d23f });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x4a4d84) {
  const _0x3154a7 = _0x4b8502, _0x47a242 = Date[_0x3154a7(332)]();
  if (cooperDataCache[_0x4a4d84] && cooperDataCacheTs[_0x4a4d84] && _0x47a242 - cooperDataCacheTs[_0x4a4d84] < COOPER_CACHE_TTL) return cooperDataCache[_0x4a4d84];
  const _0x2bcce9 = "r" + (_0x4a4d84 + 1), _0x2b0a28 = await fetch("https://cooperinc.xyz/api/initial-data?realm=" + _0x2bcce9);
  if (!_0x2b0a28["ok"]) throw new Error(_0x3154a7(379) + _0x2b0a28["status"]);
  const _0x407f26 = await _0x2b0a28["json"]();
  return cooperDataCache[_0x4a4d84] = _0x407f26, cooperDataCacheTs[_0x4a4d84] = _0x47a242, _0x407f26;
}
chrome["runtime"][_0x4b8502(427)]["addListener"]((_0x380cff, _0x3d048c, _0x478bfb) => {
  const _0x17d34c = _0x4b8502;
  if (_0x380cff[_0x17d34c(329)] === "FETCH_COOPER_DATA") return fetchCooperData(_0x380cff["realmId"])["then"]((_0x9ccbb) => _0x478bfb({ "success": !![], "data": _0x9ccbb }))[_0x17d34c(322)]((_0x72ac32) => _0x478bfb({ "success": ![], "error": _0x72ac32[_0x17d34c(439)] })), !![];
  if (_0x380cff[_0x17d34c(329)] === _0x17d34c(336)) {
    const _0x20e839 = _0x380cff["realmId"], _0x897373 = _0x17d34c(425) + _0x20e839 + _0x17d34c(306);
    return request("simcotools", { "url": _0x897373, "method": _0x17d34c(422), "credentials": "omit", "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x17d34c(282)]((_0x2542d2) => _0x478bfb({ "success": !![], "data": _0x2542d2 }))[_0x17d34c(322)]((_0x1fa2b8) => _0x478bfb({ "success": ![], "error": _0x1fa2b8[_0x17d34c(439)] || String(_0x1fa2b8) })), !![];
  }
  if (_0x380cff[_0x17d34c(329)] === "FETCH_SIMCOTOOLS_EXECUTIVES") {
    const { realmId: _0x380a6d, queryParams: _0x47fc2a, headers: _0x32cfed } = _0x380cff, _0xe3d4b5 = _0x17d34c(425) + _0x380a6d + _0x17d34c(297) + _0x47fc2a;
    return request("simcotools", { "url": _0xe3d4b5, "method": _0x17d34c(422), "headers": _0x32cfed, "credentials": _0x17d34c(361), "responseType": _0x17d34c(436), "retries": 2, "retryDelayMs": 1e3 })[_0x17d34c(282)]((_0x825679) => _0x478bfb({ "success": !![], "data": _0x825679 }))[_0x17d34c(322)]((_0x453d90) => _0x478bfb({ "success": ![], "error": _0x453d90[_0x17d34c(439)] || String(_0x453d90) })), !![];
  }
  if (_0x380cff["type"] === "FETCH_SIMCOTOOLS_STATS_BUILDINGS") {
    const { realmId: _0x47249c, headers: _0x27110d } = _0x380cff, _0x2aba59 = _0x17d34c(425) + _0x47249c + _0x17d34c(300);
    return request(_0x17d34c(404), { "url": _0x2aba59, "method": _0x17d34c(422), "headers": _0x27110d, "credentials": _0x17d34c(361), "responseType": _0x17d34c(436), "retries": 2, "retryDelayMs": 1e3 })[_0x17d34c(282)]((_0x474277) => _0x478bfb({ "success": !![], "data": _0x474277 }))[_0x17d34c(322)]((_0x59ec7d) => _0x478bfb({ "success": ![], "error": _0x59ec7d[_0x17d34c(439)] || String(_0x59ec7d) })), !![];
  }
  if (_0x380cff["type"] === _0x17d34c(392)) {
    const { realmId: _0x223669, headers: _0x5f4718 } = _0x380cff, _0x27043c = _0x17d34c(425) + _0x223669 + "/phases";
    return request(_0x17d34c(404), { "url": _0x27043c, "method": _0x17d34c(422), "headers": _0x5f4718, "credentials": _0x17d34c(361), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x17d34c(282)]((_0x1612d1) => _0x478bfb({ "success": !![], "data": _0x1612d1 }))["catch"]((_0xd728fd) => _0x478bfb({ "success": ![], "error": _0xd728fd[_0x17d34c(439)] || String(_0xd728fd) })), !![];
  }
  if (_0x380cff["type"] === _0x17d34c(364)) return scrapeCooperRetail(_0x380cff[_0x17d34c(423)])["then"]((_0xf9dda) => _0x478bfb({ "success": !![], "data": _0xf9dda }))["catch"]((_0x513b15) => _0x478bfb({ "success": ![], "error": _0x513b15[_0x17d34c(439)] })), !![];
  if (_0x380cff[_0x17d34c(329)] === "SET_BUILDING_ALARM") {
    const { buildingName: _0x523ca4, buildingId: _0x430ba3, finishTimeMs: _0x289a7c, translatedMessage: _0x225d9f } = _0x380cff[_0x17d34c(373)], _0x2f1ff8 = _0x17d34c(410) + Date[_0x17d34c(332)]() + "-" + Math[_0x17d34c(315)](Math[_0x17d34c(387)]() * 1e3);
    return chrome[_0x17d34c(417)][_0x17d34c(368)](_0x2f1ff8, { "when": _0x289a7c }), addAlarm(_0x2f1ff8, _0x523ca4, _0x430ba3, _0x289a7c, _0x225d9f)[_0x17d34c(322)](console[_0x17d34c(280)]), _0x478bfb({ "success": !![], "alarmId": _0x2f1ff8 }), !![];
  }
  if (_0x380cff[_0x17d34c(329)] === _0x17d34c(418)) {
    const { alarmId: _0x3d053e } = _0x380cff["data"];
    return chrome[_0x17d34c(417)]["clear"](_0x3d053e), removeAlarm(_0x3d053e)[_0x17d34c(322)](console["error"]), _0x478bfb({ "success": !![] }), !![];
  }
}), chrome[_0x4b8502(417)][_0x4b8502(353)][_0x4b8502(277)](async (_0x3a642e) => {
  const _0x409964 = _0x4b8502;
  if (_0x3a642e[_0x409964(293)][_0x409964(444)](_0x409964(410))) {
    const _0x1be855 = await getActiveAlarms(), _0x5ec8d3 = _0x1be855["find"]((_0x3fb98e) => _0x3fb98e[_0x409964(448)] === _0x3a642e[_0x409964(293)]), _0xb55e2a = _0x5ec8d3 ? _0x5ec8d3[_0x409964(296)] : "A building", _0x4c7008 = (_0x5ec8d3 == null ? void 0 : _0x5ec8d3[_0x409964(374)]) || _0xb55e2a + _0x409964(305);
    chrome[_0x409964(434)][_0x409964(368)](_0x3a642e["name"], { "type": _0x409964(358), "iconUrl": _0x409964(311), "title": "SimCo Manager", "message": _0x4c7008, "priority": 2 }), await removeAlarm(_0x3a642e[_0x409964(293)]);
  }
}), chrome[_0x4b8502(417)][_0x4b8502(368)](_0x4b8502(340), { "periodInMinutes": 60 }), chrome["alarms"][_0x4b8502(353)][_0x4b8502(277)]((_0x489079) => {
  const _0x54606a = _0x4b8502;
  _0x489079[_0x54606a(293)] === _0x54606a(340) && clearExpiredAlarms()[_0x54606a(322)](console[_0x54606a(280)]);
});
