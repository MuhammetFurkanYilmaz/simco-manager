const _0x4c5e87 = _0x9bed;
(function(_0x4cb7f2, _0x568d91) {
  const _0x3b1587 = _0x9bed, _0x152d18 = _0x4cb7f2();
  while (!![]) {
    try {
      const _0x4be47c = parseInt(_0x3b1587(417)) / 1 * (-parseInt(_0x3b1587(520)) / 2) + -parseInt(_0x3b1587(406)) / 3 + -parseInt(_0x3b1587(524)) / 4 * (-parseInt(_0x3b1587(527)) / 5) + -parseInt(_0x3b1587(466)) / 6 + -parseInt(_0x3b1587(410)) / 7 * (parseInt(_0x3b1587(427)) / 8) + -parseInt(_0x3b1587(453)) / 9 + parseInt(_0x3b1587(495)) / 10;
      if (_0x4be47c === _0x568d91) break;
      else _0x152d18["push"](_0x152d18["shift"]());
    } catch (_0x4cbd7f) {
      _0x152d18["push"](_0x152d18["shift"]());
    }
  }
})(_0x4d32, 362862);
const REPO_OWNER = _0x4c5e87(467), REPO_NAME = _0x4c5e87(505);
function parseVersion(_0x580207) {
  const _0x146b99 = _0x4c5e87, _0x35861a = String(_0x580207 || "")[_0x146b99(487)](/^v/i, "")["split"](".");
  return [Number(_0x35861a[0] || 0), Number(_0x35861a[1] || 0), Number(_0x35861a[2] || 0)];
}
function compareVersions(_0x5ec4fb, _0x29cf9b) {
  const [_0x4c436f, _0x18017f, _0x33d694] = parseVersion(_0x5ec4fb), [_0x457a31, _0x4c0e31, _0x4653f5] = parseVersion(_0x29cf9b);
  if (_0x4c436f !== _0x457a31) return _0x4c436f - _0x457a31;
  if (_0x18017f !== _0x4c0e31) return _0x18017f - _0x4c0e31;
  return _0x33d694 - _0x4653f5;
}
function minorKey(_0x1323cd) {
  const _0x2eccc8 = String(_0x1323cd || "")["split"]("."), _0x1eed08 = _0x2eccc8[0] || "0", _0x294309 = _0x2eccc8[1] || "0";
  return _0x1eed08 + "." + _0x294309;
}
function releasePageUrl(_0x3d6711) {
  const _0x3491fe = _0x4c5e87, _0x283d8a = String(_0x3d6711 || "")[_0x3491fe(456)]();
  return _0x3491fe(370) + REPO_OWNER + "/" + REPO_NAME + _0x3491fe(528) + encodeURIComponent(_0x283d8a);
}
function stripMarkdown(_0x5a24f2) {
  const _0x3df880 = _0x4c5e87;
  let _0x37eb4e = String(_0x5a24f2 || "");
  return _0x37eb4e = _0x37eb4e[_0x3df880(487)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x37eb4e = _0x37eb4e[_0x3df880(487)](/https?:\/\/\S+/gi, ""), _0x37eb4e = _0x37eb4e[_0x3df880(487)](/[`*_>#]/g, ""), _0x37eb4e = _0x37eb4e[_0x3df880(487)](/\s+/g, " ")[_0x3df880(456)](), _0x37eb4e;
}
function _0x9bed(_0x19aa8e, _0x2a1cd8) {
  _0x19aa8e = _0x19aa8e - 366;
  const _0x4d32ae = _0x4d32();
  let _0x9bed8b = _0x4d32ae[_0x19aa8e];
  if (_0x9bed["OkSVuQ"] === void 0) {
    var _0x3d5cf9 = function(_0x1cbec7) {
      const _0xd6db3f = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x580207 = "", _0x35861a = "";
      for (let _0x5ec4fb = 0, _0x29cf9b, _0x4c436f, _0x18017f = 0; _0x4c436f = _0x1cbec7["charAt"](_0x18017f++); ~_0x4c436f && (_0x29cf9b = _0x5ec4fb % 4 ? _0x29cf9b * 64 + _0x4c436f : _0x4c436f, _0x5ec4fb++ % 4) ? _0x580207 += String["fromCharCode"](255 & _0x29cf9b >> (-2 * _0x5ec4fb & 6)) : 0) {
        _0x4c436f = _0xd6db3f["indexOf"](_0x4c436f);
      }
      for (let _0x33d694 = 0, _0x457a31 = _0x580207["length"]; _0x33d694 < _0x457a31; _0x33d694++) {
        _0x35861a += "%" + ("00" + _0x580207["charCodeAt"](_0x33d694)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x35861a);
    };
    _0x9bed["kTVkNN"] = _0x3d5cf9, _0x9bed["nriJzK"] = {}, _0x9bed["OkSVuQ"] = !![];
  }
  const _0x241532 = _0x4d32ae[0], _0x398b62 = _0x19aa8e + _0x241532, _0x5a9e8a = _0x9bed["nriJzK"][_0x398b62];
  return !_0x5a9e8a ? (_0x9bed8b = _0x9bed["kTVkNN"](_0x9bed8b), _0x9bed["nriJzK"][_0x398b62] = _0x9bed8b) : _0x9bed8b = _0x5a9e8a, _0x9bed8b;
}
function humanizeHighlight(_0x226b1f) {
  const _0x9c26bc = _0x4c5e87;
  let _0x183de5 = stripMarkdown(_0x226b1f);
  _0x183de5 = _0x183de5["replace"](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x183de5 = _0x183de5[_0x9c26bc(487)](/\s+in\s*$/i, ""), _0x183de5 = _0x183de5[_0x9c26bc(487)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x47ad50 = _0x183de5[_0x9c26bc(387)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x47ad50) {
    const _0x28f5c7 = _0x47ad50[1][_0x9c26bc(445)](), _0x2d318b = _0x47ad50[3], _0x5a0962 = _0x28f5c7 === _0x9c26bc(529) ? _0x9c26bc(388) : _0x28f5c7 === _0x9c26bc(500) ? _0x9c26bc(533) : _0x28f5c7 === _0x9c26bc(432) ? _0x9c26bc(401) : _0x28f5c7 === "docs" ? _0x9c26bc(435) : null;
    if (_0x5a0962) _0x183de5 = _0x5a0962 + ": " + _0x2d318b;
  }
  return _0x183de5 = _0x183de5[_0x9c26bc(487)](/\s+/g, " ")[_0x9c26bc(456)](), _0x183de5;
}
function extractHighlights(_0x374c6b, { limit = 5 } = {}) {
  const _0x219a63 = _0x4c5e87, _0x2e0f26 = String(_0x374c6b || ""), _0x57f9e8 = _0x2e0f26[_0x219a63(504)](/\r?\n/), _0x3f00d7 = [];
  let _0xaa9596 = ![];
  for (const _0x38a5e5 of _0x57f9e8) {
    const _0x4034d6 = _0x38a5e5[_0x219a63(456)]();
    if (_0x4034d6[_0x219a63(450)](_0x219a63(447))) {
      _0xaa9596 = !_0xaa9596;
      continue;
    }
    if (_0xaa9596) continue;
    if (!_0x4034d6) continue;
    if (/^#+\s+/[_0x219a63(518)](_0x4034d6)) continue;
    const _0x2e92cd = _0x4034d6[_0x219a63(387)](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x2e92cd) {
      const _0x39336d = humanizeHighlight(_0x2e92cd[2]);
      if (_0x39336d) _0x3f00d7[_0x219a63(390)](_0x39336d);
    }
    if (_0x3f00d7[_0x219a63(530)] >= limit) break;
  }
  return _0x3f00d7[_0x219a63(368)](0, limit);
}
function collectHighlightsFromReleases(_0x1afc43, _0x4d762d, _0xe42b91, { limit = 10 } = {}) {
  const _0x37fb1d = _0x4c5e87, _0x173022 = (Array[_0x37fb1d(431)](_0x1afc43) ? _0x1afc43 : [])[_0x37fb1d(422)]((_0x58dd27) => !(_0x58dd27 == null ? void 0 : _0x58dd27[_0x37fb1d(376)]))[_0x37fb1d(405)]((_0xc3253d) => ({ ..._0xc3253d, "tag_name": String((_0xc3253d == null ? void 0 : _0xc3253d[_0x37fb1d(434)]) || "") }))[_0x37fb1d(422)]((_0x51fc96) => /^v?\d+\.\d+\.\d+$/["test"](_0x51fc96[_0x37fb1d(434)]))["filter"]((_0x4f0f95) => compareVersions(_0x4f0f95[_0x37fb1d(434)], _0x4d762d) > 0)[_0x37fb1d(422)]((_0x1a6211) => compareVersions(_0x1a6211[_0x37fb1d(434)], _0xe42b91) <= 0)["sort"]((_0x40a42c, _0x35b339) => compareVersions(_0x40a42c["tag_name"], _0x35b339[_0x37fb1d(434)])), _0x7bd9c2 = [];
  for (const _0x19385a of _0x173022) {
    const _0x11aea2 = extractHighlights(_0x19385a[_0x37fb1d(385)], { "limit": limit });
    for (const _0x8e2ff of _0x11aea2) {
      _0x7bd9c2[_0x37fb1d(390)](_0x8e2ff);
      if (_0x7bd9c2[_0x37fb1d(530)] >= limit) return _0x7bd9c2;
    }
  }
  return _0x7bd9c2[_0x37fb1d(368)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x134380) {
  return new Promise((_0x68d279) => setTimeout(_0x68d279, _0x134380));
}
function normalizeDomain$1(_0x3ee8ae) {
  const _0x14efed = _0x4c5e87;
  return String(_0x3ee8ae || _0x14efed(429))[_0x14efed(456)]()[_0x14efed(445)]();
}
function makeError(_0x11d513, _0x23ec26 = {}) {
  const _0x4c8583 = _0x4c5e87, _0x1100b2 = new Error(_0x11d513);
  return Object[_0x4c8583(439)](_0x1100b2, _0x23ec26), _0x1100b2;
}
function _0x4d32() {
  const _0x22c16a = ["Bwf0y2G", "tMv3", "Cg9WDxa", "ChvZAa", "ywXHCM1jza", "CMvTB3zL", "qwjVCNrfCNjVCG", "DxbKyxrL", "y29TCgfUEq", "CMvHC29U", "l2v4zwn1DgL2zxm/", "C2n4lwfSyxjTlq", "z2v0twfUAwzLC3q", "veLnru9vva", "sw1WCM92zwq", "ywrKtgLZDgvUzxi", "rKvuq0HFu0Lnq09ut09mu19tvefuu19cvuLmreLor1m", "Dw5RBM93BG", "BwfW", "nZa5nJa1rLHtuhzz", "tKvuv09ss19fuLjpuG", "y29Kzq", "C2v0", "mJGWn0DLsuvPvW", "zw50CMLLCW", "ANnVBG", "y2XLyw51Ca", "Bgv2zwW", "r0vu", "uMvXDwvZDcbMywLSzwq", "mtL3uKzJu2m", "yxjYyxLcDwzMzxi", "ChjVzhvJDgLVBK1VzgLMAwvY", "BwLUB3jlzxK", "y2HYB21L", "zMLSDgvY", "y3jLyxrL", "AwnVBNmVndGUCg5N", "z2v0", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "mZm2ofbhshb1Bq", "u0nsqvbfx0npt1bfuL9srvrbsuW", "zgvMyxvSDa", "C3rYAw5N", "AxnbCNjHEq", "CgvYzG", "z2v0sxrLBq", "DgfNx25HBwu", "vxbKyxrLza", "D2vSy29Tzs1TzxnZywDL", "A2v5", "zMLUywXSEq", "yxnZAwDU", "B25bBgfYBq", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "C2n4oG", "zNvUy3rPB24", "BM90AwzPy2f0Aw9UCW", "Dg9mB3DLCKnHC2u", "zMLUza", "ygbG", "C2n4lxDOyxrZlw5LDW", "CMvTB3zLtgLZDgvUzxi", "C3rHCNrZv2L0Aa", "l3bOyxnLCW", "u2LTq28GtwfUywDLCG", "nJuXnZeZng9YExDTsW", "ywXHCM1Z", "Aw5ZDgfSBa", "DhjPBq", "Bg9JywW", "C2nVCgvK", "C2LTy290B29SCW", "ChjLDMLVDxnwzxjZAw9U", "yMfZAwm", "ywjVCNq", "CMvZCg9UC2u", "CgfYC2u", "yNvPBgrPBMDoyw1L", "nde1nZG4nKjdr05ZEG", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "yMXVy2TLza", "C2v0sxrLBq", "Bw9Kzq", "yMXVyG", "BNvSBa", "BM93", "zgvSzxrL", "B2jQzwn0", "CMvZB2X2zq", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "zxjYB3i", "Aw5JBhvKzxm", "z2XVyMfS", "BgLZDej5uhjLzML4", "DgHLBG", "yNvPBgrPBMCTywXHCM1Z", "C2nVCgvlzxK", "sfruuca", "CMvWBgfJzq", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "C3rHDhvZ", "CMvTB3zLuMf3", "CMvTywLUAw5Ntxm", "Bwv0Ag9K", "BMfTzq", "DhLWzq", "mJe5oty0ntbwvhzSsLG", "BwvZC2fNzq", "CgfYyw1Z", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "C3rVCMfNzq", "zML4", "DMvYC2LVBG", "y2vPBa", "C2n4lwnSzwfUDxaTywXHCM1Z", "C3bSAxq", "C2LTy28TBwfUywDLCG", "DgfI", "DMfSDwu", "Bg9HzgvK", "CMvTB3zLsxrLBq", "uKfurv9msu1jvf9dt09mre9xtJO", "DhjHBNnSyxrLze1LC3nHz2u", "Bg9HzgLUzW", "B25nzxnZywDL", "B21PDa", "Dgv4Da", "D2LUzg93CW", "AgfZu2nVCgu", "DgvZDa", "q29VCgvYiefqssbLCNjVCJOG", "ndu0otbnEw9uDM8", "rKvuq0HFu0Lnq09ut09mu19fwevdvvrjvKvt", "C2n4", "B25jBNn0ywXSzwq", "mZeYngr2AuTIva", "yNvPBgrPBMDjza", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "mJy3nujdufDcyW", "l3jLBgvHC2vZl3rHzY92", "zMvHDa", "BgvUz3rO", "y29HBgvZy2u", "zgf0yq", "rML4zwq", "yxv0Aa", "D2HHDhmTBMv3lw1LDge", "l3n0yxrZl2j1AwXKAw5NCW", "zg9TywLU", "Bwf4", "C2XPy2u", "CMvHBg1jza", "Ahr0Chm6lY9NAxrODwiUy29TlW", "Bgv2zwXjBMzV", "yxv0AenVBxbHBNK", "zxHWzxjPzw5Jzq", "C3rYAw5NAwz5", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "ChjLCMvSzwfZzq", "C2nVCgu", "CNvUDgLTzq", "Aw5JBhvKzq", "AxngAw5PDgu", "qujpuLrfra", "y29HBgvZy2vlzxK", "rKvuq0HFq09puevsx0rbvee", "y29TCgfUEuLK", "yM9KEq", "y2f0y2G"];
  _0x4d32 = function() {
    return _0x22c16a;
  };
  return _0x4d32();
}
function buildInflightKey(_0x261122, _0x40581e, _0x53e763, _0x59e7b1) {
  if (_0x40581e) return _0x261122 + ":" + _0x40581e;
  return _0x261122 + ":" + _0x59e7b1 + ":" + _0x53e763;
}
function getRateLimitStatus(_0x5e9dda = "default") {
  const _0x596879 = _0x4c5e87, _0x10082b = normalizeDomain$1(_0x5e9dda), _0xe24ad1 = Number(rateLimitByDomain[_0x596879(425)](_0x10082b) || 0), _0x4cd37e = Math[_0x596879(367)](0, _0xe24ad1 - Date[_0x596879(474)]());
  return { "blocked": _0x4cd37e > 0, "remainingMs": _0x4cd37e, "blockedUntil": _0xe24ad1 };
}
async function parseResponse(_0x31bf6a, _0x1a6cd3) {
  const _0x2a947d = _0x4c5e87;
  if (_0x1a6cd3 === _0x2a947d(463)) return _0x31bf6a;
  if (_0x1a6cd3 === _0x2a947d(515)) return _0x31bf6a[_0x2a947d(515)]();
  if (_0x1a6cd3 === _0x2a947d(472)) return _0x31bf6a[_0x2a947d(472)]();
  if (_0x1a6cd3 === _0x2a947d(418)) return _0x31bf6a[_0x2a947d(418)]();
  return _0x31bf6a["json"]();
}
async function doRequest(_0x538c76, _0x262583, _0x50eeb8 = 0) {
  const _0x2a17dc = _0x4c5e87, { url: _0x2910ec, method = _0x2a17dc(415), headers: _0x3a9679, body: _0x32466c, credentials = "include", signal: _0x1c3ecc, responseType = _0x2a17dc(412), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x262583, _0x40c53a = getRateLimitStatus(_0x538c76);
  if (_0x40c53a[_0x2a17dc(469)]) throw makeError(_0x2a17dc(510) + Math[_0x2a17dc(502)](_0x40c53a[_0x2a17dc(491)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x538c76, "remainingMs": _0x40c53a["remainingMs"], "status": 429 });
  const _0xdc88c3 = timeoutMs > 0 ? new AbortController() : null, _0x551f8d = _0xdc88c3 && timeoutMs > 0 ? setTimeout(() => _0xdc88c3[_0x2a17dc(462)](makeError("Request timeout", { "code": _0x2a17dc(400), "domain": _0x538c76 })), timeoutMs) : null, _0x86d633 = _0xdc88c3 ? _0xdc88c3["signal"] : _0x1c3ecc;
  try {
    const _0x121902 = await fetch(_0x2910ec, { "method": method, "headers": _0x3a9679, "body": _0x32466c, "credentials": credentials, "signal": _0x86d633 });
    if (_0x121902[_0x2a17dc(489)] === 429 && rateLimitCooldownMs > 0) {
      const _0x154ff4 = (rateLimitHitCount["get"](_0x538c76) || 0) + 1;
      rateLimitHitCount[_0x2a17dc(409)](_0x538c76, _0x154ff4);
      const _0x2e0fb6 = _0x154ff4 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x2a17dc(409)](_0x538c76, Date[_0x2a17dc(474)]() + _0x2e0fb6);
    }
    if (!_0x121902["ok"]) {
      const _0x38138f = _0x50eeb8 < retries && retryStatuses[_0x2a17dc(480)](_0x121902[_0x2a17dc(489)]);
      if (_0x38138f) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x538c76, _0x262583, _0x50eeb8 + 1);
      }
      throw makeError(_0x2a17dc(486) + _0x121902[_0x2a17dc(489)], { "code": "HTTP_ERROR", "domain": _0x538c76, "status": _0x121902["status"] });
    }
    return rateLimitHitCount[_0x2a17dc(475)](_0x538c76), parseResponse(_0x121902, responseType);
  } catch (_0x542c3b) {
    const _0x5e9c3d = (_0x542c3b == null ? void 0 : _0x542c3b[_0x2a17dc(493)]) === _0x2a17dc(393), _0x5c7ab4 = !_0x5e9c3d && _0x50eeb8 < retries;
    if (_0x5c7ab4) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x538c76, _0x262583, _0x50eeb8 + 1);
    }
    if (_0x542c3b instanceof Error && _0x542c3b[_0x2a17dc(408)]) throw _0x542c3b;
    throw makeError(String((_0x542c3b == null ? void 0 : _0x542c3b[_0x2a17dc(496)]) || _0x542c3b || _0x2a17dc(416)), { "code": _0x5e9c3d ? _0x2a17dc(381) : _0x2a17dc(407), "domain": _0x538c76, "status": Number((_0x542c3b == null ? void 0 : _0x542c3b["status"]) || 0) || null, "cause": _0x542c3b });
  } finally {
    if (_0x551f8d) clearTimeout(_0x551f8d);
  }
}
async function request(_0x26e8fc, _0x10e7e7) {
  const _0x45fb38 = _0x4c5e87, _0x2974b6 = normalizeDomain$1(_0x26e8fc), _0x5bdc95 = buildInflightKey(_0x2974b6, _0x10e7e7 == null ? void 0 : _0x10e7e7[_0x45fb38(382)], _0x10e7e7 == null ? void 0 : _0x10e7e7["url"], (_0x10e7e7 == null ? void 0 : _0x10e7e7[_0x45fb38(492)]) || _0x45fb38(415));
  if ((_0x10e7e7 == null ? void 0 : _0x10e7e7[_0x45fb38(531)]) && inflightByKey["has"](_0x5bdc95)) return inflightByKey[_0x45fb38(425)](_0x5bdc95);
  const _0x511405 = doRequest(_0x2974b6, _0x10e7e7 || {})[_0x45fb38(438)](() => {
    const _0x54dcfe = _0x45fb38;
    inflightByKey[_0x54dcfe(475)](_0x5bdc95);
  });
  return (_0x10e7e7 == null ? void 0 : _0x10e7e7[_0x45fb38(531)]) && inflightByKey[_0x45fb38(409)](_0x5bdc95, _0x511405), _0x511405;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x4db165) {
  const _0x356987 = _0x4c5e87, _0x376af1 = _0x4db165 == null ? void 0 : _0x4db165[_0x356987(372)];
  STATE[_0x356987(534)][_0x356987(384)] = (_0x376af1 == null ? void 0 : _0x376af1[_0x356987(384)]) ?? null, STATE[_0x356987(534)][_0x356987(369)] = (_0x376af1 == null ? void 0 : _0x376af1[_0x356987(369)]) ?? null, STATE[_0x356987(534)][_0x356987(419)] = (_0x376af1 == null ? void 0 : _0x376af1[_0x356987(419)]) ?? null, STATE[_0x356987(534)]["salesModifier"] = (_0x376af1 == null ? void 0 : _0x376af1["salesModifier"]) ?? null, STATE[_0x356987(534)][_0x356987(508)] = !![];
  const _0x28b363 = _0x4db165 == null ? void 0 : _0x4db165[_0x356987(371)];
  STATE[_0x356987(371)][_0x356987(414)] = (_0x28b363 == null ? void 0 : _0x28b363[_0x356987(414)]) ?? null, STATE[_0x356987(371)][_0x356987(373)] = (_0x28b363 == null ? void 0 : _0x28b363["experience"]) ?? null, STATE[_0x356987(371)][_0x356987(375)] = (_0x28b363 == null ? void 0 : _0x28b363[_0x356987(375)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x1923b4 = _0x4c5e87;
  if (!force && STATE["auth"][_0x1923b4(508)] || STATE["auth"][_0x1923b4(512)]) return;
  STATE[_0x1923b4(534)][_0x1923b4(512)] = !![], STATE[_0x1923b4(534)][_0x1923b4(479)] = null;
  try {
    const _0x2cbf8e = await request(_0x1923b4(534), { "url": _0x1923b4(426), "credentials": _0x1923b4(379), "responseType": _0x1923b4(412), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x2cbf8e);
  } catch (_0x308f2b) {
    STATE[_0x1923b4(534)][_0x1923b4(479)] = String((_0x308f2b == null ? void 0 : _0x308f2b[_0x1923b4(496)]) || _0x308f2b);
  } finally {
    STATE["auth"][_0x1923b4(512)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x4c5e87(458), _0x4c5e87(395), _0x4c5e87(481)]);
function normalizeScopeMode(_0x1e4396) {
  const _0x4981e9 = _0x4c5e87;
  if (VALID_SCOPE_MODES["has"](_0x1e4396)) return _0x1e4396;
  return _0x4981e9(458);
}
function numericOrNull(_0x2667ef) {
  const _0x4a23d7 = _0x4c5e87;
  if (_0x2667ef === null || _0x2667ef === void 0 || _0x2667ef === "") return null;
  const _0x149fe2 = Number(_0x2667ef);
  return Number[_0x4a23d7(380)](_0x149fe2) ? _0x149fe2 : null;
}
function resolveScopeSync(_0x3c81bf = _0x4c5e87(458)) {
  var _a, _b;
  const _0x1f13a2 = _0x4c5e87, _0x424af3 = normalizeScopeMode(_0x3c81bf), _0x160a61 = numericOrNull((_a = STATE[_0x1f13a2(534)]) == null ? void 0 : _a[_0x1f13a2(384)]), _0x46f203 = numericOrNull((_b = STATE["auth"]) == null ? void 0 : _b[_0x1f13a2(369)]);
  if (_0x424af3 === _0x1f13a2(481)) return { "mode": _0x424af3, "companyId": _0x160a61, "realmId": _0x46f203, "hasScope": !![], "scopeKey": _0x1f13a2(481) };
  if (_0x424af3 === _0x1f13a2(395)) return { "mode": _0x424af3, "companyId": _0x160a61, "realmId": _0x46f203, "hasScope": Number[_0x1f13a2(380)](_0x160a61), "scopeKey": Number["isFinite"](_0x160a61) ? String(_0x160a61) : null };
  const _0xdc5a9e = Number[_0x1f13a2(380)](_0x160a61) && Number[_0x1f13a2(380)](_0x46f203);
  return { "mode": _0x424af3, "companyId": _0x160a61, "realmId": _0x46f203, "hasScope": _0xdc5a9e, "scopeKey": _0xdc5a9e ? _0x160a61 + "-" + _0x46f203 : null };
}
async function resolveScope(_0x5f225d = _0x4c5e87(458), { refreshAuth = ![] } = {}) {
  const _0x46f805 = normalizeScopeMode(_0x5f225d);
  return refreshAuth && _0x46f805 !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x46f805);
}
const DEFAULT_PREFIX = _0x4c5e87(522);
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x52d4ab = _0x4c5e87;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome[_0x52d4ab(499)]) == null ? void 0 : _a[_0x52d4ab(457)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x4856c0) {
  const _0x565849 = _0x4c5e87;
  if (_0x4856c0 == null) return null;
  if (typeof _0x4856c0 === _0x565849(476)) return _0x4856c0;
  try {
    return JSON[_0x565849(464)](String(_0x4856c0));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x1cf928, _0x42a476) {
  const _0x125d38 = _0x4c5e87;
  if (_0x1cf928 === _0x125d38(421)) return _0x42a476;
  return JSON["stringify"](_0x42a476);
}
function isEnvelopeValid(_0xae0b1f) {
  const _0x9d7f48 = _0x4c5e87;
  return Boolean(_0xae0b1f && typeof _0xae0b1f === _0x9d7f48(476) && Number[_0x9d7f48(380)](Number(_0xae0b1f["v"])));
}
function isExpired(_0x134318, _0x1a2da7 = null, _0xe3945b = Date["now"]()) {
  const _0x42ccb5 = _0x4c5e87, _0x56a6e0 = Number((_0x134318 == null ? void 0 : _0x134318["ts"]) || 0), _0x12713a = Number(_0x134318 == null ? void 0 : _0x134318["ttlMs"]), _0x51ec02 = Number[_0x42ccb5(380)](_0x12713a) ? _0x12713a : Number["isFinite"](Number(_0x1a2da7)) ? Number(_0x1a2da7) : null;
  if (!Number[_0x42ccb5(380)](_0x56a6e0) || _0x56a6e0 <= 0) return ![];
  if (!Number[_0x42ccb5(380)](_0x51ec02) || _0x51ec02 <= 0) return ![];
  return _0x56a6e0 + _0x51ec02 < _0xe3945b;
}
function normalizeBackend(_0xe844fb) {
  const _0x5a12c4 = _0x4c5e87;
  return _0xe844fb === "chrome" ? _0x5a12c4(421) : _0x5a12c4(457);
}
function normalizePrefix(_0x422833) {
  const _0x3ba02a = _0x4c5e87, _0x42ffb7 = String(_0x422833 || DEFAULT_PREFIX)[_0x3ba02a(456)]();
  return _0x42ffb7["length"] > 0 ? _0x42ffb7 : DEFAULT_PREFIX;
}
function normalizeDomain(_0x230cbd) {
  const _0x21f7e1 = _0x4c5e87;
  return String(_0x230cbd || _0x21f7e1(404))[_0x21f7e1(456)]()["replace"](/\s+/g, "-")[_0x21f7e1(445)]();
}
function buildStorageKey({ domain: _0x50da9b, version: _0x41dff9, scopeKey: _0x3f9113, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x50da9b) + ":v" + Number(_0x41dff9) + ":" + _0x3f9113;
}
async function chromeGet(_0x334be0) {
  const _0x28b9b2 = _0x4c5e87;
  if (!hasChromeStorage()) return {};
  const _0x5d41d6 = chrome[_0x28b9b2(499)]["local"];
  try {
    const _0x1cb8e6 = _0x5d41d6[_0x28b9b2(425)](_0x334be0);
    if (_0x1cb8e6 && typeof _0x1cb8e6[_0x28b9b2(483)] === _0x28b9b2(443)) return _0x1cb8e6;
  } catch {
  }
  return new Promise((_0x390ab3) => {
    const _0x32580b = _0x28b9b2;
    try {
      _0x5d41d6[_0x32580b(425)](_0x334be0, (_0x186f42) => _0x390ab3(_0x186f42 || {}));
    } catch {
      _0x390ab3({});
    }
  });
}
async function chromeSet(_0x1b2b90) {
  const _0x34d033 = _0x4c5e87;
  if (!hasChromeStorage()) return ![];
  const _0xc963ae = chrome[_0x34d033(499)][_0x34d033(457)];
  try {
    const _0x4a9632 = _0xc963ae["set"](_0x1b2b90);
    if (_0x4a9632 && typeof _0x4a9632[_0x34d033(483)] === _0x34d033(443)) return await _0x4a9632, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x327bf8) => {
    const _0x128246 = _0x34d033;
    try {
      _0xc963ae[_0x128246(409)](_0x1b2b90, () => _0x327bf8(!![]));
    } catch {
      _0x327bf8(![]);
    }
  });
}
async function chromeRemove(_0x3effb7) {
  const _0x5baa49 = _0x4c5e87;
  if (!hasChromeStorage()) return ![];
  const _0x5f3e6b = chrome[_0x5baa49(499)][_0x5baa49(457)];
  try {
    const _0x40b9be = _0x5f3e6b[_0x5baa49(392)](_0x3effb7);
    if (_0x40b9be && typeof _0x40b9be[_0x5baa49(483)] === _0x5baa49(443)) return await _0x40b9be, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x478f99) => {
    const _0x553124 = _0x5baa49;
    try {
      _0x5f3e6b[_0x553124(392)](_0x3effb7, () => _0x478f99(!![]));
    } catch {
      _0x478f99(![]);
    }
  });
}
async function getRaw(_0x64eacc, _0x2c4c8c) {
  const _0x186ff6 = _0x4c5e87, _0x4ce592 = normalizeBackend(_0x64eacc);
  if (_0x4ce592 === _0x186ff6(457)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x186ff6(433)](_0x2c4c8c);
    } catch {
      return null;
    }
  }
  const _0x1ca756 = await chromeGet(_0x2c4c8c);
  return (_0x1ca756 == null ? void 0 : _0x1ca756[_0x2c4c8c]) ?? null;
}
function localGetItemSync(_0x56816d) {
  const _0x9cf92f = _0x4c5e87;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x9cf92f(433)](_0x56816d);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x3d20c2, _0x4f62c1) {
  const _0x2bb944 = _0x4c5e87;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x2bb944(470)](_0x3d20c2, String(_0x4f62c1)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x7b446d) {
  const _0x35e43c = _0x4c5e87;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x35e43c(509)](_0x7b446d), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x2dc1b9 = "") {
  const _0x365a0b = _0x4c5e87;
  if (!hasLocalStorage()) return [];
  const _0x403606 = [], _0x13bd7c = String(_0x2dc1b9 || "");
  try {
    for (let _0x4fa335 = 0; _0x4fa335 < localStorage[_0x365a0b(530)]; _0x4fa335 += 1) {
      const _0x1738bd = localStorage[_0x365a0b(437)](_0x4fa335);
      if (!_0x1738bd || _0x13bd7c && !_0x1738bd[_0x365a0b(450)](_0x13bd7c)) continue;
      _0x403606[_0x365a0b(390)]({ "key": _0x1738bd, "value": localStorage[_0x365a0b(433)](_0x1738bd) });
    }
  } catch {
    return [];
  }
  return _0x403606;
}
async function setRaw(_0x30c5df, _0x5f5901, _0x52f3fe) {
  const _0x2ace45 = _0x4c5e87, _0x5aadd3 = normalizeBackend(_0x30c5df);
  if (_0x5aadd3 === _0x2ace45(457)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x5f5901, String(_0x52f3fe)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x5f5901]: _0x52f3fe });
}
async function removeRaw(_0x488e1a, _0x1a592e) {
  const _0x4023fc = _0x4c5e87, _0x2ea274 = normalizeBackend(_0x488e1a);
  if (_0x2ea274 === _0x4023fc(457)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x4023fc(509)](_0x1a592e), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x1a592e);
}
async function listByPrefix({ backend = _0x4c5e87(457), prefix = "" } = {}) {
  const _0x35d401 = _0x4c5e87, _0x403cf2 = normalizeBackend(backend), _0x162608 = String(prefix || "");
  if (_0x403cf2 === _0x35d401(457)) {
    if (!hasLocalStorage()) return [];
    const _0x52df96 = [];
    try {
      for (let _0x1fcde7 = 0; _0x1fcde7 < localStorage[_0x35d401(530)]; _0x1fcde7 += 1) {
        const _0x206420 = localStorage[_0x35d401(437)](_0x1fcde7);
        if (!_0x206420 || _0x162608 && !_0x206420[_0x35d401(450)](_0x162608)) continue;
        _0x52df96[_0x35d401(390)]({ "key": _0x206420, "value": localStorage[_0x35d401(433)](_0x206420) });
      }
    } catch {
      return [];
    }
    return _0x52df96;
  }
  const _0x52d951 = await chromeGet(null);
  return Object[_0x35d401(411)](_0x52d951 || {})[_0x35d401(422)](([_0x446462]) => _0x162608 ? _0x446462[_0x35d401(450)](_0x162608) : !![])["map"](([_0xcab2c4, _0x458f57]) => ({ "key": _0xcab2c4, "value": _0x458f57 }));
}
async function get({ domain: _0x4e8807, version: _0x5889ea, scope = _0x4c5e87(458), backend = _0x4c5e87(457), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0xec63d9 = _0x4c5e87, _0x13199a = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x13199a[_0xec63d9(517)] || !_0x13199a["scopeKey"]) return null;
  const _0x4f5313 = buildStorageKey({ "domain": _0x4e8807, "version": _0x5889ea, "scopeKey": _0x13199a[_0xec63d9(485)], "prefix": prefix }), _0x5d8a3f = await getRaw(backend, _0x4f5313);
  if (_0x5d8a3f == null) return null;
  const _0x4b4742 = parseJson(_0x5d8a3f);
  if (!isEnvelopeValid(_0x4b4742)) return await removeRaw(backend, _0x4f5313), null;
  const _0x14a4b2 = Number(_0x4b4742["v"]);
  if (_0x14a4b2 !== Number(_0x5889ea)) return _0x14a4b2 < Number(_0x5889ea) && await removeRaw(backend, _0x4f5313), null;
  if (isExpired(_0x4b4742, ttlMs)) return await removeRaw(backend, _0x4f5313), null;
  const _0x5dcc58 = _0x13199a[_0xec63d9(485)], _0x3e280b = String(((_a = _0x4b4742 == null ? void 0 : _0x4b4742[_0xec63d9(377)]) == null ? void 0 : _a["scopeKey"]) || "");
  if (_0x5dcc58 && _0x3e280b && _0x5dcc58 !== _0x3e280b) return await removeRaw(backend, _0x4f5313), null;
  return _0x4b4742[_0xec63d9(532)] ?? null;
}
async function set({ domain: _0x5e69a7, version: _0x709a58, scope = _0x4c5e87(458), backend = _0x4c5e87(457), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x5c37e4 } = {}) {
  const _0x3ebd4b = _0x4c5e87, _0x574d8e = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x574d8e[_0x3ebd4b(517)] || !_0x574d8e[_0x3ebd4b(485)]) return ![];
  const _0x3c9d6e = buildStorageKey({ "domain": _0x5e69a7, "version": _0x709a58, "scopeKey": _0x574d8e["scopeKey"], "prefix": prefix }), _0xaec37f = { "v": Number(_0x709a58), "ts": Date[_0x3ebd4b(474)](), "ttlMs": Number[_0x3ebd4b(380)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x574d8e[_0x3ebd4b(471)], "scopeKey": _0x574d8e["scopeKey"], "companyId": _0x574d8e[_0x3ebd4b(384)], "realmId": _0x574d8e[_0x3ebd4b(369)] }, "data": _0x5c37e4 };
  return setRaw(backend, _0x3c9d6e, toStorageRaw(normalizeBackend(backend), _0xaec37f));
}
async function remove({ domain: _0x409972, version: _0x30e8f1, scope = _0x4c5e87(458), backend = _0x4c5e87(457), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x296cbd = _0x4c5e87, _0x58d485 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x58d485[_0x296cbd(517)] || !_0x58d485[_0x296cbd(485)]) return ![];
  const _0x546c91 = buildStorageKey({ "domain": _0x409972, "version": _0x30e8f1, "scopeKey": _0x58d485[_0x296cbd(485)], "prefix": prefix });
  return removeRaw(backend, _0x546c91);
}
async function migrate({ domain: _0x3e38d3, version: _0x15dd9b, scope = _0x4c5e87(458), backend = _0x4c5e87(457), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x2b445d, cleanupLegacy = !![] } = {}) {
  const _0x6e43a9 = _0x4c5e87, _0x588fe4 = await get({ "domain": _0x3e38d3, "version": _0x15dd9b, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x588fe4 !== null && _0x588fe4 !== void 0) return { "data": _0x588fe4, "migrated": ![] };
  if (typeof _0x2b445d !== "function") return { "data": null, "migrated": ![] };
  const _0x3597f0 = await _0x2b445d({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x2670b2 = _0x3597f0 == null ? void 0 : _0x3597f0[_0x6e43a9(532)];
  if (_0x2670b2 === null || _0x2670b2 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x3e38d3, "version": _0x15dd9b, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x2670b2 }), cleanupLegacy && typeof (_0x3597f0 == null ? void 0 : _0x3597f0[_0x6e43a9(413)]) === "function" && await _0x3597f0[_0x6e43a9(413)](), { "data": _0x2670b2, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = ["scx-buildings", "scx-buildings-ts"];
let migrationsRan = ![];
function parseDomainAndVersion(_0x155371) {
  const _0x5118ac = _0x4c5e87, _0x3ea24b = String(_0x155371 || "")[_0x5118ac(504)](":");
  if (_0x3ea24b[_0x5118ac(530)] < 4) return null;
  if (_0x3ea24b[0] !== _0x5118ac(522)) return null;
  const _0x380d25 = _0x3ea24b[1], _0x5b085b = _0x3ea24b[2] || "";
  if (!_0x5b085b[_0x5118ac(450)]("v")) return null;
  const _0x36338d = Number(_0x5b085b[_0x5118ac(368)](1));
  if (!Number[_0x5118ac(380)](_0x36338d)) return null;
  return { "domain": _0x380d25, "version": _0x36338d };
}
async function cleanupVersionedEnvelopes(_0x43f823) {
  const _0x282730 = _0x4c5e87, _0x279979 = await storage[_0x282730(482)]({ "backend": _0x43f823, "prefix": _0x282730(442) });
  for (const _0x426786 of _0x279979) {
    const _0x303fc6 = parseDomainAndVersion(_0x426786[_0x282730(437)]);
    if (!_0x303fc6) continue;
    const _0x487ee4 = Number(MIN_DOMAIN_VERSION[_0x303fc6[_0x282730(366)]] || 1);
    if (_0x303fc6["version"] < _0x487ee4) {
      await storage[_0x282730(490)](_0x43f823, _0x426786[_0x282730(437)]);
      continue;
    }
    if (_0x426786[_0x282730(507)] == null) {
      await storage["removeRaw"](_0x43f823, _0x426786[_0x282730(437)]);
      continue;
    }
    const _0x1a742a = typeof _0x426786["value"] === _0x282730(430) ? (() => {
      const _0x1e83b5 = _0x282730;
      try {
        return JSON[_0x1e83b5(464)](_0x426786["value"] || _0x1e83b5(473));
      } catch {
        return null;
      }
    })() : _0x426786[_0x282730(507)];
    if (!_0x1a742a || typeof _0x1a742a !== "object" || !Number[_0x282730(380)](Number(_0x1a742a["v"]))) {
      await storage[_0x282730(490)](_0x43f823, _0x426786["key"]);
      continue;
    }
    Number(_0x1a742a["v"]) < _0x487ee4 && await storage[_0x282730(490)](_0x43f823, _0x426786[_0x282730(437)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x433815 = _0x4c5e87;
  for (const _0x301ce9 of LEGACY_GLOBAL_KEYS) {
    await storage["removeRaw"](_0x433815(457), _0x301ce9), await storage["removeRaw"](_0x433815(421), _0x301ce9);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0xe53c88 = _0x4c5e87;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0xe53c88(457)), await cleanupVersionedEnvelopes(_0xe53c88(421)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x77d3b3, _0x58381d) {
  return new Promise((_0x287921, _0x5003ac) => {
    const _0x53aa6a = _0x9bed;
    let _0x1bb8c2 = null;
    const _0x2fb074 = (_0x13eabe, _0x5d4149, _0xa9333f) => {
      const _0x3a8023 = _0x9bed;
      if (_0x1bb8c2 !== null && _0x5d4149["tab"] && _0x5d4149[_0x3a8023(506)]["windowId"] !== _0x1bb8c2) return;
      _0x13eabe["type"] === "COOPER_IFRAME_RESULT" && (_0x307c0d(), _0x13eabe[_0x3a8023(479)] ? _0x5003ac(new Error(_0x13eabe["error"])) : _0x13eabe["data"] && _0x13eabe[_0x3a8023(532)]["length"] === 0 ? _0x287921([]) : _0x287921(_0x13eabe[_0x3a8023(532)]));
    };
    chrome[_0x53aa6a(378)][_0x53aa6a(513)][_0x53aa6a(402)](_0x2fb074);
    const _0x32a8e7 = setTimeout(() => {
      const _0x427fb7 = _0x53aa6a;
      _0x307c0d(), _0x5003ac(new Error(_0x427fb7(478)));
    }, 25e3), _0x307c0d = () => {
      const _0x9c10fd = _0x53aa6a;
      clearTimeout(_0x32a8e7), chrome["runtime"][_0x9c10fd(513)][_0x9c10fd(449)](_0x2fb074), _0x1bb8c2 !== null && chrome[_0x9c10fd(516)][_0x9c10fd(392)](_0x1bb8c2)[_0x9c10fd(386)](() => {
      });
    }, _0x524779 = encodeURIComponent(JSON[_0x53aa6a(374)](_0x77d3b3)), _0x587746 = "https://cooperinc.xyz/retail?scx_params=" + _0x524779;
    chrome[_0x53aa6a(516)]["create"]({ "url": _0x587746, "type": _0x53aa6a(389), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x53aa6a(483)]((_0x451a96) => {
      _0x1bb8c2 = _0x451a96["id"];
    })[_0x53aa6a(386)]((_0x526444) => {
      _0x307c0d(), _0x5003ac(_0x526444);
    });
  });
}
const DOMAIN = _0x4c5e87(484), VERSION = 1;
async function getActiveAlarms() {
  const _0x29d00f = _0x4c5e87, _0x19d4e7 = await storage[_0x29d00f(425)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x29d00f(481), "backend": "chrome" });
  return (_0x19d4e7 == null ? void 0 : _0x19d4e7[_0x29d00f(454)]) || [];
}
async function saveActiveAlarms(_0x55d5ab) {
  const _0x31fb1a = _0x4c5e87;
  await storage[_0x31fb1a(409)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x31fb1a(481), "backend": _0x31fb1a(421), "data": { "alarms": _0x55d5ab } });
}
let addAlarmQueue = Promise[_0x4c5e87(477)]();
function addAlarm(_0x1a7bdb, _0x494de3, _0x102ede, _0x8d9f17, _0x37008d) {
  const _0x593285 = _0x4c5e87;
  return addAlarmQueue = addAlarmQueue[_0x593285(483)](async () => {
    const _0x4ea739 = _0x593285, _0x465102 = await getActiveAlarms(), _0x54e84f = _0x465102[_0x4ea739(422)]((_0x550b69) => {
      const _0x40484b = _0x4ea739;
      if (_0x102ede && _0x550b69[_0x40484b(525)]) return _0x550b69[_0x40484b(525)] !== _0x102ede;
      return _0x550b69[_0x40484b(391)] !== _0x1a7bdb;
    });
    _0x54e84f["push"]({ "alarmId": _0x1a7bdb, "buildingName": _0x494de3, "buildingId": _0x102ede, "finishTimeMs": _0x8d9f17, "translatedMessage": _0x37008d }), await saveActiveAlarms(_0x54e84f);
  })[_0x593285(386)](console[_0x593285(479)]), addAlarmQueue;
}
async function removeAlarm(_0x4e6978) {
  const _0xe89f84 = _0x4c5e87, _0x565437 = await getActiveAlarms(), _0x335a17 = _0x565437[_0xe89f84(422)]((_0x5f55f9) => _0x5f55f9["alarmId"] !== _0x4e6978);
  _0x565437[_0xe89f84(530)] !== _0x335a17[_0xe89f84(530)] && await saveActiveAlarms(_0x335a17);
}
async function clearExpiredAlarms() {
  const _0x2bfbd3 = _0x4c5e87, _0x5e591a = await getActiveAlarms(), _0x49938e = Date[_0x2bfbd3(474)](), _0x3ca209 = _0x5e591a[_0x2bfbd3(422)]((_0x5ab3b9) => _0x5ab3b9["finishTimeMs"] > _0x49938e);
  _0x5e591a["length"] !== _0x3ca209["length"] && await saveActiveAlarms(_0x3ca209);
}
const KEY_WHATS_NEW = _0x4c5e87(448), KEY_LAST_MINOR = _0x4c5e87(441), KEY_LAST_VERSION = _0x4c5e87(498), STORAGE_DOMAIN_WHATS_NEW = "whats-new", STORAGE_DOMAIN_WHATS_NEW_META = _0x4c5e87(535), STORAGE_VERSION = 1;
async function setWhatsNew(_0x41521e) {
  const _0x36f165 = _0x4c5e87;
  await storage[_0x36f165(409)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": "global", "backend": _0x36f165(421), "refreshAuth": ![], "data": _0x41521e }), await storage[_0x36f165(409)]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x36f165(481), "backend": _0x36f165(421), "refreshAuth": ![], "data": { "minorKey": _0x41521e[_0x36f165(420)], "lastVersion": _0x41521e["lastVersion"] } }), await storage[_0x36f165(490)](_0x36f165(421), KEY_WHATS_NEW), await storage[_0x36f165(490)](_0x36f165(421), KEY_LAST_MINOR), await storage[_0x36f165(490)](_0x36f165(421), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x3e92d8 = _0x4c5e87;
  return request("github-releases", { "url": "https://api.github.com/repos/MuhammetFurkanYilmaz/simco-manager/releases?per_page=100", "credentials": _0x3e92d8(514), "responseType": _0x3e92d8(412), "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x4c5e87(378)][_0x4c5e87(523)][_0x4c5e87(402)](async (_0x5ade5c) => {
  const _0x6781f5 = _0x4c5e87;
  await initializeDataPlatform();
  _0x5ade5c[_0x6781f5(396)] === _0x6781f5(455) && await storage[_0x6781f5(409)]({ "domain": _0x6781f5(436), "version": 1, "scope": _0x6781f5(481), "backend": _0x6781f5(421), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x5ade5c[_0x6781f5(396)] === _0x6781f5(394) && _0x5ade5c[_0x6781f5(460)]) {
    const _0x21efac = chrome[_0x6781f5(378)][_0x6781f5(399)]()[_0x6781f5(501)];
    if (_0x21efac !== _0x5ade5c[_0x6781f5(460)]) try {
      const _0x30e254 = await fetchAllReleases();
      let _0x2ad636 = [];
      const _0x18e35e = releasePageUrl(_0x21efac);
      _0x30e254 && Array[_0x6781f5(431)](_0x30e254) && (_0x2ad636 = collectHighlightsFromReleases(_0x30e254, _0x5ade5c[_0x6781f5(460)], _0x21efac)), await setWhatsNew({ "show": !![], "version": _0x21efac, "url": _0x18e35e, "highlights": _0x2ad636, "error": !_0x30e254 || !Array["isArray"](_0x30e254), "minorKey": minorKey(_0x21efac), "lastVersion": _0x21efac });
    } catch (_0x3b80be) {
      console[_0x6781f5(479)]("Failed to fetch release notes:", _0x3b80be), await setWhatsNew({ "show": !![], "version": _0x21efac, "url": releasePageUrl(_0x21efac), "highlights": [], "error": !![], "minorKey": minorKey(_0x21efac), "lastVersion": _0x21efac });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x5a506b) {
  const _0x921427 = _0x4c5e87, _0x4efd98 = Date[_0x921427(474)]();
  if (cooperDataCache[_0x5a506b] && cooperDataCacheTs[_0x5a506b] && _0x4efd98 - cooperDataCacheTs[_0x5a506b] < COOPER_CACHE_TTL) return cooperDataCache[_0x5a506b];
  const _0x5c7388 = "r" + (_0x5a506b + 1), _0x19df43 = await fetch(_0x921427(526) + _0x5c7388);
  if (!_0x19df43["ok"]) throw new Error(_0x921427(519) + _0x19df43[_0x921427(489)]);
  const _0x290d6d = await _0x19df43["json"]();
  return cooperDataCache[_0x5a506b] = _0x290d6d, cooperDataCacheTs[_0x5a506b] = _0x4efd98, _0x290d6d;
}
chrome[_0x4c5e87(378)][_0x4c5e87(513)][_0x4c5e87(402)]((_0x2c373e, _0x42041f, _0x5ec96e) => {
  const _0x1c7ec5 = _0x4c5e87;
  if (_0x2c373e[_0x1c7ec5(494)] === _0x1c7ec5(383)) return fetchCooperData(_0x2c373e["realmId"])[_0x1c7ec5(483)]((_0x31e4a4) => _0x5ec96e({ "success": !![], "data": _0x31e4a4 }))[_0x1c7ec5(386)]((_0x1c0c89) => _0x5ec96e({ "success": ![], "error": _0x1c0c89[_0x1c7ec5(496)] })), !![];
  if (_0x2c373e[_0x1c7ec5(494)] === "FETCH_SIMCOTOOLS_VWAP") {
    const _0x4069ef = _0x2c373e[_0x1c7ec5(369)], _0x4ad589 = "https://api.simcotools.com/v1/realms/" + _0x4069ef + "/market/vwaps";
    return request("simcotools", { "url": _0x4ad589, "method": _0x1c7ec5(415), "credentials": _0x1c7ec5(514), "responseType": _0x1c7ec5(412), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x761f9a) => _0x5ec96e({ "success": !![], "data": _0x761f9a }))[_0x1c7ec5(386)]((_0x130100) => _0x5ec96e({ "success": ![], "error": _0x130100[_0x1c7ec5(496)] || String(_0x130100) })), !![];
  }
  if (_0x2c373e[_0x1c7ec5(494)] === _0x1c7ec5(521)) {
    const { realmId: _0x28cf34, queryParams: _0x74fa1b, headers: _0x1a49d4 } = _0x2c373e, _0xfd3629 = _0x1c7ec5(488) + _0x28cf34 + _0x1c7ec5(397) + _0x74fa1b;
    return request(_0x1c7ec5(459), { "url": _0xfd3629, "method": "GET", "headers": _0x1a49d4, "credentials": "omit", "responseType": _0x1c7ec5(412), "retries": 2, "retryDelayMs": 1e3 })[_0x1c7ec5(483)]((_0x399a40) => _0x5ec96e({ "success": !![], "data": _0x399a40 }))[_0x1c7ec5(386)]((_0x53e4f9) => _0x5ec96e({ "success": ![], "error": _0x53e4f9["message"] || String(_0x53e4f9) })), !![];
  }
  if (_0x2c373e[_0x1c7ec5(494)] === _0x1c7ec5(403)) {
    const { realmId: _0x2fa437, headers: _0x42ecdd } = _0x2c373e, _0x5f42ff = _0x1c7ec5(488) + _0x2fa437 + _0x1c7ec5(536);
    return request(_0x1c7ec5(459), { "url": _0x5f42ff, "method": _0x1c7ec5(415), "headers": _0x42ecdd, "credentials": _0x1c7ec5(514), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x1c7ec5(483)]((_0x2d0140) => _0x5ec96e({ "success": !![], "data": _0x2d0140 }))[_0x1c7ec5(386)]((_0x364b1a) => _0x5ec96e({ "success": ![], "error": _0x364b1a[_0x1c7ec5(496)] || String(_0x364b1a) })), !![];
  }
  if (_0x2c373e[_0x1c7ec5(494)] === "FETCH_SIMCOTOOLS_PHASES") {
    const { realmId: _0x3b9c87, headers: _0xe76b93 } = _0x2c373e, _0x1c7781 = _0x1c7ec5(488) + _0x3b9c87 + _0x1c7ec5(451);
    return request(_0x1c7ec5(459), { "url": _0x1c7781, "method": _0x1c7ec5(415), "headers": _0xe76b93, "credentials": _0x1c7ec5(514), "responseType": _0x1c7ec5(412), "retries": 2, "retryDelayMs": 1e3 })[_0x1c7ec5(483)]((_0x1c7428) => _0x5ec96e({ "success": !![], "data": _0x1c7428 }))[_0x1c7ec5(386)]((_0x19ab0d) => _0x5ec96e({ "success": ![], "error": _0x19ab0d[_0x1c7ec5(496)] || String(_0x19ab0d) })), !![];
  }
  if (_0x2c373e["type"] === _0x1c7ec5(428)) return scrapeCooperRetail(_0x2c373e[_0x1c7ec5(497)])[_0x1c7ec5(483)]((_0x4fb1de) => _0x5ec96e({ "success": !![], "data": _0x4fb1de }))[_0x1c7ec5(386)]((_0x307cfd) => _0x5ec96e({ "success": ![], "error": _0x307cfd[_0x1c7ec5(496)] })), !![];
  if (_0x2c373e[_0x1c7ec5(494)] === "SET_BUILDING_ALARM") {
    const { buildingName: _0x1212b3, buildingId: _0x39ddc2, finishTimeMs: _0x1c210c, translatedMessage: _0x28604a } = _0x2c373e[_0x1c7ec5(532)], _0x4a9a1a = "scx-alarm-" + Date[_0x1c7ec5(474)]() + "-" + Math["floor"](Math["random"]() * 1e3);
    return chrome[_0x1c7ec5(454)][_0x1c7ec5(423)](_0x4a9a1a, { "when": _0x1c210c }), addAlarm(_0x4a9a1a, _0x1212b3, _0x39ddc2, _0x1c210c, _0x28604a)[_0x1c7ec5(386)](console["error"]), _0x5ec96e({ "success": !![], "alarmId": _0x4a9a1a }), !![];
  }
  if (_0x2c373e[_0x1c7ec5(494)] === "CANCEL_BUILDING_ALARM") {
    const { alarmId: _0x227b52 } = _0x2c373e["data"];
    return chrome[_0x1c7ec5(454)]["clear"](_0x227b52), removeAlarm(_0x227b52)[_0x1c7ec5(386)](console["error"]), _0x5ec96e({ "success": !![] }), !![];
  }
}), chrome[_0x4c5e87(454)][_0x4c5e87(440)][_0x4c5e87(402)](async (_0x1916e3) => {
  const _0x1b21f5 = _0x4c5e87;
  if (_0x1916e3[_0x1b21f5(493)][_0x1b21f5(450)](_0x1b21f5(398))) {
    const _0x2c82e5 = await getActiveAlarms(), _0x4bc03b = _0x2c82e5[_0x1b21f5(446)]((_0x2a8c45) => _0x2a8c45[_0x1b21f5(391)] === _0x1916e3[_0x1b21f5(493)]), _0x2baa5c = _0x4bc03b ? _0x4bc03b[_0x1b21f5(465)] : "A building", _0x51952e = (_0x4bc03b == null ? void 0 : _0x4bc03b[_0x1b21f5(511)]) || _0x2baa5c + _0x1b21f5(468);
    chrome[_0x1b21f5(444)][_0x1b21f5(423)](_0x1916e3["name"], { "type": _0x1b21f5(461), "iconUrl": _0x1b21f5(424), "title": _0x1b21f5(452), "message": _0x51952e, "priority": 2 }), await removeAlarm(_0x1916e3[_0x1b21f5(493)]);
  }
}), chrome[_0x4c5e87(454)][_0x4c5e87(423)](_0x4c5e87(503), { "periodInMinutes": 60 }), chrome["alarms"]["onAlarm"][_0x4c5e87(402)]((_0x54cc68) => {
  const _0x2ce877 = _0x4c5e87;
  _0x54cc68[_0x2ce877(493)] === _0x2ce877(503) && clearExpiredAlarms()[_0x2ce877(386)](console["error"]);
});
