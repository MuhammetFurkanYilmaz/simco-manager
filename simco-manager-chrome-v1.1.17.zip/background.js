const _0x125d1c = _0x1707;
(function(_0x251dd4, _0x366081) {
  const _0x3f8133 = _0x1707, _0x11aa90 = _0x251dd4();
  while (!![]) {
    try {
      const _0x21cb45 = -parseInt(_0x3f8133(483)) / 1 * (parseInt(_0x3f8133(637)) / 2) + parseInt(_0x3f8133(621)) / 3 * (parseInt(_0x3f8133(529)) / 4) + parseInt(_0x3f8133(527)) / 5 * (-parseInt(_0x3f8133(551)) / 6) + -parseInt(_0x3f8133(602)) / 7 + -parseInt(_0x3f8133(610)) / 8 + -parseInt(_0x3f8133(632)) / 9 * (parseInt(_0x3f8133(539)) / 10) + parseInt(_0x3f8133(588)) / 11 * (parseInt(_0x3f8133(629)) / 12);
      if (_0x21cb45 === _0x366081) break;
      else _0x11aa90["push"](_0x11aa90["shift"]());
    } catch (_0x533b21) {
      _0x11aa90["push"](_0x11aa90["shift"]());
    }
  }
})(_0x4e47, 492556);
const REPO_OWNER = "MuhammetFurkanYilmaz", REPO_NAME = _0x125d1c(486);
function parseVersion(_0x5a2561) {
  const _0x298a21 = _0x125d1c, _0x1c5fa8 = String(_0x5a2561 || "")["replace"](/^v/i, "")[_0x298a21(507)](".");
  return [Number(_0x1c5fa8[0] || 0), Number(_0x1c5fa8[1] || 0), Number(_0x1c5fa8[2] || 0)];
}
function compareVersions(_0x2b6704, _0x40d9b4) {
  const [_0x42879f, _0x2d45fb, _0x247d16] = parseVersion(_0x2b6704), [_0x2ec591, _0xb46b13, _0x3696d1] = parseVersion(_0x40d9b4);
  if (_0x42879f !== _0x2ec591) return _0x42879f - _0x2ec591;
  if (_0x2d45fb !== _0xb46b13) return _0x2d45fb - _0xb46b13;
  return _0x247d16 - _0x3696d1;
}
function minorKey(_0x4acff9) {
  const _0x192f8e = _0x125d1c, _0x3e2684 = String(_0x4acff9 || "")[_0x192f8e(507)]("."), _0x445e83 = _0x3e2684[0] || "0", _0x116d07 = _0x3e2684[1] || "0";
  return _0x445e83 + "." + _0x116d07;
}
function releasePageUrl(_0x57ce5c) {
  const _0x537b9d = _0x125d1c, _0x2ded0b = String(_0x57ce5c || "")[_0x537b9d(623)]();
  return "https://github.com/" + REPO_OWNER + "/" + REPO_NAME + _0x537b9d(568) + encodeURIComponent(_0x2ded0b);
}
function stripMarkdown(_0x21dc82) {
  const _0x429c9f = _0x125d1c;
  let _0x4c659a = String(_0x21dc82 || "");
  return _0x4c659a = _0x4c659a[_0x429c9f(565)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x4c659a = _0x4c659a[_0x429c9f(565)](/https?:\/\/\S+/gi, ""), _0x4c659a = _0x4c659a["replace"](/[`*_>#]/g, ""), _0x4c659a = _0x4c659a[_0x429c9f(565)](/\s+/g, " ")[_0x429c9f(623)](), _0x4c659a;
}
function humanizeHighlight(_0x316e75) {
  const _0x139d31 = _0x125d1c;
  let _0x1b743a = stripMarkdown(_0x316e75);
  _0x1b743a = _0x1b743a[_0x139d31(565)](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x1b743a = _0x1b743a[_0x139d31(565)](/\s+in\s*$/i, ""), _0x1b743a = _0x1b743a[_0x139d31(565)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x4c2a68 = _0x1b743a[_0x139d31(484)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x4c2a68) {
    const _0x4979f8 = _0x4c2a68[1][_0x139d31(584)](), _0x453a29 = _0x4c2a68[3], _0x32c46d = _0x4979f8 === _0x139d31(607) ? _0x139d31(498) : _0x4979f8 === _0x139d31(630) ? _0x139d31(493) : _0x4979f8 === "perf" ? "Improved" : _0x4979f8 === _0x139d31(596) ? _0x139d31(491) : null;
    if (_0x32c46d) _0x1b743a = _0x32c46d + ": " + _0x453a29;
  }
  return _0x1b743a = _0x1b743a[_0x139d31(565)](/\s+/g, " ")[_0x139d31(623)](), _0x1b743a;
}
function extractHighlights(_0x4324ff, { limit = 5 } = {}) {
  const _0x3bde74 = _0x125d1c, _0x570d53 = String(_0x4324ff || ""), _0x367527 = _0x570d53["split"](/\r?\n/), _0x50195e = [];
  let _0x2dd261 = ![];
  for (const _0x250415 of _0x367527) {
    const _0x417e8e = _0x250415[_0x3bde74(623)]();
    if (_0x417e8e[_0x3bde74(620)](_0x3bde74(583))) {
      _0x2dd261 = !_0x2dd261;
      continue;
    }
    if (_0x2dd261) continue;
    if (!_0x417e8e) continue;
    if (/^#+\s+/["test"](_0x417e8e)) continue;
    const _0x353022 = _0x417e8e[_0x3bde74(484)](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x353022) {
      const _0x4d4827 = humanizeHighlight(_0x353022[2]);
      if (_0x4d4827) _0x50195e[_0x3bde74(643)](_0x4d4827);
    }
    if (_0x50195e[_0x3bde74(533)] >= limit) break;
  }
  return _0x50195e[_0x3bde74(569)](0, limit);
}
function collectHighlightsFromReleases(_0x359a95, _0x241c8d, _0x4dc9eb, { limit = 10 } = {}) {
  const _0x2e69a5 = _0x125d1c, _0x39ffd1 = (Array[_0x2e69a5(577)](_0x359a95) ? _0x359a95 : [])[_0x2e69a5(530)]((_0x82677c) => !(_0x82677c == null ? void 0 : _0x82677c[_0x2e69a5(614)]))["map"]((_0x3f8d5e) => ({ ..._0x3f8d5e, "tag_name": String((_0x3f8d5e == null ? void 0 : _0x3f8d5e[_0x2e69a5(619)]) || "") }))[_0x2e69a5(530)]((_0xb3b65a) => /^v?\d+\.\d+\.\d+$/[_0x2e69a5(520)](_0xb3b65a["tag_name"]))[_0x2e69a5(530)]((_0x4e21df) => compareVersions(_0x4e21df[_0x2e69a5(619)], _0x241c8d) > 0)[_0x2e69a5(530)]((_0x2936ac) => compareVersions(_0x2936ac[_0x2e69a5(619)], _0x4dc9eb) <= 0)[_0x2e69a5(628)]((_0x1616bd, _0x40e1e2) => compareVersions(_0x1616bd[_0x2e69a5(619)], _0x40e1e2[_0x2e69a5(619)])), _0x16bbd1 = [];
  for (const _0x144f2d of _0x39ffd1) {
    const _0x448f1d = extractHighlights(_0x144f2d[_0x2e69a5(599)], { "limit": limit });
    for (const _0x3f64ba of _0x448f1d) {
      _0x16bbd1[_0x2e69a5(643)](_0x3f64ba);
      if (_0x16bbd1[_0x2e69a5(533)] >= limit) return _0x16bbd1;
    }
  }
  return _0x16bbd1[_0x2e69a5(569)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x26c674) {
  return new Promise((_0x34dcf3) => setTimeout(_0x34dcf3, _0x26c674));
}
function normalizeDomain$1(_0x10073f) {
  const _0xf64010 = _0x125d1c;
  return String(_0x10073f || _0xf64010(615))["trim"]()[_0xf64010(584)]();
}
function makeError(_0x1feb1e, _0x2902d1 = {}) {
  const _0xba2e35 = _0x125d1c, _0x3ab400 = new Error(_0x1feb1e);
  return Object[_0xba2e35(547)](_0x3ab400, _0x2902d1), _0x3ab400;
}
function buildInflightKey(_0x157430, _0x4b3e80, _0x48188a, _0x3d10) {
  if (_0x4b3e80) return _0x157430 + ":" + _0x4b3e80;
  return _0x157430 + ":" + _0x3d10 + ":" + _0x48188a;
}
function getRateLimitStatus(_0x21ac1b = _0x125d1c(615)) {
  const _0x4b0854 = _0x125d1c, _0x48280f = normalizeDomain$1(_0x21ac1b), _0x846f25 = Number(rateLimitByDomain[_0x4b0854(488)](_0x48280f) || 0), _0x4af20e = Math[_0x4b0854(513)](0, _0x846f25 - Date[_0x4b0854(495)]());
  return { "blocked": _0x4af20e > 0, "remainingMs": _0x4af20e, "blockedUntil": _0x846f25 };
}
async function parseResponse(_0x2571ce, _0x39de6b) {
  const _0x587397 = _0x125d1c;
  if (_0x39de6b === _0x587397(528)) return _0x2571ce;
  if (_0x39de6b === "text") return _0x2571ce["text"]();
  if (_0x39de6b === "blob") return _0x2571ce[_0x587397(476)]();
  if (_0x39de6b === _0x587397(502)) return _0x2571ce[_0x587397(502)]();
  return _0x2571ce[_0x587397(490)]();
}
async function doRequest(_0x1827cd, _0x56f920, _0x27189c = 0) {
  const _0x49d1a1 = _0x125d1c, { url: _0x569d85, method = _0x49d1a1(489), headers: _0x27ac9d, body: _0x12e6a5, credentials = _0x49d1a1(512), signal: _0x4532c7, responseType = "json", retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x56f920, _0x515e3c = getRateLimitStatus(_0x1827cd);
  if (_0x515e3c[_0x49d1a1(576)]) throw makeError(_0x49d1a1(531) + Math[_0x49d1a1(581)](_0x515e3c[_0x49d1a1(478)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x1827cd, "remainingMs": _0x515e3c[_0x49d1a1(478)], "status": 429 });
  const _0xb951da = timeoutMs > 0 ? new AbortController() : null, _0x3cf08b = _0xb951da && timeoutMs > 0 ? setTimeout(() => _0xb951da["abort"](makeError(_0x49d1a1(595), { "code": _0x49d1a1(580), "domain": _0x1827cd })), timeoutMs) : null, _0x20aa28 = _0xb951da ? _0xb951da["signal"] : _0x4532c7;
  try {
    const _0x50c963 = await fetch(_0x569d85, { "method": method, "headers": _0x27ac9d, "body": _0x12e6a5, "credentials": credentials, "signal": _0x20aa28 });
    if (_0x50c963[_0x49d1a1(542)] === 429 && rateLimitCooldownMs > 0) {
      const _0x208ac8 = (rateLimitHitCount[_0x49d1a1(488)](_0x1827cd) || 0) + 1;
      rateLimitHitCount["set"](_0x1827cd, _0x208ac8);
      const _0x74060c = _0x208ac8 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x49d1a1(598)](_0x1827cd, Date["now"]() + _0x74060c);
    }
    if (!_0x50c963["ok"]) {
      const _0x1381f0 = _0x27189c < retries && retryStatuses[_0x49d1a1(501)](_0x50c963[_0x49d1a1(542)]);
      if (_0x1381f0) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x1827cd, _0x56f920, _0x27189c + 1);
      }
      throw makeError("HTTP " + _0x50c963[_0x49d1a1(542)], { "code": _0x49d1a1(605), "domain": _0x1827cd, "status": _0x50c963["status"] });
    }
    return rateLimitHitCount[_0x49d1a1(557)](_0x1827cd), parseResponse(_0x50c963, responseType);
  } catch (_0x3b1d39) {
    const _0x46ce9e = (_0x3b1d39 == null ? void 0 : _0x3b1d39["name"]) === _0x49d1a1(646), _0x19575f = !_0x46ce9e && _0x27189c < retries;
    if (_0x19575f) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x1827cd, _0x56f920, _0x27189c + 1);
    }
    if (_0x3b1d39 instanceof Error && _0x3b1d39[_0x49d1a1(561)]) throw _0x3b1d39;
    throw makeError(String((_0x3b1d39 == null ? void 0 : _0x3b1d39[_0x49d1a1(634)]) || _0x3b1d39 || _0x49d1a1(642)), { "code": _0x46ce9e ? _0x49d1a1(504) : _0x49d1a1(543), "domain": _0x1827cd, "status": Number((_0x3b1d39 == null ? void 0 : _0x3b1d39[_0x49d1a1(542)]) || 0) || null, "cause": _0x3b1d39 });
  } finally {
    if (_0x3cf08b) clearTimeout(_0x3cf08b);
  }
}
function _0x1707(_0x2d068c, _0x4e03fd) {
  _0x2d068c = _0x2d068c - 475;
  const _0x4e474e = _0x4e47();
  let _0x170795 = _0x4e474e[_0x2d068c];
  if (_0x1707["qcZjNP"] === void 0) {
    var _0x50efeb = function(_0x452d68) {
      const _0x4f2c9d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x5a2561 = "", _0x1c5fa8 = "";
      for (let _0x2b6704 = 0, _0x40d9b4, _0x42879f, _0x2d45fb = 0; _0x42879f = _0x452d68["charAt"](_0x2d45fb++); ~_0x42879f && (_0x40d9b4 = _0x2b6704 % 4 ? _0x40d9b4 * 64 + _0x42879f : _0x42879f, _0x2b6704++ % 4) ? _0x5a2561 += String["fromCharCode"](255 & _0x40d9b4 >> (-2 * _0x2b6704 & 6)) : 0) {
        _0x42879f = _0x4f2c9d["indexOf"](_0x42879f);
      }
      for (let _0x247d16 = 0, _0x2ec591 = _0x5a2561["length"]; _0x247d16 < _0x2ec591; _0x247d16++) {
        _0x1c5fa8 += "%" + ("00" + _0x5a2561["charCodeAt"](_0x247d16)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x1c5fa8);
    };
    _0x1707["EocDCf"] = _0x50efeb, _0x1707["wcWBFa"] = {}, _0x1707["qcZjNP"] = !![];
  }
  const _0x36f5a7 = _0x4e474e[0], _0x4ab7bc = _0x2d068c + _0x36f5a7, _0x381909 = _0x1707["wcWBFa"][_0x4ab7bc];
  return !_0x381909 ? (_0x170795 = _0x1707["EocDCf"](_0x170795), _0x1707["wcWBFa"][_0x4ab7bc] = _0x170795) : _0x170795 = _0x381909, _0x170795;
}
async function request(_0x3b9616, _0x16769a) {
  const _0x462e7e = _0x125d1c, _0x378907 = normalizeDomain$1(_0x3b9616), _0x168f63 = buildInflightKey(_0x378907, _0x16769a == null ? void 0 : _0x16769a[_0x462e7e(622)], _0x16769a == null ? void 0 : _0x16769a[_0x462e7e(594)], (_0x16769a == null ? void 0 : _0x16769a[_0x462e7e(559)]) || _0x462e7e(489));
  if ((_0x16769a == null ? void 0 : _0x16769a[_0x462e7e(638)]) && inflightByKey[_0x462e7e(616)](_0x168f63)) return inflightByKey[_0x462e7e(488)](_0x168f63);
  const _0x47d22c = doRequest(_0x378907, _0x16769a || {})[_0x462e7e(603)](() => {
    const _0x1eaeb6 = _0x462e7e;
    inflightByKey[_0x1eaeb6(557)](_0x168f63);
  });
  return (_0x16769a == null ? void 0 : _0x16769a[_0x462e7e(638)]) && inflightByKey[_0x462e7e(598)](_0x168f63, _0x47d22c), _0x47d22c;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x325bd9) {
  const _0x53addc = _0x125d1c, _0x6c0c14 = _0x325bd9 == null ? void 0 : _0x325bd9[_0x53addc(606)];
  STATE["auth"][_0x53addc(477)] = (_0x6c0c14 == null ? void 0 : _0x6c0c14[_0x53addc(477)]) ?? null, STATE[_0x53addc(526)][_0x53addc(613)] = (_0x6c0c14 == null ? void 0 : _0x6c0c14[_0x53addc(613)]) ?? null, STATE["auth"][_0x53addc(597)] = (_0x6c0c14 == null ? void 0 : _0x6c0c14[_0x53addc(597)]) ?? null, STATE[_0x53addc(526)]["salesModifier"] = (_0x6c0c14 == null ? void 0 : _0x6c0c14[_0x53addc(480)]) ?? null, STATE["auth"][_0x53addc(535)] = !![];
  const _0x354a8c = _0x325bd9 == null ? void 0 : _0x325bd9["levelInfo"];
  STATE[_0x53addc(549)]["level"] = (_0x354a8c == null ? void 0 : _0x354a8c["level"]) ?? null, STATE[_0x53addc(549)][_0x53addc(562)] = (_0x354a8c == null ? void 0 : _0x354a8c[_0x53addc(562)]) ?? null, STATE[_0x53addc(549)]["experienceToNextLevel"] = (_0x354a8c == null ? void 0 : _0x354a8c[_0x53addc(500)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x3f087d = _0x125d1c;
  if (!force && STATE[_0x3f087d(526)]["loaded"] || STATE[_0x3f087d(526)][_0x3f087d(578)]) return;
  STATE[_0x3f087d(526)][_0x3f087d(578)] = !![], STATE[_0x3f087d(526)][_0x3f087d(482)] = null;
  try {
    const _0xf4c36 = await request(_0x3f087d(526), { "url": _0x3f087d(609), "credentials": "include", "responseType": _0x3f087d(490), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0xf4c36);
  } catch (_0x1b2b0c) {
    STATE[_0x3f087d(526)][_0x3f087d(482)] = String((_0x1b2b0c == null ? void 0 : _0x1b2b0c["message"]) || _0x1b2b0c);
  } finally {
    STATE["auth"][_0x3f087d(578)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x125d1c(587), _0x125d1c(585), _0x125d1c(571)]);
function normalizeScopeMode(_0xa8565d) {
  const _0x122c0c = _0x125d1c;
  if (VALID_SCOPE_MODES[_0x122c0c(616)](_0xa8565d)) return _0xa8565d;
  return _0x122c0c(587);
}
function numericOrNull(_0x491be0) {
  if (_0x491be0 === null || _0x491be0 === void 0 || _0x491be0 === "") return null;
  const _0x4eeb9f = Number(_0x491be0);
  return Number["isFinite"](_0x4eeb9f) ? _0x4eeb9f : null;
}
function resolveScopeSync(_0x308f01 = _0x125d1c(587)) {
  var _a, _b;
  const _0x5311ea = _0x125d1c, _0xff960a = normalizeScopeMode(_0x308f01), _0x4699b9 = numericOrNull((_a = STATE[_0x5311ea(526)]) == null ? void 0 : _a[_0x5311ea(477)]), _0x4432d3 = numericOrNull((_b = STATE[_0x5311ea(526)]) == null ? void 0 : _b["realmId"]);
  if (_0xff960a === _0x5311ea(571)) return { "mode": _0xff960a, "companyId": _0x4699b9, "realmId": _0x4432d3, "hasScope": !![], "scopeKey": _0x5311ea(571) };
  if (_0xff960a === _0x5311ea(585)) return { "mode": _0xff960a, "companyId": _0x4699b9, "realmId": _0x4432d3, "hasScope": Number[_0x5311ea(639)](_0x4699b9), "scopeKey": Number["isFinite"](_0x4699b9) ? String(_0x4699b9) : null };
  const _0x54694b = Number[_0x5311ea(639)](_0x4699b9) && Number[_0x5311ea(639)](_0x4432d3);
  return { "mode": _0xff960a, "companyId": _0x4699b9, "realmId": _0x4432d3, "hasScope": _0x54694b, "scopeKey": _0x54694b ? _0x4699b9 + "-" + _0x4432d3 : null };
}
async function resolveScope(_0x65ac75 = "scoped", { refreshAuth = ![] } = {}) {
  const _0x453a00 = _0x125d1c, _0xb37394 = normalizeScopeMode(_0x65ac75);
  return refreshAuth && _0xb37394 !== _0x453a00(571) && await loadAuthDataOnce(), resolveScopeSync(_0xb37394);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  const _0x2fd122 = _0x125d1c;
  try {
    return typeof localStorage !== _0x2fd122(645) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x4e1ab7 = _0x125d1c;
  try {
    return typeof chrome !== _0x4e1ab7(645) && Boolean((_a = chrome == null ? void 0 : chrome[_0x4e1ab7(496)]) == null ? void 0 : _a["local"]);
  } catch {
    return ![];
  }
}
function parseJson(_0x5e4656) {
  const _0x3dec22 = _0x125d1c;
  if (_0x5e4656 == null) return null;
  if (typeof _0x5e4656 === "object") return _0x5e4656;
  try {
    return JSON[_0x3dec22(521)](String(_0x5e4656));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x4522af, _0x5beae4) {
  const _0x313a44 = _0x125d1c;
  if (_0x4522af === _0x313a44(636)) return _0x5beae4;
  return JSON[_0x313a44(499)](_0x5beae4);
}
function isEnvelopeValid(_0x178c0e) {
  const _0x4be156 = _0x125d1c;
  return Boolean(_0x178c0e && typeof _0x178c0e === "object" && Number[_0x4be156(639)](Number(_0x178c0e["v"])));
}
function isExpired(_0x159451, _0x2f497d = null, _0x37f1f3 = Date[_0x125d1c(495)]()) {
  const _0x334e42 = _0x125d1c, _0x26579e = Number((_0x159451 == null ? void 0 : _0x159451["ts"]) || 0), _0x3d68af = Number(_0x159451 == null ? void 0 : _0x159451[_0x334e42(552)]), _0x1a98ef = Number[_0x334e42(639)](_0x3d68af) ? _0x3d68af : Number["isFinite"](Number(_0x2f497d)) ? Number(_0x2f497d) : null;
  if (!Number[_0x334e42(639)](_0x26579e) || _0x26579e <= 0) return ![];
  if (!Number[_0x334e42(639)](_0x1a98ef) || _0x1a98ef <= 0) return ![];
  return _0x26579e + _0x1a98ef < _0x37f1f3;
}
function normalizeBackend(_0x237616) {
  const _0x3a941b = _0x125d1c;
  return _0x237616 === "chrome" ? "chrome" : _0x3a941b(524);
}
function normalizePrefix(_0x48816d) {
  const _0x369c67 = _0x125d1c, _0x4c3bde = String(_0x48816d || DEFAULT_PREFIX)[_0x369c67(623)]();
  return _0x4c3bde[_0x369c67(533)] > 0 ? _0x4c3bde : DEFAULT_PREFIX;
}
function normalizeDomain(_0x399419) {
  const _0x191ece = _0x125d1c;
  return String(_0x399419 || _0x191ece(624))["trim"]()["replace"](/\s+/g, "-")["toLowerCase"]();
}
function buildStorageKey({ domain: _0xc13401, version: _0x544560, scopeKey: _0x4e9772, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0xc13401) + ":v" + Number(_0x544560) + ":" + _0x4e9772;
}
async function chromeGet(_0x43a744) {
  const _0x3e2174 = _0x125d1c;
  if (!hasChromeStorage()) return {};
  const _0xfadfc5 = chrome[_0x3e2174(496)]["local"];
  try {
    const _0x4b4e37 = _0xfadfc5["get"](_0x43a744);
    if (_0x4b4e37 && typeof _0x4b4e37[_0x3e2174(644)] === _0x3e2174(579)) return _0x4b4e37;
  } catch {
  }
  return new Promise((_0x593b61) => {
    try {
      _0xfadfc5["get"](_0x43a744, (_0x596ce0) => _0x593b61(_0x596ce0 || {}));
    } catch {
      _0x593b61({});
    }
  });
}
async function chromeSet(_0x2dbbce) {
  const _0x4751dc = _0x125d1c;
  if (!hasChromeStorage()) return ![];
  const _0x22db14 = chrome[_0x4751dc(496)][_0x4751dc(524)];
  try {
    const _0x4e6368 = _0x22db14[_0x4751dc(598)](_0x2dbbce);
    if (_0x4e6368 && typeof _0x4e6368[_0x4751dc(644)] === _0x4751dc(579)) return await _0x4e6368, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x16743e) => {
    const _0x4bc9a9 = _0x4751dc;
    try {
      _0x22db14[_0x4bc9a9(598)](_0x2dbbce, () => _0x16743e(!![]));
    } catch {
      _0x16743e(![]);
    }
  });
}
async function chromeRemove(_0x4b11cf) {
  const _0x110521 = _0x125d1c;
  if (!hasChromeStorage()) return ![];
  const _0x510942 = chrome[_0x110521(496)][_0x110521(524)];
  try {
    const _0x3d451a = _0x510942[_0x110521(532)](_0x4b11cf);
    if (_0x3d451a && typeof _0x3d451a[_0x110521(644)] === _0x110521(579)) return await _0x3d451a, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x38aca1) => {
    try {
      _0x510942["remove"](_0x4b11cf, () => _0x38aca1(!![]));
    } catch {
      _0x38aca1(![]);
    }
  });
}
async function getRaw(_0x186ff1, _0x3673f4) {
  const _0x23368e = _0x125d1c, _0x5f1f83 = normalizeBackend(_0x186ff1);
  if (_0x5f1f83 === _0x23368e(524)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x23368e(481)](_0x3673f4);
    } catch {
      return null;
    }
  }
  const _0x109ef9 = await chromeGet(_0x3673f4);
  return (_0x109ef9 == null ? void 0 : _0x109ef9[_0x3673f4]) ?? null;
}
function localGetItemSync(_0x2fa543) {
  const _0x54ff9b = _0x125d1c;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x54ff9b(481)](_0x2fa543);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x3e0286, _0x344dd8) {
  const _0x4ce46a = _0x125d1c;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x4ce46a(611)](_0x3e0286, String(_0x344dd8)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x1bba90) {
  const _0x3d65b0 = _0x125d1c;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x3d65b0(625)](_0x1bba90), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x438e5a = "") {
  const _0xed646 = _0x125d1c;
  if (!hasLocalStorage()) return [];
  const _0xad985d = [], _0x55ec33 = String(_0x438e5a || "");
  try {
    for (let _0x56d1b9 = 0; _0x56d1b9 < localStorage[_0xed646(533)]; _0x56d1b9 += 1) {
      const _0xe1eb73 = localStorage["key"](_0x56d1b9);
      if (!_0xe1eb73 || _0x55ec33 && !_0xe1eb73[_0xed646(620)](_0x55ec33)) continue;
      _0xad985d[_0xed646(643)]({ "key": _0xe1eb73, "value": localStorage["getItem"](_0xe1eb73) });
    }
  } catch {
    return [];
  }
  return _0xad985d;
}
async function setRaw(_0x51ca38, _0x26d72c, _0x32b017) {
  const _0x4750f7 = _0x125d1c, _0x4f75bd = normalizeBackend(_0x51ca38);
  if (_0x4f75bd === _0x4750f7(524)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x4750f7(611)](_0x26d72c, String(_0x32b017)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x26d72c]: _0x32b017 });
}
async function removeRaw(_0x1c91e2, _0x3231d1) {
  const _0x492440 = _0x125d1c, _0x262219 = normalizeBackend(_0x1c91e2);
  if (_0x262219 === _0x492440(524)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x492440(625)](_0x3231d1), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x3231d1);
}
async function listByPrefix({ backend = _0x125d1c(524), prefix = "" } = {}) {
  const _0xbf4c88 = _0x125d1c, _0x4471f3 = normalizeBackend(backend), _0x136f1a = String(prefix || "");
  if (_0x4471f3 === _0xbf4c88(524)) {
    if (!hasLocalStorage()) return [];
    const _0x29b979 = [];
    try {
      for (let _0x41d849 = 0; _0x41d849 < localStorage[_0xbf4c88(533)]; _0x41d849 += 1) {
        const _0x53463f = localStorage[_0xbf4c88(582)](_0x41d849);
        if (!_0x53463f || _0x136f1a && !_0x53463f["startsWith"](_0x136f1a)) continue;
        _0x29b979[_0xbf4c88(643)]({ "key": _0x53463f, "value": localStorage[_0xbf4c88(481)](_0x53463f) });
      }
    } catch {
      return [];
    }
    return _0x29b979;
  }
  const _0x13d327 = await chromeGet(null);
  return Object[_0xbf4c88(589)](_0x13d327 || {})[_0xbf4c88(530)](([_0x6db343]) => _0x136f1a ? _0x6db343[_0xbf4c88(620)](_0x136f1a) : !![])[_0xbf4c88(497)](([_0x1b1694, _0x1ee364]) => ({ "key": _0x1b1694, "value": _0x1ee364 }));
}
async function get({ domain: _0x47fdf3, version: _0x44ae07, scope = _0x125d1c(587), backend = _0x125d1c(524), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x49264c = _0x125d1c, _0x362b90 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x362b90[_0x49264c(540)] || !_0x362b90["scopeKey"]) return null;
  const _0x39d4dd = buildStorageKey({ "domain": _0x47fdf3, "version": _0x44ae07, "scopeKey": _0x362b90["scopeKey"], "prefix": prefix }), _0x2d2b10 = await getRaw(backend, _0x39d4dd);
  if (_0x2d2b10 == null) return null;
  const _0x15d19a = parseJson(_0x2d2b10);
  if (!isEnvelopeValid(_0x15d19a)) return await removeRaw(backend, _0x39d4dd), null;
  const _0xc117c1 = Number(_0x15d19a["v"]);
  if (_0xc117c1 !== Number(_0x44ae07)) return _0xc117c1 < Number(_0x44ae07) && await removeRaw(backend, _0x39d4dd), null;
  if (isExpired(_0x15d19a, ttlMs)) return await removeRaw(backend, _0x39d4dd), null;
  const _0x406a99 = _0x362b90[_0x49264c(612)], _0x292c32 = String(((_a = _0x15d19a == null ? void 0 : _0x15d19a[_0x49264c(479)]) == null ? void 0 : _a[_0x49264c(612)]) || "");
  if (_0x406a99 && _0x292c32 && _0x406a99 !== _0x292c32) return await removeRaw(backend, _0x39d4dd), null;
  return _0x15d19a[_0x49264c(537)] ?? null;
}
async function set({ domain: _0x2fd5fe, version: _0x10f526, scope = _0x125d1c(587), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x10662e } = {}) {
  const _0x4faeaf = _0x125d1c, _0x5063e9 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5063e9["hasScope"] || !_0x5063e9[_0x4faeaf(612)]) return ![];
  const _0x275af0 = buildStorageKey({ "domain": _0x2fd5fe, "version": _0x10f526, "scopeKey": _0x5063e9[_0x4faeaf(612)], "prefix": prefix }), _0x51071f = { "v": Number(_0x10f526), "ts": Date[_0x4faeaf(495)](), "ttlMs": Number["isFinite"](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x5063e9[_0x4faeaf(541)], "scopeKey": _0x5063e9[_0x4faeaf(612)], "companyId": _0x5063e9[_0x4faeaf(477)], "realmId": _0x5063e9[_0x4faeaf(613)] }, "data": _0x10662e };
  return setRaw(backend, _0x275af0, toStorageRaw(normalizeBackend(backend), _0x51071f));
}
async function remove({ domain: _0x288abb, version: _0x41b76e, scope = _0x125d1c(587), backend = "local", prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x4528f4 = _0x125d1c, _0x490f2b = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x490f2b["hasScope"] || !_0x490f2b[_0x4528f4(612)]) return ![];
  const _0x57dfe6 = buildStorageKey({ "domain": _0x288abb, "version": _0x41b76e, "scopeKey": _0x490f2b[_0x4528f4(612)], "prefix": prefix });
  return removeRaw(backend, _0x57dfe6);
}
async function migrate({ domain: _0x4561d4, version: _0x162de7, scope = _0x125d1c(587), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x2e531d, cleanupLegacy = !![] } = {}) {
  const _0x148455 = _0x125d1c, _0x89fc6 = await get({ "domain": _0x4561d4, "version": _0x162de7, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x89fc6 !== null && _0x89fc6 !== void 0) return { "data": _0x89fc6, "migrated": ![] };
  if (typeof _0x2e531d !== "function") return { "data": null, "migrated": ![] };
  const _0x3577f4 = await _0x2e531d({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x119c53 = _0x3577f4 == null ? void 0 : _0x3577f4[_0x148455(537)];
  if (_0x119c53 === null || _0x119c53 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x4561d4, "version": _0x162de7, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x119c53 }), cleanupLegacy && typeof (_0x3577f4 == null ? void 0 : _0x3577f4[_0x148455(510)]) === _0x148455(579) && await _0x3577f4[_0x148455(510)](), { "data": _0x119c53, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = ["scx-buildings", _0x125d1c(570)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x28b1f5) {
  const _0x2a43fe = _0x125d1c, _0x49d78b = String(_0x28b1f5 || "")["split"](":");
  if (_0x49d78b["length"] < 4) return null;
  if (_0x49d78b[0] !== _0x2a43fe(534)) return null;
  const _0x21d904 = _0x49d78b[1], _0xd8cfc5 = _0x49d78b[2] || "";
  if (!_0xd8cfc5[_0x2a43fe(620)]("v")) return null;
  const _0x5288ed = Number(_0xd8cfc5[_0x2a43fe(569)](1));
  if (!Number[_0x2a43fe(639)](_0x5288ed)) return null;
  return { "domain": _0x21d904, "version": _0x5288ed };
}
async function cleanupVersionedEnvelopes(_0x2b7f32) {
  const _0x598c4b = _0x125d1c, _0x53943c = await storage[_0x598c4b(590)]({ "backend": _0x2b7f32, "prefix": _0x598c4b(626) });
  for (const _0x3a40b4 of _0x53943c) {
    const _0x131a70 = parseDomainAndVersion(_0x3a40b4[_0x598c4b(582)]);
    if (!_0x131a70) continue;
    const _0x47daf2 = Number(MIN_DOMAIN_VERSION[_0x131a70[_0x598c4b(567)]] || 1);
    if (_0x131a70[_0x598c4b(522)] < _0x47daf2) {
      await storage["removeRaw"](_0x2b7f32, _0x3a40b4[_0x598c4b(582)]);
      continue;
    }
    if (_0x3a40b4[_0x598c4b(627)] == null) {
      await storage[_0x598c4b(575)](_0x2b7f32, _0x3a40b4[_0x598c4b(582)]);
      continue;
    }
    const _0x2e3326 = typeof _0x3a40b4[_0x598c4b(627)] === _0x598c4b(618) ? (() => {
      const _0x19755e = _0x598c4b;
      try {
        return JSON[_0x19755e(521)](_0x3a40b4[_0x19755e(627)] || "null");
      } catch {
        return null;
      }
    })() : _0x3a40b4[_0x598c4b(627)];
    if (!_0x2e3326 || typeof _0x2e3326 !== "object" || !Number[_0x598c4b(639)](Number(_0x2e3326["v"]))) {
      await storage["removeRaw"](_0x2b7f32, _0x3a40b4[_0x598c4b(582)]);
      continue;
    }
    Number(_0x2e3326["v"]) < _0x47daf2 && await storage[_0x598c4b(575)](_0x2b7f32, _0x3a40b4[_0x598c4b(582)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x58931f = _0x125d1c;
  for (const _0xfc6b20 of LEGACY_GLOBAL_KEYS) {
    await storage[_0x58931f(575)](_0x58931f(524), _0xfc6b20), await storage[_0x58931f(575)](_0x58931f(636), _0xfc6b20);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x36555d = _0x125d1c;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x36555d(524)), await cleanupVersionedEnvelopes(_0x36555d(636)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x20dd86, _0x19e02e) {
  return new Promise((_0x4dffbe, _0x2a17ef) => {
    const _0x48cb25 = _0x1707;
    let _0x2bda04 = null;
    const _0x3db8df = (_0x4f63ea, _0xf0cd39, _0x4d330b) => {
      const _0x1cb193 = _0x1707;
      if (_0x2bda04 !== null && _0xf0cd39["tab"] && _0xf0cd39[_0x1cb193(563)][_0x1cb193(592)] !== _0x2bda04) return;
      _0x4f63ea[_0x1cb193(536)] === _0x1cb193(601) && (_0x515c46(), _0x4f63ea[_0x1cb193(482)] ? _0x2a17ef(new Error(_0x4f63ea["error"])) : _0x4f63ea[_0x1cb193(537)] && _0x4f63ea[_0x1cb193(537)][_0x1cb193(533)] === 0 ? _0x4dffbe([]) : _0x4dffbe(_0x4f63ea[_0x1cb193(537)]));
    };
    chrome["runtime"][_0x48cb25(556)][_0x48cb25(548)](_0x3db8df);
    const _0x31cb4c = setTimeout(() => {
      _0x515c46(), _0x2a17ef(new Error("Timeout waiting for CooperInc window to return data."));
    }, 25e3), _0x515c46 = () => {
      const _0xdc6371 = _0x48cb25;
      clearTimeout(_0x31cb4c), chrome[_0xdc6371(564)][_0xdc6371(556)]["removeListener"](_0x3db8df), _0x2bda04 !== null && chrome[_0xdc6371(593)][_0xdc6371(532)](_0x2bda04)[_0xdc6371(554)](() => {
      });
    }, _0x501ce5 = encodeURIComponent(JSON[_0x48cb25(499)](_0x20dd86)), _0x24184a = _0x48cb25(544) + _0x501ce5;
    chrome[_0x48cb25(593)][_0x48cb25(475)]({ "url": _0x24184a, "type": _0x48cb25(633), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x48cb25(644)]((_0x9db5f) => {
      _0x2bda04 = _0x9db5f["id"];
    })[_0x48cb25(554)]((_0x4807c2) => {
      _0x515c46(), _0x2a17ef(_0x4807c2);
    });
  });
}
const DOMAIN = "building-alarms", VERSION = 1;
async function getActiveAlarms() {
  const _0x387a9d = _0x125d1c, _0x8a9dcb = await storage[_0x387a9d(488)]({ "domain": DOMAIN, "version": VERSION, "scope": "global", "backend": _0x387a9d(636) });
  return (_0x8a9dcb == null ? void 0 : _0x8a9dcb["alarms"]) || [];
}
async function saveActiveAlarms(_0x4af0a7) {
  const _0x4dd163 = _0x125d1c;
  await storage[_0x4dd163(598)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x4dd163(571), "backend": "chrome", "data": { "alarms": _0x4af0a7 } });
}
let addAlarmQueue = Promise[_0x125d1c(546)]();
function addAlarm(_0x47a7f9, _0x5493c5, _0x47bf9b, _0x582b7f, _0x7dcd15) {
  const _0x282169 = _0x125d1c;
  return addAlarmQueue = addAlarmQueue[_0x282169(644)](async () => {
    const _0xced48e = _0x282169, _0x36a7e7 = await getActiveAlarms(), _0x282dbc = _0x36a7e7[_0xced48e(530)]((_0x2801ab) => {
      const _0x22e5ba = _0xced48e;
      if (_0x47bf9b && _0x2801ab["buildingId"]) return _0x2801ab[_0x22e5ba(641)] !== _0x47bf9b;
      return _0x2801ab[_0x22e5ba(515)] !== _0x47a7f9;
    });
    _0x282dbc[_0xced48e(643)]({ "alarmId": _0x47a7f9, "buildingName": _0x5493c5, "buildingId": _0x47bf9b, "finishTimeMs": _0x582b7f, "translatedMessage": _0x7dcd15 }), await saveActiveAlarms(_0x282dbc);
  })[_0x282169(554)](console[_0x282169(482)]), addAlarmQueue;
}
async function removeAlarm(_0x2895f7) {
  const _0x54cd8d = _0x125d1c, _0x2d9a21 = await getActiveAlarms(), _0x40ffb6 = _0x2d9a21[_0x54cd8d(530)]((_0x33b140) => _0x33b140[_0x54cd8d(515)] !== _0x2895f7);
  _0x2d9a21[_0x54cd8d(533)] !== _0x40ffb6["length"] && await saveActiveAlarms(_0x40ffb6);
}
async function clearExpiredAlarms() {
  const _0x3e351e = _0x125d1c, _0x5ad1dc = await getActiveAlarms(), _0x1e1006 = Date[_0x3e351e(495)](), _0x2e101c = _0x5ad1dc[_0x3e351e(530)]((_0x44d8fe) => _0x44d8fe["finishTimeMs"] > _0x1e1006);
  _0x5ad1dc[_0x3e351e(533)] !== _0x2e101c[_0x3e351e(533)] && await saveActiveAlarms(_0x2e101c);
}
const KEY_WHATS_NEW = _0x125d1c(508), KEY_LAST_MINOR = _0x125d1c(509), KEY_LAST_VERSION = _0x125d1c(518), STORAGE_DOMAIN_WHATS_NEW = _0x125d1c(550), STORAGE_DOMAIN_WHATS_NEW_META = _0x125d1c(516), STORAGE_VERSION = 1;
async function setWhatsNew(_0x432783) {
  const _0x397d58 = _0x125d1c;
  await storage[_0x397d58(598)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": _0x397d58(571), "backend": _0x397d58(636), "refreshAuth": ![], "data": _0x432783 }), await storage[_0x397d58(598)]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": "global", "backend": _0x397d58(636), "refreshAuth": ![], "data": { "minorKey": _0x432783[_0x397d58(572)], "lastVersion": _0x432783[_0x397d58(560)] } }), await storage[_0x397d58(575)](_0x397d58(636), KEY_WHATS_NEW), await storage[_0x397d58(575)](_0x397d58(636), KEY_LAST_MINOR), await storage["removeRaw"](_0x397d58(636), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0xc9c859 = _0x125d1c;
  return request(_0xc9c859(555), { "url": _0xc9c859(511), "credentials": "omit", "responseType": "json", "retries": 1, "retryDelayMs": 300 });
}
chrome["runtime"][_0x125d1c(506)][_0x125d1c(548)](async (_0x1254f0) => {
  const _0x228ad5 = _0x125d1c;
  await initializeDataPlatform();
  _0x1254f0[_0x228ad5(538)] === _0x228ad5(635) && await storage[_0x228ad5(598)]({ "domain": "welcome-message", "version": 1, "scope": _0x228ad5(571), "backend": "chrome", "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x1254f0["reason"] === _0x228ad5(485) && _0x1254f0[_0x228ad5(608)]) {
    const _0x4e2e8e = chrome[_0x228ad5(564)][_0x228ad5(487)]()[_0x228ad5(522)];
    if (_0x4e2e8e !== _0x1254f0[_0x228ad5(608)]) try {
      const _0x56c45e = await fetchAllReleases();
      let _0xc3d650 = [];
      const _0x338414 = releasePageUrl(_0x4e2e8e);
      _0x56c45e && Array["isArray"](_0x56c45e) && (_0xc3d650 = collectHighlightsFromReleases(_0x56c45e, _0x1254f0[_0x228ad5(608)], _0x4e2e8e)), await setWhatsNew({ "show": !![], "version": _0x4e2e8e, "url": _0x338414, "highlights": _0xc3d650, "error": !_0x56c45e || !Array["isArray"](_0x56c45e), "minorKey": minorKey(_0x4e2e8e), "lastVersion": _0x4e2e8e });
    } catch (_0x58d816) {
      console[_0x228ad5(482)]("Failed to fetch release notes:", _0x58d816), await setWhatsNew({ "show": !![], "version": _0x4e2e8e, "url": releasePageUrl(_0x4e2e8e), "highlights": [], "error": !![], "minorKey": minorKey(_0x4e2e8e), "lastVersion": _0x4e2e8e });
    }
  }
});
function _0x4e47() {
  const _0x5cfdc9 = ["rKvuq0HFq09puevsx0rbvee", "D2LUzg93swq", "D2LUzg93CW", "DxjS", "uMvXDwvZDcb0Aw1LB3v0", "zg9JCW", "ChjVzhvJDgLVBK1VzgLMAwvY", "C2v0", "yM9KEq", "q29VCgvYiefqssbLCNjVCJOG", "q09puevsx0LguKfnrv9srvnvtfq", "ntG2mJu5ohPzz2LUwG", "zMLUywXSEq", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "sfruuf9fuLjpuG", "yxv0AenVBxbHBNK", "zMvHDa", "ChjLDMLVDxnwzxjZAw9U", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "nZy4nZC1mMTruw13DW", "C2v0sxrLBq", "C2nVCgvlzxK", "CMvHBg1jza", "ChjLCMvSzwfZzq", "zgvMyxvSDa", "AgfZ", "qsbIDwLSzgLUzW", "C3rYAw5N", "DgfNx25HBwu", "C3rHCNrZv2L0Aa", "odG5odL5z2PZz3u", "y29HBgvZy2vlzxK", "DhjPBq", "Dw5RBM93BG", "CMvTB3zLsxrLBq", "C2n4oG", "DMfSDwu", "C29YDa", "mtjbtM15rva", "zML4", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "mJD2AeXZwey", "Cg9WDxa", "BwvZC2fNzq", "Aw5ZDgfSBa", "y2HYB21L", "mLjUD0Pzzq", "y29HBgvZy2u", "AxngAw5PDgu", "l2v4zwn1DgL2zxm/", "yNvPBgrPBMDjza", "uMvXDwvZDcbMywLSzwq", "ChvZAa", "DgHLBG", "Dw5KzwzPBMvK", "qwjVCNrfCNjVCG", "y3jLyxrL", "yMXVyG", "y29TCgfUEuLK", "CMvTywLUAw5Ntxm", "C2nVCgu", "C2fSzxnnB2rPzMLLCG", "z2v0sxrLBq", "zxjYB3i", "mtu5ndaYCuXfy2vl", "Bwf0y2G", "DxbKyxrL", "C2LTy28TBwfUywDLCG", "z2v0twfUAwzLC3q", "z2v0", "r0vu", "ANnVBG", "vxbKyxrLza", "AwnVBNmVndGUCg5N", "rML4zwq", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "BM93", "C3rVCMfNzq", "BwfW", "tMv3", "C3rYAw5NAwz5", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "Aw5JBhvKzxm", "yxjYyxLcDwzMzxi", "BMfTzq", "qujpuLrfra", "l3bOyxnLCW", "B25jBNn0ywXSzwq", "C3bSAxq", "C2n4lxDOyxrZlw5LDW", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "y2XLyw51Ca", "Ahr0Chm6lY9HCgKUz2L0AhvIlMnVBs9YzxbVCY9nDwHHBw1LDez1CMTHBLLPBg1HEI9ZAw1JBY1Tyw5Hz2vYl3jLBgvHC2vZp3bLCL9WywDLpteWma", "Aw5JBhvKzq", "Bwf4", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "ywXHCM1jza", "D2HHDhmTBMv3lw1LDge", "zMLUza", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "zMXVB3i", "DgvZDa", "CgfYC2u", "DMvYC2LVBG", "C2n4lwfSyxjTlq", "Bg9JywW", "rKvuq0HFu0Lnq09ut09mu19fwevdvvrjvKvt", "yxv0Aa", "ndvYyNvXA3m", "CMvZCg9UC2u", "mte2EfnhtwHr", "zMLSDgvY", "uKfurv9msu1jvf9dt09mre9xtJO", "CMvTB3zL", "BgvUz3rO", "C2n4", "Bg9HzgvK", "DhLWzq", "zgf0yq", "CMvHC29U", "mteXmJy4mgzRBgD2wq", "AgfZu2nVCgu", "Bw9Kzq", "C3rHDhvZ", "tKvuv09ss19fuLjpuG", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l3jLDgfPBd9Zy3HFCgfYyw1Zpq", "C2LTy290B29SCW", "CMvZB2X2zq", "yxnZAwDU", "ywrKtgLZDgvUzxi", "Bgv2zwXjBMzV", "D2HHDhmTBMv3", "nte4nZmWuuTtANfc", "DhrStxm", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "y2f0y2G", "z2L0AhvIlxjLBgvHC2vZ", "B25nzxnZywDL", "zgvSzxrL", "ywXHCM1Z", "Bwv0Ag9K", "BgfZDfzLCNnPB24", "y29Kzq", "zxHWzxjPzw5Jzq", "DgfI", "CNvUDgLTzq", "CMvWBgfJzq", "rKvuq0HFu0Lnq09ut09mu19qseftrvm", "zg9TywLU", "l3jLBgvHC2vZl3rHzY92", "C2XPy2u", "C2n4lwj1AwXKAw5NCY10CW", "z2XVyMfS", "BwLUB3jlzxK", "B21PDa", "rKvuq0HFu0Lnq09ut09mu19tvefuu19cvuLmreLor1m", "CMvTB3zLuMf3", "yMXVy2TLza", "AxnbCNjHEq", "Bg9HzgLUzW", "zNvUy3rPB24", "veLnru9vva", "y2vPBa", "A2v5", "ygbG", "Dg9mB3DLCKnHC2u", "y29TCgfUEq", "l3n0yxrZl2j1AwXKAw5NCW", "C2nVCgvK", "mJK3mJmYndnuz29UAKG", "zw50CMLLCW", "BgLZDej5uhjLzML4"];
  _0x4e47 = function() {
    return _0x5cfdc9;
  };
  return _0x4e47();
}
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x2ce525) {
  const _0x4c306e = _0x125d1c, _0x5bf1e3 = Date["now"]();
  if (cooperDataCache[_0x2ce525] && cooperDataCacheTs[_0x2ce525] && _0x5bf1e3 - cooperDataCacheTs[_0x2ce525] < COOPER_CACHE_TTL) return cooperDataCache[_0x2ce525];
  const _0x288b85 = "r" + (_0x2ce525 + 1), _0xa6d7d0 = await fetch(_0x4c306e(514) + _0x288b85);
  if (!_0xa6d7d0["ok"]) throw new Error(_0x4c306e(600) + _0xa6d7d0[_0x4c306e(542)]);
  const _0x25b851 = await _0xa6d7d0[_0x4c306e(490)]();
  return cooperDataCache[_0x2ce525] = _0x25b851, cooperDataCacheTs[_0x2ce525] = _0x5bf1e3, _0x25b851;
}
chrome["runtime"][_0x125d1c(556)][_0x125d1c(548)]((_0x26c52c, _0x41826e, _0x22807b) => {
  const _0x37d41e = _0x125d1c;
  if (_0x26c52c["type"] === _0x37d41e(591)) return fetchCooperData(_0x26c52c[_0x37d41e(613)])[_0x37d41e(644)]((_0x5b87d1) => _0x22807b({ "success": !![], "data": _0x5b87d1 }))[_0x37d41e(554)]((_0x55219e) => _0x22807b({ "success": ![], "error": _0x55219e[_0x37d41e(634)] })), !![];
  if (_0x26c52c["type"] === _0x37d41e(494)) {
    const _0xd47c4a = _0x26c52c[_0x37d41e(613)], _0x3a1ddc = _0x37d41e(553) + _0xd47c4a + "/market/vwaps";
    return request(_0x37d41e(545), { "url": _0x3a1ddc, "method": _0x37d41e(489), "credentials": _0x37d41e(573), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x37d41e(644)]((_0x44c236) => _0x22807b({ "success": !![], "data": _0x44c236 }))[_0x37d41e(554)]((_0x2db386) => _0x22807b({ "success": ![], "error": _0x2db386[_0x37d41e(634)] || String(_0x2db386) })), !![];
  }
  if (_0x26c52c["type"] === _0x37d41e(525)) {
    const { realmId: _0x55d99c, queryParams: _0x4a7383, headers: _0x276a2a } = _0x26c52c, _0x4a41c8 = _0x37d41e(553) + _0x55d99c + _0x37d41e(640) + _0x4a7383;
    return request(_0x37d41e(545), { "url": _0x4a41c8, "method": "GET", "headers": _0x276a2a, "credentials": _0x37d41e(573), "responseType": _0x37d41e(490), "retries": 2, "retryDelayMs": 1e3 })[_0x37d41e(644)]((_0x197379) => _0x22807b({ "success": !![], "data": _0x197379 }))["catch"]((_0x4eb879) => _0x22807b({ "success": ![], "error": _0x4eb879["message"] || String(_0x4eb879) })), !![];
  }
  if (_0x26c52c[_0x37d41e(536)] === _0x37d41e(574)) {
    const { realmId: _0x219661, headers: _0x3108eb } = _0x26c52c, _0x5815bd = "https://api.simcotools.com/v1/realms/" + _0x219661 + _0x37d41e(586);
    return request("simcotools", { "url": _0x5815bd, "method": _0x37d41e(489), "headers": _0x3108eb, "credentials": "omit", "responseType": _0x37d41e(490), "retries": 2, "retryDelayMs": 1e3 })[_0x37d41e(644)]((_0x51b43f) => _0x22807b({ "success": !![], "data": _0x51b43f }))[_0x37d41e(554)]((_0x59beac) => _0x22807b({ "success": ![], "error": _0x59beac[_0x37d41e(634)] || String(_0x59beac) })), !![];
  }
  if (_0x26c52c[_0x37d41e(536)] === _0x37d41e(566)) {
    const { realmId: _0x178347, headers: _0x4f378a } = _0x26c52c, _0x1596f4 = _0x37d41e(553) + _0x178347 + _0x37d41e(505);
    return request(_0x37d41e(545), { "url": _0x1596f4, "method": _0x37d41e(489), "headers": _0x4f378a, "credentials": _0x37d41e(573), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x37d41e(644)]((_0x370057) => _0x22807b({ "success": !![], "data": _0x370057 }))["catch"]((_0xd3ca9c) => _0x22807b({ "success": ![], "error": _0xd3ca9c[_0x37d41e(634)] || String(_0xd3ca9c) })), !![];
  }
  if (_0x26c52c["type"] === "SCRAPE_COOPER_RETAIL") return scrapeCooperRetail(_0x26c52c["params"])["then"]((_0x330fd0) => _0x22807b({ "success": !![], "data": _0x330fd0 }))[_0x37d41e(554)]((_0x398691) => _0x22807b({ "success": ![], "error": _0x398691[_0x37d41e(634)] })), !![];
  if (_0x26c52c[_0x37d41e(536)] === "SET_BUILDING_ALARM") {
    const { buildingName: _0x379e1e, buildingId: _0x49b423, finishTimeMs: _0x18cc93, translatedMessage: _0x2efc1a } = _0x26c52c[_0x37d41e(537)], _0x26b955 = "scx-alarm-" + Date["now"]() + "-" + Math[_0x37d41e(519)](Math["random"]() * 1e3);
    return chrome[_0x37d41e(558)][_0x37d41e(475)](_0x26b955, { "when": _0x18cc93 }), addAlarm(_0x26b955, _0x379e1e, _0x49b423, _0x18cc93, _0x2efc1a)[_0x37d41e(554)](console["error"]), _0x22807b({ "success": !![], "alarmId": _0x26b955 }), !![];
  }
  if (_0x26c52c[_0x37d41e(536)] === _0x37d41e(604)) {
    const { alarmId: _0x20d2f1 } = _0x26c52c["data"];
    return chrome[_0x37d41e(558)]["clear"](_0x20d2f1), removeAlarm(_0x20d2f1)[_0x37d41e(554)](console[_0x37d41e(482)]), _0x22807b({ "success": !![] }), !![];
  }
}), chrome[_0x125d1c(558)]["onAlarm"][_0x125d1c(548)](async (_0x554ee2) => {
  const _0x54c5ac = _0x125d1c;
  if (_0x554ee2["name"]["startsWith"](_0x54c5ac(523))) {
    const _0xcad05c = await getActiveAlarms(), _0x442fbd = _0xcad05c[_0x54c5ac(517)]((_0x4365a7) => _0x4365a7[_0x54c5ac(515)] === _0x554ee2[_0x54c5ac(503)]), _0xb4c0fa = _0x442fbd ? _0x442fbd["buildingName"] : _0x54c5ac(617), _0x243c55 = (_0x442fbd == null ? void 0 : _0x442fbd["translatedMessage"]) || _0xb4c0fa + _0x54c5ac(631);
    chrome["notifications"][_0x54c5ac(475)](_0x554ee2[_0x54c5ac(503)], { "type": "basic", "iconUrl": _0x54c5ac(492), "title": "SimCo Manager", "message": _0x243c55, "priority": 2 }), await removeAlarm(_0x554ee2[_0x54c5ac(503)]);
  }
}), chrome[_0x125d1c(558)][_0x125d1c(475)]("scx-cleanup-alarms", { "periodInMinutes": 60 }), chrome[_0x125d1c(558)]["onAlarm"]["addListener"]((_0x139548) => {
  const _0x3bcef6 = _0x125d1c;
  _0x139548["name"] === "scx-cleanup-alarms" && clearExpiredAlarms()[_0x3bcef6(554)](console[_0x3bcef6(482)]);
});
