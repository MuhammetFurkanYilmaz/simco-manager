(function(_0x3d66c9, _0x3d82f0) {
  var _0xa2a21c = _0x4223, _0x446bfc = _0x3d66c9();
  while (!![]) {
    try {
      var _0x4d1412 = parseInt(_0xa2a21c(285)) / 1 * (-parseInt(_0xa2a21c(282)) / 2) + parseInt(_0xa2a21c(289)) / 3 + -parseInt(_0xa2a21c(283)) / 4 * (-parseInt(_0xa2a21c(288)) / 5) + parseInt(_0xa2a21c(284)) / 6 * (parseInt(_0xa2a21c(290)) / 7) + parseInt(_0xa2a21c(287)) / 8 + parseInt(_0xa2a21c(292)) / 9 * (parseInt(_0xa2a21c(286)) / 10) + -parseInt(_0xa2a21c(291)) / 11;
      if (_0x4d1412 === _0x3d82f0) break;
      else _0x446bfc["push"](_0x446bfc["shift"]());
    } catch (_0x2bf53d) {
      _0x446bfc["push"](_0x446bfc["shift"]());
    }
  }
})(_0x2250, 563123);
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x2250() {
  var _0x41522a = ["mtmZBfrezxL6", "mty4mfrbzNH3zW", "ntaZmdq0mgTRvvH2sq", "mtqZmdvrzLrxENi", "nJeXotCWCfzOr0zN", "mtrUC1fWBhy", "nJKWodu5ngHqu256zq", "mtiYotrjs1j2r3K", "nJG2nNPQB3HXqW", "mJKYwMPXwuL5", "mteYotG5me1IAurzDW"];
  _0x2250 = function() {
    return _0x41522a;
  };
  return _0x2250();
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function _0x4223(_0x2c679c, _0x3146c0) {
  _0x2c679c = _0x2c679c - 282;
  var _0x225069 = _0x2250();
  var _0x4223c2 = _0x225069[_0x2c679c];
  if (_0x4223["TCpvKK"] === void 0) {
    var _0x5f182e = function(_0x56585f) {
      var _0x3d266a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x311436 = "", _0x1c5beb = "";
      for (var _0x385304 = 0, _0x3887b8, _0x3fa204, _0x4a4efd = 0; _0x3fa204 = _0x56585f["charAt"](_0x4a4efd++); ~_0x3fa204 && (_0x3887b8 = _0x385304 % 4 ? _0x3887b8 * 64 + _0x3fa204 : _0x3fa204, _0x385304++ % 4) ? _0x311436 += String["fromCharCode"](255 & _0x3887b8 >> (-2 * _0x385304 & 6)) : 0) {
        _0x3fa204 = _0x3d266a["indexOf"](_0x3fa204);
      }
      for (var _0x396759 = 0, _0x46e313 = _0x311436["length"]; _0x396759 < _0x46e313; _0x396759++) {
        _0x1c5beb += "%" + ("00" + _0x311436["charCodeAt"](_0x396759)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x1c5beb);
    };
    _0x4223["LXsxmB"] = _0x5f182e, _0x4223["tqBswy"] = {}, _0x4223["TCpvKK"] = !![];
  }
  var _0x1cea3a = _0x225069[0], _0x57dc96 = _0x2c679c + _0x1cea3a, _0xc23d59 = _0x4223["tqBswy"][_0x57dc96];
  return !_0xc23d59 ? (_0x4223c2 = _0x4223["LXsxmB"](_0x4223c2), _0x4223["tqBswy"][_0x57dc96] = _0x4223c2) : _0x4223c2 = _0xc23d59, _0x4223c2;
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
