(function(_0x4e2bb5, _0x209806) {
  var _0x3b9a21 = _0x3ca8, _0x5045a2 = _0x4e2bb5();
  while (!![]) {
    try {
      var _0x17aecd = -parseInt(_0x3b9a21(434)) / 1 + -parseInt(_0x3b9a21(440)) / 2 * (-parseInt(_0x3b9a21(436)) / 3) + -parseInt(_0x3b9a21(433)) / 4 * (parseInt(_0x3b9a21(438)) / 5) + parseInt(_0x3b9a21(432)) / 6 + -parseInt(_0x3b9a21(439)) / 7 + -parseInt(_0x3b9a21(435)) / 8 + parseInt(_0x3b9a21(437)) / 9;
      if (_0x17aecd === _0x209806) break;
      else _0x5045a2["push"](_0x5045a2["shift"]());
    } catch (_0x3b52ed) {
      _0x5045a2["push"](_0x5045a2["shift"]());
    }
  }
})(_0x20cb, 325149);
function _0x3ca8(_0x2c55b5, _0x437706) {
  _0x2c55b5 = _0x2c55b5 - 432;
  var _0x20cb3b = _0x20cb();
  var _0x3ca88c = _0x20cb3b[_0x2c55b5];
  if (_0x3ca8["USWBPm"] === void 0) {
    var _0x145963 = function(_0x3807b9) {
      var _0x36b5e1 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x17dd63 = "", _0xd2df7d = "";
      for (var _0x5e5b82 = 0, _0x1598f9, _0x30a9bb, _0x667cb1 = 0; _0x30a9bb = _0x3807b9["charAt"](_0x667cb1++); ~_0x30a9bb && (_0x1598f9 = _0x5e5b82 % 4 ? _0x1598f9 * 64 + _0x30a9bb : _0x30a9bb, _0x5e5b82++ % 4) ? _0x17dd63 += String["fromCharCode"](255 & _0x1598f9 >> (-2 * _0x5e5b82 & 6)) : 0) {
        _0x30a9bb = _0x36b5e1["indexOf"](_0x30a9bb);
      }
      for (var _0x1fc94a = 0, _0xbc5f2c = _0x17dd63["length"]; _0x1fc94a < _0xbc5f2c; _0x1fc94a++) {
        _0xd2df7d += "%" + ("00" + _0x17dd63["charCodeAt"](_0x1fc94a)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0xd2df7d);
    };
    _0x3ca8["mNhVdy"] = _0x145963, _0x3ca8["WoIreq"] = {}, _0x3ca8["USWBPm"] = !![];
  }
  var _0x3a590a = _0x20cb3b[0], _0x515732 = _0x2c55b5 + _0x3a590a, _0x2673ed = _0x3ca8["WoIreq"][_0x515732];
  return !_0x2673ed ? (_0x3ca88c = _0x3ca8["mNhVdy"](_0x3ca88c), _0x3ca8["WoIreq"][_0x515732] = _0x3ca88c) : _0x3ca88c = _0x2673ed, _0x3ca88c;
}
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function _0x20cb() {
  var _0x1bb901 = ["mZK0mtq0oeHjEeLewq", "ndeWnJzbs0jPz3a", "nZK3ntjxwwnvEuW", "mtqYmZqYoefrDLDvwq", "ndCWnJCXz1DKsvPt", "mtCZnteZnKLZzuvKyq", "otn0zxrXDfa", "mte1mZyZnJjQrgvZDeO", "nuLrzNPjDG"];
  _0x20cb = function() {
    return _0x1bb901;
  };
  return _0x20cb();
}
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
