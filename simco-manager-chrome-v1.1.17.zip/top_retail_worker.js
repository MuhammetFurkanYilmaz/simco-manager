function _0x1225() {
  const _0x4fe0df = ["ChbOCgW", "mtq4whv5DvPe", "ChjVzhvJDeLK", "mJrTEMfHthq", "ChjVzhvJDe5HBwu", "mJaXnti1DhjLALfp", "nti4nLPurK1nBG", "mtmWotGYng95rvL0BW", "BwvZC2fNzq", "B25TzxnZywDL", "Bwf4", "BwLU", "uhjVzhvJDca", "ng9MvxL4zq", "C2f0DxjHDgLVBG", "Cg9ZDe1LC3nHz2u", "odq3odi5nhf1svDRrq", "ntyXohnpqM5Wqq", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "y2fSy3vSyxrL", "CM91BMq", "Dg9mB3DLCKnHC2u", "CMvJzxnZAw9U", "C29YDa", "mJmYmdK0ohjKv0DQwq", "mJaWnwPKB3ryDa", "Dg9gAxHLza", "y29ZDa", "ndyXmJq1mfjyBfDtDq", "CMvZDwX0"];
  _0x1225 = function() {
    return _0x4fe0df;
  };
  return _0x1225();
}
const _0x516c67 = _0x277e;
function _0x277e(_0x2396a4, _0x44c5ba) {
  _0x2396a4 = _0x2396a4 - 380;
  const _0x122542 = _0x1225();
  let _0x277e71 = _0x122542[_0x2396a4];
  if (_0x277e["BylDHD"] === void 0) {
    var _0x26555a = function(_0x475ca9) {
      const _0x94c51d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x837fd0 = "", _0x4ef558 = "";
      for (let _0x492453 = 0, _0x472bbc, _0x402dae, _0x22b9c3 = 0; _0x402dae = _0x475ca9["charAt"](_0x22b9c3++); ~_0x402dae && (_0x472bbc = _0x492453 % 4 ? _0x472bbc * 64 + _0x402dae : _0x402dae, _0x492453++ % 4) ? _0x837fd0 += String["fromCharCode"](255 & _0x472bbc >> (-2 * _0x492453 & 6)) : 0) {
        _0x402dae = _0x94c51d["indexOf"](_0x402dae);
      }
      for (let _0x1dafc1 = 0, _0x4482cd = _0x837fd0["length"]; _0x1dafc1 < _0x4482cd; _0x1dafc1++) {
        _0x4ef558 += "%" + ("00" + _0x837fd0["charCodeAt"](_0x1dafc1)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x4ef558);
    };
    _0x277e["awdWCk"] = _0x26555a, _0x277e["bIfJOp"] = {}, _0x277e["BylDHD"] = !![];
  }
  const _0x54650e = _0x122542[0], _0x207491 = _0x2396a4 + _0x54650e, _0x296d29 = _0x277e["bIfJOp"][_0x207491];
  return !_0x296d29 ? (_0x277e71 = _0x277e["awdWCk"](_0x277e71), _0x277e["bIfJOp"][_0x207491] = _0x277e71) : _0x277e71 = _0x296d29, _0x277e71;
}
(function(_0x247907, _0x1accd4) {
  const _0x51809d = _0x277e, _0x108388 = _0x247907();
  while (!![]) {
    try {
      const _0x3aed7f = -parseInt(_0x51809d(384)) / 1 * (-parseInt(_0x51809d(398)) / 2) + parseInt(_0x51809d(402)) / 3 * (-parseInt(_0x51809d(380)) / 4) + parseInt(_0x51809d(392)) / 5 * (parseInt(_0x51809d(403)) / 6) + parseInt(_0x51809d(391)) / 7 + parseInt(_0x51809d(400)) / 8 * (parseInt(_0x51809d(404)) / 9) + -parseInt(_0x51809d(395)) / 10 + -parseInt(_0x51809d(383)) / 11;
      if (_0x3aed7f === _0x1accd4) break;
      else _0x108388["push"](_0x108388["shift"]());
    } catch (_0x51be27) {
      _0x108388["push"](_0x108388["shift"]());
    }
  }
})(_0x1225, 238011), self[_0x516c67(406)] = async (_0x837fd0) => {
  const _0x46684e = _0x516c67, { action: _0x4ef558, products: _0x492453, adminOverhead: _0x472bbc, salesBonus: _0x402dae, economyPhase: _0x22b9c3, simulateError: _0x1dafc1 } = _0x837fd0["data"];
  if (_0x4ef558 === _0x46684e(386)) {
    if (_0x1dafc1) {
      self[_0x46684e(382)]({ "error": _0x46684e(385) });
      return;
    }
    try {
      const _0x4482cd = _0x472bbc !== void 0 ? _0x472bbc : 0, _0xd2d19b = _0x402dae !== void 0 ? _0x402dae : 0, _0x368572 = _0x22b9c3 || "Normal", _0x54d363 = Math[_0x46684e(407)](0, Math[_0x46684e(408)](_0x4482cd, 200)), _0xc10386 = Math["max"](0, Math[_0x46684e(408)](_0xd2d19b, 50)), _0xca0306 = _0x368572[_0x46684e(388)]() === _0x46684e(389) ? 0.9 : _0x368572[_0x46684e(388)]() === "boom" ? 1.12 : 1, _0x471381 = [];
      for (const _0x3ff60b of _0x492453) {
        for (let _0x105c66 = 0; _0x105c66 <= 9; _0x105c66++) {
          const _0x167d4f = _0x105c66, _0x318137 = _0x3ff60b[_0x46684e(381)] <= 0 || _0x3ff60b["saturation"] == null ? 0.1 : Math[_0x46684e(407)](0.1, Math["min"](_0x3ff60b[_0x46684e(381)], 5)), _0x123a98 = 1 + _0x167d4f * 0.05, _0x353c7a = 100, _0x1e80f3 = _0x353c7a / _0x318137 * _0x123a98 * _0xca0306 * (1 + _0xc10386 / 100), _0x2814cb = _0x1e80f3 / 24, _0x1e1d6d = _0x3ff60b["averagePrice"] || _0x3ff60b["cost"] * 1.5, _0x59294f = _0x1e1d6d - _0x3ff60b[_0x46684e(394)], _0x4071c9 = _0x1e80f3 * _0x1e1d6d, _0x196967 = _0x4071c9 * (_0x54d363 / 100), _0x357ecf = _0x1e80f3 * _0x59294f - _0x196967;
          if (_0x357ecf < 0) continue;
          _0x471381["push"]({ "productId": _0x3ff60b["productId"], "productName": _0x3ff60b[_0x46684e(401)] || _0x46684e(409) + _0x3ff60b[_0x46684e(399)], "quality": _0x167d4f, "price": parseFloat(_0x1e1d6d[_0x46684e(393)](2)), "cost": parseFloat(_0x3ff60b[_0x46684e(394)]["toFixed"](2)), "profitPerUnit": parseFloat(_0x59294f[_0x46684e(393)](2)), "profitPerDay": Math["round"](_0x357ecf), "grossRevPerDay": Math[_0x46684e(387)](_0x4071c9), "unitsPerHr": parseFloat(_0x2814cb[_0x46684e(393)](1)), "unitsPerDay": Math[_0x46684e(387)](_0x1e80f3), "pphpl": _0x357ecf });
        }
      }
      _0x471381[_0x46684e(390)]((_0x46d77c, _0x5da0bc) => _0x5da0bc[_0x46684e(397)] - _0x46d77c[_0x46684e(397)]), self[_0x46684e(382)]({ "action": _0x46684e(396), "results": _0x471381 });
    } catch (_0x6d1ddc) {
      self[_0x46684e(382)]({ "error": _0x6d1ddc[_0x46684e(405)] });
    }
  }
};
