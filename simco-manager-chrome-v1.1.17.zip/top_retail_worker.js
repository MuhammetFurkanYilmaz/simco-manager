function _0x50e6(_0x56cb8f, _0x3c6b32) {
  _0x56cb8f = _0x56cb8f - 487;
  const _0x4194c4 = _0x4194();
  let _0x50e663 = _0x4194c4[_0x56cb8f];
  if (_0x50e6["OnLCAa"] === void 0) {
    var _0x48e06f = function(_0x4b7fbf) {
      const _0x46c235 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x14b89e = "", _0x4b9189 = "";
      for (let _0x3aef84 = 0, _0x22d8e5, _0x4ae698, _0x2d4639 = 0; _0x4ae698 = _0x4b7fbf["charAt"](_0x2d4639++); ~_0x4ae698 && (_0x22d8e5 = _0x3aef84 % 4 ? _0x22d8e5 * 64 + _0x4ae698 : _0x4ae698, _0x3aef84++ % 4) ? _0x14b89e += String["fromCharCode"](255 & _0x22d8e5 >> (-2 * _0x3aef84 & 6)) : 0) {
        _0x4ae698 = _0x46c235["indexOf"](_0x4ae698);
      }
      for (let _0x2d2d09 = 0, _0x192ce2 = _0x14b89e["length"]; _0x2d2d09 < _0x192ce2; _0x2d2d09++) {
        _0x4b9189 += "%" + ("00" + _0x14b89e["charCodeAt"](_0x2d2d09)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x4b9189);
    };
    _0x50e6["sHPsQp"] = _0x48e06f, _0x50e6["SDKgFd"] = {}, _0x50e6["OnLCAa"] = !![];
  }
  const _0x18831 = _0x4194c4[0], _0x5097f0 = _0x56cb8f + _0x18831, _0x313a13 = _0x50e6["SDKgFd"][_0x5097f0];
  return !_0x313a13 ? (_0x50e663 = _0x50e6["sHPsQp"](_0x50e663), _0x50e6["SDKgFd"][_0x5097f0] = _0x50e663) : _0x50e663 = _0x313a13, _0x50e663;
}
const _0x4b2fd4 = _0x50e6;
function _0x4194() {
  const _0x1413b5 = ["ChjVzhvJDeLK", "mJm4mJG3mK9WBu1NyW", "BwLU", "Bwf4", "Dg9gAxHLza", "nJz6C1rMvhK", "CM91BMq", "ChjVzhvJDe5HBwu", "n0PRyM16Dq", "y29ZDa", "uhjVzhvJDca", "zgf0yq", "y2fSy3vSyxrL", "CMvJzxnZAw9U", "C2f0DxjHDgLVBG", "ChvZAa", "ndK3odu4vgnrD2jd", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "odeXmtjTrvHLzha", "mJa0ode5zePcC2np", "Cg9ZDe1LC3nHz2u", "mti5odyXmhrRqvjSsW", "nw5eBKn2qq", "BwvZC2fNzq", "CMvZDwX0", "nde0nda5nND5sxHcAW", "ChbOCgW", "Dg9mB3DLCKnHC2u", "ndeWu2XlsMzi", "mty1odyXA0fHrerM", "yxzLCMfNzvbYAwnL", "B25TzxnZywDL"];
  _0x4194 = function() {
    return _0x1413b5;
  };
  return _0x4194();
}
(function(_0x2ad8c7, _0x48efd2) {
  const _0x25a40f = _0x50e6, _0x482b90 = _0x2ad8c7();
  while (!![]) {
    try {
      const _0x3c5ad4 = parseInt(_0x25a40f(490)) / 1 + parseInt(_0x25a40f(487)) / 2 + -parseInt(_0x25a40f(508)) / 3 * (-parseInt(_0x25a40f(489)) / 4) + -parseInt(_0x25a40f(493)) / 5 * (-parseInt(_0x25a40f(492)) / 6) + parseInt(_0x25a40f(511)) / 7 * (-parseInt(_0x25a40f(504)) / 8) + -parseInt(_0x25a40f(500)) / 9 * (parseInt(_0x25a40f(499)) / 10) + parseInt(_0x25a40f(496)) / 11;
      if (_0x3c5ad4 === _0x48efd2) break;
      else _0x482b90["push"](_0x482b90["shift"]());
    } catch (_0xcb5640) {
      _0x482b90["push"](_0x482b90["shift"]());
    }
  }
})(_0x4194, 439587), self[_0x4b2fd4(502)] = async (_0x14b89e) => {
  const _0x4656db = _0x4b2fd4, { action: _0x4b9189, products: _0x3aef84, adminOverhead: _0x22d8e5, salesBonus: _0x4ae698, economyPhase: _0x2d4639, simulateError: _0x2d2d09 } = _0x14b89e[_0x4656db(514)];
  if (_0x4b9189 === _0x4656db(515)) {
    if (_0x2d2d09) {
      self["postMessage"]({ "error": _0x4656db(488) });
      return;
    }
    try {
      const _0x192ce2 = _0x22d8e5 !== void 0 ? _0x22d8e5 : 0, _0x300f45 = _0x4ae698 !== void 0 ? _0x4ae698 : 0, _0x5ed593 = _0x2d4639 || "Normal", _0x16c61c = Math[_0x4656db(506)](0, Math[_0x4656db(505)](_0x192ce2, 200)), _0x199f36 = Math[_0x4656db(506)](0, Math[_0x4656db(505)](_0x300f45, 50)), _0x24f12b = _0x5ed593[_0x4656db(498)]() === _0x4656db(516) ? 0.9 : _0x5ed593[_0x4656db(498)]() === "boom" ? 1.12 : 1, _0x5cc036 = [];
      for (const _0x17d692 of _0x3aef84) {
        for (let _0x317de2 = 0; _0x317de2 <= 9; _0x317de2++) {
          const _0x284f08 = _0x317de2, _0x23ff96 = _0x17d692["saturation"] <= 0 || _0x17d692["saturation"] == null ? 0.1 : Math[_0x4656db(506)](0.1, Math[_0x4656db(505)](_0x17d692[_0x4656db(517)], 5)), _0x36ca50 = 1 + _0x284f08 * 0.05, _0x2ac28d = 100, _0x53200e = _0x2ac28d / _0x23ff96 * _0x36ca50 * _0x24f12b * (1 + _0x199f36 / 100), _0x3ef054 = _0x53200e / 24, _0x2bc6a0 = _0x17d692[_0x4656db(501)] || _0x17d692[_0x4656db(512)] * 1.5, _0x5d041f = _0x2bc6a0 - _0x17d692[_0x4656db(512)], _0x292c68 = _0x53200e * _0x2bc6a0, _0x33ca3a = _0x292c68 * (_0x16c61c / 100), _0x70a25a = _0x53200e * _0x5d041f - _0x33ca3a;
          if (_0x70a25a < 0) continue;
          _0x5cc036[_0x4656db(518)]({ "productId": _0x17d692[_0x4656db(503)], "productName": _0x17d692[_0x4656db(510)] || _0x4656db(513) + _0x17d692["productId"], "quality": _0x284f08, "price": parseFloat(_0x2bc6a0["toFixed"](2)), "cost": parseFloat(_0x17d692["cost"][_0x4656db(507)](2)), "profitPerUnit": parseFloat(_0x5d041f[_0x4656db(507)](2)), "profitPerDay": Math[_0x4656db(509)](_0x70a25a), "grossRevPerDay": Math[_0x4656db(509)](_0x292c68), "unitsPerHr": parseFloat(_0x3ef054[_0x4656db(507)](1)), "unitsPerDay": Math[_0x4656db(509)](_0x53200e), "pphpl": _0x70a25a });
        }
      }
      _0x5cc036["sort"]((_0x38001e, _0x154a12) => _0x154a12[_0x4656db(497)] - _0x38001e[_0x4656db(497)]), self[_0x4656db(491)]({ "action": _0x4656db(495), "results": _0x5cc036 });
    } catch (_0x55d5f7) {
      self[_0x4656db(491)]({ "error": _0x55d5f7[_0x4656db(494)] });
    }
  }
};
