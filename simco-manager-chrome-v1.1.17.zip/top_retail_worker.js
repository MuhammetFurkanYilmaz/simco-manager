const _0x2d88b2 = _0x55ab;
function _0x55ab(_0x2e1d2, _0x1bbeb5) {
  _0x2e1d2 = _0x2e1d2 - 137;
  const _0x3a9206 = _0x3a92();
  let _0x55ab01 = _0x3a9206[_0x2e1d2];
  if (_0x55ab["rloxjX"] === void 0) {
    var _0x3617dc = function(_0xbc169b) {
      const _0x63b44c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x26930a = "", _0x50d751 = "";
      for (let _0xe4df80 = 0, _0x2b2c8f, _0x281969, _0x2dc650 = 0; _0x281969 = _0xbc169b["charAt"](_0x2dc650++); ~_0x281969 && (_0x2b2c8f = _0xe4df80 % 4 ? _0x2b2c8f * 64 + _0x281969 : _0x281969, _0xe4df80++ % 4) ? _0x26930a += String["fromCharCode"](255 & _0x2b2c8f >> (-2 * _0xe4df80 & 6)) : 0) {
        _0x281969 = _0x63b44c["indexOf"](_0x281969);
      }
      for (let _0x598bc9 = 0, _0x4cb905 = _0x26930a["length"]; _0x598bc9 < _0x4cb905; _0x598bc9++) {
        _0x50d751 += "%" + ("00" + _0x26930a["charCodeAt"](_0x598bc9)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x50d751);
    };
    _0x55ab["OxUsVB"] = _0x3617dc, _0x55ab["qdwgEh"] = {}, _0x55ab["rloxjX"] = !![];
  }
  const _0x25ac3b = _0x3a9206[0], _0x2a90e8 = _0x2e1d2 + _0x25ac3b, _0xaa434 = _0x55ab["qdwgEh"][_0x2a90e8];
  return !_0xaa434 ? (_0x55ab01 = _0x55ab["OxUsVB"](_0x55ab01), _0x55ab["qdwgEh"][_0x2a90e8] = _0x55ab01) : _0x55ab01 = _0xaa434, _0x55ab01;
}
(function(_0x3a922e, _0x39b9b1) {
  const _0x2a45a1 = _0x55ab, _0x24585 = _0x3a922e();
  while (!![]) {
    try {
      const _0x17c4e7 = parseInt(_0x2a45a1(169)) / 1 * (parseInt(_0x2a45a1(157)) / 2) + -parseInt(_0x2a45a1(163)) / 3 * (parseInt(_0x2a45a1(140)) / 4) + -parseInt(_0x2a45a1(154)) / 5 + parseInt(_0x2a45a1(151)) / 6 + -parseInt(_0x2a45a1(162)) / 7 * (parseInt(_0x2a45a1(137)) / 8) + -parseInt(_0x2a45a1(166)) / 9 * (-parseInt(_0x2a45a1(156)) / 10) + parseInt(_0x2a45a1(138)) / 11 * (parseInt(_0x2a45a1(145)) / 12);
      if (_0x17c4e7 === _0x39b9b1) break;
      else _0x24585["push"](_0x24585["shift"]());
    } catch (_0x49441a) {
      _0x24585["push"](_0x24585["shift"]());
    }
  }
})(_0x3a92, 193179), self[_0x2d88b2(152)] = async (_0x26930a) => {
  const _0x1680d3 = _0x2d88b2, { action: _0x50d751, products: _0xe4df80, adminOverhead: _0x2b2c8f, salesBonus: _0x281969, economyPhase: _0x2dc650, simulateError: _0x598bc9 } = _0x26930a[_0x1680d3(164)];
  if (_0x50d751 === _0x1680d3(144)) {
    if (_0x598bc9) {
      self["postMessage"]({ "error": _0x1680d3(161) });
      return;
    }
    try {
      const _0x4cb905 = _0x2b2c8f !== void 0 ? _0x2b2c8f : 0, _0x148122 = _0x281969 !== void 0 ? _0x281969 : 0, _0x1e2565 = _0x2dc650 || "Normal", _0x313ac2 = Math[_0x1680d3(149)](0, Math[_0x1680d3(153)](_0x4cb905, 200)), _0x39bd7a = Math[_0x1680d3(149)](0, Math[_0x1680d3(153)](_0x148122, 50)), _0x589f15 = _0x1e2565["toLowerCase"]() === "recession" ? 0.9 : _0x1e2565[_0x1680d3(148)]() === _0x1680d3(146) ? 1.12 : 1, _0x56db4d = [];
      for (const _0x28df2a of _0xe4df80) {
        for (let _0x2035c9 = 0; _0x2035c9 <= 9; _0x2035c9++) {
          const _0x2e52d1 = _0x2035c9, _0x3b1463 = _0x28df2a[_0x1680d3(139)] <= 0 || _0x28df2a[_0x1680d3(139)] == null ? 0.1 : Math[_0x1680d3(149)](0.1, Math[_0x1680d3(153)](_0x28df2a[_0x1680d3(139)], 5)), _0xd9a93d = 1 + _0x2e52d1 * 0.05, _0x2078ea = 100, _0x5d632c = _0x2078ea / _0x3b1463 * _0xd9a93d * _0x589f15 * (1 + _0x39bd7a / 100), _0x23f5e7 = _0x5d632c / 24, _0x255623 = _0x28df2a[_0x1680d3(155)] || _0x28df2a[_0x1680d3(165)] * 1.5, _0x40aac0 = _0x255623 - _0x28df2a["cost"], _0x495cf8 = _0x5d632c * _0x255623, _0x80a97a = _0x495cf8 * (_0x313ac2 / 100), _0x13734c = _0x5d632c * _0x40aac0 - _0x80a97a;
          if (_0x13734c < 0) continue;
          _0x56db4d[_0x1680d3(150)]({ "productId": _0x28df2a[_0x1680d3(158)], "productName": _0x28df2a[_0x1680d3(159)] || "Product " + _0x28df2a[_0x1680d3(158)], "quality": _0x2e52d1, "price": parseFloat(_0x255623[_0x1680d3(147)](2)), "cost": parseFloat(_0x28df2a[_0x1680d3(165)][_0x1680d3(147)](2)), "profitPerUnit": parseFloat(_0x40aac0[_0x1680d3(147)](2)), "profitPerDay": Math[_0x1680d3(160)](_0x13734c), "grossRevPerDay": Math["round"](_0x495cf8), "unitsPerHr": parseFloat(_0x23f5e7[_0x1680d3(147)](1)), "unitsPerDay": Math[_0x1680d3(160)](_0x5d632c), "pphpl": _0x13734c });
        }
      }
      _0x56db4d[_0x1680d3(143)]((_0x17a232, _0x144a56) => _0x144a56[_0x1680d3(142)] - _0x17a232[_0x1680d3(142)]), self["postMessage"]({ "action": _0x1680d3(167), "results": _0x56db4d });
    } catch (_0x1203fc) {
      self[_0x1680d3(141)]({ "error": _0x1203fc[_0x1680d3(168)] });
    }
  }
};
function _0x3a92() {
  const _0x3e44b4 = ["y29ZDa", "mJyYote2mwf5uw5cua", "CMvZDwX0", "BwvZC2fNzq", "ntiWmwnNuxHZvq", "ofP6C3PuDq", "nJe1oty1owrsy0j6uG", "C2f0DxjHDgLVBG", "mtmWmtCYDvHRwKXX", "Cg9ZDe1LC3nHz2u", "ChbOCgW", "C29YDa", "y2fSy3vSyxrL", "mtjey2rqrK0", "yM9VBq", "Dg9gAxHLza", "Dg9mB3DLCKnHC2u", "Bwf4", "ChvZAa", "nteYntaYCfzgsuvh", "B25TzxnZywDL", "BwLU", "mtC0ndaYmePkEufnBG", "yxzLCMfNzvbYAwnL", "mtbbvMPxq3m", "ntb2r1vTqMS", "ChjVzhvJDeLK", "ChjVzhvJDe5HBwu", "CM91BMq", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "mJa4ndi5mLrWr2LuqW", "mJfTCenyDfy", "zgf0yq"];
  _0x3a92 = function() {
    return _0x3e44b4;
  };
  return _0x3a92();
}
