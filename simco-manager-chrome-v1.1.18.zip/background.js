const _0x470f55 = _0x2675;
(function(_0x4f8c43, _0x1b16c1) {
  const _0x4ba90a = _0x2675, _0x30db68 = _0x4f8c43();
  while (!![]) {
    try {
      const _0x5b8fe2 = -parseInt(_0x4ba90a(509)) / 1 * (-parseInt(_0x4ba90a(562)) / 2) + -parseInt(_0x4ba90a(447)) / 3 * (-parseInt(_0x4ba90a(549)) / 4) + -parseInt(_0x4ba90a(530)) / 5 * (parseInt(_0x4ba90a(556)) / 6) + -parseInt(_0x4ba90a(472)) / 7 + -parseInt(_0x4ba90a(553)) / 8 * (parseInt(_0x4ba90a(471)) / 9) + parseInt(_0x4ba90a(414)) / 10 * (-parseInt(_0x4ba90a(424)) / 11) + parseInt(_0x4ba90a(551)) / 12;
      if (_0x5b8fe2 === _0x1b16c1) break;
      else _0x30db68["push"](_0x30db68["shift"]());
    } catch (_0x39ca82) {
      _0x30db68["push"](_0x30db68["shift"]());
    }
  }
})(_0x4dc5, 536482);
const REPO_OWNER = _0x470f55(469), REPO_NAME = "simco-manager";
function parseVersion(_0x1df026) {
  const _0x3520da = _0x470f55, _0x11b0af = String(_0x1df026 || "")[_0x3520da(519)](/^v/i, "")["split"](".");
  return [Number(_0x11b0af[0] || 0), Number(_0x11b0af[1] || 0), Number(_0x11b0af[2] || 0)];
}
function compareVersions(_0x330faa, _0x318e83) {
  const [_0x1baa24, _0x5bce7d, _0x2ab0ab] = parseVersion(_0x330faa), [_0x1482ac, _0x3c7a88, _0x1d8cf1] = parseVersion(_0x318e83);
  if (_0x1baa24 !== _0x1482ac) return _0x1baa24 - _0x1482ac;
  if (_0x5bce7d !== _0x3c7a88) return _0x5bce7d - _0x3c7a88;
  return _0x2ab0ab - _0x1d8cf1;
}
function minorKey(_0x2170c9) {
  const _0x4daf71 = _0x470f55, _0x378785 = String(_0x2170c9 || "")[_0x4daf71(581)]("."), _0x18cd57 = _0x378785[0] || "0", _0x3188e4 = _0x378785[1] || "0";
  return _0x18cd57 + "." + _0x3188e4;
}
function releasePageUrl(_0x2311f8) {
  const _0x276ca2 = _0x470f55, _0x4a9c7e = String(_0x2311f8 || "")[_0x276ca2(503)]();
  return _0x276ca2(438) + REPO_OWNER + "/" + REPO_NAME + _0x276ca2(568) + encodeURIComponent(_0x4a9c7e);
}
function stripMarkdown(_0x9c03d6) {
  const _0x48a167 = _0x470f55;
  let _0x3e7085 = String(_0x9c03d6 || "");
  return _0x3e7085 = _0x3e7085[_0x48a167(519)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x3e7085 = _0x3e7085[_0x48a167(519)](/https?:\/\/\S+/gi, ""), _0x3e7085 = _0x3e7085[_0x48a167(519)](/[`*_>#]/g, ""), _0x3e7085 = _0x3e7085[_0x48a167(519)](/\s+/g, " ")[_0x48a167(503)](), _0x3e7085;
}
function humanizeHighlight(_0x308055) {
  const _0x5706ae = _0x470f55;
  let _0x2792c4 = stripMarkdown(_0x308055);
  _0x2792c4 = _0x2792c4[_0x5706ae(519)](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x2792c4 = _0x2792c4[_0x5706ae(519)](/\s+in\s*$/i, ""), _0x2792c4 = _0x2792c4[_0x5706ae(519)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x6a1f0c = _0x2792c4[_0x5706ae(559)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x6a1f0c) {
    const _0x24dcf8 = _0x6a1f0c[1][_0x5706ae(517)](), _0xe3f43e = _0x6a1f0c[3], _0x3f8b77 = _0x24dcf8 === _0x5706ae(442) ? _0x5706ae(504) : _0x24dcf8 === _0x5706ae(473) ? "Fixed" : _0x24dcf8 === _0x5706ae(571) ? _0x5706ae(567) : _0x24dcf8 === _0x5706ae(476) ? "Updated" : null;
    if (_0x3f8b77) _0x2792c4 = _0x3f8b77 + ": " + _0xe3f43e;
  }
  return _0x2792c4 = _0x2792c4["replace"](/\s+/g, " ")["trim"](), _0x2792c4;
}
function extractHighlights(_0x2c1768, { limit = 5 } = {}) {
  const _0x528333 = _0x470f55, _0x15e5be = String(_0x2c1768 || ""), _0x3b5220 = _0x15e5be[_0x528333(581)](/\r?\n/), _0x1041a0 = [];
  let _0x143daf = ![];
  for (const _0x5e682a of _0x3b5220) {
    const _0x43e31 = _0x5e682a["trim"]();
    if (_0x43e31[_0x528333(518)]("```")) {
      _0x143daf = !_0x143daf;
      continue;
    }
    if (_0x143daf) continue;
    if (!_0x43e31) continue;
    if (/^#+\s+/[_0x528333(465)](_0x43e31)) continue;
    const _0x638b2e = _0x43e31["match"](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x638b2e) {
      const _0x45c9ea = humanizeHighlight(_0x638b2e[2]);
      if (_0x45c9ea) _0x1041a0[_0x528333(457)](_0x45c9ea);
    }
    if (_0x1041a0[_0x528333(440)] >= limit) break;
  }
  return _0x1041a0[_0x528333(541)](0, limit);
}
function collectHighlightsFromReleases(_0x3eb31f, _0x41405d, _0x256e21, { limit = 10 } = {}) {
  const _0x3a7d3d = _0x470f55, _0x412e50 = (Array[_0x3a7d3d(545)](_0x3eb31f) ? _0x3eb31f : [])[_0x3a7d3d(526)]((_0x1eea58) => !(_0x1eea58 == null ? void 0 : _0x1eea58[_0x3a7d3d(446)]))[_0x3a7d3d(487)]((_0x5dc3ee) => ({ ..._0x5dc3ee, "tag_name": String((_0x5dc3ee == null ? void 0 : _0x5dc3ee[_0x3a7d3d(548)]) || "") }))[_0x3a7d3d(526)]((_0x21e362) => /^v?\d+\.\d+\.\d+$/[_0x3a7d3d(465)](_0x21e362["tag_name"]))[_0x3a7d3d(526)]((_0x863e68) => compareVersions(_0x863e68[_0x3a7d3d(548)], _0x41405d) > 0)["filter"]((_0x6c7397) => compareVersions(_0x6c7397[_0x3a7d3d(548)], _0x256e21) <= 0)[_0x3a7d3d(441)]((_0x4025f9, _0x7638ad) => compareVersions(_0x4025f9[_0x3a7d3d(548)], _0x7638ad[_0x3a7d3d(548)])), _0x5b6992 = [];
  for (const _0x104860 of _0x412e50) {
    const _0x33da59 = extractHighlights(_0x104860[_0x3a7d3d(466)], { "limit": limit });
    for (const _0x51d7ed of _0x33da59) {
      _0x5b6992[_0x3a7d3d(457)](_0x51d7ed);
      if (_0x5b6992["length"] >= limit) return _0x5b6992;
    }
  }
  return _0x5b6992[_0x3a7d3d(541)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x3027b9) {
  return new Promise((_0x454ebf) => setTimeout(_0x454ebf, _0x3027b9));
}
function normalizeDomain$1(_0x558cb1) {
  const _0x2ff2c5 = _0x470f55;
  return String(_0x558cb1 || _0x2ff2c5(456))[_0x2ff2c5(503)]()["toLowerCase"]();
}
function makeError(_0xb88666, _0x2aec5e = {}) {
  const _0x3b8f70 = _0x470f55, _0x383386 = new Error(_0xb88666);
  return Object[_0x3b8f70(448)](_0x383386, _0x2aec5e), _0x383386;
}
function buildInflightKey(_0x1e9c86, _0x16809e, _0x58fc02, _0x1e108d) {
  if (_0x16809e) return _0x1e9c86 + ":" + _0x16809e;
  return _0x1e9c86 + ":" + _0x1e108d + ":" + _0x58fc02;
}
function getRateLimitStatus(_0x3f4935 = _0x470f55(456)) {
  const _0x4c752d = _0x470f55, _0x441a24 = normalizeDomain$1(_0x3f4935), _0x444c2f = Number(rateLimitByDomain[_0x4c752d(420)](_0x441a24) || 0), _0x5ae66c = Math[_0x4c752d(484)](0, _0x444c2f - Date[_0x4c752d(493)]());
  return { "blocked": _0x5ae66c > 0, "remainingMs": _0x5ae66c, "blockedUntil": _0x444c2f };
}
async function parseResponse(_0x457026, _0x4837a9) {
  const _0x56fe11 = _0x470f55;
  if (_0x4837a9 === _0x56fe11(481)) return _0x457026;
  if (_0x4837a9 === _0x56fe11(482)) return _0x457026["text"]();
  if (_0x4837a9 === _0x56fe11(523)) return _0x457026["blob"]();
  if (_0x4837a9 === _0x56fe11(532)) return _0x457026[_0x56fe11(532)]();
  return _0x457026[_0x56fe11(555)]();
}
async function doRequest(_0x3d4d5b, _0x2c5aa1, _0x5ec05d = 0) {
  const _0x56f544 = _0x470f55, { url: _0x5b853d, method = _0x56f544(534), headers: _0x123d61, body: _0x12b79e, credentials = "include", signal: _0x5e4d28, responseType = _0x56f544(555), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x2c5aa1, _0x3cbd99 = getRateLimitStatus(_0x3d4d5b);
  if (_0x3cbd99[_0x56f544(452)]) throw makeError(_0x56f544(437) + Math[_0x56f544(506)](_0x3cbd99["remainingMs"] / 1e3), { "code": _0x56f544(485), "domain": _0x3d4d5b, "remainingMs": _0x3cbd99[_0x56f544(566)], "status": 429 });
  const _0x4cec35 = timeoutMs > 0 ? new AbortController() : null, _0x1b1dd8 = _0x4cec35 && timeoutMs > 0 ? setTimeout(() => _0x4cec35[_0x56f544(461)](makeError(_0x56f544(483), { "code": _0x56f544(419), "domain": _0x3d4d5b })), timeoutMs) : null, _0xfe822 = _0x4cec35 ? _0x4cec35[_0x56f544(516)] : _0x5e4d28;
  try {
    const _0x2e6c13 = await fetch(_0x5b853d, { "method": method, "headers": _0x123d61, "body": _0x12b79e, "credentials": credentials, "signal": _0xfe822 });
    if (_0x2e6c13["status"] === 429 && rateLimitCooldownMs > 0) {
      const _0x2807c5 = (rateLimitHitCount["get"](_0x3d4d5b) || 0) + 1;
      rateLimitHitCount["set"](_0x3d4d5b, _0x2807c5);
      const _0x56f69a = _0x2807c5 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x56f544(576)](_0x3d4d5b, Date["now"]() + _0x56f69a);
    }
    if (!_0x2e6c13["ok"]) {
      const _0xc8102e = _0x5ec05d < retries && retryStatuses[_0x56f544(460)](_0x2e6c13[_0x56f544(561)]);
      if (_0xc8102e) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x3d4d5b, _0x2c5aa1, _0x5ec05d + 1);
      }
      throw makeError("HTTP " + _0x2e6c13["status"], { "code": _0x56f544(411), "domain": _0x3d4d5b, "status": _0x2e6c13["status"] });
    }
    return rateLimitHitCount[_0x56f544(410)](_0x3d4d5b), parseResponse(_0x2e6c13, responseType);
  } catch (_0x2cbcfa) {
    const _0x32430a = (_0x2cbcfa == null ? void 0 : _0x2cbcfa[_0x56f544(467)]) === "AbortError", _0x1ac2ad = !_0x32430a && _0x5ec05d < retries;
    if (_0x1ac2ad) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x3d4d5b, _0x2c5aa1, _0x5ec05d + 1);
    }
    if (_0x2cbcfa instanceof Error && _0x2cbcfa["code"]) throw _0x2cbcfa;
    throw makeError(String((_0x2cbcfa == null ? void 0 : _0x2cbcfa[_0x56f544(510)]) || _0x2cbcfa || "Request failed"), { "code": _0x32430a ? _0x56f544(560) : _0x56f544(427), "domain": _0x3d4d5b, "status": Number((_0x2cbcfa == null ? void 0 : _0x2cbcfa["status"]) || 0) || null, "cause": _0x2cbcfa });
  } finally {
    if (_0x1b1dd8) clearTimeout(_0x1b1dd8);
  }
}
async function request(_0x48d04d, _0x58af94) {
  const _0x5c342b = _0x470f55, _0x536750 = normalizeDomain$1(_0x48d04d), _0x4598c1 = buildInflightKey(_0x536750, _0x58af94 == null ? void 0 : _0x58af94[_0x5c342b(459)], _0x58af94 == null ? void 0 : _0x58af94["url"], (_0x58af94 == null ? void 0 : _0x58af94[_0x5c342b(512)]) || _0x5c342b(534));
  if ((_0x58af94 == null ? void 0 : _0x58af94[_0x5c342b(443)]) && inflightByKey[_0x5c342b(547)](_0x4598c1)) return inflightByKey[_0x5c342b(420)](_0x4598c1);
  const _0x49c22b = doRequest(_0x536750, _0x58af94 || {})[_0x5c342b(570)](() => {
    const _0x3d78f7 = _0x5c342b;
    inflightByKey[_0x3d78f7(410)](_0x4598c1);
  });
  return (_0x58af94 == null ? void 0 : _0x58af94[_0x5c342b(443)]) && inflightByKey["set"](_0x4598c1, _0x49c22b), _0x49c22b;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0xaca539) {
  const _0x1c628d = _0x470f55, _0x4c9cd3 = _0xaca539 == null ? void 0 : _0xaca539[_0x1c628d(497)];
  STATE[_0x1c628d(529)][_0x1c628d(478)] = (_0x4c9cd3 == null ? void 0 : _0x4c9cd3[_0x1c628d(478)]) ?? null, STATE[_0x1c628d(529)][_0x1c628d(445)] = (_0x4c9cd3 == null ? void 0 : _0x4c9cd3[_0x1c628d(445)]) ?? null, STATE[_0x1c628d(529)][_0x1c628d(468)] = (_0x4c9cd3 == null ? void 0 : _0x4c9cd3[_0x1c628d(468)]) ?? null, STATE[_0x1c628d(529)]["salesModifier"] = (_0x4c9cd3 == null ? void 0 : _0x4c9cd3[_0x1c628d(584)]) ?? null, STATE["auth"][_0x1c628d(495)] = !![];
  const _0x356385 = _0xaca539 == null ? void 0 : _0xaca539["levelInfo"];
  STATE["levelInfo"][_0x1c628d(463)] = (_0x356385 == null ? void 0 : _0x356385[_0x1c628d(463)]) ?? null, STATE[_0x1c628d(539)]["experience"] = (_0x356385 == null ? void 0 : _0x356385[_0x1c628d(538)]) ?? null, STATE[_0x1c628d(539)][_0x1c628d(418)] = (_0x356385 == null ? void 0 : _0x356385[_0x1c628d(418)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x1375b2 = _0x470f55;
  if (!force && STATE[_0x1375b2(529)][_0x1375b2(495)] || STATE[_0x1375b2(529)][_0x1375b2(514)]) return;
  STATE["auth"]["loading"] = !![], STATE["auth"][_0x1375b2(432)] = null;
  try {
    const _0x5b32a9 = await request(_0x1375b2(529), { "url": "https://www.simcompanies.com/api/v3/companies/auth-data/", "credentials": "include", "responseType": _0x1375b2(555), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x5b32a9);
  } catch (_0x596b78) {
    STATE[_0x1375b2(529)][_0x1375b2(432)] = String((_0x596b78 == null ? void 0 : _0x596b78[_0x1375b2(510)]) || _0x596b78);
  } finally {
    STATE["auth"][_0x1375b2(514)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set(["scoped", _0x470f55(507), "global"]);
function normalizeScopeMode(_0x41ee9c) {
  const _0x25f80e = _0x470f55;
  if (VALID_SCOPE_MODES[_0x25f80e(547)](_0x41ee9c)) return _0x41ee9c;
  return _0x25f80e(525);
}
function numericOrNull(_0x9aa4b5) {
  const _0x4b2a71 = _0x470f55;
  if (_0x9aa4b5 === null || _0x9aa4b5 === void 0 || _0x9aa4b5 === "") return null;
  const _0x41f3ba = Number(_0x9aa4b5);
  return Number[_0x4b2a71(508)](_0x41f3ba) ? _0x41f3ba : null;
}
function resolveScopeSync(_0x9cf804 = "scoped") {
  var _a, _b;
  const _0x36c28a = _0x470f55, _0x2c66f1 = normalizeScopeMode(_0x9cf804), _0x5ac687 = numericOrNull((_a = STATE[_0x36c28a(529)]) == null ? void 0 : _a[_0x36c28a(478)]), _0x3c28d9 = numericOrNull((_b = STATE[_0x36c28a(529)]) == null ? void 0 : _b[_0x36c28a(445)]);
  if (_0x2c66f1 === "global") return { "mode": _0x2c66f1, "companyId": _0x5ac687, "realmId": _0x3c28d9, "hasScope": !![], "scopeKey": _0x36c28a(458) };
  if (_0x2c66f1 === _0x36c28a(507)) return { "mode": _0x2c66f1, "companyId": _0x5ac687, "realmId": _0x3c28d9, "hasScope": Number[_0x36c28a(508)](_0x5ac687), "scopeKey": Number[_0x36c28a(508)](_0x5ac687) ? String(_0x5ac687) : null };
  const _0x478bcd = Number[_0x36c28a(508)](_0x5ac687) && Number[_0x36c28a(508)](_0x3c28d9);
  return { "mode": _0x2c66f1, "companyId": _0x5ac687, "realmId": _0x3c28d9, "hasScope": _0x478bcd, "scopeKey": _0x478bcd ? _0x5ac687 + "-" + _0x3c28d9 : null };
}
async function resolveScope(_0x2030de = "scoped", { refreshAuth = ![] } = {}) {
  const _0x9c84f4 = normalizeScopeMode(_0x2030de);
  return refreshAuth && _0x9c84f4 !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x9c84f4);
}
const DEFAULT_PREFIX = _0x470f55(543);
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x2dfd15 = _0x470f55;
  try {
    return typeof chrome !== _0x2dfd15(500) && Boolean((_a = chrome == null ? void 0 : chrome[_0x2dfd15(429)]) == null ? void 0 : _a[_0x2dfd15(582)]);
  } catch {
    return ![];
  }
}
function parseJson(_0xe49287) {
  const _0x4e9413 = _0x470f55;
  if (_0xe49287 == null) return null;
  if (typeof _0xe49287 === _0x4e9413(480)) return _0xe49287;
  try {
    return JSON[_0x4e9413(470)](String(_0xe49287));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x94acf5, _0xa5c376) {
  const _0x452611 = _0x470f55;
  if (_0x94acf5 === _0x452611(502)) return _0xa5c376;
  return JSON[_0x452611(574)](_0xa5c376);
}
function isEnvelopeValid(_0x168733) {
  const _0x2fd1d1 = _0x470f55;
  return Boolean(_0x168733 && typeof _0x168733 === "object" && Number[_0x2fd1d1(508)](Number(_0x168733["v"])));
}
function isExpired(_0x12e424, _0x216c27 = null, _0x2045fb = Date[_0x470f55(493)]()) {
  const _0x3c05e9 = _0x470f55, _0x46d6db = Number((_0x12e424 == null ? void 0 : _0x12e424["ts"]) || 0), _0x2903a0 = Number(_0x12e424 == null ? void 0 : _0x12e424["ttlMs"]), _0x2792f5 = Number[_0x3c05e9(508)](_0x2903a0) ? _0x2903a0 : Number["isFinite"](Number(_0x216c27)) ? Number(_0x216c27) : null;
  if (!Number["isFinite"](_0x46d6db) || _0x46d6db <= 0) return ![];
  if (!Number[_0x3c05e9(508)](_0x2792f5) || _0x2792f5 <= 0) return ![];
  return _0x46d6db + _0x2792f5 < _0x2045fb;
}
function normalizeBackend(_0x5f1a3c) {
  const _0x48c1f3 = _0x470f55;
  return _0x5f1a3c === _0x48c1f3(502) ? _0x48c1f3(502) : _0x48c1f3(582);
}
function normalizePrefix(_0x2d16b2) {
  const _0x15859b = _0x470f55, _0x4d3c46 = String(_0x2d16b2 || DEFAULT_PREFIX)[_0x15859b(503)]();
  return _0x4d3c46[_0x15859b(440)] > 0 ? _0x4d3c46 : DEFAULT_PREFIX;
}
function normalizeDomain(_0x5c49ee) {
  const _0x262cf0 = _0x470f55;
  return String(_0x5c49ee || _0x262cf0(569))[_0x262cf0(503)]()[_0x262cf0(519)](/\s+/g, "-")[_0x262cf0(517)]();
}
function buildStorageKey({ domain: _0x159fcc, version: _0xf46df6, scopeKey: _0x3c5a5f, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x159fcc) + ":v" + Number(_0xf46df6) + ":" + _0x3c5a5f;
}
async function chromeGet(_0x488b19) {
  const _0x4405aa = _0x470f55;
  if (!hasChromeStorage()) return {};
  const _0x5d0221 = chrome["storage"][_0x4405aa(582)];
  try {
    const _0xce8c63 = _0x5d0221[_0x4405aa(420)](_0x488b19);
    if (_0xce8c63 && typeof _0xce8c63[_0x4405aa(491)] === _0x4405aa(494)) return _0xce8c63;
  } catch {
  }
  return new Promise((_0x870eb6) => {
    const _0x9ae88 = _0x4405aa;
    try {
      _0x5d0221[_0x9ae88(420)](_0x488b19, (_0x2f2fc6) => _0x870eb6(_0x2f2fc6 || {}));
    } catch {
      _0x870eb6({});
    }
  });
}
async function chromeSet(_0xa5a96d) {
  const _0x371d70 = _0x470f55;
  if (!hasChromeStorage()) return ![];
  const _0x4eb953 = chrome[_0x371d70(429)][_0x371d70(582)];
  try {
    const _0x3c951f = _0x4eb953[_0x371d70(576)](_0xa5a96d);
    if (_0x3c951f && typeof _0x3c951f[_0x371d70(491)] === "function") return await _0x3c951f, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x2d8dd5) => {
    const _0x4324d8 = _0x371d70;
    try {
      _0x4eb953[_0x4324d8(576)](_0xa5a96d, () => _0x2d8dd5(!![]));
    } catch {
      _0x2d8dd5(![]);
    }
  });
}
async function chromeRemove(_0x3bec09) {
  const _0x4e1b99 = _0x470f55;
  if (!hasChromeStorage()) return ![];
  const _0x2587c3 = chrome[_0x4e1b99(429)][_0x4e1b99(582)];
  try {
    const _0x323f55 = _0x2587c3["remove"](_0x3bec09);
    if (_0x323f55 && typeof _0x323f55[_0x4e1b99(491)] === _0x4e1b99(494)) return await _0x323f55, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x211b37) => {
    const _0x5ae2f0 = _0x4e1b99;
    try {
      _0x2587c3[_0x5ae2f0(451)](_0x3bec09, () => _0x211b37(!![]));
    } catch {
      _0x211b37(![]);
    }
  });
}
async function getRaw(_0x3ee571, _0x821ea) {
  const _0xf9432a = _0x470f55, _0x2cbc21 = normalizeBackend(_0x3ee571);
  if (_0x2cbc21 === _0xf9432a(582)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage["getItem"](_0x821ea);
    } catch {
      return null;
    }
  }
  const _0x2ffee9 = await chromeGet(_0x821ea);
  return (_0x2ffee9 == null ? void 0 : _0x2ffee9[_0x821ea]) ?? null;
}
function localGetItemSync(_0x419fde) {
  const _0x58ecc0 = _0x470f55;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x58ecc0(515)](_0x419fde);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x5ec4ce, _0x47bc87) {
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage["setItem"](_0x5ec4ce, String(_0x47bc87)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x569db8) {
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage["removeItem"](_0x569db8), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x3dd487 = "") {
  const _0x39e77 = _0x470f55;
  if (!hasLocalStorage()) return [];
  const _0x1beb0e = [], _0x515e41 = String(_0x3dd487 || "");
  try {
    for (let _0xe77f5b = 0; _0xe77f5b < localStorage[_0x39e77(440)]; _0xe77f5b += 1) {
      const _0x297790 = localStorage[_0x39e77(496)](_0xe77f5b);
      if (!_0x297790 || _0x515e41 && !_0x297790[_0x39e77(518)](_0x515e41)) continue;
      _0x1beb0e["push"]({ "key": _0x297790, "value": localStorage[_0x39e77(515)](_0x297790) });
    }
  } catch {
    return [];
  }
  return _0x1beb0e;
}
async function setRaw(_0x37a1fe, _0x4058bd, _0x550986) {
  const _0x3e98f8 = _0x470f55, _0xc97241 = normalizeBackend(_0x37a1fe);
  if (_0xc97241 === _0x3e98f8(582)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x3e98f8(546)](_0x4058bd, String(_0x550986)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x4058bd]: _0x550986 });
}
async function removeRaw(_0x4a98e9, _0x402f26) {
  const _0x3e214a = _0x470f55, _0xd7f8be = normalizeBackend(_0x4a98e9);
  if (_0xd7f8be === _0x3e214a(582)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["removeItem"](_0x402f26), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x402f26);
}
async function listByPrefix({ backend = _0x470f55(582), prefix = "" } = {}) {
  const _0x2b53f4 = _0x470f55, _0x278cd4 = normalizeBackend(backend), _0x3b5595 = String(prefix || "");
  if (_0x278cd4 === _0x2b53f4(582)) {
    if (!hasLocalStorage()) return [];
    const _0xa28ba8 = [];
    try {
      for (let _0x23c2ee = 0; _0x23c2ee < localStorage[_0x2b53f4(440)]; _0x23c2ee += 1) {
        const _0x8bdd1a = localStorage[_0x2b53f4(496)](_0x23c2ee);
        if (!_0x8bdd1a || _0x3b5595 && !_0x8bdd1a[_0x2b53f4(518)](_0x3b5595)) continue;
        _0xa28ba8[_0x2b53f4(457)]({ "key": _0x8bdd1a, "value": localStorage["getItem"](_0x8bdd1a) });
      }
    } catch {
      return [];
    }
    return _0xa28ba8;
  }
  const _0x2627ec = await chromeGet(null);
  return Object[_0x2b53f4(453)](_0x2627ec || {})[_0x2b53f4(526)](([_0x7aec65]) => _0x3b5595 ? _0x7aec65["startsWith"](_0x3b5595) : !![])["map"](([_0x147af6, _0x474afc]) => ({ "key": _0x147af6, "value": _0x474afc }));
}
async function get({ domain: _0x5a058a, version: _0x351e7d, scope = _0x470f55(525), backend = _0x470f55(582), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x364b68 = _0x470f55, _0x891de6 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x891de6[_0x364b68(550)] || !_0x891de6[_0x364b68(535)]) return null;
  const _0x2af23c = buildStorageKey({ "domain": _0x5a058a, "version": _0x351e7d, "scopeKey": _0x891de6["scopeKey"], "prefix": prefix }), _0x34109a = await getRaw(backend, _0x2af23c);
  if (_0x34109a == null) return null;
  const _0x277a51 = parseJson(_0x34109a);
  if (!isEnvelopeValid(_0x277a51)) return await removeRaw(backend, _0x2af23c), null;
  const _0x283f77 = Number(_0x277a51["v"]);
  if (_0x283f77 !== Number(_0x351e7d)) return _0x283f77 < Number(_0x351e7d) && await removeRaw(backend, _0x2af23c), null;
  if (isExpired(_0x277a51, ttlMs)) return await removeRaw(backend, _0x2af23c), null;
  const _0x94ae01 = _0x891de6[_0x364b68(535)], _0x39eb14 = String(((_a = _0x277a51 == null ? void 0 : _0x277a51[_0x364b68(552)]) == null ? void 0 : _a[_0x364b68(535)]) || "");
  if (_0x94ae01 && _0x39eb14 && _0x94ae01 !== _0x39eb14) return await removeRaw(backend, _0x2af23c), null;
  return _0x277a51["data"] ?? null;
}
async function set({ domain: _0x5e0789, version: _0x29a6d1, scope = "scoped", backend = _0x470f55(582), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x7f3bd5 } = {}) {
  const _0x514afb = _0x470f55, _0x5afae7 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5afae7["hasScope"] || !_0x5afae7[_0x514afb(535)]) return ![];
  const _0x312f52 = buildStorageKey({ "domain": _0x5e0789, "version": _0x29a6d1, "scopeKey": _0x5afae7[_0x514afb(535)], "prefix": prefix }), _0x3d03ee = { "v": Number(_0x29a6d1), "ts": Date[_0x514afb(493)](), "ttlMs": Number[_0x514afb(508)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x5afae7[_0x514afb(455)], "scopeKey": _0x5afae7["scopeKey"], "companyId": _0x5afae7[_0x514afb(478)], "realmId": _0x5afae7[_0x514afb(445)] }, "data": _0x7f3bd5 };
  return setRaw(backend, _0x312f52, toStorageRaw(normalizeBackend(backend), _0x3d03ee));
}
async function remove({ domain: _0x1b44c0, version: _0xd9615, scope = _0x470f55(525), backend = "local", prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x489a68 = _0x470f55, _0x6693b2 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x6693b2[_0x489a68(550)] || !_0x6693b2[_0x489a68(535)]) return ![];
  const _0xb8a21b = buildStorageKey({ "domain": _0x1b44c0, "version": _0xd9615, "scopeKey": _0x6693b2[_0x489a68(535)], "prefix": prefix });
  return removeRaw(backend, _0xb8a21b);
}
async function migrate({ domain: _0x59b01e, version: _0xe8a5a5, scope = _0x470f55(525), backend = _0x470f55(582), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x4f0349, cleanupLegacy = !![] } = {}) {
  const _0x5267bc = _0x470f55, _0x347796 = await get({ "domain": _0x59b01e, "version": _0xe8a5a5, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x347796 !== null && _0x347796 !== void 0) return { "data": _0x347796, "migrated": ![] };
  if (typeof _0x4f0349 !== "function") return { "data": null, "migrated": ![] };
  const _0x20519f = await _0x4f0349({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x40af92 = _0x20519f == null ? void 0 : _0x20519f[_0x5267bc(450)];
  if (_0x40af92 === null || _0x40af92 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x59b01e, "version": _0xe8a5a5, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x40af92 }), cleanupLegacy && typeof (_0x20519f == null ? void 0 : _0x20519f[_0x5267bc(434)]) === _0x5267bc(494) && await _0x20519f[_0x5267bc(434)](), { "data": _0x40af92, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x470f55(531), _0x470f55(436)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x21f0cd) {
  const _0x13ab47 = _0x470f55, _0x5e11d7 = String(_0x21f0cd || "")[_0x13ab47(581)](":");
  if (_0x5e11d7[_0x13ab47(440)] < 4) return null;
  if (_0x5e11d7[0] !== _0x13ab47(543)) return null;
  const _0x2ba285 = _0x5e11d7[1], _0x4f2d58 = _0x5e11d7[2] || "";
  if (!_0x4f2d58[_0x13ab47(518)]("v")) return null;
  const _0x42ca09 = Number(_0x4f2d58[_0x13ab47(541)](1));
  if (!Number["isFinite"](_0x42ca09)) return null;
  return { "domain": _0x2ba285, "version": _0x42ca09 };
}
async function cleanupVersionedEnvelopes(_0x4c4aeb) {
  const _0x4da543 = _0x470f55, _0x553c82 = await storage[_0x4da543(577)]({ "backend": _0x4c4aeb, "prefix": _0x4da543(521) });
  for (const _0x37e55f of _0x553c82) {
    const _0x268b74 = parseDomainAndVersion(_0x37e55f[_0x4da543(496)]);
    if (!_0x268b74) continue;
    const _0x1c162a = Number(MIN_DOMAIN_VERSION[_0x268b74[_0x4da543(537)]] || 1);
    if (_0x268b74[_0x4da543(513)] < _0x1c162a) {
      await storage[_0x4da543(492)](_0x4c4aeb, _0x37e55f[_0x4da543(496)]);
      continue;
    }
    if (_0x37e55f[_0x4da543(423)] == null) {
      await storage[_0x4da543(492)](_0x4c4aeb, _0x37e55f["key"]);
      continue;
    }
    const _0x329a41 = typeof _0x37e55f[_0x4da543(423)] === _0x4da543(511) ? (() => {
      const _0x228071 = _0x4da543;
      try {
        return JSON[_0x228071(470)](_0x37e55f[_0x228071(423)] || _0x228071(433));
      } catch {
        return null;
      }
    })() : _0x37e55f[_0x4da543(423)];
    if (!_0x329a41 || typeof _0x329a41 !== _0x4da543(480) || !Number[_0x4da543(508)](Number(_0x329a41["v"]))) {
      await storage[_0x4da543(492)](_0x4c4aeb, _0x37e55f["key"]);
      continue;
    }
    Number(_0x329a41["v"]) < _0x1c162a && await storage[_0x4da543(492)](_0x4c4aeb, _0x37e55f[_0x4da543(496)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x48f384 = _0x470f55;
  for (const _0xe0f493 of LEGACY_GLOBAL_KEYS) {
    await storage[_0x48f384(492)](_0x48f384(582), _0xe0f493), await storage[_0x48f384(492)](_0x48f384(502), _0xe0f493);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0xdf20ab = _0x470f55;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0xdf20ab(582)), await cleanupVersionedEnvelopes(_0xdf20ab(502)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
function _0x2675(_0xa21aa3, _0x18a655) {
  _0xa21aa3 = _0xa21aa3 - 409;
  const _0x4dc5ea = _0x4dc5();
  let _0x267512 = _0x4dc5ea[_0xa21aa3];
  if (_0x2675["dXcaqX"] === void 0) {
    var _0x5b6bf5 = function(_0x3d39e1) {
      const _0x12a471 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x1df026 = "", _0x11b0af = "";
      for (let _0x330faa = 0, _0x318e83, _0x1baa24, _0x5bce7d = 0; _0x1baa24 = _0x3d39e1["charAt"](_0x5bce7d++); ~_0x1baa24 && (_0x318e83 = _0x330faa % 4 ? _0x318e83 * 64 + _0x1baa24 : _0x1baa24, _0x330faa++ % 4) ? _0x1df026 += String["fromCharCode"](255 & _0x318e83 >> (-2 * _0x330faa & 6)) : 0) {
        _0x1baa24 = _0x12a471["indexOf"](_0x1baa24);
      }
      for (let _0x2ab0ab = 0, _0x1482ac = _0x1df026["length"]; _0x2ab0ab < _0x1482ac; _0x2ab0ab++) {
        _0x11b0af += "%" + ("00" + _0x1df026["charCodeAt"](_0x2ab0ab)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x11b0af);
    };
    _0x2675["tOFCDl"] = _0x5b6bf5, _0x2675["ZDlbKO"] = {}, _0x2675["dXcaqX"] = !![];
  }
  const _0x28f596 = _0x4dc5ea[0], _0x289cbc = _0xa21aa3 + _0x28f596, _0x29c0a0 = _0x2675["ZDlbKO"][_0x289cbc];
  return !_0x29c0a0 ? (_0x267512 = _0x2675["tOFCDl"](_0x267512), _0x2675["ZDlbKO"][_0x289cbc] = _0x267512) : _0x267512 = _0x29c0a0, _0x267512;
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x464961, _0x1469e4) {
  return new Promise((_0x4ee21f, _0x14732d) => {
    const _0x396363 = _0x2675;
    let _0x30fe27 = null;
    const _0xa8abaa = (_0x2e3c80, _0x4d9273, _0x29b0c5) => {
      const _0x2a5ced = _0x2675;
      if (_0x30fe27 !== null && _0x4d9273[_0x2a5ced(578)] && _0x4d9273[_0x2a5ced(578)][_0x2a5ced(421)] !== _0x30fe27) return;
      _0x2e3c80["type"] === "COOPER_IFRAME_RESULT" && (_0x49e024(), _0x2e3c80[_0x2a5ced(432)] ? _0x14732d(new Error(_0x2e3c80[_0x2a5ced(432)])) : _0x2e3c80[_0x2a5ced(450)] && _0x2e3c80[_0x2a5ced(450)]["length"] === 0 ? _0x4ee21f([]) : _0x4ee21f(_0x2e3c80[_0x2a5ced(450)]));
    };
    chrome[_0x396363(462)][_0x396363(486)][_0x396363(417)](_0xa8abaa);
    const _0x338ad9 = setTimeout(() => {
      const _0x113a5e = _0x396363;
      _0x49e024(), _0x14732d(new Error(_0x113a5e(522)));
    }, 25e3), _0x49e024 = () => {
      const _0x2e2d14 = _0x396363;
      clearTimeout(_0x338ad9), chrome[_0x2e2d14(462)][_0x2e2d14(486)][_0x2e2d14(490)](_0xa8abaa), _0x30fe27 !== null && chrome["windows"][_0x2e2d14(451)](_0x30fe27)[_0x2e2d14(415)](() => {
      });
    }, _0x122ed7 = encodeURIComponent(JSON["stringify"](_0x464961)), _0x2f6324 = _0x396363(575) + _0x122ed7;
    chrome["windows"][_0x396363(505)]({ "url": _0x2f6324, "type": _0x396363(563), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x396363(491)]((_0x476a2a) => {
      _0x30fe27 = _0x476a2a["id"];
    })["catch"]((_0x4af478) => {
      _0x49e024(), _0x14732d(_0x4af478);
    });
  });
}
const DOMAIN = "building-alarms", VERSION = 1;
async function getActiveAlarms() {
  const _0x30a1f8 = _0x470f55, _0x727187 = await storage[_0x30a1f8(420)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x30a1f8(458), "backend": _0x30a1f8(502) });
  return (_0x727187 == null ? void 0 : _0x727187["alarms"]) || [];
}
async function saveActiveAlarms(_0x16a680) {
  const _0x2fe888 = _0x470f55;
  await storage[_0x2fe888(576)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x2fe888(458), "backend": _0x2fe888(502), "data": { "alarms": _0x16a680 } });
}
function _0x4dc5() {
  const _0x5093e7 = ["yxv0Aa", "mtb1AhHiDhu", "C2n4lwj1AwXKAw5NCW", "yxjYyxLcDwzMzxi", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "r0vu", "C2nVCgvlzxK", "rMfPBgvKihrVigzLDgnOihjLBgvHC2uGBM90zxm6", "zg9TywLU", "zxHWzxjPzw5Jzq", "Bgv2zwXjBMzV", "BM90AwzPy2f0Aw9UCW", "C2XPy2u", "C2n4lwnSzwfUDxaTywXHCM1Z", "C2n4", "z2L0AhvIlxjLBgvHC2vZ", "AxnbCNjHEq", "C2v0sxrLBq", "AgfZ", "DgfNx25HBwu", "mJm1nJu0ogv3rfPNtq", "AgfZu2nVCgu", "nZuYnJaWngzhq2fmtG", "C2nVCgu", "mJmXnZi5nLjnqLDSCa", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "ANnVBG", "mtCYnJa1mefQqMDPzW", "B21PDa", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "Bwf0y2G", "qujpuLrfra", "C3rHDhvZ", "mZqXnZy0wLDYy1Lf", "Cg9WDxa", "y2XLyxi", "zMLUAxnOvgLTzu1Z", "CMvTywLUAw5Ntxm", "sw1WCM92zwq", "l3jLBgvHC2vZl3rHzY92", "Dw5RBM93BG", "zMLUywXSEq", "CgvYzG", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "C3rYAw5NAwz5", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l3jLDgfPBd9Zy3HFCgfYyw1Zpq", "C2v0", "BgLZDej5uhjLzML4", "DgfI", "rKvuq0HFu0Lnq09ut09mu19qseftrvm", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "C3bSAxq", "Bg9JywW", "zMLUza", "C2fSzxnnB2rPzMLLCG", "B25jBNn0ywXSzwq", "zgvSzxrL", "sfruuf9fuLjpuG", "rKvuq0HFq09puevsx0rbvee", "u2LTq28GtwfUywDLCG", "odC3me5ssKnhyW", "y2f0y2G", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "ywrKtgLZDgvUzxi", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "veLnru9vva", "z2v0", "D2LUzg93swq", "yMfZAwm", "DMfSDwu", "nty1ngLTrfP6zq", "ywXHCM1Z", "C2n4lwfSyxjTlq", "tKvuv09ss19fuLjpuG", "u0vux0jvsuXesu5hx0fmqvjn", "C3rVCMfNzq", "DhjHBNnSyxrLze1LC3nHz2u", "ywXHCM1jza", "zxjYB3i", "BNvSBa", "y2XLyw51Ca", "l21HCMTLDc92D2fWCW", "C2n4lwj1AwXKAw5NCY10CW", "uKfurv9msu1jvf9dt09mre9xtJO", "Ahr0Chm6lY9NAxrODwiUy29TlW", "rKvuq0HFu0Lnq09ut09mu19tvefuu19cvuLmreLor1m", "BgvUz3rO", "C29YDa", "zMvHDa", "y29HBgvZy2u", "C2LTy290B29SCW", "CMvHBg1jza", "ChjLCMvSzwfZzq", "m2nXB2zrrW", "yxnZAwDU", "z2v0twfUAwzLC3q", "zgf0yq", "CMvTB3zL", "yMXVy2TLza", "zw50CMLLCW", "Aw5ZDgfSBa", "Bw9Kzq", "zgvMyxvSDa", "ChvZAa", "z2XVyMfS", "y29HBgvZy2vlzxK", "Aw5JBhvKzxm", "ywjVCNq", "CNvUDgLTzq", "Bgv2zwW", "BgfZDfzLCNnPB24", "DgvZDa", "yM9KEq", "BMfTzq", "ChjVzhvJDgLVBK1VzgLMAwvY", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "CgfYC2u", "owPRuwvJsG", "mtuYota5ng92wwf2sW", "zML4", "l3n0yxrZl2j1AwXKAw5NCW", "yNvPBgrPBMDjza", "zg9JCW", "CgfYyw1Z", "y29TCgfUEuLK", "D2vSy29Tzs1TzxnZywDL", "B2jQzwn0", "CMvZCg9UC2u", "Dgv4Da", "uMvXDwvZDcb0Aw1LB3v0", "Bwf4", "uKfurv9msu1jvf9dt09mre9xtG", "B25nzxnZywDL", "BwfW", "l2v4zwn1DgL2zxm/", "Ahr0Chm6lY9HCgKUz2L0AhvIlMnVBs9YzxbVCY9nDwHHBw1LDez1CMTHBLLPBg1HEI9ZAw1JBY1Tyw5Hz2vYl3jLBgvHC2vZp3bLCL9WywDLpteWma", "CMvTB3zLtgLZDgvUzxi", "DgHLBG", "CMvTB3zLuMf3", "BM93", "zNvUy3rPB24", "Bg9HzgvK", "A2v5", "yxv0AenVBxbHBNK", "q29VCgvYiefqssbLCNjVCJOG", "DhLWzq", "Dw5KzwzPBMvK", "qsbIDwLSzgLUzW", "y2HYB21L", "DhjPBq", "tMv3", "y3jLyxrL", "y2vPBa", "y29TCgfUEq", "AxngAw5PDgu", "nuHrtvPyyG", "BwvZC2fNzq", "C3rYAw5N", "Bwv0Ag9K", "DMvYC2LVBG", "Bg9HzgLUzW", "z2v0sxrLBq", "C2LNBMfS", "Dg9mB3DLCKnHC2u", "C3rHCNrZv2L0Aa", "CMvWBgfJzq", "CMvZB2X2zq", "C2n4oG", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "yMXVyG", "D2HHDhmTBMv3lw1LDge", "C2nVCgvK", "zMLSDgvY", "ChjLDMLVDxnwzxjZAw9U", "CMfUzg9T"];
  _0x4dc5 = function() {
    return _0x5093e7;
  };
  return _0x4dc5();
}
let addAlarmQueue = Promise[_0x470f55(520)]();
function addAlarm(_0x2f4ea2, _0x366d2d, _0x16789d, _0x5f0741, _0x193b71) {
  const _0x1d4424 = _0x470f55;
  return addAlarmQueue = addAlarmQueue["then"](async () => {
    const _0x205f1f = _0x2675, _0x37795b = await getActiveAlarms(), _0x15d62e = _0x37795b[_0x205f1f(526)]((_0x436e92) => {
      const _0x5d71a6 = _0x205f1f;
      if (_0x16789d && _0x436e92[_0x5d71a6(475)]) return _0x436e92[_0x5d71a6(475)] !== _0x16789d;
      return _0x436e92["alarmId"] !== _0x2f4ea2;
    });
    _0x15d62e[_0x205f1f(457)]({ "alarmId": _0x2f4ea2, "buildingName": _0x366d2d, "buildingId": _0x16789d, "finishTimeMs": _0x5f0741, "translatedMessage": _0x193b71 }), await saveActiveAlarms(_0x15d62e);
  })[_0x1d4424(415)](console[_0x1d4424(432)]), addAlarmQueue;
}
async function removeAlarm(_0x4d2d9c) {
  const _0x5350ea = _0x470f55, _0x5b96e0 = await getActiveAlarms(), _0x42512f = _0x5b96e0[_0x5350ea(526)]((_0x1b4d4e) => _0x1b4d4e[_0x5350ea(431)] !== _0x4d2d9c);
  _0x5b96e0[_0x5350ea(440)] !== _0x42512f[_0x5350ea(440)] && await saveActiveAlarms(_0x42512f);
}
async function clearExpiredAlarms() {
  const _0x21c660 = _0x470f55, _0x13ec97 = await getActiveAlarms(), _0x2fd3ff = Date[_0x21c660(493)](), _0x41062a = _0x13ec97[_0x21c660(526)]((_0x25479d) => _0x25479d[_0x21c660(565)] > _0x2fd3ff);
  _0x13ec97[_0x21c660(440)] !== _0x41062a[_0x21c660(440)] && await saveActiveAlarms(_0x41062a);
}
const KEY_WHATS_NEW = "scx-whats-new", KEY_LAST_MINOR = _0x470f55(416), KEY_LAST_VERSION = _0x470f55(533), STORAGE_DOMAIN_WHATS_NEW = "whats-new", STORAGE_DOMAIN_WHATS_NEW_META = _0x470f55(524), STORAGE_VERSION = 1;
async function setWhatsNew(_0x1c46f1) {
  const _0x3c02ef = _0x470f55;
  await storage[_0x3c02ef(576)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": _0x3c02ef(458), "backend": _0x3c02ef(502), "refreshAuth": ![], "data": _0x1c46f1 }), await storage["set"]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x3c02ef(458), "backend": _0x3c02ef(502), "refreshAuth": ![], "data": { "minorKey": _0x1c46f1["minorKey"], "lastVersion": _0x1c46f1[_0x3c02ef(464)] } }), await storage[_0x3c02ef(492)](_0x3c02ef(502), KEY_WHATS_NEW), await storage[_0x3c02ef(492)](_0x3c02ef(502), KEY_LAST_MINOR), await storage[_0x3c02ef(492)](_0x3c02ef(502), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x37a094 = _0x470f55;
  return request(_0x37a094(544), { "url": _0x37a094(489), "credentials": "omit", "responseType": _0x37a094(555), "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x470f55(462)][_0x470f55(409)][_0x470f55(417)](async (_0x17b7b9) => {
  const _0x1fdbe3 = _0x470f55;
  await initializeDataPlatform();
  _0x17b7b9["reason"] === _0x1fdbe3(454) && await storage[_0x1fdbe3(576)]({ "domain": _0x1fdbe3(479), "version": 1, "scope": _0x1fdbe3(458), "backend": _0x1fdbe3(502), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x17b7b9["reason"] === "update" && _0x17b7b9[_0x1fdbe3(527)]) {
    const _0x41c8d0 = chrome[_0x1fdbe3(462)][_0x1fdbe3(449)]()[_0x1fdbe3(513)];
    if (_0x41c8d0 !== _0x17b7b9[_0x1fdbe3(527)]) try {
      const _0xfe615b = await fetchAllReleases();
      let _0x2861ce = [];
      const _0x273dc8 = releasePageUrl(_0x41c8d0);
      _0xfe615b && Array[_0x1fdbe3(545)](_0xfe615b) && (_0x2861ce = collectHighlightsFromReleases(_0xfe615b, _0x17b7b9["previousVersion"], _0x41c8d0)), await setWhatsNew({ "show": !![], "version": _0x41c8d0, "url": _0x273dc8, "highlights": _0x2861ce, "error": !_0xfe615b || !Array[_0x1fdbe3(545)](_0xfe615b), "minorKey": minorKey(_0x41c8d0), "lastVersion": _0x41c8d0 });
    } catch (_0x956c45) {
      console[_0x1fdbe3(432)](_0x1fdbe3(536), _0x956c45), await setWhatsNew({ "show": !![], "version": _0x41c8d0, "url": releasePageUrl(_0x41c8d0), "highlights": [], "error": !![], "minorKey": minorKey(_0x41c8d0), "lastVersion": _0x41c8d0 });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x39efa5) {
  const _0x11bb86 = _0x470f55, _0x22e9ae = Date["now"]();
  if (cooperDataCache[_0x39efa5] && cooperDataCacheTs[_0x39efa5] && _0x22e9ae - cooperDataCacheTs[_0x39efa5] < COOPER_CACHE_TTL) return cooperDataCache[_0x39efa5];
  const _0x1be932 = "r" + (_0x39efa5 + 1), _0x29f5a6 = await fetch(_0x11bb86(554) + _0x1be932);
  if (!_0x29f5a6["ok"]) throw new Error(_0x11bb86(498) + _0x29f5a6["status"]);
  const _0x208cc5 = await _0x29f5a6[_0x11bb86(555)]();
  return cooperDataCache[_0x39efa5] = _0x208cc5, cooperDataCacheTs[_0x39efa5] = _0x22e9ae, _0x208cc5;
}
chrome[_0x470f55(462)][_0x470f55(486)][_0x470f55(417)]((_0x241e87, _0x3703e5, _0x2ea8a8) => {
  const _0x2e0da5 = _0x470f55;
  if (_0x241e87[_0x2e0da5(499)] === _0x2e0da5(412)) return fetchCooperData(_0x241e87[_0x2e0da5(445)])[_0x2e0da5(491)]((_0x176ee6) => _0x2ea8a8({ "success": !![], "data": _0x176ee6 }))[_0x2e0da5(415)]((_0x5ccdfa) => _0x2ea8a8({ "success": ![], "error": _0x5ccdfa["message"] })), !![];
  if (_0x241e87[_0x2e0da5(499)] === _0x2e0da5(573)) {
    const _0x5c18b4 = _0x241e87["realmId"], _0x9e5905 = _0x2e0da5(558) + _0x5c18b4 + _0x2e0da5(435);
    return request(_0x2e0da5(444), { "url": _0x9e5905, "method": _0x2e0da5(534), "credentials": _0x2e0da5(557), "responseType": _0x2e0da5(555), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x69c71a) => _0x2ea8a8({ "success": !![], "data": _0x69c71a }))["catch"]((_0x307a05) => _0x2ea8a8({ "success": ![], "error": _0x307a05[_0x2e0da5(510)] || String(_0x307a05) })), !![];
  }
  if (_0x241e87["type"] === "FETCH_SIMCOTOOLS_EXECUTIVES") {
    const { realmId: _0x2335a6, queryParams: _0x1f2f88, headers: _0x273baa } = _0x241e87, _0xada8ad = "https://api.simcotools.com/v1/realms/" + _0x2335a6 + _0x2e0da5(488) + _0x1f2f88;
    return request(_0x2e0da5(444), { "url": _0xada8ad, "method": _0x2e0da5(534), "headers": _0x273baa, "credentials": "omit", "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x2e0da5(491)]((_0x591151) => _0x2ea8a8({ "success": !![], "data": _0x591151 }))[_0x2e0da5(415)]((_0x4ced46) => _0x2ea8a8({ "success": ![], "error": _0x4ced46["message"] || String(_0x4ced46) })), !![];
  }
  if (_0x241e87[_0x2e0da5(499)] === _0x2e0da5(439)) {
    const { realmId: _0x31ba54, headers: _0x321ae1 } = _0x241e87, _0x3a7107 = "https://api.simcotools.com/v1/realms/" + _0x31ba54 + _0x2e0da5(474);
    return request(_0x2e0da5(444), { "url": _0x3a7107, "method": "GET", "headers": _0x321ae1, "credentials": "omit", "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x2e0da5(491)]((_0x9ef5ea) => _0x2ea8a8({ "success": !![], "data": _0x9ef5ea }))[_0x2e0da5(415)]((_0x3a9087) => _0x2ea8a8({ "success": ![], "error": _0x3a9087[_0x2e0da5(510)] || String(_0x3a9087) })), !![];
  }
  if (_0x241e87["type"] === _0x2e0da5(579)) {
    const { realmId: _0x2e5c6d, headers: _0x164d3f } = _0x241e87, _0x363dd3 = _0x2e0da5(558) + _0x2e5c6d + "/phases";
    return request("simcotools", { "url": _0x363dd3, "method": _0x2e0da5(534), "headers": _0x164d3f, "credentials": _0x2e0da5(557), "responseType": _0x2e0da5(555), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x437bb2) => _0x2ea8a8({ "success": !![], "data": _0x437bb2 }))[_0x2e0da5(415)]((_0x12fe3f) => _0x2ea8a8({ "success": ![], "error": _0x12fe3f["message"] || String(_0x12fe3f) })), !![];
  }
  if (_0x241e87[_0x2e0da5(499)] === "SCRAPE_COOPER_RETAIL") return scrapeCooperRetail(_0x241e87[_0x2e0da5(477)])[_0x2e0da5(491)]((_0x251d80) => _0x2ea8a8({ "success": !![], "data": _0x251d80 }))[_0x2e0da5(415)]((_0x491442) => _0x2ea8a8({ "success": ![], "error": _0x491442[_0x2e0da5(510)] })), !![];
  if (_0x241e87[_0x2e0da5(499)] === _0x2e0da5(428)) {
    const { buildingName: _0x167b27, buildingId: _0x15d22a, finishTimeMs: _0x80f75c, translatedMessage: _0x13261f } = _0x241e87[_0x2e0da5(450)], _0x30a519 = "scx-alarm-" + Date[_0x2e0da5(493)]() + "-" + Math["floor"](Math[_0x2e0da5(528)]() * 1e3);
    return chrome[_0x2e0da5(425)][_0x2e0da5(505)](_0x30a519, { "when": _0x80f75c }), addAlarm(_0x30a519, _0x167b27, _0x15d22a, _0x80f75c, _0x13261f)[_0x2e0da5(415)](console[_0x2e0da5(432)]), _0x2ea8a8({ "success": !![], "alarmId": _0x30a519 }), !![];
  }
  if (_0x241e87["type"] === _0x2e0da5(572)) {
    const { alarmId: _0xbe6241 } = _0x241e87[_0x2e0da5(450)];
    return chrome[_0x2e0da5(425)][_0x2e0da5(564)](_0xbe6241), removeAlarm(_0xbe6241)["catch"](console[_0x2e0da5(432)]), _0x2ea8a8({ "success": !![] }), !![];
  }
}), chrome[_0x470f55(425)]["onAlarm"]["addListener"](async (_0x26d53c) => {
  const _0x1898af = _0x470f55;
  if (_0x26d53c[_0x1898af(467)][_0x1898af(518)](_0x1898af(426))) {
    const _0x6e4678 = await getActiveAlarms(), _0x325b1a = _0x6e4678[_0x1898af(583)]((_0x52ecdb) => _0x52ecdb[_0x1898af(431)] === _0x26d53c[_0x1898af(467)]), _0x22b8b7 = _0x325b1a ? _0x325b1a["buildingName"] : _0x1898af(501), _0x429467 = (_0x325b1a == null ? void 0 : _0x325b1a[_0x1898af(430)]) || _0x22b8b7 + _0x1898af(580);
    chrome[_0x1898af(540)][_0x1898af(505)](_0x26d53c[_0x1898af(467)], { "type": _0x1898af(422), "iconUrl": "icons/48.png", "title": _0x1898af(413), "message": _0x429467, "priority": 2 }), await removeAlarm(_0x26d53c["name"]);
  }
}), chrome["alarms"][_0x470f55(505)]("scx-cleanup-alarms", { "periodInMinutes": 60 }), chrome[_0x470f55(425)]["onAlarm"][_0x470f55(417)]((_0x21fe77) => {
  const _0xde55ab = _0x470f55;
  _0x21fe77[_0xde55ab(467)] === _0xde55ab(542) && clearExpiredAlarms()[_0xde55ab(415)](console[_0xde55ab(432)]);
});
