(function(_0x1f062f, _0x179961) {
  var _0x13f542 = _0x48b3, _0xef751f = _0x1f062f();
  while (!![]) {
    try {
      var _0x1e87ce = -parseInt(_0x13f542(382)) / 1 + parseInt(_0x13f542(386)) / 2 * (parseInt(_0x13f542(389)) / 3) + parseInt(_0x13f542(391)) / 4 + parseInt(_0x13f542(388)) / 5 * (parseInt(_0x13f542(385)) / 6) + parseInt(_0x13f542(390)) / 7 + parseInt(_0x13f542(383)) / 8 + -parseInt(_0x13f542(387)) / 9 * (parseInt(_0x13f542(384)) / 10);
      if (_0x1e87ce === _0x179961) break;
      else _0xef751f["push"](_0xef751f["shift"]());
    } catch (_0x528943) {
      _0xef751f["push"](_0xef751f["shift"]());
    }
  }
})(_0x399d, 201734);
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x48b3(_0x43ece1, _0xe7f5e2) {
  _0x43ece1 = _0x43ece1 - 382;
  var _0x399d80 = _0x399d();
  var _0x48b315 = _0x399d80[_0x43ece1];
  if (_0x48b3["HlXaDE"] === void 0) {
    var _0x29b040 = function(_0x4b2a67) {
      var _0x35adda = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0xac9e05 = "", _0x16de39 = "";
      for (var _0x32c1b2 = 0, _0x5c2806, _0x35f63e, _0x354de6 = 0; _0x35f63e = _0x4b2a67["charAt"](_0x354de6++); ~_0x35f63e && (_0x5c2806 = _0x32c1b2 % 4 ? _0x5c2806 * 64 + _0x35f63e : _0x35f63e, _0x32c1b2++ % 4) ? _0xac9e05 += String["fromCharCode"](255 & _0x5c2806 >> (-2 * _0x32c1b2 & 6)) : 0) {
        _0x35f63e = _0x35adda["indexOf"](_0x35f63e);
      }
      for (var _0x414f86 = 0, _0xf96a66 = _0xac9e05["length"]; _0x414f86 < _0xf96a66; _0x414f86++) {
        _0x16de39 += "%" + ("00" + _0xac9e05["charCodeAt"](_0x414f86)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x16de39);
    };
    _0x48b3["eRUFJO"] = _0x29b040, _0x48b3["HPpROu"] = {}, _0x48b3["HlXaDE"] = !![];
  }
  var _0x2e55e1 = _0x399d80[0], _0x1d963c = _0x43ece1 + _0x2e55e1, _0x255661 = _0x48b3["HPpROu"][_0x1d963c];
  return !_0x255661 ? (_0x48b315 = _0x48b3["eRUFJO"](_0x48b315), _0x48b3["HPpROu"][_0x1d963c] = _0x48b315) : _0x48b315 = _0x255661, _0x48b315;
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function _0x399d() {
  var _0x1b06c8 = ["mtuWnte4ngDywhDpwG", "mJeWmdm1CKLUEfLr", "mte5mJK3nKrjywL1Ba", "mtbWyuTAzxa", "nMPmwLH6uG", "nZqXogT0tgf1CW", "mJe2mtK4ovHZquH3uq", "mJy1ndm1r0DrAMnJ", "mJfzAgDxru8", "mZmYnJu0EeXTr1f3"];
  _0x399d = function() {
    return _0x1b06c8;
  };
  return _0x399d();
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
