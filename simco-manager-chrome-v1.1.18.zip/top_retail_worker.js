function _0x56de() {
  const _0x500e66 = ["Dg9mB3DLCKnHC2u", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "ChvZAa", "B25TzxnZywDL", "yM9VBq", "nda3ntC0merKAePbqG", "CM91BMq", "ow5zA0H2Eq", "nJe0ogf1yNf2Ca", "nZK1ndu2ogfQsNzbEG", "Bwf4", "y29ZDa", "BwLU", "nti2mtu3mvvcz3PxAa", "yxzLCMfNzvbYAwnL", "mZq1m0DZq3LmBq", "CMvZDwX0", "Dg9gAxHLza", "ChjVzhvJDe5HBwu", "CMvJzxnZAw9U", "mti5odK4nw9UDwTRsG", "mZC0nJG5me1uuvDHsq", "BwvZC2fNzq", "zgf0yq", "ChjVzhvJDeLK", "C2f0DxjHDgLVBG", "uhjVzhvJDca", "mJuWndCXBKPbyMTl", "Cg9ZDe1LC3nHz2u"];
  _0x56de = function() {
    return _0x500e66;
  };
  return _0x56de();
}
const _0xa2f8d2 = _0x1d86;
function _0x1d86(_0x5c12e0, _0x616d68) {
  _0x5c12e0 = _0x5c12e0 - 383;
  const _0x56de0e = _0x56de();
  let _0x1d8691 = _0x56de0e[_0x5c12e0];
  if (_0x1d86["bDAwCO"] === void 0) {
    var _0x3d0cc3 = function(_0x320609) {
      const _0x5c2782 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x204b6d = "", _0x6df2d9 = "";
      for (let _0x5af071 = 0, _0x4688f8, _0xd3cb59, _0x469d1f = 0; _0xd3cb59 = _0x320609["charAt"](_0x469d1f++); ~_0xd3cb59 && (_0x4688f8 = _0x5af071 % 4 ? _0x4688f8 * 64 + _0xd3cb59 : _0xd3cb59, _0x5af071++ % 4) ? _0x204b6d += String["fromCharCode"](255 & _0x4688f8 >> (-2 * _0x5af071 & 6)) : 0) {
        _0xd3cb59 = _0x5c2782["indexOf"](_0xd3cb59);
      }
      for (let _0x1c9967 = 0, _0x280a63 = _0x204b6d["length"]; _0x1c9967 < _0x280a63; _0x1c9967++) {
        _0x6df2d9 += "%" + ("00" + _0x204b6d["charCodeAt"](_0x1c9967)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x6df2d9);
    };
    _0x1d86["gIlfXd"] = _0x3d0cc3, _0x1d86["iQvRLq"] = {}, _0x1d86["bDAwCO"] = !![];
  }
  const _0x2373ea = _0x56de0e[0], _0x5583d1 = _0x5c12e0 + _0x2373ea, _0x4da81d = _0x1d86["iQvRLq"][_0x5583d1];
  return !_0x4da81d ? (_0x1d8691 = _0x1d86["gIlfXd"](_0x1d8691), _0x1d86["iQvRLq"][_0x5583d1] = _0x1d8691) : _0x1d8691 = _0x4da81d, _0x1d8691;
}
(function(_0x3cc384, _0x5ed5a8) {
  const _0x57ae84 = _0x1d86, _0x1bf569 = _0x3cc384();
  while (!![]) {
    try {
      const _0x4f3cba = -parseInt(_0x57ae84(409)) / 1 + -parseInt(_0x57ae84(403)) / 2 + parseInt(_0x57ae84(397)) / 3 * (parseInt(_0x57ae84(390)) / 4) + parseInt(_0x57ae84(402)) / 5 + -parseInt(_0x57ae84(387)) / 6 + parseInt(_0x57ae84(395)) / 7 + parseInt(_0x57ae84(391)) / 8 * (parseInt(_0x57ae84(389)) / 9);
      if (_0x4f3cba === _0x5ed5a8) break;
      else _0x1bf569["push"](_0x1bf569["shift"]());
    } catch (_0x5e310a) {
      _0x1bf569["push"](_0x1bf569["shift"]());
    }
  }
})(_0x56de, 971652), self[_0xa2f8d2(385)] = async (_0x204b6d) => {
  const _0x31105d = _0xa2f8d2, { action: _0x6df2d9, products: _0x5af071, adminOverhead: _0x4688f8, salesBonus: _0xd3cb59, economyPhase: _0x469d1f, simulateError: _0x1c9967 } = _0x204b6d[_0x31105d(405)];
  if (_0x6df2d9 === "calculate") {
    if (_0x1c9967) {
      self[_0x31105d(410)]({ "error": _0x31105d(383) });
      return;
    }
    try {
      const _0x280a63 = _0x4688f8 !== void 0 ? _0x4688f8 : 0, _0x465721 = _0xd3cb59 !== void 0 ? _0xd3cb59 : 0, _0x689894 = _0x469d1f || "Normal", _0x3ac12d = Math["max"](0, Math[_0x31105d(394)](_0x280a63, 200)), _0x5ded21 = Math[_0x31105d(392)](0, Math["min"](_0x465721, 50)), _0x11b934 = _0x689894[_0x31105d(411)]() === _0x31105d(401) ? 0.9 : _0x689894[_0x31105d(411)]() === _0x31105d(386) ? 1.12 : 1, _0x4e3200 = [];
      for (const _0x5b69cc of _0x5af071) {
        for (let _0x5b69e0 = 0; _0x5b69e0 <= 9; _0x5b69e0++) {
          const _0xde39ed = _0x5b69e0, _0x1d5b73 = _0x5b69cc["saturation"] <= 0 || _0x5b69cc["saturation"] == null ? 0.1 : Math[_0x31105d(392)](0.1, Math[_0x31105d(394)](_0x5b69cc[_0x31105d(407)], 5)), _0x1689e2 = 1 + _0xde39ed * 0.05, _0x85e754 = 100, _0x49dba4 = _0x85e754 / _0x1d5b73 * _0x1689e2 * _0x11b934 * (1 + _0x5ded21 / 100), _0x51e164 = _0x49dba4 / 24, _0x5c38f4 = _0x5b69cc[_0x31105d(396)] || _0x5b69cc[_0x31105d(393)] * 1.5, _0x1b47c8 = _0x5c38f4 - _0x5b69cc[_0x31105d(393)], _0x1987be = _0x49dba4 * _0x5c38f4, _0x7ffd40 = _0x1987be * (_0x3ac12d / 100), _0x42ef72 = _0x49dba4 * _0x1b47c8 - _0x7ffd40;
          if (_0x42ef72 < 0) continue;
          _0x4e3200[_0x31105d(384)]({ "productId": _0x5b69cc[_0x31105d(406)], "productName": _0x5b69cc[_0x31105d(400)] || _0x31105d(408) + _0x5b69cc[_0x31105d(406)], "quality": _0xde39ed, "price": parseFloat(_0x5c38f4[_0x31105d(399)](2)), "cost": parseFloat(_0x5b69cc[_0x31105d(393)]["toFixed"](2)), "profitPerUnit": parseFloat(_0x1b47c8[_0x31105d(399)](2)), "profitPerDay": Math["round"](_0x42ef72), "grossRevPerDay": Math[_0x31105d(388)](_0x1987be), "unitsPerHr": parseFloat(_0x51e164[_0x31105d(399)](1)), "unitsPerDay": Math[_0x31105d(388)](_0x49dba4), "pphpl": _0x42ef72 });
        }
      }
      _0x4e3200["sort"]((_0x5c217b, _0x276b4b) => _0x276b4b["pphpl"] - _0x5c217b["pphpl"]), self[_0x31105d(410)]({ "action": _0x31105d(398), "results": _0x4e3200 });
    } catch (_0x28b5af) {
      self[_0x31105d(410)]({ "error": _0x28b5af[_0x31105d(404)] });
    }
  }
};
