const _0x316601 = _0x2be8;
(function(_0x6832f7, _0x3034b) {
  const _0x5a0f3c = _0x2be8, _0x42fd06 = _0x6832f7();
  while (!![]) {
    try {
      const _0x137cb4 = parseInt(_0x5a0f3c(425)) / 1 + parseInt(_0x5a0f3c(383)) / 2 + parseInt(_0x5a0f3c(457)) / 3 + -parseInt(_0x5a0f3c(509)) / 4 * (parseInt(_0x5a0f3c(492)) / 5) + parseInt(_0x5a0f3c(427)) / 6 + parseInt(_0x5a0f3c(422)) / 7 + -parseInt(_0x5a0f3c(351)) / 8;
      if (_0x137cb4 === _0x3034b) break;
      else _0x42fd06["push"](_0x42fd06["shift"]());
    } catch (_0x6aa930) {
      _0x42fd06["push"](_0x42fd06["shift"]());
    }
  }
})(_0x475a, 432654);
const REPO_OWNER = _0x316601(352), REPO_NAME = _0x316601(350);
function parseVersion(_0x1c81fb) {
  const _0x1a7bbf = _0x316601, _0x4b046c = String(_0x1c81fb || "")[_0x1a7bbf(366)](/^v/i, "")[_0x1a7bbf(412)](".");
  return [Number(_0x4b046c[0] || 0), Number(_0x4b046c[1] || 0), Number(_0x4b046c[2] || 0)];
}
function compareVersions(_0x5e857a, _0x4cc72e) {
  const [_0x4c1d93, _0x27c7fa, _0x322708] = parseVersion(_0x5e857a), [_0x574e74, _0x30f811, _0x29265e] = parseVersion(_0x4cc72e);
  if (_0x4c1d93 !== _0x574e74) return _0x4c1d93 - _0x574e74;
  if (_0x27c7fa !== _0x30f811) return _0x27c7fa - _0x30f811;
  return _0x322708 - _0x29265e;
}
function minorKey(_0x121b04) {
  const _0x109953 = _0x316601, _0x27be8e = String(_0x121b04 || "")[_0x109953(412)]("."), _0x56dfeb = _0x27be8e[0] || "0", _0x59dd45 = _0x27be8e[1] || "0";
  return _0x56dfeb + "." + _0x59dd45;
}
function releasePageUrl(_0xabcbe3) {
  const _0xd21299 = _0x316601, _0x263942 = String(_0xabcbe3 || "")[_0xd21299(406)]();
  return _0xd21299(503) + REPO_OWNER + "/" + REPO_NAME + _0xd21299(475) + encodeURIComponent(_0x263942);
}
function stripMarkdown(_0xba1526) {
  const _0x3fca8e = _0x316601;
  let _0x30fc47 = String(_0xba1526 || "");
  return _0x30fc47 = _0x30fc47[_0x3fca8e(366)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x30fc47 = _0x30fc47[_0x3fca8e(366)](/https?:\/\/\S+/gi, ""), _0x30fc47 = _0x30fc47["replace"](/[`*_>#]/g, ""), _0x30fc47 = _0x30fc47[_0x3fca8e(366)](/\s+/g, " ")[_0x3fca8e(406)](), _0x30fc47;
}
function humanizeHighlight(_0x47cf9a) {
  const _0x5f2152 = _0x316601;
  let _0x52ee06 = stripMarkdown(_0x47cf9a);
  _0x52ee06 = _0x52ee06[_0x5f2152(366)](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x52ee06 = _0x52ee06["replace"](/\s+in\s*$/i, ""), _0x52ee06 = _0x52ee06["replace"](/\s*\(#?\d+\)\s*$/i, "");
  const _0x4d7c4b = _0x52ee06[_0x5f2152(471)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x4d7c4b) {
    const _0x1dcd2f = _0x4d7c4b[1]["toLowerCase"](), _0x4b8dbe = _0x4d7c4b[3], _0x13dcc2 = _0x1dcd2f === _0x5f2152(480) ? _0x5f2152(337) : _0x1dcd2f === "fix" ? _0x5f2152(389) : _0x1dcd2f === _0x5f2152(448) ? _0x5f2152(418) : _0x1dcd2f === "docs" ? _0x5f2152(343) : null;
    if (_0x13dcc2) _0x52ee06 = _0x13dcc2 + ": " + _0x4b8dbe;
  }
  return _0x52ee06 = _0x52ee06[_0x5f2152(366)](/\s+/g, " ")["trim"](), _0x52ee06;
}
function extractHighlights(_0x350809, { limit = 5 } = {}) {
  const _0x755ae1 = _0x316601, _0x46dee7 = String(_0x350809 || ""), _0x379ee4 = _0x46dee7[_0x755ae1(412)](/\r?\n/), _0x3c5ef5 = [];
  let _0x10505a = ![];
  for (const _0x3a88f4 of _0x379ee4) {
    const _0xc583ed = _0x3a88f4[_0x755ae1(406)]();
    if (_0xc583ed[_0x755ae1(500)](_0x755ae1(354))) {
      _0x10505a = !_0x10505a;
      continue;
    }
    if (_0x10505a) continue;
    if (!_0xc583ed) continue;
    if (/^#+\s+/["test"](_0xc583ed)) continue;
    const _0x547fbd = _0xc583ed[_0x755ae1(471)](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x547fbd) {
      const _0xaf4f90 = humanizeHighlight(_0x547fbd[2]);
      if (_0xaf4f90) _0x3c5ef5["push"](_0xaf4f90);
    }
    if (_0x3c5ef5[_0x755ae1(408)] >= limit) break;
  }
  return _0x3c5ef5[_0x755ae1(373)](0, limit);
}
function _0x475a() {
  const _0x1ab579 = ["Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "DgfI", "zgvMyxvSDa", "vxbKyxrLza", "Cg9WDxa", "yMfZAwm", "C2nVCgu", "DgHLBG", "AxngAw5PDgu", "zNvUy3rPB24", "C2LTy28TBwfUywDLCG", "nZaYmJm2oev0C1fZsa", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "C2n4lwnSzwfUDxaTywXHCM1Z", "ygbG", "BMfTzq", "AgfZu2nVCgu", "C2nVCgvK", "Dgv4Da", "zMXVB3i", "zxjYB3i", "A2v5", "rKvuq0HFq09puevsx0rbvee", "B21PDa", "rKvuq0HFu0Lnq09ut09mu19fwevdvvrjvKvt", "BwLUB3jlzxK", "CMvWBgfJzq", "C2v0", "D2LUzg93CW", "ChjLDMLVDxnwzxjZAw9U", "l2v4zwn1DgL2zxm/", "B25bBgfYBq", "yM9KEq", "C2XPy2u", "qujpuLrfra", "CMvZB2X2zq", "Bgv2zwW", "z2L0AhvIlxjLBgvHC2vZ", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "C2nVCgvlzxK", "DgvZDa", "zw50CMLLCW", "zMLUywXSEq", "mtG5nZy4v2PKtePw", "CMvHBg1jza", "sfruuca", "y29TCgfUEuLK", "z2v0twfUAwzLC3q", "zgf0yq", "rML4zwq", "Dw5KzwzPBMvK", "z2v0", "q09puevsx0LguKfnrv9srvnvtfq", "Bw9Kzq", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "C2n4", "ChjVzhvJDgLVBK1VzgLMAwvY", "C2v0sxrLBq", "CgfYC2u", "yNvPBgrPBMDjza", "zMLUAxnOvgLTzu1Z", "CMvTB3zL", "ChjLCMvSzwfZzq", "q29VCgvYiefqssbLCNjVCJOG", "Bgv2zwXjBMzV", "yMXVy2TLza", "DhjPBq", "veLnru9vva", "BgvUz3rO", "y2XLyxi", "D2vSy29Tzs1TzxnZywDL", "CNvUDgLTzq", "C3bSAxq", "z2v0sxrLBq", "C3rYAw5NAwz5", "BwfW", "AxnbCNjHEq", "zMLSDgvY", "sw1WCM92zwq", "B25jBNn0ywXSzwq", "CMvZCg9UC2u", "Bg9HzgLUzW", "mZqZmda0mMTWsvL1qq", "ywXHCM1jza", "yMXVyG", "mZK4odi1t0ztwfDW", "C2n4lwj1AwXKAw5NCW", "ndC1nJi1ngvmu0nNyW", "y3jLyxrL", "yxv0Aa", "ywjVCNq", "DMvYC2LVBG", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "DxjS", "C2n4lwj1AwXKAw5NCY10CW", "ywrKtgLZDgvUzxi", "D2HHDhmTBMv3lw1LDge", "y2f0y2G", "ANnVBG", "BM90AwzPy2f0Aw9UCW", "Bwf4", "CMfUzg9T", "zMLUza", "DMfSDwu", "Bg9HzgvK", "u2LTq28GtwfUywDLCG", "B2jQzwn0", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "CgvYzG", "yNvPBgrPBMCTywXHCM1Z", "yxjYyxLcDwzMzxi", "tKvuv09ss19fuLjpuG", "y29TCgfUEq", "C2n4lwfSyxjTlq", "Dg9mB3DLCKnHC2u", "D2LUzg93swq", "BgLZDej5uhjLzML4", "otq2mdyYsMz4DNDH", "y29Kzq", "Aw5ZDgfSBa", "uMvXDwvZDcbMywLSzwq", "qwjVCNrfCNjVCG", "ChvZAa", "uKfurv9msu1jvf9dt09mre9xtJO", "y2XLyw51Ca", "DgfNx25HBwu", "y2HYB21L", "C2LNBMfS", "DhLWzq", "C3rHDhvZ", "zgvSzxrL", "Bwf0y2G", "Bwv0Ag9K", "y29HBgvZy2vlzxK", "y29HBgvZy2u", "l3jLBgvHC2vZl3rHzY92", "C2LTy290B29SCW", "l3bOyxnLCW", "y2vPBa", "Aw5JBhvKzxm", "zMvHDa", "C2fSzxnnB2rPzMLLCG", "C2n4oG", "CMvTywLUAw5Ntxm", "l3n0yxrZl2j1AwXKAw5NCW", "Dw5RBM93BG", "yNvPBgrPBMDoyw1L", "C3rVCMfNzq", "z2XVyMfS", "uKfurv9msu1jvf9dt09mre9xtG", "r0vu", "CMvTB3zLsxrLBq", "mZC2mhL0Cw1Qta", "sfruuf9fuLjpuG", "B25nzxnZywDL", "CMvTB3zLuMf3", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l3jLDgfPBd9Zy3HFCgfYyw1Zpq", "Bg9JywW", "rMfPBgvKihrVigzLDgnOihjLBgvHC2uGBM90zxm6", "rKvuq0HFu0Lnq09ut09mu19tvefuu19cvuLmreLor1m", "C3rHCNrZv2L0Aa", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "C29YDa", "Ahr0Chm6lY9NAxrODwiUy29TlW", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "CMvHC29U", "BM93", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "u0nsqvbfx0npt1bfuL9srvrbsuW", "nde1nKfIDurXzq", "AgfZ", "l21HCMTLDc92D2fWCW", "qsbIDwLSzgLUzW", "Aw5JBhvKzq", "CMvTB3zLtgLZDgvUzxi", "BwvZC2fNzq", "ywXHCM1Z", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "uMvXDwvZDcb0Aw1LB3v0", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "tMv3", "DhrStxm", "BgfZDfzLCNnPB24"];
  _0x475a = function() {
    return _0x1ab579;
  };
  return _0x475a();
}
function collectHighlightsFromReleases(_0x64444, _0x44fdd8, _0x3015e6, { limit = 10 } = {}) {
  const _0x2a8359 = _0x316601, _0x3b97c1 = (Array["isArray"](_0x64444) ? _0x64444 : [])["filter"]((_0x325842) => !(_0x325842 == null ? void 0 : _0x325842[_0x2a8359(402)]))[_0x2a8359(415)]((_0x3ffb33) => ({ ..._0x3ffb33, "tag_name": String((_0x3ffb33 == null ? void 0 : _0x3ffb33[_0x2a8359(465)]) || "") }))[_0x2a8359(417)]((_0x27adc7) => /^v?\d+\.\d+\.\d+$/[_0x2a8359(380)](_0x27adc7[_0x2a8359(465)]))[_0x2a8359(417)]((_0xa8cbea) => compareVersions(_0xa8cbea[_0x2a8359(465)], _0x44fdd8) > 0)[_0x2a8359(417)]((_0x234b3a) => compareVersions(_0x234b3a["tag_name"], _0x3015e6) <= 0)[_0x2a8359(502)]((_0x226e0a, _0x346ddd) => compareVersions(_0x226e0a[_0x2a8359(465)], _0x346ddd[_0x2a8359(465)])), _0x5c4497 = [];
  for (const _0x928ec5 of _0x3b97c1) {
    const _0x11a19f = extractHighlights(_0x928ec5[_0x2a8359(372)], { "limit": limit });
    for (const _0x452a32 of _0x11a19f) {
      _0x5c4497["push"](_0x452a32);
      if (_0x5c4497["length"] >= limit) return _0x5c4497;
    }
  }
  return _0x5c4497[_0x2a8359(373)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x4c7a1c) {
  return new Promise((_0x3d0d17) => setTimeout(_0x3d0d17, _0x4c7a1c));
}
function normalizeDomain$1(_0x433a80) {
  const _0x83162b = _0x316601;
  return String(_0x433a80 || _0x83162b(342))[_0x83162b(406)]()[_0x83162b(454)]();
}
function makeError(_0x3cd3e0, _0x28a89d = {}) {
  const _0x28a02f = new Error(_0x3cd3e0);
  return Object["assign"](_0x28a02f, _0x28a89d), _0x28a02f;
}
function buildInflightKey(_0x33e833, _0x55cb54, _0x10db58, _0x5492d3) {
  if (_0x55cb54) return _0x33e833 + ":" + _0x55cb54;
  return _0x33e833 + ":" + _0x5492d3 + ":" + _0x10db58;
}
function getRateLimitStatus(_0x481f58 = _0x316601(342)) {
  const _0x20ae24 = _0x316601, _0x40fab1 = normalizeDomain$1(_0x481f58), _0x2f5903 = Number(rateLimitByDomain["get"](_0x40fab1) || 0), _0x4ffba9 = Math[_0x20ae24(440)](0, _0x2f5903 - Date[_0x20ae24(506)]());
  return { "blocked": _0x4ffba9 > 0, "remainingMs": _0x4ffba9, "blockedUntil": _0x2f5903 };
}
async function parseResponse(_0xbf8534, _0x16869d) {
  const _0x40b84a = _0x316601;
  if (_0x16869d === _0x40b84a(420)) return _0xbf8534;
  if (_0x16869d === _0x40b84a(358)) return _0xbf8534[_0x40b84a(358)]();
  if (_0x16869d === "blob") return _0xbf8534[_0x40b84a(424)]();
  if (_0x16869d === _0x40b84a(450)) return _0xbf8534["arrayBuffer"]();
  return _0xbf8534[_0x40b84a(438)]();
}
async function doRequest(_0x588c7d, _0x659930, _0x40cd02 = 0) {
  const _0x1a54fb = _0x316601, { url: _0x44e752, method = _0x1a54fb(490), headers: _0x2d1e86, body: _0x400a39, credentials = _0x1a54fb(513), signal: _0x27f082, responseType = _0x1a54fb(438), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x659930, _0x27a78d = getRateLimitStatus(_0x588c7d);
  if (_0x27a78d[_0x1a54fb(405)]) throw makeError(_0x1a54fb(463) + Math[_0x1a54fb(478)](_0x27a78d[_0x1a54fb(483)] / 1e3), { "code": _0x1a54fb(489), "domain": _0x588c7d, "remainingMs": _0x27a78d[_0x1a54fb(483)], "status": 429 });
  const _0x206c31 = timeoutMs > 0 ? new AbortController() : null, _0x326abb = _0x206c31 && timeoutMs > 0 ? setTimeout(() => _0x206c31[_0x1a54fb(430)](makeError(_0x1a54fb(518), { "code": _0x1a54fb(407), "domain": _0x588c7d })), timeoutMs) : null, _0x458df7 = _0x206c31 ? _0x206c31[_0x1a54fb(467)] : _0x27f082;
  try {
    const _0x57d176 = await fetch(_0x44e752, { "method": method, "headers": _0x2d1e86, "body": _0x400a39, "credentials": credentials, "signal": _0x458df7 });
    if (_0x57d176[_0x1a54fb(469)] === 429 && rateLimitCooldownMs > 0) {
      const _0x183812 = (rateLimitHitCount[_0x1a54fb(391)](_0x588c7d) || 0) + 1;
      rateLimitHitCount[_0x1a54fb(367)](_0x588c7d, _0x183812);
      const _0x3fb765 = _0x183812 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x1a54fb(367)](_0x588c7d, Date["now"]() + _0x3fb765);
    }
    if (!_0x57d176["ok"]) {
      const _0x162847 = _0x40cd02 < retries && retryStatuses[_0x1a54fb(479)](_0x57d176["status"]);
      if (_0x162847) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x588c7d, _0x659930, _0x40cd02 + 1);
      }
      throw makeError(_0x1a54fb(385) + _0x57d176["status"], { "code": _0x1a54fb(493), "domain": _0x588c7d, "status": _0x57d176[_0x1a54fb(469)] });
    }
    return rateLimitHitCount["delete"](_0x588c7d), parseResponse(_0x57d176, responseType);
  } catch (_0x1e0146) {
    const _0x58f592 = (_0x1e0146 == null ? void 0 : _0x1e0146["name"]) === _0x1a54fb(461), _0xb8cfe8 = !_0x58f592 && _0x40cd02 < retries;
    if (_0xb8cfe8) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x588c7d, _0x659930, _0x40cd02 + 1);
    }
    if (_0x1e0146 instanceof Error && _0x1e0146[_0x1a54fb(458)]) throw _0x1e0146;
    throw makeError(String((_0x1e0146 == null ? void 0 : _0x1e0146[_0x1a54fb(515)]) || _0x1e0146 || _0x1a54fb(460)), { "code": _0x58f592 ? _0x1a54fb(374) : _0x1a54fb(451), "domain": _0x588c7d, "status": Number((_0x1e0146 == null ? void 0 : _0x1e0146[_0x1a54fb(469)]) || 0) || null, "cause": _0x1e0146 });
  } finally {
    if (_0x326abb) clearTimeout(_0x326abb);
  }
}
async function request(_0x83e3f, _0xe531f9) {
  const _0x42151a = _0x316601, _0x865028 = normalizeDomain$1(_0x83e3f), _0x6be0e1 = buildInflightKey(_0x865028, _0xe531f9 == null ? void 0 : _0xe531f9[_0x42151a(473)], _0xe531f9 == null ? void 0 : _0xe531f9[_0x42151a(433)], (_0xe531f9 == null ? void 0 : _0xe531f9[_0x42151a(472)]) || _0x42151a(490));
  if ((_0xe531f9 == null ? void 0 : _0xe531f9[_0x42151a(474)]) && inflightByKey[_0x42151a(510)](_0x6be0e1)) return inflightByKey[_0x42151a(391)](_0x6be0e1);
  const _0x33d5ce = doRequest(_0x865028, _0xe531f9 || {})[_0x42151a(382)](() => {
    const _0x26b104 = _0x42151a;
    inflightByKey[_0x26b104(470)](_0x6be0e1);
  });
  return (_0xe531f9 == null ? void 0 : _0xe531f9[_0x42151a(474)]) && inflightByKey["set"](_0x6be0e1, _0x33d5ce), _0x33d5ce;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x4737cb) {
  const _0x3588e5 = _0x316601, _0x1ea63e = _0x4737cb == null ? void 0 : _0x4737cb["authCompany"];
  STATE[_0x3588e5(429)][_0x3588e5(386)] = (_0x1ea63e == null ? void 0 : _0x1ea63e[_0x3588e5(386)]) ?? null, STATE["auth"][_0x3588e5(384)] = (_0x1ea63e == null ? void 0 : _0x1ea63e[_0x3588e5(384)]) ?? null, STATE[_0x3588e5(429)][_0x3588e5(396)] = (_0x1ea63e == null ? void 0 : _0x1ea63e["productionModifier"]) ?? null, STATE["auth"][_0x3588e5(481)] = (_0x1ea63e == null ? void 0 : _0x1ea63e[_0x3588e5(481)]) ?? null, STATE[_0x3588e5(429)][_0x3588e5(444)] = !![];
  const _0x78b867 = _0x4737cb == null ? void 0 : _0x4737cb["levelInfo"];
  STATE["levelInfo"]["level"] = (_0x78b867 == null ? void 0 : _0x78b867[_0x3588e5(376)]) ?? null, STATE[_0x3588e5(404)]["experience"] = (_0x78b867 == null ? void 0 : _0x78b867["experience"]) ?? null, STATE["levelInfo"][_0x3588e5(501)] = (_0x78b867 == null ? void 0 : _0x78b867["experienceToNextLevel"]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x265d7d = _0x316601;
  if (!force && STATE[_0x265d7d(429)][_0x265d7d(444)] || STATE["auth"][_0x265d7d(421)]) return;
  STATE[_0x265d7d(429)][_0x265d7d(421)] = !![], STATE["auth"][_0x265d7d(360)] = null;
  try {
    const _0x55da33 = await request(_0x265d7d(429), { "url": _0x265d7d(340), "credentials": _0x265d7d(513), "responseType": _0x265d7d(438), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x55da33);
  } catch (_0x5a2a8b) {
    STATE["auth"][_0x265d7d(360)] = String((_0x5a2a8b == null ? void 0 : _0x5a2a8b[_0x265d7d(515)]) || _0x5a2a8b);
  } finally {
    STATE["auth"][_0x265d7d(421)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x316601(357), _0x316601(452), _0x316601(488)]);
function normalizeScopeMode(_0x38be00) {
  const _0x4e1038 = _0x316601;
  if (VALID_SCOPE_MODES[_0x4e1038(510)](_0x38be00)) return _0x38be00;
  return _0x4e1038(357);
}
function numericOrNull(_0x5de8c8) {
  if (_0x5de8c8 === null || _0x5de8c8 === void 0 || _0x5de8c8 === "") return null;
  const _0x486018 = Number(_0x5de8c8);
  return Number["isFinite"](_0x486018) ? _0x486018 : null;
}
function resolveScopeSync(_0x41a0c4 = _0x316601(357)) {
  var _a, _b;
  const _0x1c340a = _0x316601, _0x49c17c = normalizeScopeMode(_0x41a0c4), _0x7e45e6 = numericOrNull((_a = STATE[_0x1c340a(429)]) == null ? void 0 : _a[_0x1c340a(386)]), _0x28a04f = numericOrNull((_b = STATE[_0x1c340a(429)]) == null ? void 0 : _b["realmId"]);
  if (_0x49c17c === "global") return { "mode": _0x49c17c, "companyId": _0x7e45e6, "realmId": _0x28a04f, "hasScope": !![], "scopeKey": _0x1c340a(488) };
  if (_0x49c17c === _0x1c340a(452)) return { "mode": _0x49c17c, "companyId": _0x7e45e6, "realmId": _0x28a04f, "hasScope": Number[_0x1c340a(348)](_0x7e45e6), "scopeKey": Number[_0x1c340a(348)](_0x7e45e6) ? String(_0x7e45e6) : null };
  const _0x5cc59c = Number[_0x1c340a(348)](_0x7e45e6) && Number[_0x1c340a(348)](_0x28a04f);
  return { "mode": _0x49c17c, "companyId": _0x7e45e6, "realmId": _0x28a04f, "hasScope": _0x5cc59c, "scopeKey": _0x5cc59c ? _0x7e45e6 + "-" + _0x28a04f : null };
}
async function resolveScope(_0x45fb09 = "scoped", { refreshAuth = ![] } = {}) {
  const _0x260433 = normalizeScopeMode(_0x45fb09);
  return refreshAuth && _0x260433 !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x260433);
}
const DEFAULT_PREFIX = _0x316601(395);
function hasLocalStorage() {
  const _0x48ec86 = _0x316601;
  try {
    return typeof localStorage !== _0x48ec86(390) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x5d862c = _0x316601;
  try {
    return typeof chrome !== _0x5d862c(390) && Boolean((_a = chrome == null ? void 0 : chrome[_0x5d862c(487)]) == null ? void 0 : _a[_0x5d862c(497)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x10a816) {
  if (_0x10a816 == null) return null;
  if (typeof _0x10a816 === "object") return _0x10a816;
  try {
    return JSON["parse"](String(_0x10a816));
  } catch {
    return null;
  }
}
function toStorageRaw(_0xc63a74, _0x69f0fe) {
  const _0x38d758 = _0x316601;
  if (_0xc63a74 === _0x38d758(466)) return _0x69f0fe;
  return JSON[_0x38d758(414)](_0x69f0fe);
}
function isEnvelopeValid(_0xfe2ee) {
  const _0x448f28 = _0x316601;
  return Boolean(_0xfe2ee && typeof _0xfe2ee === _0x448f28(446) && Number["isFinite"](Number(_0xfe2ee["v"])));
}
function isExpired(_0x1cbe98, _0x2670f4 = null, _0x21fad6 = Date[_0x316601(506)]()) {
  const _0x106160 = _0x316601, _0x44db98 = Number((_0x1cbe98 == null ? void 0 : _0x1cbe98["ts"]) || 0), _0x2ed8b1 = Number(_0x1cbe98 == null ? void 0 : _0x1cbe98[_0x106160(338)]), _0x415a20 = Number[_0x106160(348)](_0x2ed8b1) ? _0x2ed8b1 : Number[_0x106160(348)](Number(_0x2670f4)) ? Number(_0x2670f4) : null;
  if (!Number[_0x106160(348)](_0x44db98) || _0x44db98 <= 0) return ![];
  if (!Number[_0x106160(348)](_0x415a20) || _0x415a20 <= 0) return ![];
  return _0x44db98 + _0x415a20 < _0x21fad6;
}
function normalizeBackend(_0x21662e) {
  const _0x4372f5 = _0x316601;
  return _0x21662e === _0x4372f5(466) ? _0x4372f5(466) : _0x4372f5(497);
}
function normalizePrefix(_0x12a33a) {
  const _0x38758e = _0x316601, _0x54f8f9 = String(_0x12a33a || DEFAULT_PREFIX)[_0x38758e(406)]();
  return _0x54f8f9[_0x38758e(408)] > 0 ? _0x54f8f9 : DEFAULT_PREFIX;
}
function normalizeDomain(_0x3d1545) {
  const _0x588509 = _0x316601;
  return String(_0x3d1545 || _0x588509(485))["trim"]()[_0x588509(366)](/\s+/g, "-")["toLowerCase"]();
}
function buildStorageKey({ domain: _0x2da2ea, version: _0x47bc0c, scopeKey: _0x1fb2ed, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x2da2ea) + ":v" + Number(_0x47bc0c) + ":" + _0x1fb2ed;
}
async function chromeGet(_0x573725) {
  const _0x4255cf = _0x316601;
  if (!hasChromeStorage()) return {};
  const _0x282377 = chrome[_0x4255cf(487)][_0x4255cf(497)];
  try {
    const _0x486d2d = _0x282377["get"](_0x573725);
    if (_0x486d2d && typeof _0x486d2d["then"] === _0x4255cf(349)) return _0x486d2d;
  } catch {
  }
  return new Promise((_0x291920) => {
    const _0x4c4b26 = _0x4255cf;
    try {
      _0x282377[_0x4c4b26(391)](_0x573725, (_0x1ac115) => _0x291920(_0x1ac115 || {}));
    } catch {
      _0x291920({});
    }
  });
}
async function chromeSet(_0x19bc3c) {
  const _0x20cc1d = _0x316601;
  if (!hasChromeStorage()) return ![];
  const _0x5023ab = chrome["storage"][_0x20cc1d(497)];
  try {
    const _0x1794e2 = _0x5023ab[_0x20cc1d(367)](_0x19bc3c);
    if (_0x1794e2 && typeof _0x1794e2["then"] === _0x20cc1d(349)) return await _0x1794e2, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x3037a6) => {
    const _0x1b2987 = _0x20cc1d;
    try {
      _0x5023ab[_0x1b2987(367)](_0x19bc3c, () => _0x3037a6(!![]));
    } catch {
      _0x3037a6(![]);
    }
  });
}
async function chromeRemove(_0x4a104d) {
  const _0x13cfc9 = _0x316601;
  if (!hasChromeStorage()) return ![];
  const _0x402464 = chrome["storage"][_0x13cfc9(497)];
  try {
    const _0x1cd054 = _0x402464[_0x13cfc9(401)](_0x4a104d);
    if (_0x1cd054 && typeof _0x1cd054[_0x13cfc9(347)] === "function") return await _0x1cd054, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x4a27f7) => {
    const _0x5d8e33 = _0x13cfc9;
    try {
      _0x402464[_0x5d8e33(401)](_0x4a104d, () => _0x4a27f7(!![]));
    } catch {
      _0x4a27f7(![]);
    }
  });
}
async function getRaw(_0x13a98a, _0x4587dc) {
  const _0x5050fb = _0x316601, _0xc1bbdd = normalizeBackend(_0x13a98a);
  if (_0xc1bbdd === "local") {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x5050fb(413)](_0x4587dc);
    } catch {
      return null;
    }
  }
  const _0x33d33b = await chromeGet(_0x4587dc);
  return (_0x33d33b == null ? void 0 : _0x33d33b[_0x4587dc]) ?? null;
}
function localGetItemSync(_0x4a30a4) {
  const _0x483c10 = _0x316601;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x483c10(413)](_0x4a30a4);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x1d144d, _0x1aa741) {
  const _0x3837a5 = _0x316601;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x3837a5(397)](_0x1d144d, String(_0x1aa741)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x47bcfb) {
  const _0x168f4e = _0x316601;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x168f4e(491)](_0x47bcfb), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x496dcc = "") {
  const _0x2e1da6 = _0x316601;
  if (!hasLocalStorage()) return [];
  const _0x2e0b84 = [], _0x1abc8d = String(_0x496dcc || "");
  try {
    for (let _0xc32563 = 0; _0xc32563 < localStorage["length"]; _0xc32563 += 1) {
      const _0x5ef9e = localStorage["key"](_0xc32563);
      if (!_0x5ef9e || _0x1abc8d && !_0x5ef9e[_0x2e1da6(500)](_0x1abc8d)) continue;
      _0x2e0b84["push"]({ "key": _0x5ef9e, "value": localStorage[_0x2e1da6(413)](_0x5ef9e) });
    }
  } catch {
    return [];
  }
  return _0x2e0b84;
}
async function setRaw(_0x5cbd62, _0x5ced5f, _0x24a692) {
  const _0x3e6b5e = _0x316601, _0x233d2c = normalizeBackend(_0x5cbd62);
  if (_0x233d2c === _0x3e6b5e(497)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x5ced5f, String(_0x24a692)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x5ced5f]: _0x24a692 });
}
async function removeRaw(_0x3d14a6, _0x360141) {
  const _0x429f5e = _0x316601, _0x859e8f = normalizeBackend(_0x3d14a6);
  if (_0x859e8f === _0x429f5e(497)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x429f5e(491)](_0x360141), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x360141);
}
async function listByPrefix({ backend = _0x316601(497), prefix = "" } = {}) {
  const _0x5b60fb = _0x316601, _0x5e57f3 = normalizeBackend(backend), _0x12c703 = String(prefix || "");
  if (_0x5e57f3 === _0x5b60fb(497)) {
    if (!hasLocalStorage()) return [];
    const _0x4c55a5 = [];
    try {
      for (let _0x4720af = 0; _0x4720af < localStorage[_0x5b60fb(408)]; _0x4720af += 1) {
        const _0x2ef052 = localStorage[_0x5b60fb(361)](_0x4720af);
        if (!_0x2ef052 || _0x12c703 && !_0x2ef052[_0x5b60fb(500)](_0x12c703)) continue;
        _0x4c55a5[_0x5b60fb(462)]({ "key": _0x2ef052, "value": localStorage[_0x5b60fb(413)](_0x2ef052) });
      }
    } catch {
      return [];
    }
    return _0x4c55a5;
  }
  const _0x170113 = await chromeGet(null);
  return Object[_0x5b60fb(381)](_0x170113 || {})[_0x5b60fb(417)](([_0x2c4350]) => _0x12c703 ? _0x2c4350[_0x5b60fb(500)](_0x12c703) : !![])[_0x5b60fb(415)](([_0x1de4bf, _0x30aa6b]) => ({ "key": _0x1de4bf, "value": _0x30aa6b }));
}
async function get({ domain: _0x36b07d, version: _0x3f4d6d, scope = _0x316601(357), backend = _0x316601(497), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x3dc4e2 = _0x316601, _0x5508b7 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5508b7[_0x3dc4e2(356)] || !_0x5508b7[_0x3dc4e2(379)]) return null;
  const _0x3726f9 = buildStorageKey({ "domain": _0x36b07d, "version": _0x3f4d6d, "scopeKey": _0x5508b7[_0x3dc4e2(379)], "prefix": prefix }), _0x46c308 = await getRaw(backend, _0x3726f9);
  if (_0x46c308 == null) return null;
  const _0x19cde0 = parseJson(_0x46c308);
  if (!isEnvelopeValid(_0x19cde0)) return await removeRaw(backend, _0x3726f9), null;
  const _0x17b3ee = Number(_0x19cde0["v"]);
  if (_0x17b3ee !== Number(_0x3f4d6d)) return _0x17b3ee < Number(_0x3f4d6d) && await removeRaw(backend, _0x3726f9), null;
  if (isExpired(_0x19cde0, ttlMs)) return await removeRaw(backend, _0x3726f9), null;
  const _0x455528 = _0x5508b7[_0x3dc4e2(379)], _0x337a79 = String(((_a = _0x19cde0 == null ? void 0 : _0x19cde0[_0x3dc4e2(346)]) == null ? void 0 : _a[_0x3dc4e2(379)]) || "");
  if (_0x455528 && _0x337a79 && _0x455528 !== _0x337a79) return await removeRaw(backend, _0x3726f9), null;
  return _0x19cde0["data"] ?? null;
}
async function set({ domain: _0x3ee443, version: _0x57b612, scope = _0x316601(357), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x454b60 } = {}) {
  const _0x592c56 = _0x316601, _0x3bf658 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x3bf658[_0x592c56(356)] || !_0x3bf658[_0x592c56(379)]) return ![];
  const _0x381441 = buildStorageKey({ "domain": _0x3ee443, "version": _0x57b612, "scopeKey": _0x3bf658[_0x592c56(379)], "prefix": prefix }), _0x224720 = { "v": Number(_0x57b612), "ts": Date[_0x592c56(506)](), "ttlMs": Number[_0x592c56(348)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x3bf658[_0x592c56(393)], "scopeKey": _0x3bf658[_0x592c56(379)], "companyId": _0x3bf658[_0x592c56(386)], "realmId": _0x3bf658[_0x592c56(384)] }, "data": _0x454b60 };
  return setRaw(backend, _0x381441, toStorageRaw(normalizeBackend(backend), _0x224720));
}
async function remove({ domain: _0x5dc401, version: _0x2b3e09, scope = "scoped", backend = "local", prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x39e439 = _0x316601, _0x51d919 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x51d919[_0x39e439(356)] || !_0x51d919["scopeKey"]) return ![];
  const _0x204a1b = buildStorageKey({ "domain": _0x5dc401, "version": _0x2b3e09, "scopeKey": _0x51d919["scopeKey"], "prefix": prefix });
  return removeRaw(backend, _0x204a1b);
}
async function migrate({ domain: _0x38d01d, version: _0x597375, scope = _0x316601(357), backend = _0x316601(497), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x300238, cleanupLegacy = !![] } = {}) {
  const _0x5d24a2 = _0x316601, _0x323913 = await get({ "domain": _0x38d01d, "version": _0x597375, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x323913 !== null && _0x323913 !== void 0) return { "data": _0x323913, "migrated": ![] };
  if (typeof _0x300238 !== _0x5d24a2(349)) return { "data": null, "migrated": ![] };
  const _0x265ad6 = await _0x300238({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x5f45fe = _0x265ad6 == null ? void 0 : _0x265ad6["data"];
  if (_0x5f45fe === null || _0x5f45fe === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x38d01d, "version": _0x597375, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x5f45fe }), cleanupLegacy && typeof (_0x265ad6 == null ? void 0 : _0x265ad6[_0x5d24a2(464)]) === _0x5d24a2(349) && await _0x265ad6[_0x5d24a2(464)](), { "data": _0x5f45fe, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x316601(426), _0x316601(434)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x4d819e) {
  const _0x1ac27a = _0x316601, _0x41df13 = String(_0x4d819e || "")[_0x1ac27a(412)](":");
  if (_0x41df13[_0x1ac27a(408)] < 4) return null;
  if (_0x41df13[0] !== "scx") return null;
  const _0xaec3c2 = _0x41df13[1], _0x5b3f67 = _0x41df13[2] || "";
  if (!_0x5b3f67[_0x1ac27a(500)]("v")) return null;
  const _0x5c1679 = Number(_0x5b3f67[_0x1ac27a(373)](1));
  if (!Number[_0x1ac27a(348)](_0x5c1679)) return null;
  return { "domain": _0xaec3c2, "version": _0x5c1679 };
}
async function cleanupVersionedEnvelopes(_0x41de73) {
  const _0x23bbaa = _0x316601, _0x12a16e = await storage[_0x23bbaa(456)]({ "backend": _0x41de73, "prefix": _0x23bbaa(482) });
  for (const _0x5bd5ce of _0x12a16e) {
    const _0x608834 = parseDomainAndVersion(_0x5bd5ce[_0x23bbaa(361)]);
    if (!_0x608834) continue;
    const _0x17dd64 = Number(MIN_DOMAIN_VERSION[_0x608834["domain"]] || 1);
    if (_0x608834[_0x23bbaa(431)] < _0x17dd64) {
      await storage["removeRaw"](_0x41de73, _0x5bd5ce["key"]);
      continue;
    }
    if (_0x5bd5ce[_0x23bbaa(443)] == null) {
      await storage[_0x23bbaa(495)](_0x41de73, _0x5bd5ce[_0x23bbaa(361)]);
      continue;
    }
    const _0x12212c = typeof _0x5bd5ce["value"] === "string" ? (() => {
      const _0xfffda8 = _0x23bbaa;
      try {
        return JSON[_0xfffda8(398)](_0x5bd5ce[_0xfffda8(443)] || "null");
      } catch {
        return null;
      }
    })() : _0x5bd5ce[_0x23bbaa(443)];
    if (!_0x12212c || typeof _0x12212c !== _0x23bbaa(446) || !Number["isFinite"](Number(_0x12212c["v"]))) {
      await storage[_0x23bbaa(495)](_0x41de73, _0x5bd5ce[_0x23bbaa(361)]);
      continue;
    }
    Number(_0x12212c["v"]) < _0x17dd64 && await storage["removeRaw"](_0x41de73, _0x5bd5ce["key"]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x1003bc = _0x316601;
  for (const _0xfa343f of LEGACY_GLOBAL_KEYS) {
    await storage[_0x1003bc(495)]("local", _0xfa343f), await storage["removeRaw"]("chrome", _0xfa343f);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x360cfb = _0x316601;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x360cfb(497)), await cleanupVersionedEnvelopes(_0x360cfb(466)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0xdf9cd0, _0x5b9fca) {
  return new Promise((_0x29580d, _0x281083) => {
    const _0x42f836 = _0x2be8;
    let _0x4ba833 = null;
    const _0x584b8d = (_0x2dcc50, _0x285104, _0xedf9c1) => {
      const _0x39fc55 = _0x2be8;
      if (_0x4ba833 !== null && _0x285104[_0x39fc55(341)] && _0x285104[_0x39fc55(341)][_0x39fc55(455)] !== _0x4ba833) return;
      _0x2dcc50[_0x39fc55(468)] === _0x39fc55(392) && (_0x35f24f(), _0x2dcc50[_0x39fc55(360)] ? _0x281083(new Error(_0x2dcc50[_0x39fc55(360)])) : _0x2dcc50[_0x39fc55(388)] && _0x2dcc50["data"][_0x39fc55(408)] === 0 ? _0x29580d([]) : _0x29580d(_0x2dcc50["data"]));
    };
    chrome[_0x42f836(411)]["onMessage"][_0x42f836(435)](_0x584b8d);
    const _0x5ccf36 = setTimeout(() => {
      const _0x364e33 = _0x42f836;
      _0x35f24f(), _0x281083(new Error(_0x364e33(504)));
    }, 25e3), _0x35f24f = () => {
      const _0x1034b0 = _0x42f836;
      clearTimeout(_0x5ccf36), chrome[_0x1034b0(411)][_0x1034b0(494)][_0x1034b0(514)](_0x584b8d), _0x4ba833 !== null && chrome["windows"][_0x1034b0(401)](_0x4ba833)[_0x1034b0(437)](() => {
      });
    }, _0x4c3138 = encodeURIComponent(JSON[_0x42f836(414)](_0xdf9cd0)), _0x4f0290 = _0x42f836(496) + _0x4c3138;
    chrome[_0x42f836(368)][_0x42f836(428)]({ "url": _0x4f0290, "type": _0x42f836(344), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x42f836(347)]((_0x343c01) => {
      _0x4ba833 = _0x343c01["id"];
    })[_0x42f836(437)]((_0x15e1b9) => {
      _0x35f24f(), _0x281083(_0x15e1b9);
    });
  });
}
const DOMAIN = _0x316601(449), VERSION = 1;
async function getActiveAlarms() {
  const _0x4884aa = _0x316601, _0x4d165f = await storage[_0x4884aa(391)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x4884aa(488), "backend": _0x4884aa(466) });
  return (_0x4d165f == null ? void 0 : _0x4d165f[_0x4884aa(516)]) || [];
}
async function saveActiveAlarms(_0x230bb6) {
  const _0x1ed017 = _0x316601;
  await storage[_0x1ed017(367)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x1ed017(488), "backend": _0x1ed017(466), "data": { "alarms": _0x230bb6 } });
}
let addAlarmQueue = Promise[_0x316601(375)]();
function addAlarm(_0x3b00c8, _0x51652e, _0x88c36b, _0x2b6b1d, _0x110a46) {
  const _0x179286 = _0x316601;
  return addAlarmQueue = addAlarmQueue[_0x179286(347)](async () => {
    const _0x4a13e5 = _0x179286, _0x31941c = await getActiveAlarms(), _0x4b1f37 = _0x31941c[_0x4a13e5(417)]((_0x4ee9c3) => {
      const _0x58ec35 = _0x4a13e5;
      if (_0x88c36b && _0x4ee9c3[_0x58ec35(399)]) return _0x4ee9c3[_0x58ec35(399)] !== _0x88c36b;
      return _0x4ee9c3[_0x58ec35(423)] !== _0x3b00c8;
    });
    _0x4b1f37[_0x4a13e5(462)]({ "alarmId": _0x3b00c8, "buildingName": _0x51652e, "buildingId": _0x88c36b, "finishTimeMs": _0x2b6b1d, "translatedMessage": _0x110a46 }), await saveActiveAlarms(_0x4b1f37);
  })[_0x179286(437)](console[_0x179286(360)]), addAlarmQueue;
}
async function removeAlarm(_0xa68280) {
  const _0x37fffa = _0x316601, _0xe0399d = await getActiveAlarms(), _0x4383fa = _0xe0399d["filter"]((_0x48f6de) => _0x48f6de[_0x37fffa(423)] !== _0xa68280);
  _0xe0399d[_0x37fffa(408)] !== _0x4383fa[_0x37fffa(408)] && await saveActiveAlarms(_0x4383fa);
}
async function clearExpiredAlarms() {
  const _0x502cba = _0x316601, _0xacbda4 = await getActiveAlarms(), _0x2d014c = Date[_0x502cba(506)](), _0x337bc7 = _0xacbda4[_0x502cba(417)]((_0x55278c) => _0x55278c[_0x502cba(400)] > _0x2d014c);
  _0xacbda4[_0x502cba(408)] !== _0x337bc7[_0x502cba(408)] && await saveActiveAlarms(_0x337bc7);
}
const KEY_WHATS_NEW = "scx-whats-new", KEY_LAST_MINOR = _0x316601(378), KEY_LAST_VERSION = _0x316601(447), STORAGE_DOMAIN_WHATS_NEW = "whats-new", STORAGE_DOMAIN_WHATS_NEW_META = _0x316601(436), STORAGE_VERSION = 1;
async function setWhatsNew(_0x22eb1d) {
  const _0x3601ed = _0x316601;
  await storage[_0x3601ed(367)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": "global", "backend": "chrome", "refreshAuth": ![], "data": _0x22eb1d }), await storage[_0x3601ed(367)]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x3601ed(488), "backend": _0x3601ed(466), "refreshAuth": ![], "data": { "minorKey": _0x22eb1d[_0x3601ed(365)], "lastVersion": _0x22eb1d[_0x3601ed(339)] } }), await storage[_0x3601ed(495)](_0x3601ed(466), KEY_WHATS_NEW), await storage["removeRaw"](_0x3601ed(466), KEY_LAST_MINOR), await storage[_0x3601ed(495)](_0x3601ed(466), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x494aa0 = _0x316601;
  return request(_0x494aa0(377), { "url": "https://api.github.com/repos/MuhammetFurkanYilmaz/simco-manager/releases?per_page=100", "credentials": "omit", "responseType": _0x494aa0(438), "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x316601(411)][_0x316601(419)][_0x316601(435)](async (_0x4e7103) => {
  const _0x553fe0 = _0x316601;
  await initializeDataPlatform();
  _0x4e7103[_0x553fe0(505)] === _0x553fe0(459) && await storage[_0x553fe0(367)]({ "domain": _0x553fe0(410), "version": 1, "scope": _0x553fe0(488), "backend": _0x553fe0(466), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x4e7103[_0x553fe0(505)] === "update" && _0x4e7103[_0x553fe0(369)]) {
    const _0x264b87 = chrome[_0x553fe0(411)][_0x553fe0(387)]()["version"];
    if (_0x264b87 !== _0x4e7103[_0x553fe0(369)]) try {
      const _0x237a23 = await fetchAllReleases();
      let _0x5b2f8c = [];
      const _0x2acbc5 = releasePageUrl(_0x264b87);
      _0x237a23 && Array[_0x553fe0(416)](_0x237a23) && (_0x5b2f8c = collectHighlightsFromReleases(_0x237a23, _0x4e7103["previousVersion"], _0x264b87)), await setWhatsNew({ "show": !![], "version": _0x264b87, "url": _0x2acbc5, "highlights": _0x5b2f8c, "error": !_0x237a23 || !Array[_0x553fe0(416)](_0x237a23), "minorKey": minorKey(_0x264b87), "lastVersion": _0x264b87 });
    } catch (_0x3618f5) {
      console[_0x553fe0(360)](_0x553fe0(498), _0x3618f5), await setWhatsNew({ "show": !![], "version": _0x264b87, "url": releasePageUrl(_0x264b87), "highlights": [], "error": !![], "minorKey": minorKey(_0x264b87), "lastVersion": _0x264b87 });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
function _0x2be8(_0x306090, _0x5161c0) {
  _0x306090 = _0x306090 - 336;
  const _0x475a4a = _0x475a();
  let _0x2be8aa = _0x475a4a[_0x306090];
  if (_0x2be8["eDalRK"] === void 0) {
    var _0xe3b95 = function(_0x23202f) {
      const _0x4f54ae = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x1c81fb = "", _0x4b046c = "";
      for (let _0x5e857a = 0, _0x4cc72e, _0x4c1d93, _0x27c7fa = 0; _0x4c1d93 = _0x23202f["charAt"](_0x27c7fa++); ~_0x4c1d93 && (_0x4cc72e = _0x5e857a % 4 ? _0x4cc72e * 64 + _0x4c1d93 : _0x4c1d93, _0x5e857a++ % 4) ? _0x1c81fb += String["fromCharCode"](255 & _0x4cc72e >> (-2 * _0x5e857a & 6)) : 0) {
        _0x4c1d93 = _0x4f54ae["indexOf"](_0x4c1d93);
      }
      for (let _0x322708 = 0, _0x574e74 = _0x1c81fb["length"]; _0x322708 < _0x574e74; _0x322708++) {
        _0x4b046c += "%" + ("00" + _0x1c81fb["charCodeAt"](_0x322708)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x4b046c);
    };
    _0x2be8["cVimYX"] = _0xe3b95, _0x2be8["wOJzMW"] = {}, _0x2be8["eDalRK"] = !![];
  }
  const _0x4a7f51 = _0x475a4a[0], _0x5a44ca = _0x306090 + _0x4a7f51, _0x47a593 = _0x2be8["wOJzMW"][_0x5a44ca];
  return !_0x47a593 ? (_0x2be8aa = _0x2be8["cVimYX"](_0x2be8aa), _0x2be8["wOJzMW"][_0x5a44ca] = _0x2be8aa) : _0x2be8aa = _0x47a593, _0x2be8aa;
}
async function fetchCooperData(_0x3612aa) {
  const _0x4534c2 = _0x316601, _0x3d448a = Date[_0x4534c2(506)]();
  if (cooperDataCache[_0x3612aa] && cooperDataCacheTs[_0x3612aa] && _0x3d448a - cooperDataCacheTs[_0x3612aa] < COOPER_CACHE_TTL) return cooperDataCache[_0x3612aa];
  const _0x23cf3a = "r" + (_0x3612aa + 1), _0x12e5ae = await fetch(_0x4534c2(394) + _0x23cf3a);
  if (!_0x12e5ae["ok"]) throw new Error(_0x4534c2(403) + _0x12e5ae[_0x4534c2(469)]);
  const _0x37a166 = await _0x12e5ae["json"]();
  return cooperDataCache[_0x3612aa] = _0x37a166, cooperDataCacheTs[_0x3612aa] = _0x3d448a, _0x37a166;
}
chrome[_0x316601(411)][_0x316601(494)][_0x316601(435)]((_0x4370ff, _0x11acd5, _0x583bca) => {
  const _0x29dec6 = _0x316601;
  if (_0x4370ff[_0x29dec6(468)] === _0x29dec6(362)) return fetchCooperData(_0x4370ff["realmId"])[_0x29dec6(347)]((_0x47f0b4) => _0x583bca({ "success": !![], "data": _0x47f0b4 }))[_0x29dec6(437)]((_0x4b5c7c) => _0x583bca({ "success": ![], "error": _0x4b5c7c[_0x29dec6(515)] })), !![];
  if (_0x4370ff["type"] === _0x29dec6(432)) {
    const _0x14bc36 = _0x4370ff[_0x29dec6(384)], _0x97d628 = _0x29dec6(507) + _0x14bc36 + _0x29dec6(511);
    return request(_0x29dec6(476), { "url": _0x97d628, "method": _0x29dec6(490), "credentials": "omit", "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })["then"]((_0xb496a3) => _0x583bca({ "success": !![], "data": _0xb496a3 }))[_0x29dec6(437)]((_0x1792ef) => _0x583bca({ "success": ![], "error": _0x1792ef["message"] || String(_0x1792ef) })), !![];
  }
  if (_0x4370ff[_0x29dec6(468)] === _0x29dec6(364)) {
    const { realmId: _0x17b5fc, queryParams: _0x16a634, headers: _0x12b438 } = _0x4370ff, _0x30ecb0 = _0x29dec6(507) + _0x17b5fc + _0x29dec6(370) + _0x16a634;
    return request(_0x29dec6(476), { "url": _0x30ecb0, "method": "GET", "headers": _0x12b438, "credentials": _0x29dec6(363), "responseType": _0x29dec6(438), "retries": 2, "retryDelayMs": 1e3 })[_0x29dec6(347)]((_0x1b3dfa) => _0x583bca({ "success": !![], "data": _0x1b3dfa }))[_0x29dec6(437)]((_0x4463d2) => _0x583bca({ "success": ![], "error": _0x4463d2[_0x29dec6(515)] || String(_0x4463d2) })), !![];
  }
  if (_0x4370ff[_0x29dec6(468)] === _0x29dec6(499)) {
    const { realmId: _0x39c670, headers: _0x531bf2 } = _0x4370ff, _0x3186db = _0x29dec6(507) + _0x39c670 + _0x29dec6(484);
    return request(_0x29dec6(476), { "url": _0x3186db, "method": _0x29dec6(490), "headers": _0x531bf2, "credentials": _0x29dec6(363), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })[_0x29dec6(347)]((_0x3ac079) => _0x583bca({ "success": !![], "data": _0x3ac079 }))[_0x29dec6(437)]((_0x80210f) => _0x583bca({ "success": ![], "error": _0x80210f[_0x29dec6(515)] || String(_0x80210f) })), !![];
  }
  if (_0x4370ff[_0x29dec6(468)] === "FETCH_SIMCOTOOLS_PHASES") {
    const { realmId: _0x212135, headers: _0xcbaa2f } = _0x4370ff, _0x4b2cf8 = _0x29dec6(507) + _0x212135 + _0x29dec6(477);
    return request(_0x29dec6(476), { "url": _0x4b2cf8, "method": _0x29dec6(490), "headers": _0xcbaa2f, "credentials": _0x29dec6(363), "responseType": _0x29dec6(438), "retries": 2, "retryDelayMs": 1e3 })[_0x29dec6(347)]((_0x3d6fa4) => _0x583bca({ "success": !![], "data": _0x3d6fa4 }))[_0x29dec6(437)]((_0x136540) => _0x583bca({ "success": ![], "error": _0x136540[_0x29dec6(515)] || String(_0x136540) })), !![];
  }
  if (_0x4370ff[_0x29dec6(468)] === _0x29dec6(508)) return scrapeCooperRetail(_0x4370ff["params"])[_0x29dec6(347)]((_0x434fa7) => _0x583bca({ "success": !![], "data": _0x434fa7 }))[_0x29dec6(437)]((_0xbdebcd) => _0x583bca({ "success": ![], "error": _0xbdebcd[_0x29dec6(515)] })), !![];
  if (_0x4370ff["type"] === "SET_BUILDING_ALARM") {
    const { buildingName: _0xa0735d, buildingId: _0x330ea7, finishTimeMs: _0x2ae32d, translatedMessage: _0x131b4a } = _0x4370ff[_0x29dec6(388)], _0x571a98 = _0x29dec6(453) + Date[_0x29dec6(506)]() + "-" + Math[_0x29dec6(359)](Math[_0x29dec6(441)]() * 1e3);
    return chrome[_0x29dec6(516)][_0x29dec6(428)](_0x571a98, { "when": _0x2ae32d }), addAlarm(_0x571a98, _0xa0735d, _0x330ea7, _0x2ae32d, _0x131b4a)[_0x29dec6(437)](console["error"]), _0x583bca({ "success": !![], "alarmId": _0x571a98 }), !![];
  }
  if (_0x4370ff[_0x29dec6(468)] === _0x29dec6(336)) {
    const { alarmId: _0x349bbb } = _0x4370ff[_0x29dec6(388)];
    return chrome["alarms"][_0x29dec6(409)](_0x349bbb), removeAlarm(_0x349bbb)[_0x29dec6(437)](console[_0x29dec6(360)]), _0x583bca({ "success": !![] }), !![];
  }
}), chrome[_0x316601(516)][_0x316601(371)][_0x316601(435)](async (_0x2965be) => {
  const _0x3fe0f8 = _0x316601;
  if (_0x2965be[_0x3fe0f8(355)][_0x3fe0f8(500)](_0x3fe0f8(453))) {
    const _0x42c6f1 = await getActiveAlarms(), _0x3d5489 = _0x42c6f1[_0x3fe0f8(442)]((_0x3d7970) => _0x3d7970[_0x3fe0f8(423)] === _0x2965be[_0x3fe0f8(355)]), _0x2d655d = _0x3d5489 ? _0x3d5489[_0x3fe0f8(486)] : _0x3fe0f8(512), _0x2d5e35 = (_0x3d5489 == null ? void 0 : _0x3d5489["translatedMessage"]) || _0x2d655d + _0x3fe0f8(517);
    chrome[_0x3fe0f8(439)]["create"](_0x2965be[_0x3fe0f8(355)], { "type": _0x3fe0f8(345), "iconUrl": "icons/48.png", "title": _0x3fe0f8(445), "message": _0x2d5e35, "priority": 2 }), await removeAlarm(_0x2965be[_0x3fe0f8(355)]);
  }
}), chrome[_0x316601(516)]["create"](_0x316601(353), { "periodInMinutes": 60 }), chrome[_0x316601(516)][_0x316601(371)][_0x316601(435)]((_0x4f3913) => {
  const _0x450f6c = _0x316601;
  _0x4f3913[_0x450f6c(355)] === _0x450f6c(353) && clearExpiredAlarms()[_0x450f6c(437)](console["error"]);
});
