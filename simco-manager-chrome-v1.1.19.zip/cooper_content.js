function _0x1197() {
  var _0x18f187 = ["mtK1otyYnffTBxPTEa", "mtuYnJm1wwP1vhPA", "mtm2odyZv0f6yMX3", "mZeYotjxrwfYDgq", "ndHtr1r5BNK", "nJbMv2PhDxe", "mteWndK0ohfbugHIDG", "mteYmJK5nMHQvvvwzq", "mteZnde3mffyrfrPCq"];
  _0x1197 = function() {
    return _0x18f187;
  };
  return _0x1197();
}
(function(_0x23b0a8, _0x14ada9) {
  var _0x4c9afb = _0x2b5d, _0x81b141 = _0x23b0a8();
  while (!![]) {
    try {
      var _0x135475 = -parseInt(_0x4c9afb(381)) / 1 + -parseInt(_0x4c9afb(382)) / 2 * (-parseInt(_0x4c9afb(374)) / 3) + -parseInt(_0x4c9afb(377)) / 4 + parseInt(_0x4c9afb(378)) / 5 + parseInt(_0x4c9afb(375)) / 6 * (parseInt(_0x4c9afb(380)) / 7) + -parseInt(_0x4c9afb(379)) / 8 + parseInt(_0x4c9afb(376)) / 9;
      if (_0x135475 === _0x14ada9) break;
      else _0x81b141["push"](_0x81b141["shift"]());
    } catch (_0x4394b3) {
      _0x81b141["push"](_0x81b141["shift"]());
    }
  }
})(_0x1197, 155427);
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x2b5d(_0x281f16, _0x326b13) {
  _0x281f16 = _0x281f16 - 374;
  var _0x11970d = _0x1197();
  var _0x2b5d2b = _0x11970d[_0x281f16];
  if (_0x2b5d["ayATTj"] === void 0) {
    var _0x5b1236 = function(_0x584e5f) {
      var _0x4e935b = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x5e1d81 = "", _0x1ab24b = "";
      for (var _0x5615cc = 0, _0x4a0891, _0x527af6, _0x51220f = 0; _0x527af6 = _0x584e5f["charAt"](_0x51220f++); ~_0x527af6 && (_0x4a0891 = _0x5615cc % 4 ? _0x4a0891 * 64 + _0x527af6 : _0x527af6, _0x5615cc++ % 4) ? _0x5e1d81 += String["fromCharCode"](255 & _0x4a0891 >> (-2 * _0x5615cc & 6)) : 0) {
        _0x527af6 = _0x4e935b["indexOf"](_0x527af6);
      }
      for (var _0xa1e162 = 0, _0x1eacdd = _0x5e1d81["length"]; _0xa1e162 < _0x1eacdd; _0xa1e162++) {
        _0x1ab24b += "%" + ("00" + _0x5e1d81["charCodeAt"](_0xa1e162)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x1ab24b);
    };
    _0x2b5d["xkylMZ"] = _0x5b1236, _0x2b5d["JXzvyk"] = {}, _0x2b5d["ayATTj"] = !![];
  }
  var _0x6563ae = _0x11970d[0], _0x332272 = _0x281f16 + _0x6563ae, _0x480d6f = _0x2b5d["JXzvyk"][_0x332272];
  return !_0x480d6f ? (_0x2b5d2b = _0x2b5d["xkylMZ"](_0x2b5d2b), _0x2b5d["JXzvyk"][_0x332272] = _0x2b5d2b) : _0x2b5d2b = _0x480d6f, _0x2b5d2b;
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
