const _0x15afba = _0x30fd;
function _0x4d22() {
  const _0x7bc8c2 = ["yxzLCMfNzvbYAwnL", "BwLU", "C2f0DxjHDgLVBG", "ChbOCgW", "CMvZDwX0", "mtKZmda4u0DZqLf4", "CMvJzxnZAw9U", "y2fSy3vSyxrL", "Cg9ZDe1LC3nHz2u", "Dg9gAxHLza", "mtiWnde4mhzOCgn3uq", "mZjfy3D4uLq", "mty3ntKYDvPwveDl", "mJa3B2PTr2vd", "B25TzxnZywDL", "Bwf4", "CM91BMq", "nte1mtG4me1nzvvRqq", "ntu4mdu2ngfZwhDkEG", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "ChjVzhvJDe5HBwu", "Dg9mB3DLCKnHC2u", "odeWndmWnNDvB0XqAG", "zgf0yq", "uhjVzhvJDca", "nJq0nte0qLPfALzp", "y29ZDa", "ChvZAa"];
  _0x4d22 = function() {
    return _0x7bc8c2;
  };
  return _0x4d22();
}
function _0x30fd(_0x1d17c6, _0x598fb1) {
  _0x1d17c6 = _0x1d17c6 - 393;
  const _0x4d2278 = _0x4d22();
  let _0x30fd32 = _0x4d2278[_0x1d17c6];
  if (_0x30fd["YFvPIG"] === void 0) {
    var _0x321d52 = function(_0x3ce1d6) {
      const _0x1d1216 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x5ea741 = "", _0xbd707d = "";
      for (let _0x1a77df = 0, _0x2f5c1c, _0x4522e5, _0x4eada2 = 0; _0x4522e5 = _0x3ce1d6["charAt"](_0x4eada2++); ~_0x4522e5 && (_0x2f5c1c = _0x1a77df % 4 ? _0x2f5c1c * 64 + _0x4522e5 : _0x4522e5, _0x1a77df++ % 4) ? _0x5ea741 += String["fromCharCode"](255 & _0x2f5c1c >> (-2 * _0x1a77df & 6)) : 0) {
        _0x4522e5 = _0x1d1216["indexOf"](_0x4522e5);
      }
      for (let _0x241d1f = 0, _0x2a90a3 = _0x5ea741["length"]; _0x241d1f < _0x2a90a3; _0x241d1f++) {
        _0xbd707d += "%" + ("00" + _0x5ea741["charCodeAt"](_0x241d1f)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0xbd707d);
    };
    _0x30fd["QbXFre"] = _0x321d52, _0x30fd["ckafDw"] = {}, _0x30fd["YFvPIG"] = !![];
  }
  const _0x555588 = _0x4d2278[0], _0x3d773b = _0x1d17c6 + _0x555588, _0xbea1f1 = _0x30fd["ckafDw"][_0x3d773b];
  return !_0xbea1f1 ? (_0x30fd32 = _0x30fd["QbXFre"](_0x30fd32), _0x30fd["ckafDw"][_0x3d773b] = _0x30fd32) : _0x30fd32 = _0xbea1f1, _0x30fd32;
}
(function(_0x4a7f7f, _0x3e017d) {
  const _0x2f4f81 = _0x30fd, _0x4cc237 = _0x4a7f7f();
  while (!![]) {
    try {
      const _0x5aad8b = -parseInt(_0x2f4f81(397)) / 1 + parseInt(_0x2f4f81(411)) / 2 * (parseInt(_0x2f4f81(405)) / 3) + -parseInt(_0x2f4f81(410)) / 4 + -parseInt(_0x2f4f81(417)) / 5 + parseInt(_0x2f4f81(418)) / 6 + parseInt(_0x2f4f81(394)) / 7 + -parseInt(_0x2f4f81(412)) / 8 * (parseInt(_0x2f4f81(413)) / 9);
      if (_0x5aad8b === _0x3e017d) break;
      else _0x4cc237["push"](_0x4cc237["shift"]());
    } catch (_0x545b7a) {
      _0x4cc237["push"](_0x4cc237["shift"]());
    }
  }
})(_0x4d22, 659466), self[_0x15afba(414)] = async (_0x5ea741) => {
  const _0xcadacd = _0x15afba, { action: _0xbd707d, products: _0x1a77df, adminOverhead: _0x2f5c1c, salesBonus: _0x4522e5, economyPhase: _0x4eada2, simulateError: _0x241d1f } = _0x5ea741[_0xcadacd(395)];
  if (_0xbd707d === _0xcadacd(407)) {
    if (_0x241d1f) {
      self["postMessage"]({ "error": _0xcadacd(419) });
      return;
    }
    try {
      const _0x2a90a3 = _0x2f5c1c !== void 0 ? _0x2f5c1c : 0, _0x45a6e1 = _0x4522e5 !== void 0 ? _0x4522e5 : 0, _0x5b67d5 = _0x4eada2 || "Normal", _0x6c6ebf = Math[_0xcadacd(415)](0, Math[_0xcadacd(401)](_0x2a90a3, 200)), _0x4cc06c = Math[_0xcadacd(415)](0, Math["min"](_0x45a6e1, 50)), _0x5b6c8a = _0x5b67d5[_0xcadacd(393)]() === _0xcadacd(406) ? 0.9 : _0x5b67d5[_0xcadacd(393)]() === "boom" ? 1.12 : 1, _0xe6cc4b = [];
      for (const _0x979f4a of _0x1a77df) {
        for (let _0x4117e0 = 0; _0x4117e0 <= 9; _0x4117e0++) {
          const _0x7ef9d5 = _0x4117e0, _0x23d44d = _0x979f4a[_0xcadacd(402)] <= 0 || _0x979f4a[_0xcadacd(402)] == null ? 0.1 : Math[_0xcadacd(415)](0.1, Math[_0xcadacd(401)](_0x979f4a["saturation"], 5)), _0x474f00 = 1 + _0x7ef9d5 * 0.05, _0x36121f = 100, _0x17c7bb = _0x36121f / _0x23d44d * _0x474f00 * _0x5b6c8a * (1 + _0x4cc06c / 100), _0x48a849 = _0x17c7bb / 24, _0x1c5561 = _0x979f4a[_0xcadacd(400)] || _0x979f4a[_0xcadacd(398)] * 1.5, _0x1186cf = _0x1c5561 - _0x979f4a[_0xcadacd(398)], _0x3227f6 = _0x17c7bb * _0x1c5561, _0x385d00 = _0x3227f6 * (_0x6c6ebf / 100), _0x5c753f = _0x17c7bb * _0x1186cf - _0x385d00;
          if (_0x5c753f < 0) continue;
          _0xe6cc4b[_0xcadacd(399)]({ "productId": _0x979f4a["productId"], "productName": _0x979f4a[_0xcadacd(420)] || _0xcadacd(396) + _0x979f4a["productId"], "quality": _0x7ef9d5, "price": parseFloat(_0x1c5561[_0xcadacd(409)](2)), "cost": parseFloat(_0x979f4a[_0xcadacd(398)][_0xcadacd(409)](2)), "profitPerUnit": parseFloat(_0x1186cf[_0xcadacd(409)](2)), "profitPerDay": Math["round"](_0x5c753f), "grossRevPerDay": Math[_0xcadacd(416)](_0x3227f6), "unitsPerHr": parseFloat(_0x48a849[_0xcadacd(409)](1)), "unitsPerDay": Math["round"](_0x17c7bb), "pphpl": _0x5c753f });
        }
      }
      _0xe6cc4b["sort"]((_0x360d5d, _0x29d54d) => _0x29d54d[_0xcadacd(403)] - _0x360d5d[_0xcadacd(403)]), self[_0xcadacd(408)]({ "action": _0xcadacd(404), "results": _0xe6cc4b });
    } catch (_0x2f0c59) {
      self["postMessage"]({ "error": _0x2f0c59["message"] });
    }
  }
};
