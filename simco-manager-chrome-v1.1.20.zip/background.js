const _0x703c90 = _0x41a3;
function _0x2082() {
  const _0xd89e7a = ["l3n0yxrZl2j1AwXKAw5NCW", "yM9KEq", "yMXVy2TLza", "yNvPBgrPBMDoyw1L", "C2nVCgvlzxK", "Aw5ZDgfSBa", "ywjVCNq", "zMLUza", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "C2fSzxnnB2rPzMLLCG", "BgvUz3rO", "ChjVzhvJDgLVBK1VzgLMAwvY", "DxjS", "l2v4zwn1DgL2zxm/", "D2vSy29Tzs1TzxnZywDL", "Bwf0y2G", "vxbKyxrLza", "ChjLDMLVDxnwzxjZAw9U", "C3rHCNrZv2L0Aa", "AxngAw5PDgu", "C3rHDhvZ", "C2n4lxDOyxrZlw5LDW", "CMvTywLUAw5Ntxm", "zMLUAxnOvgLTzu1Z", "CMfUzg9T", "CMvTB3zLsxrLBq", "l3jLBgvHC2vZl3rHzY92", "D2HHDhmTBMv3lw1LDge", "yxnZAwDU", "mJfdC3Hnu1C", "Ahr0Chm6lY9NAxrODwiUy29TlW", "yxv0Aa", "uMvXDwvZDcbMywLSzwq", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "Bg9HzgLUzW", "u0vux0jvsuXesu5hx0fmqvjn", "y29HBgvZy2u", "uMvXDwvZDcb0Aw1LB3v0", "zgvSzxrL", "B25bBgfYBq", "DhjPBq", "BMfTzq", "mtiWotq2ndnqrfHfEKO", "CNvUDgLTzq", "ywrKtgLZDgvUzxi", "C2XPy2u", "Aw5JBhvKzq", "mtb2rvror0C", "rML4zwq", "zMXVB3i", "C2LNBMfS", "DhLWzq", "CgfYC2u", "BM93", "zMLSDgvY", "Bw9Kzq", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "y2f0y2G", "C2LTy290B29SCW", "Bgv2zwW", "z2v0", "yMXVyG", "yNvPBgrPBMDjza", "y2HYB21L", "B21PDa", "y3jLyxrL", "C3rVCMfNzq", "u2LTq28GtwfUywDLCG", "Dgv4Da", "Aw5JBhvKzxm", "yNvPBgrPBMCTywXHCM1Z", "ywXHCM1jza", "y29TCgfUEq", "AgfZu2nVCgu", "Dw5RBM93BG", "zMLUywXSEq", "zxjYB3i", "CMvTB3zLuMf3", "rKvuq0HFq09puevsx0rbvee", "y29TCgfUEuLK", "AxnbCNjHEq", "B2jQzwn0", "C2n4lwnSzwfUDxaTywXHCM1Z", "DxbKyxrL", "Dw5KzwzPBMvK", "yxjYyxLcDwzMzxi", "qujpuLrfra", "DgHLBG", "Bg9HzgvK", "z2v0twfUAwzLC3q", "zNvUy3rPB24", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "DgvZDa", "z2v0sxrLBq", "zML4", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "q09puevsx0LguKfnrv9srvnvtfq", "ywXHCM1Z", "C2n4lwj1AwXKAw5NCY10CW", "tKvuv09ss19fuLjpuG", "DMvYC2LVBG", "sw1WCM92zwq", "C2n4oG", "AgfZ", "Bgv2zwXjBMzV", "qsbIDwLSzgLUzW", "BgLZDej5uhjLzML4", "zgvMyxvSDa", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "C3rYAw5NAwz5", "mJe3ndCWnwHZzwXIyq", "A2v5", "mJy3mZuYogjwBunHwq", "Cg9WDxa", "veLnru9vva", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l3jLDgfPBd9Zy3HFCgfYyw1Zpq", "nKLyD2rpDa", "yMfZAwm", "y2vPBa", "tMv3", "zw50CMLLCW", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "DgfNx25HBwu", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "uKfurv9msu1jvf9dt09mre9xtJO", "DMfSDwu", "D2LUzg93CW", "z2L0AhvIlxjLBgvHC2vZ", "C2v0", "ChjLCMvSzwfZzq", "mta0mtyWnJbzywzsq1O", "C2v0sxrLBq", "BM90AwzPy2f0Aw9UCW", "sfruuca", "DgfI", "B25jBNn0ywXSzwq", "C2nVCgvK", "Dg9mB3DLCKnHC2u", "zg9TywLU", "B25nzxnZywDL", "CMvHC29U", "BwfW", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "sfruuf9fuLjpuG", "l3bOyxnLCW", "ChvZAa", "C3rYAw5N", "CMvTB3zL", "BNvSBa", "mtm2ntqWohDMB2XSEq", "zgf0yq", "Bwv0Ag9K", "ANnVBG", "mtGXmJy3t21hvxzf", "CMvHBg1jza", "zxHWzxjPzw5Jzq", "rKvuq0HFu0Lnq09ut09mu19fwevdvvrjvKvt", "Bwf4", "C3bSAxq", "CMvWBgfJzq", "rMfPBgvKihrVigzLDgnOihjLBgvHC2uGBM90zxm6", "BwvZC2fNzq", "C2n4lwj1AwXKAw5NCW", "C2LTy28TBwfUywDLCG", "Bg9JywW", "mZu4odeYnNreBvPxsa", "C2n4", "z2XVyMfS", "Ahr0Chm6lY9HCgKUz2L0AhvIlMnVBs9YzxbVCY9nDwHHBw1LDez1CMTHBLLPBg1HEI9ZAw1JBY1Tyw5Hz2vYl3jLBgvHC2vZp3bLCL9WywDLpteWma", "DhjHBNnSyxrLze1LC3nHz2u", "r0vu", "mLb2v1Hvrq"];
  _0x2082 = function() {
    return _0xd89e7a;
  };
  return _0x2082();
}
(function(_0x35dca4, _0x37e4b3) {
  const _0x817bce = _0x41a3, _0x10785a = _0x35dca4();
  while (!![]) {
    try {
      const _0xa0d521 = -parseInt(_0x817bce(296)) / 1 * (parseInt(_0x817bce(314)) / 2) + parseInt(_0x817bce(308)) / 3 + parseInt(_0x817bce(292)) / 4 + -parseInt(_0x817bce(253)) / 5 * (-parseInt(_0x817bce(259)) / 6) + parseInt(_0x817bce(345)) / 7 * (-parseInt(_0x817bce(255)) / 8) + parseInt(_0x817bce(273)) / 9 + parseInt(_0x817bce(363)) / 10 * (-parseInt(_0x817bce(358)) / 11);
      if (_0xa0d521 === _0x37e4b3) break;
      else _0x10785a["push"](_0x10785a["shift"]());
    } catch (_0x1866c8) {
      _0x10785a["push"](_0x10785a["shift"]());
    }
  }
})(_0x2082, 846322);
const REPO_OWNER = _0x703c90(251), REPO_NAME = _0x703c90(306);
function parseVersion(_0x18293c) {
  const _0x1acf4e = _0x703c90, _0x2b351a = String(_0x18293c || "")[_0x1acf4e(302)](/^v/i, "")[_0x1acf4e(301)](".");
  return [Number(_0x2b351a[0] || 0), Number(_0x2b351a[1] || 0), Number(_0x2b351a[2] || 0)];
}
function compareVersions(_0x36d7ec, _0x57eee4) {
  const [_0x71081d, _0x508107, _0x2e2aba] = parseVersion(_0x36d7ec), [_0x26e33b, _0xddc9cc, _0x170f77] = parseVersion(_0x57eee4);
  if (_0x71081d !== _0x26e33b) return _0x71081d - _0x26e33b;
  if (_0x508107 !== _0xddc9cc) return _0x508107 - _0xddc9cc;
  return _0x2e2aba - _0x170f77;
}
function minorKey(_0x39e0c3) {
  const _0xf06d98 = _0x703c90, _0x227e20 = String(_0x39e0c3 || "")[_0xf06d98(301)]("."), _0x1a6532 = _0x227e20[0] || "0", _0x13fa9f = _0x227e20[1] || "0";
  return _0x1a6532 + "." + _0x13fa9f;
}
function releasePageUrl(_0x2d611a) {
  const _0x476d67 = _0x703c90, _0x53585f = String(_0x2d611a || "")["trim"]();
  return _0x476d67(346) + REPO_OWNER + "/" + REPO_NAME + _0x476d67(342) + encodeURIComponent(_0x53585f);
}
function stripMarkdown(_0x1e93be) {
  const _0x47b852 = _0x703c90;
  let _0x4eda02 = String(_0x1e93be || "");
  return _0x4eda02 = _0x4eda02[_0x47b852(302)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0x4eda02 = _0x4eda02[_0x47b852(302)](/https?:\/\/\S+/gi, ""), _0x4eda02 = _0x4eda02[_0x47b852(302)](/[`*_>#]/g, ""), _0x4eda02 = _0x4eda02[_0x47b852(302)](/\s+/g, " ")[_0x47b852(356)](), _0x4eda02;
}
function humanizeHighlight(_0x68add5) {
  const _0x5e6663 = _0x703c90;
  let _0x469901 = stripMarkdown(_0x68add5);
  _0x469901 = _0x469901["replace"](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x469901 = _0x469901[_0x5e6663(302)](/\s+in\s*$/i, ""), _0x469901 = _0x469901[_0x5e6663(302)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x52626e = _0x469901["match"](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x52626e) {
    const _0x1555bb = _0x52626e[1][_0x5e6663(280)](), _0x1befdb = _0x52626e[3], _0x50348f = _0x1555bb === "feat" ? _0x5e6663(262) : _0x1555bb === _0x5e6663(237) ? _0x5e6663(191) : _0x1555bb === "perf" ? _0x5e6663(244) : _0x1555bb === "docs" ? _0x5e6663(332) : null;
    if (_0x50348f) _0x469901 = _0x50348f + ": " + _0x1befdb;
  }
  return _0x469901 = _0x469901[_0x5e6663(302)](/\s+/g, " ")[_0x5e6663(356)](), _0x469901;
}
function extractHighlights(_0x189403, { limit = 5 } = {}) {
  const _0x3e81f6 = _0x703c90, _0x42d575 = String(_0x189403 || ""), _0x20b01e = _0x42d575[_0x3e81f6(301)](/\r?\n/), _0xf05ea4 = [];
  let _0x145d10 = ![];
  for (const _0x4d70c3 of _0x20b01e) {
    const _0xba431d = _0x4d70c3[_0x3e81f6(356)]();
    if (_0xba431d["startsWith"]("```")) {
      _0x145d10 = !_0x145d10;
      continue;
    }
    if (_0x145d10) continue;
    if (!_0xba431d) continue;
    if (/^#+\s+/[_0x3e81f6(235)](_0xba431d)) continue;
    const _0x42e358 = _0xba431d[_0x3e81f6(331)](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x42e358) {
      const _0x25c261 = humanizeHighlight(_0x42e358[2]);
      if (_0x25c261) _0xf05ea4[_0x3e81f6(288)](_0x25c261);
    }
    if (_0xf05ea4[_0x3e81f6(326)] >= limit) break;
  }
  return _0xf05ea4[_0x3e81f6(361)](0, limit);
}
function collectHighlightsFromReleases(_0x4d6483, _0xe66de6, _0x19e9de, { limit = 10 } = {}) {
  const _0x399670 = _0x703c90, _0x588ed2 = (Array[_0x399670(223)](_0x4d6483) ? _0x4d6483 : [])["filter"]((_0x124807) => !(_0x124807 == null ? void 0 : _0x124807[_0x399670(272)]))[_0x399670(284)]((_0x29b5ff) => ({ ..._0x29b5ff, "tag_name": String((_0x29b5ff == null ? void 0 : _0x29b5ff[_0x399670(265)]) || "") }))["filter"]((_0x358e39) => /^v?\d+\.\d+\.\d+$/[_0x399670(235)](_0x358e39[_0x399670(265)]))["filter"]((_0x102c9a) => compareVersions(_0x102c9a["tag_name"], _0xe66de6) > 0)[_0x399670(197)]((_0x2078e8) => compareVersions(_0x2078e8[_0x399670(265)], _0x19e9de) <= 0)["sort"]((_0x431cfc, _0x51df6b) => compareVersions(_0x431cfc["tag_name"], _0x51df6b[_0x399670(265)])), _0xcc6a8b = [];
  for (const _0x339b9b of _0x588ed2) {
    const _0x591782 = extractHighlights(_0x339b9b[_0x399670(316)], { "limit": limit });
    for (const _0x18ddd5 of _0x591782) {
      _0xcc6a8b["push"](_0x18ddd5);
      if (_0xcc6a8b["length"] >= limit) return _0xcc6a8b;
    }
  }
  return _0xcc6a8b[_0x399670(361)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x36b283) {
  return new Promise((_0x45a902) => setTimeout(_0x45a902, _0x36b283));
}
function _0x41a3(_0x2164f8, _0x269ebb) {
  _0x2164f8 = _0x2164f8 - 191;
  const _0x2082cd = _0x2082();
  let _0x41a3b4 = _0x2082cd[_0x2164f8];
  if (_0x41a3["ChSviw"] === void 0) {
    var _0xa141fc = function(_0x1515ba) {
      const _0x20b12d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x18293c = "", _0x2b351a = "";
      for (let _0x36d7ec = 0, _0x57eee4, _0x71081d, _0x508107 = 0; _0x71081d = _0x1515ba["charAt"](_0x508107++); ~_0x71081d && (_0x57eee4 = _0x36d7ec % 4 ? _0x57eee4 * 64 + _0x71081d : _0x71081d, _0x36d7ec++ % 4) ? _0x18293c += String["fromCharCode"](255 & _0x57eee4 >> (-2 * _0x36d7ec & 6)) : 0) {
        _0x71081d = _0x20b12d["indexOf"](_0x71081d);
      }
      for (let _0x2e2aba = 0, _0x26e33b = _0x18293c["length"]; _0x2e2aba < _0x26e33b; _0x2e2aba++) {
        _0x2b351a += "%" + ("00" + _0x18293c["charCodeAt"](_0x2e2aba)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x2b351a);
    };
    _0x41a3["utJPMi"] = _0xa141fc, _0x41a3["ryReCe"] = {}, _0x41a3["ChSviw"] = !![];
  }
  const _0x47f90c = _0x2082cd[0], _0x56283e = _0x2164f8 + _0x47f90c, _0x1a38c0 = _0x41a3["ryReCe"][_0x56283e];
  return !_0x1a38c0 ? (_0x41a3b4 = _0x41a3["utJPMi"](_0x41a3b4), _0x41a3["ryReCe"][_0x56283e] = _0x41a3b4) : _0x41a3b4 = _0x1a38c0, _0x41a3b4;
}
function normalizeDomain$1(_0x4f9524) {
  const _0x3a31a5 = _0x703c90;
  return String(_0x4f9524 || _0x3a31a5(250))[_0x3a31a5(356)]()[_0x3a31a5(280)]();
}
function makeError(_0x51346f, _0x7f5e92 = {}) {
  const _0x261c39 = _0x703c90, _0xb051a6 = new Error(_0x51346f);
  return Object[_0x261c39(344)](_0xb051a6, _0x7f5e92), _0xb051a6;
}
function buildInflightKey(_0x4bc33a, _0x200a62, _0x3d4b92, _0xe136f5) {
  if (_0x200a62) return _0x4bc33a + ":" + _0x200a62;
  return _0x4bc33a + ":" + _0xe136f5 + ":" + _0x3d4b92;
}
function getRateLimitStatus(_0x3ed995 = _0x703c90(250)) {
  const _0x17e6ef = _0x703c90, _0x29b237 = normalizeDomain$1(_0x3ed995), _0x5f0c8f = Number(rateLimitByDomain[_0x17e6ef(203)](_0x29b237) || 0), _0x353326 = Math[_0x17e6ef(300)](0, _0x5f0c8f - Date[_0x17e6ef(196)]());
  return { "blocked": _0x353326 > 0, "remainingMs": _0x353326, "blockedUntil": _0x5f0c8f };
}
async function parseResponse(_0x55cf0f, _0x330d08) {
  const _0x1f5ea5 = _0x703c90;
  if (_0x330d08 === "response") return _0x55cf0f;
  if (_0x330d08 === _0x1f5ea5(211)) return _0x55cf0f[_0x1f5ea5(211)]();
  if (_0x330d08 === _0x1f5ea5(204)) return _0x55cf0f[_0x1f5ea5(204)]();
  if (_0x330d08 === _0x1f5ea5(228)) return _0x55cf0f["arrayBuffer"]();
  return _0x55cf0f[_0x1f5ea5(295)]();
}
async function doRequest(_0x475753, _0x236f80, _0x3aae16 = 0) {
  const _0x14895e = _0x703c90, { url: _0x2d15aa, method = _0x14895e(313), headers: _0x436113, body: _0xad219f, credentials = "include", signal: _0x8642fa, responseType = _0x14895e(295), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x236f80, _0xbc2adb = getRateLimitStatus(_0x475753);
  if (_0xbc2adb[_0x14895e(317)]) throw makeError(_0x14895e(267) + Math[_0x14895e(261)](_0xbc2adb[_0x14895e(338)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x475753, "remainingMs": _0xbc2adb[_0x14895e(338)], "status": 429 });
  const _0x8de47f = timeoutMs > 0 ? new AbortController() : null, _0x5ea52f = _0x8de47f && timeoutMs > 0 ? setTimeout(() => _0x8de47f[_0x14895e(321)](makeError(_0x14895e(353), { "code": _0x14895e(257), "domain": _0x475753 })), timeoutMs) : null, _0xdef6d8 = _0x8de47f ? _0x8de47f[_0x14895e(193)] : _0x8642fa;
  try {
    const _0x43fad2 = await fetch(_0x2d15aa, { "method": method, "headers": _0x436113, "body": _0xad219f, "credentials": credentials, "signal": _0xdef6d8 });
    if (_0x43fad2["status"] === 429 && rateLimitCooldownMs > 0) {
      const _0x239fdf = (rateLimitHitCount["get"](_0x475753) || 0) + 1;
      rateLimitHitCount[_0x14895e(271)](_0x475753, _0x239fdf);
      const _0x2ba208 = _0x239fdf <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x14895e(271)](_0x475753, Date["now"]() + _0x2ba208);
    }
    if (!_0x43fad2["ok"]) {
      const _0x31aac0 = _0x3aae16 < retries && retryStatuses[_0x14895e(212)](_0x43fad2[_0x14895e(336)]);
      if (_0x31aac0) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x475753, _0x236f80, _0x3aae16 + 1);
      }
      throw makeError(_0x14895e(276) + _0x43fad2[_0x14895e(336)], { "code": _0x14895e(286), "domain": _0x475753, "status": _0x43fad2[_0x14895e(336)] });
    }
    return rateLimitHitCount[_0x14895e(354)](_0x475753), parseResponse(_0x43fad2, responseType);
  } catch (_0x4545e3) {
    const _0x2c017d = (_0x4545e3 == null ? void 0 : _0x4545e3[_0x14895e(357)]) === "AbortError", _0x5ccfa9 = !_0x2c017d && _0x3aae16 < retries;
    if (_0x5ccfa9) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x475753, _0x236f80, _0x3aae16 + 1);
    }
    if (_0x4545e3 instanceof Error && _0x4545e3["code"]) throw _0x4545e3;
    throw makeError(String((_0x4545e3 == null ? void 0 : _0x4545e3["message"]) || _0x4545e3 || _0x14895e(348)), { "code": _0x2c017d ? _0x14895e(229) : _0x14895e(242), "domain": _0x475753, "status": Number((_0x4545e3 == null ? void 0 : _0x4545e3["status"]) || 0) || null, "cause": _0x4545e3 });
  } finally {
    if (_0x5ea52f) clearTimeout(_0x5ea52f);
  }
}
async function request(_0x1f39bd, _0x1177ed) {
  const _0x120140 = _0x703c90, _0x56202d = normalizeDomain$1(_0x1f39bd), _0x1943f0 = buildInflightKey(_0x56202d, _0x1177ed == null ? void 0 : _0x1177ed["coalesceKey"], _0x1177ed == null ? void 0 : _0x1177ed[_0x120140(328)], (_0x1177ed == null ? void 0 : _0x1177ed[_0x120140(294)]) || _0x120140(313));
  if ((_0x1177ed == null ? void 0 : _0x1177ed[_0x120140(352)]) && inflightByKey["has"](_0x1943f0)) return inflightByKey[_0x120140(203)](_0x1943f0);
  const _0xa690e0 = doRequest(_0x56202d, _0x1177ed || {})[_0x120140(218)](() => {
    const _0x1d59bf = _0x120140;
    inflightByKey[_0x1d59bf(354)](_0x1943f0);
  });
  return (_0x1177ed == null ? void 0 : _0x1177ed[_0x120140(352)]) && inflightByKey["set"](_0x1943f0, _0xa690e0), _0xa690e0;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x3c6d85) {
  const _0x133b11 = _0x703c90, _0x2b77f4 = _0x3c6d85 == null ? void 0 : _0x3c6d85["authCompany"];
  STATE["auth"][_0x133b11(222)] = (_0x2b77f4 == null ? void 0 : _0x2b77f4["companyId"]) ?? null, STATE[_0x133b11(347)][_0x133b11(297)] = (_0x2b77f4 == null ? void 0 : _0x2b77f4[_0x133b11(297)]) ?? null, STATE[_0x133b11(347)]["productionModifier"] = (_0x2b77f4 == null ? void 0 : _0x2b77f4[_0x133b11(327)]) ?? null, STATE[_0x133b11(347)][_0x133b11(325)] = (_0x2b77f4 == null ? void 0 : _0x2b77f4["salesModifier"]) ?? null, STATE[_0x133b11(347)][_0x133b11(231)] = !![];
  const _0x2dd63e = _0x3c6d85 == null ? void 0 : _0x3c6d85[_0x133b11(247)];
  STATE[_0x133b11(247)][_0x133b11(202)] = (_0x2dd63e == null ? void 0 : _0x2dd63e[_0x133b11(202)]) ?? null, STATE[_0x133b11(247)]["experience"] = (_0x2dd63e == null ? void 0 : _0x2dd63e[_0x133b11(298)]) ?? null, STATE[_0x133b11(247)][_0x133b11(285)] = (_0x2dd63e == null ? void 0 : _0x2dd63e[_0x133b11(285)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x5abb89 = _0x703c90;
  if (!force && STATE["auth"]["loaded"] || STATE[_0x5abb89(347)][_0x5abb89(350)]) return;
  STATE[_0x5abb89(347)]["loading"] = !![], STATE[_0x5abb89(347)][_0x5abb89(219)] = null;
  try {
    const _0x4ab3f6 = await request(_0x5abb89(347), { "url": _0x5abb89(199), "credentials": _0x5abb89(362), "responseType": _0x5abb89(295), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x4ab3f6);
  } catch (_0x4d0338) {
    STATE["auth"][_0x5abb89(219)] = String((_0x4d0338 == null ? void 0 : _0x4d0338[_0x5abb89(304)]) || _0x4d0338);
  } finally {
    STATE[_0x5abb89(347)][_0x5abb89(350)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x703c90(279), _0x703c90(215), "global"]);
function normalizeScopeMode(_0x2dfce2) {
  const _0xd23a94 = _0x703c90;
  if (VALID_SCOPE_MODES[_0xd23a94(246)](_0x2dfce2)) return _0x2dfce2;
  return _0xd23a94(279);
}
function numericOrNull(_0xbc9b09) {
  if (_0xbc9b09 === null || _0xbc9b09 === void 0 || _0xbc9b09 === "") return null;
  const _0x3f11c2 = Number(_0xbc9b09);
  return Number["isFinite"](_0x3f11c2) ? _0x3f11c2 : null;
}
function resolveScopeSync(_0x160589 = _0x703c90(279)) {
  var _a, _b;
  const _0x284763 = _0x703c90, _0x3771c7 = normalizeScopeMode(_0x160589), _0x3d006a = numericOrNull((_a = STATE[_0x284763(347)]) == null ? void 0 : _a[_0x284763(222)]), _0x29477f = numericOrNull((_b = STATE[_0x284763(347)]) == null ? void 0 : _b["realmId"]);
  if (_0x3771c7 === _0x284763(310)) return { "mode": _0x3771c7, "companyId": _0x3d006a, "realmId": _0x29477f, "hasScope": !![], "scopeKey": _0x284763(310) };
  if (_0x3771c7 === _0x284763(215)) return { "mode": _0x3771c7, "companyId": _0x3d006a, "realmId": _0x29477f, "hasScope": Number[_0x284763(335)](_0x3d006a), "scopeKey": Number[_0x284763(335)](_0x3d006a) ? String(_0x3d006a) : null };
  const _0x24e9b5 = Number["isFinite"](_0x3d006a) && Number["isFinite"](_0x29477f);
  return { "mode": _0x3771c7, "companyId": _0x3d006a, "realmId": _0x29477f, "hasScope": _0x24e9b5, "scopeKey": _0x24e9b5 ? _0x3d006a + "-" + _0x29477f : null };
}
async function resolveScope(_0x262a8a = "scoped", { refreshAuth = ![] } = {}) {
  const _0x583ff5 = _0x703c90, _0x55fe8e = normalizeScopeMode(_0x262a8a);
  return refreshAuth && _0x55fe8e !== _0x583ff5(310) && await loadAuthDataOnce(), resolveScopeSync(_0x55fe8e);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  const _0x2344c3 = _0x703c90;
  try {
    return typeof localStorage !== _0x2344c3(227) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome["storage"]) == null ? void 0 : _a["local"]);
  } catch {
    return ![];
  }
}
function parseJson(_0x32f1cf) {
  const _0x131157 = _0x703c90;
  if (_0x32f1cf == null) return null;
  if (typeof _0x32f1cf === "object") return _0x32f1cf;
  try {
    return JSON[_0x131157(195)](String(_0x32f1cf));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x548882, _0x5b652c) {
  const _0x14663e = _0x703c90;
  if (_0x548882 === _0x14663e(206)) return _0x5b652c;
  return JSON[_0x14663e(252)](_0x5b652c);
}
function isEnvelopeValid(_0x2a31de) {
  const _0x27ff9e = _0x703c90;
  return Boolean(_0x2a31de && typeof _0x2a31de === _0x27ff9e(224) && Number[_0x27ff9e(335)](Number(_0x2a31de["v"])));
}
function isExpired(_0x5d1109, _0x234a4d = null, _0x5595be = Date["now"]()) {
  const _0x1fa540 = _0x703c90, _0x4a5098 = Number((_0x5d1109 == null ? void 0 : _0x5d1109["ts"]) || 0), _0x51a458 = Number(_0x5d1109 == null ? void 0 : _0x5d1109["ttlMs"]), _0x2de258 = Number[_0x1fa540(335)](_0x51a458) ? _0x51a458 : Number["isFinite"](Number(_0x234a4d)) ? Number(_0x234a4d) : null;
  if (!Number[_0x1fa540(335)](_0x4a5098) || _0x4a5098 <= 0) return ![];
  if (!Number["isFinite"](_0x2de258) || _0x2de258 <= 0) return ![];
  return _0x4a5098 + _0x2de258 < _0x5595be;
}
function normalizeBackend(_0x407fd6) {
  const _0x1b6b04 = _0x703c90;
  return _0x407fd6 === "chrome" ? _0x1b6b04(206) : _0x1b6b04(307);
}
function normalizePrefix(_0x18b514) {
  const _0x52dda5 = _0x703c90, _0x297f7a = String(_0x18b514 || DEFAULT_PREFIX)[_0x52dda5(356)]();
  return _0x297f7a[_0x52dda5(326)] > 0 ? _0x297f7a : DEFAULT_PREFIX;
}
function normalizeDomain(_0x574c28) {
  const _0x47e982 = _0x703c90;
  return String(_0x574c28 || _0x47e982(217))[_0x47e982(356)]()[_0x47e982(302)](/\s+/g, "-")[_0x47e982(280)]();
}
function buildStorageKey({ domain: _0x54adb5, version: _0x31d044, scopeKey: _0x10c942, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x54adb5) + ":v" + Number(_0x31d044) + ":" + _0x10c942;
}
async function chromeGet(_0x49c850) {
  const _0x17f076 = _0x703c90;
  if (!hasChromeStorage()) return {};
  const _0x5e0e9e = chrome[_0x17f076(209)][_0x17f076(307)];
  try {
    const _0x894609 = _0x5e0e9e[_0x17f076(203)](_0x49c850);
    if (_0x894609 && typeof _0x894609[_0x17f076(230)] === "function") return _0x894609;
  } catch {
  }
  return new Promise((_0x24e48f) => {
    const _0x19e5cf = _0x17f076;
    try {
      _0x5e0e9e[_0x19e5cf(203)](_0x49c850, (_0x41d1a9) => _0x24e48f(_0x41d1a9 || {}));
    } catch {
      _0x24e48f({});
    }
  });
}
async function chromeSet(_0x356329) {
  const _0x178bc6 = _0x703c90;
  if (!hasChromeStorage()) return ![];
  const _0xfaa53f = chrome[_0x178bc6(209)]["local"];
  try {
    const _0x33bc88 = _0xfaa53f["set"](_0x356329);
    if (_0x33bc88 && typeof _0x33bc88[_0x178bc6(230)] === _0x178bc6(233)) return await _0x33bc88, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x579fb8) => {
    try {
      _0xfaa53f["set"](_0x356329, () => _0x579fb8(!![]));
    } catch {
      _0x579fb8(![]);
    }
  });
}
async function chromeRemove(_0x5e5ddc) {
  const _0x2ed824 = _0x703c90;
  if (!hasChromeStorage()) return ![];
  const _0x257d5f = chrome[_0x2ed824(209)]["local"];
  try {
    const _0xb9750f = _0x257d5f[_0x2ed824(290)](_0x5e5ddc);
    if (_0xb9750f && typeof _0xb9750f[_0x2ed824(230)] === _0x2ed824(233)) return await _0xb9750f, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x22de6d) => {
    const _0x5bfcc7 = _0x2ed824;
    try {
      _0x257d5f[_0x5bfcc7(290)](_0x5e5ddc, () => _0x22de6d(!![]));
    } catch {
      _0x22de6d(![]);
    }
  });
}
async function getRaw(_0x13902a, _0x3a6abb) {
  const _0x1dee27 = _0x703c90, _0x5b2103 = normalizeBackend(_0x13902a);
  if (_0x5b2103 === _0x1dee27(307)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x1dee27(236)](_0x3a6abb);
    } catch {
      return null;
    }
  }
  const _0x3578e3 = await chromeGet(_0x3a6abb);
  return (_0x3578e3 == null ? void 0 : _0x3578e3[_0x3a6abb]) ?? null;
}
function localGetItemSync(_0x166142) {
  const _0x3b1156 = _0x703c90;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x3b1156(236)](_0x166142);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x434c3a, _0x3fb095) {
  const _0x373289 = _0x703c90;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x373289(274)](_0x434c3a, String(_0x3fb095)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x172419) {
  const _0x2c8ab4 = _0x703c90;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x2c8ab4(341)](_0x172419), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x22b753 = "") {
  const _0xc41e67 = _0x703c90;
  if (!hasLocalStorage()) return [];
  const _0x486cbd = [], _0x8d9338 = String(_0x22b753 || "");
  try {
    for (let _0x22a811 = 0; _0x22a811 < localStorage[_0xc41e67(326)]; _0x22a811 += 1) {
      const _0x3f3e65 = localStorage[_0xc41e67(254)](_0x22a811);
      if (!_0x3f3e65 || _0x8d9338 && !_0x3f3e65["startsWith"](_0x8d9338)) continue;
      _0x486cbd[_0xc41e67(288)]({ "key": _0x3f3e65, "value": localStorage[_0xc41e67(236)](_0x3f3e65) });
    }
  } catch {
    return [];
  }
  return _0x486cbd;
}
async function setRaw(_0x7c40d8, _0x84ff50, _0x3d5f7a) {
  const _0x2b110c = _0x703c90, _0x32f6a4 = normalizeBackend(_0x7c40d8);
  if (_0x32f6a4 === _0x2b110c(307)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x2b110c(274)](_0x84ff50, String(_0x3d5f7a)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x84ff50]: _0x3d5f7a });
}
async function removeRaw(_0x3846b9, _0x57c68e) {
  const _0x356af9 = _0x703c90, _0x9638a4 = normalizeBackend(_0x3846b9);
  if (_0x9638a4 === _0x356af9(307)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x356af9(341)](_0x57c68e), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x57c68e);
}
async function listByPrefix({ backend = _0x703c90(307), prefix = "" } = {}) {
  const _0x1e729b = _0x703c90, _0x4b44bb = normalizeBackend(backend), _0x3ca486 = String(prefix || "");
  if (_0x4b44bb === _0x1e729b(307)) {
    if (!hasLocalStorage()) return [];
    const _0x4e66f3 = [];
    try {
      for (let _0x1302ee = 0; _0x1302ee < localStorage[_0x1e729b(326)]; _0x1302ee += 1) {
        const _0x3a6db9 = localStorage[_0x1e729b(254)](_0x1302ee);
        if (!_0x3a6db9 || _0x3ca486 && !_0x3a6db9["startsWith"](_0x3ca486)) continue;
        _0x4e66f3[_0x1e729b(288)]({ "key": _0x3a6db9, "value": localStorage[_0x1e729b(236)](_0x3a6db9) });
      }
    } catch {
      return [];
    }
    return _0x4e66f3;
  }
  const _0x36fb22 = await chromeGet(null);
  return Object[_0x1e729b(263)](_0x36fb22 || {})[_0x1e729b(197)](([_0x162667]) => _0x3ca486 ? _0x162667[_0x1e729b(334)](_0x3ca486) : !![])[_0x1e729b(284)](([_0x364b77, _0x1f8d1b]) => ({ "key": _0x364b77, "value": _0x1f8d1b }));
}
async function get({ domain: _0x285ca6, version: _0x35e5ad, scope = _0x703c90(279), backend = _0x703c90(307), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x2319ef = _0x703c90, _0x3428e6 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x3428e6[_0x2319ef(216)] || !_0x3428e6["scopeKey"]) return null;
  const _0x449a3d = buildStorageKey({ "domain": _0x285ca6, "version": _0x35e5ad, "scopeKey": _0x3428e6[_0x2319ef(319)], "prefix": prefix }), _0x279f50 = await getRaw(backend, _0x449a3d);
  if (_0x279f50 == null) return null;
  const _0x18ca93 = parseJson(_0x279f50);
  if (!isEnvelopeValid(_0x18ca93)) return await removeRaw(backend, _0x449a3d), null;
  const _0xad4634 = Number(_0x18ca93["v"]);
  if (_0xad4634 !== Number(_0x35e5ad)) return _0xad4634 < Number(_0x35e5ad) && await removeRaw(backend, _0x449a3d), null;
  if (isExpired(_0x18ca93, ttlMs)) return await removeRaw(backend, _0x449a3d), null;
  const _0x3406a5 = _0x3428e6[_0x2319ef(319)], _0x62be51 = String(((_a = _0x18ca93 == null ? void 0 : _0x18ca93["scope"]) == null ? void 0 : _a[_0x2319ef(319)]) || "");
  if (_0x3406a5 && _0x62be51 && _0x3406a5 !== _0x62be51) return await removeRaw(backend, _0x449a3d), null;
  return _0x18ca93[_0x2319ef(293)] ?? null;
}
async function set({ domain: _0x53ec95, version: _0x4618d6, scope = _0x703c90(279), backend = _0x703c90(307), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x524f41 } = {}) {
  const _0x421052 = _0x703c90, _0x325b56 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x325b56["hasScope"] || !_0x325b56[_0x421052(319)]) return ![];
  const _0x3ffeb0 = buildStorageKey({ "domain": _0x53ec95, "version": _0x4618d6, "scopeKey": _0x325b56[_0x421052(319)], "prefix": prefix }), _0xb448fe = { "v": Number(_0x4618d6), "ts": Date[_0x421052(196)](), "ttlMs": Number["isFinite"](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x325b56[_0x421052(198)], "scopeKey": _0x325b56["scopeKey"], "companyId": _0x325b56[_0x421052(222)], "realmId": _0x325b56["realmId"] }, "data": _0x524f41 };
  return setRaw(backend, _0x3ffeb0, toStorageRaw(normalizeBackend(backend), _0xb448fe));
}
async function remove({ domain: _0x5637e8, version: _0x2702ee, scope = _0x703c90(279), backend = _0x703c90(307), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x2fbefb = _0x703c90, _0x2101e5 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x2101e5["hasScope"] || !_0x2101e5[_0x2fbefb(319)]) return ![];
  const _0x3a928e = buildStorageKey({ "domain": _0x5637e8, "version": _0x2702ee, "scopeKey": _0x2101e5[_0x2fbefb(319)], "prefix": prefix });
  return removeRaw(backend, _0x3a928e);
}
async function migrate({ domain: _0x43bbe4, version: _0x4643ba, scope = _0x703c90(279), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x1af7bd, cleanupLegacy = !![] } = {}) {
  const _0x2d929c = _0x703c90, _0x1f6347 = await get({ "domain": _0x43bbe4, "version": _0x4643ba, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x1f6347 !== null && _0x1f6347 !== void 0) return { "data": _0x1f6347, "migrated": ![] };
  if (typeof _0x1af7bd !== _0x2d929c(233)) return { "data": null, "migrated": ![] };
  const _0x5b9e30 = await _0x1af7bd({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x1aae26 = _0x5b9e30 == null ? void 0 : _0x5b9e30[_0x2d929c(293)];
  if (_0x1aae26 === null || _0x1aae26 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x43bbe4, "version": _0x4643ba, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x1aae26 }), cleanupLegacy && typeof (_0x5b9e30 == null ? void 0 : _0x5b9e30["cleanup"]) === _0x2d929c(233) && await _0x5b9e30["cleanup"](), { "data": _0x1aae26, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x703c90(305), _0x703c90(241)];
let migrationsRan = ![];
function parseDomainAndVersion(_0xc79a43) {
  const _0x2efdea = _0x703c90, _0x49000b = String(_0xc79a43 || "")[_0x2efdea(301)](":");
  if (_0x49000b[_0x2efdea(326)] < 4) return null;
  if (_0x49000b[0] !== _0x2efdea(309)) return null;
  const _0x3d9938 = _0x49000b[1], _0x466a18 = _0x49000b[2] || "";
  if (!_0x466a18["startsWith"]("v")) return null;
  const _0x54821c = Number(_0x466a18["slice"](1));
  if (!Number["isFinite"](_0x54821c)) return null;
  return { "domain": _0x3d9938, "version": _0x54821c };
}
async function cleanupVersionedEnvelopes(_0x768d39) {
  const _0x43a2bf = _0x703c90, _0x11a3d1 = await storage[_0x43a2bf(249)]({ "backend": _0x768d39, "prefix": _0x43a2bf(245) });
  for (const _0x566b71 of _0x11a3d1) {
    const _0x1024f5 = parseDomainAndVersion(_0x566b71[_0x43a2bf(254)]);
    if (!_0x1024f5) continue;
    const _0x1209a3 = Number(MIN_DOMAIN_VERSION[_0x1024f5[_0x43a2bf(281)]] || 1);
    if (_0x1024f5[_0x43a2bf(243)] < _0x1209a3) {
      await storage[_0x43a2bf(220)](_0x768d39, _0x566b71[_0x43a2bf(254)]);
      continue;
    }
    if (_0x566b71[_0x43a2bf(268)] == null) {
      await storage[_0x43a2bf(220)](_0x768d39, _0x566b71["key"]);
      continue;
    }
    const _0x26fc70 = typeof _0x566b71[_0x43a2bf(268)] === _0x43a2bf(289) ? (() => {
      const _0x3f2173 = _0x43a2bf;
      try {
        return JSON[_0x3f2173(195)](_0x566b71["value"] || _0x3f2173(291));
      } catch {
        return null;
      }
    })() : _0x566b71[_0x43a2bf(268)];
    if (!_0x26fc70 || typeof _0x26fc70 !== _0x43a2bf(224) || !Number[_0x43a2bf(335)](Number(_0x26fc70["v"]))) {
      await storage["removeRaw"](_0x768d39, _0x566b71[_0x43a2bf(254)]);
      continue;
    }
    Number(_0x26fc70["v"]) < _0x1209a3 && await storage[_0x43a2bf(220)](_0x768d39, _0x566b71[_0x43a2bf(254)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x4fc318 = _0x703c90;
  for (const _0x24cae8 of LEGACY_GLOBAL_KEYS) {
    await storage["removeRaw"](_0x4fc318(307), _0x24cae8), await storage[_0x4fc318(220)]("chrome", _0x24cae8);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes("local"), await cleanupVersionedEnvelopes("chrome"), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x4d4985, _0x11c767) {
  return new Promise((_0x11b453, _0x1a27ab) => {
    const _0x691e = _0x41a3;
    let _0x301b2d = null;
    const _0x3b6701 = (_0x4f61fe, _0x4d4ecd, _0x9ff026) => {
      const _0x179dbf = _0x41a3;
      if (_0x301b2d !== null && _0x4d4ecd[_0x179dbf(277)] && _0x4d4ecd[_0x179dbf(277)]["windowId"] !== _0x301b2d) return;
      _0x4f61fe["type"] === _0x179dbf(239) && (_0x3179ae(), _0x4f61fe[_0x179dbf(219)] ? _0x1a27ab(new Error(_0x4f61fe[_0x179dbf(219)])) : _0x4f61fe[_0x179dbf(293)] && _0x4f61fe[_0x179dbf(293)][_0x179dbf(326)] === 0 ? _0x11b453([]) : _0x11b453(_0x4f61fe[_0x179dbf(293)]));
    };
    chrome[_0x691e(359)][_0x691e(282)][_0x691e(360)](_0x3b6701);
    const _0x45b730 = setTimeout(() => {
      const _0x4d9933 = _0x691e;
      _0x3179ae(), _0x1a27ab(new Error(_0x4d9933(238)));
    }, 25e3), _0x3179ae = () => {
      const _0x2b293b = _0x691e;
      clearTimeout(_0x45b730), chrome["runtime"][_0x2b293b(282)]["removeListener"](_0x3b6701), _0x301b2d !== null && chrome[_0x2b293b(269)]["remove"](_0x301b2d)[_0x2b293b(200)](() => {
      });
    }, _0x4aebf6 = encodeURIComponent(JSON[_0x691e(252)](_0x4d4985)), _0x122bfc = _0x691e(258) + _0x4aebf6;
    chrome[_0x691e(269)][_0x691e(208)]({ "url": _0x122bfc, "type": _0x691e(256), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x691e(230)]((_0x30d257) => {
      _0x301b2d = _0x30d257["id"];
    })[_0x691e(200)]((_0x115913) => {
      _0x3179ae(), _0x1a27ab(_0x115913);
    });
  });
}
const DOMAIN = _0x703c90(213), VERSION = 1;
async function getActiveAlarms() {
  const _0x3bb3d4 = _0x703c90, _0x231ddf = await storage["get"]({ "domain": DOMAIN, "version": VERSION, "scope": _0x3bb3d4(310), "backend": _0x3bb3d4(206) });
  return (_0x231ddf == null ? void 0 : _0x231ddf[_0x3bb3d4(240)]) || [];
}
async function saveActiveAlarms(_0x1f4292) {
  const _0x8c7460 = _0x703c90;
  await storage[_0x8c7460(271)]({ "domain": DOMAIN, "version": VERSION, "scope": _0x8c7460(310), "backend": "chrome", "data": { "alarms": _0x1f4292 } });
}
let addAlarmQueue = Promise["resolve"]();
function addAlarm(_0x96bd5, _0x4c881c, _0x3b7083, _0xa5d557, _0x4eef25) {
  const _0x5dcfe0 = _0x703c90;
  return addAlarmQueue = addAlarmQueue[_0x5dcfe0(230)](async () => {
    const _0x3e5fdd = _0x5dcfe0, _0x54c4d4 = await getActiveAlarms(), _0x27e6cf = _0x54c4d4["filter"]((_0x599c5d) => {
      const _0x199511 = _0x41a3;
      if (_0x3b7083 && _0x599c5d[_0x199511(205)]) return _0x599c5d[_0x199511(205)] !== _0x3b7083;
      return _0x599c5d[_0x199511(214)] !== _0x96bd5;
    });
    _0x27e6cf[_0x3e5fdd(288)]({ "alarmId": _0x96bd5, "buildingName": _0x4c881c, "buildingId": _0x3b7083, "finishTimeMs": _0xa5d557, "translatedMessage": _0x4eef25 }), await saveActiveAlarms(_0x27e6cf);
  })[_0x5dcfe0(200)](console[_0x5dcfe0(219)]), addAlarmQueue;
}
async function removeAlarm(_0x199fe8) {
  const _0xe0a0e1 = _0x703c90, _0x36aaa4 = await getActiveAlarms(), _0x29c6a8 = _0x36aaa4["filter"]((_0xbaedb1) => _0xbaedb1["alarmId"] !== _0x199fe8);
  _0x36aaa4[_0xe0a0e1(326)] !== _0x29c6a8[_0xe0a0e1(326)] && await saveActiveAlarms(_0x29c6a8);
}
async function clearExpiredAlarms() {
  const _0x4a347c = _0x703c90, _0x366e68 = await getActiveAlarms(), _0xf8fb5a = Date[_0x4a347c(196)](), _0x1b2051 = _0x366e68[_0x4a347c(197)]((_0x3f872e) => _0x3f872e[_0x4a347c(339)] > _0xf8fb5a);
  _0x366e68[_0x4a347c(326)] !== _0x1b2051[_0x4a347c(326)] && await saveActiveAlarms(_0x1b2051);
}
const KEY_WHATS_NEW = _0x703c90(337), KEY_LAST_MINOR = _0x703c90(266), KEY_LAST_VERSION = _0x703c90(324), STORAGE_DOMAIN_WHATS_NEW = "whats-new", STORAGE_DOMAIN_WHATS_NEW_META = _0x703c90(343), STORAGE_VERSION = 1;
async function setWhatsNew(_0x28a4c4) {
  const _0x2dd659 = _0x703c90;
  await storage[_0x2dd659(271)]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": "global", "backend": _0x2dd659(206), "refreshAuth": ![], "data": _0x28a4c4 }), await storage[_0x2dd659(271)]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x2dd659(310), "backend": _0x2dd659(206), "refreshAuth": ![], "data": { "minorKey": _0x28a4c4["minorKey"], "lastVersion": _0x28a4c4["lastVersion"] } }), await storage[_0x2dd659(220)](_0x2dd659(206), KEY_WHATS_NEW), await storage[_0x2dd659(220)](_0x2dd659(206), KEY_LAST_MINOR), await storage[_0x2dd659(220)](_0x2dd659(206), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x3d0e31 = _0x703c90;
  return request(_0x3d0e31(270), { "url": _0x3d0e31(311), "credentials": _0x3d0e31(207), "responseType": "json", "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x703c90(359)][_0x703c90(278)][_0x703c90(360)](async (_0x1dd0df) => {
  const _0x23ad0f = _0x703c90;
  await initializeDataPlatform();
  _0x1dd0df[_0x23ad0f(283)] === _0x23ad0f(320) && await storage[_0x23ad0f(271)]({ "domain": _0x23ad0f(330), "version": 1, "scope": _0x23ad0f(310), "backend": _0x23ad0f(206), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0x1dd0df["reason"] === _0x23ad0f(226) && _0x1dd0df[_0x23ad0f(333)]) {
    const _0x337a9b = chrome[_0x23ad0f(359)][_0x23ad0f(232)]()[_0x23ad0f(243)];
    if (_0x337a9b !== _0x1dd0df["previousVersion"]) try {
      const _0x106eb8 = await fetchAllReleases();
      let _0x23b2c1 = [];
      const _0x5b7ae1 = releasePageUrl(_0x337a9b);
      _0x106eb8 && Array[_0x23ad0f(223)](_0x106eb8) && (_0x23b2c1 = collectHighlightsFromReleases(_0x106eb8, _0x1dd0df[_0x23ad0f(333)], _0x337a9b)), await setWhatsNew({ "show": !![], "version": _0x337a9b, "url": _0x5b7ae1, "highlights": _0x23b2c1, "error": !_0x106eb8 || !Array[_0x23ad0f(223)](_0x106eb8), "minorKey": minorKey(_0x337a9b), "lastVersion": _0x337a9b });
    } catch (_0x16de9f) {
      console["error"](_0x23ad0f(303), _0x16de9f), await setWhatsNew({ "show": !![], "version": _0x337a9b, "url": releasePageUrl(_0x337a9b), "highlights": [], "error": !![], "minorKey": minorKey(_0x337a9b), "lastVersion": _0x337a9b });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x2e4ad0) {
  const _0x1c91e6 = _0x703c90, _0x2a8b23 = Date["now"]();
  if (cooperDataCache[_0x2e4ad0] && cooperDataCacheTs[_0x2e4ad0] && _0x2a8b23 - cooperDataCacheTs[_0x2e4ad0] < COOPER_CACHE_TTL) return cooperDataCache[_0x2e4ad0];
  const _0x1b74af = "r" + (_0x2e4ad0 + 1), _0x187e62 = await fetch(_0x1c91e6(349) + _0x1b74af);
  if (!_0x187e62["ok"]) throw new Error("Cooper API error: " + _0x187e62[_0x1c91e6(336)]);
  const _0x58fe19 = await _0x187e62["json"]();
  return cooperDataCache[_0x2e4ad0] = _0x58fe19, cooperDataCacheTs[_0x2e4ad0] = _0x2a8b23, _0x58fe19;
}
chrome["runtime"][_0x703c90(282)][_0x703c90(360)]((_0x1bd57f, _0x43e719, _0x4a6a97) => {
  const _0x3d3d07 = _0x703c90;
  if (_0x1bd57f[_0x3d3d07(194)] === _0x3d3d07(221)) return fetchCooperData(_0x1bd57f[_0x3d3d07(297)])[_0x3d3d07(230)]((_0xe39eeb) => _0x4a6a97({ "success": !![], "data": _0xe39eeb }))[_0x3d3d07(200)]((_0x10446b) => _0x4a6a97({ "success": ![], "error": _0x10446b[_0x3d3d07(304)] })), !![];
  if (_0x1bd57f["type"] === _0x3d3d07(234)) {
    const _0x22498d = _0x1bd57f[_0x3d3d07(297)], _0x56a3f6 = _0x3d3d07(264) + _0x22498d + "/market/vwaps";
    return request(_0x3d3d07(201), { "url": _0x56a3f6, "method": _0x3d3d07(313), "credentials": "omit", "responseType": _0x3d3d07(295), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x3cca73) => _0x4a6a97({ "success": !![], "data": _0x3cca73 }))["catch"]((_0x3de410) => _0x4a6a97({ "success": ![], "error": _0x3de410["message"] || String(_0x3de410) })), !![];
  }
  if (_0x1bd57f["type"] === _0x3d3d07(299)) {
    const { realmId: _0x2fcbf0, queryParams: _0x68340, headers: _0x2a3652 } = _0x1bd57f, _0x2d1b89 = _0x3d3d07(264) + _0x2fcbf0 + _0x3d3d07(329) + _0x68340;
    return request(_0x3d3d07(201), { "url": _0x2d1b89, "method": _0x3d3d07(313), "headers": _0x2a3652, "credentials": "omit", "responseType": _0x3d3d07(295), "retries": 2, "retryDelayMs": 1e3 })[_0x3d3d07(230)]((_0x54d46c) => _0x4a6a97({ "success": !![], "data": _0x54d46c }))[_0x3d3d07(200)]((_0xd1ff9b) => _0x4a6a97({ "success": ![], "error": _0xd1ff9b[_0x3d3d07(304)] || String(_0xd1ff9b) })), !![];
  }
  if (_0x1bd57f["type"] === "FETCH_SIMCOTOOLS_STATS_BUILDINGS") {
    const { realmId: _0x525a85, headers: _0xacb05d } = _0x1bd57f, _0x36be97 = "https://api.simcotools.com/v1/realms/" + _0x525a85 + _0x3d3d07(315);
    return request("simcotools", { "url": _0x36be97, "method": _0x3d3d07(313), "headers": _0xacb05d, "credentials": _0x3d3d07(207), "responseType": _0x3d3d07(295), "retries": 2, "retryDelayMs": 1e3 })[_0x3d3d07(230)]((_0x2105be) => _0x4a6a97({ "success": !![], "data": _0x2105be }))[_0x3d3d07(200)]((_0x40e13e) => _0x4a6a97({ "success": ![], "error": _0x40e13e["message"] || String(_0x40e13e) })), !![];
  }
  if (_0x1bd57f["type"] === "FETCH_SIMCOTOOLS_PHASES") {
    const { realmId: _0x31bb28, headers: _0x3df6d3 } = _0x1bd57f, _0x376902 = "https://api.simcotools.com/v1/realms/" + _0x31bb28 + _0x3d3d07(287);
    return request("simcotools", { "url": _0x376902, "method": "GET", "headers": _0x3df6d3, "credentials": "omit", "responseType": _0x3d3d07(295), "retries": 2, "retryDelayMs": 1e3 })[_0x3d3d07(230)]((_0x5ba429) => _0x4a6a97({ "success": !![], "data": _0x5ba429 }))["catch"]((_0x15fd36) => _0x4a6a97({ "success": ![], "error": _0x15fd36["message"] || String(_0x15fd36) })), !![];
  }
  if (_0x1bd57f["type"] === "SCRAPE_COOPER_RETAIL") return scrapeCooperRetail(_0x1bd57f["params"])["then"]((_0x10d433) => _0x4a6a97({ "success": !![], "data": _0x10d433 }))[_0x3d3d07(200)]((_0x4f71cc) => _0x4a6a97({ "success": ![], "error": _0x4f71cc[_0x3d3d07(304)] })), !![];
  if (_0x1bd57f[_0x3d3d07(194)] === _0x3d3d07(351)) {
    const { buildingName: _0x539afa, buildingId: _0x7fd7ca, finishTimeMs: _0x3893b8, translatedMessage: _0x3be05a } = _0x1bd57f[_0x3d3d07(293)], _0x45f57d = "scx-alarm-" + Date["now"]() + "-" + Math[_0x3d3d07(192)](Math[_0x3d3d07(340)]() * 1e3);
    return chrome[_0x3d3d07(240)][_0x3d3d07(208)](_0x45f57d, { "when": _0x3893b8 }), addAlarm(_0x45f57d, _0x539afa, _0x7fd7ca, _0x3893b8, _0x3be05a)[_0x3d3d07(200)](console[_0x3d3d07(219)]), _0x4a6a97({ "success": !![], "alarmId": _0x45f57d }), !![];
  }
  if (_0x1bd57f[_0x3d3d07(194)] === _0x3d3d07(323)) {
    const { alarmId: _0x28f3e3 } = _0x1bd57f[_0x3d3d07(293)];
    return chrome["alarms"]["clear"](_0x28f3e3), removeAlarm(_0x28f3e3)[_0x3d3d07(200)](console[_0x3d3d07(219)]), _0x4a6a97({ "success": !![] }), !![];
  }
}), chrome["alarms"][_0x703c90(355)]["addListener"](async (_0x45449f) => {
  const _0x5cf489 = _0x703c90;
  if (_0x45449f[_0x5cf489(357)]["startsWith"]("scx-alarm-")) {
    const _0x3f7df5 = await getActiveAlarms(), _0x3475c0 = _0x3f7df5[_0x5cf489(322)]((_0x508de4) => _0x508de4["alarmId"] === _0x45449f[_0x5cf489(357)]), _0x5f5031 = _0x3475c0 ? _0x3475c0[_0x5cf489(318)] : _0x5cf489(248), _0x4592ee = (_0x3475c0 == null ? void 0 : _0x3475c0[_0x5cf489(312)]) || _0x5f5031 + " has finished production!";
    chrome[_0x5cf489(275)][_0x5cf489(208)](_0x45449f[_0x5cf489(357)], { "type": _0x5cf489(260), "iconUrl": "icons/48.png", "title": _0x5cf489(210), "message": _0x4592ee, "priority": 2 }), await removeAlarm(_0x45449f[_0x5cf489(357)]);
  }
}), chrome[_0x703c90(240)][_0x703c90(208)](_0x703c90(225), { "periodInMinutes": 60 }), chrome[_0x703c90(240)][_0x703c90(355)]["addListener"]((_0x433683) => {
  const _0x25b485 = _0x703c90;
  _0x433683[_0x25b485(357)] === _0x25b485(225) && clearExpiredAlarms()[_0x25b485(200)](console[_0x25b485(219)]);
});
