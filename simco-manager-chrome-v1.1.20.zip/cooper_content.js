(function(_0x147bef, _0x2b37ac) {
  var _0x529cdb = _0x1fd4, _0x11a32c = _0x147bef();
  while (!![]) {
    try {
      var _0x5f28c8 = parseInt(_0x529cdb(376)) / 1 + parseInt(_0x529cdb(378)) / 2 + parseInt(_0x529cdb(381)) / 3 + -parseInt(_0x529cdb(373)) / 4 * (-parseInt(_0x529cdb(379)) / 5) + parseInt(_0x529cdb(375)) / 6 + -parseInt(_0x529cdb(380)) / 7 * (parseInt(_0x529cdb(374)) / 8) + -parseInt(_0x529cdb(377)) / 9 * (parseInt(_0x529cdb(372)) / 10);
      if (_0x5f28c8 === _0x2b37ac) break;
      else _0x11a32c["push"](_0x11a32c["shift"]());
    } catch (_0x2f1b6f) {
      _0x11a32c["push"](_0x11a32c["shift"]());
    }
  }
})(_0x3a15, 758032);
function _0x3a15() {
  var _0x7903c6 = ["mJa0odyXm1HOwvbYsW", "mJiWmJbhq09WCum", "mZe0mZa4BwPWC0Pu", "mJy4mJr6teniy3q", "mJqXmtuXnhPPwMzbEG", "mtK2nte2reLyrurX", "mJuYovbiwg5IBq", "mJy3otq0De1wzw1O", "nZvPrg1wyMO", "mJu0mxr5uezSAq"];
  _0x3a15 = function() {
    return _0x7903c6;
  };
  return _0x3a15();
}
function _0x1fd4(_0x4428ef, _0x8e1047) {
  _0x4428ef = _0x4428ef - 372;
  var _0x3a159c = _0x3a15();
  var _0x1fd442 = _0x3a159c[_0x4428ef];
  if (_0x1fd4["tIlMjV"] === void 0) {
    var _0x4e34d7 = function(_0x5dfcf9) {
      var _0x433009 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x45bae6 = "", _0x35de66 = "";
      for (var _0x33e6db = 0, _0x452a08, _0x54c196, _0x3c5419 = 0; _0x54c196 = _0x5dfcf9["charAt"](_0x3c5419++); ~_0x54c196 && (_0x452a08 = _0x33e6db % 4 ? _0x452a08 * 64 + _0x54c196 : _0x54c196, _0x33e6db++ % 4) ? _0x45bae6 += String["fromCharCode"](255 & _0x452a08 >> (-2 * _0x33e6db & 6)) : 0) {
        _0x54c196 = _0x433009["indexOf"](_0x54c196);
      }
      for (var _0x969157 = 0, _0x1b071f = _0x45bae6["length"]; _0x969157 < _0x1b071f; _0x969157++) {
        _0x35de66 += "%" + ("00" + _0x45bae6["charCodeAt"](_0x969157)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x35de66);
    };
    _0x1fd4["USFtFV"] = _0x4e34d7, _0x1fd4["emCHIR"] = {}, _0x1fd4["tIlMjV"] = !![];
  }
  var _0x3416fa = _0x3a159c[0], _0x5af49 = _0x4428ef + _0x3416fa, _0x16d8f6 = _0x1fd4["emCHIR"][_0x5af49];
  return !_0x16d8f6 ? (_0x1fd442 = _0x1fd4["USFtFV"](_0x1fd442), _0x1fd4["emCHIR"][_0x5af49] = _0x1fd442) : _0x1fd442 = _0x16d8f6, _0x1fd442;
}
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
