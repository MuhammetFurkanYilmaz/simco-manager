const _0x6e9183 = _0x203f;
function _0x36b1() {
  const _0x3d9afa = ["yxzLCMfNzvbYAwnL", "ChvZAa", "y2fSy3vSyxrL", "ChjVzhvJDe5HBwu", "ndK3ywjoqM1g", "yM9VBq", "Dg9mB3DLCKnHC2u", "mtu0mtqWy0PbtLPU", "mteXneLPCenIza", "ChbOCgW", "mJrUrufkCey", "C29YDa", "B25TzxnZywDL", "CM91BMq", "tM9YBwfS", "CMvJzxnZAw9U", "uhjVzhvJDca", "oti4mefmv2LjsW", "mta1ntq0mfr0CePyAG", "ntm3mdC4vMv5yvzd", "nZa2nvPLvwXmza", "BwLU", "mJG2nZqYnJfZq3Puqxa", "Cg9ZDe1LC3nHz2u", "Dg9gAxHLza", "nZbMsxH6D08", "y29ZDa", "Bwf4", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "ChjVzhvJDeLK", "otu2mZa2ngrXwxHdEq", "C2f0DxjHDgLVBG", "BwvZC2fNzq"];
  _0x36b1 = function() {
    return _0x3d9afa;
  };
  return _0x36b1();
}
function _0x203f(_0x402f1f, _0x3ca3b6) {
  _0x402f1f = _0x402f1f - 226;
  const _0x36b127 = _0x36b1();
  let _0x203fb9 = _0x36b127[_0x402f1f];
  if (_0x203f["hpykSM"] === void 0) {
    var _0x8cc8f9 = function(_0x4760b6) {
      const _0x520933 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x2d96e0 = "", _0x366721 = "";
      for (let _0x3da867 = 0, _0x3c6517, _0xd2dbc0, _0x195417 = 0; _0xd2dbc0 = _0x4760b6["charAt"](_0x195417++); ~_0xd2dbc0 && (_0x3c6517 = _0x3da867 % 4 ? _0x3c6517 * 64 + _0xd2dbc0 : _0xd2dbc0, _0x3da867++ % 4) ? _0x2d96e0 += String["fromCharCode"](255 & _0x3c6517 >> (-2 * _0x3da867 & 6)) : 0) {
        _0xd2dbc0 = _0x520933["indexOf"](_0xd2dbc0);
      }
      for (let _0x35f84e = 0, _0x29d056 = _0x2d96e0["length"]; _0x35f84e < _0x29d056; _0x35f84e++) {
        _0x366721 += "%" + ("00" + _0x2d96e0["charCodeAt"](_0x35f84e)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x366721);
    };
    _0x203f["jvKSIb"] = _0x8cc8f9, _0x203f["cpbtqp"] = {}, _0x203f["hpykSM"] = !![];
  }
  const _0x23834b = _0x36b127[0], _0x169e3c = _0x402f1f + _0x23834b, _0x4b6168 = _0x203f["cpbtqp"][_0x169e3c];
  return !_0x4b6168 ? (_0x203fb9 = _0x203f["jvKSIb"](_0x203fb9), _0x203f["cpbtqp"][_0x169e3c] = _0x203fb9) : _0x203fb9 = _0x4b6168, _0x203fb9;
}
(function(_0x2b64a8, _0x4fc888) {
  const _0x283145 = _0x203f, _0x4b90f4 = _0x2b64a8();
  while (!![]) {
    try {
      const _0x4dde60 = -parseInt(_0x283145(233)) / 1 * (parseInt(_0x283145(237)) / 2) + -parseInt(_0x283145(248)) / 3 * (parseInt(_0x283145(239)) / 4) + parseInt(_0x283145(247)) / 5 + parseInt(_0x283145(236)) / 6 * (-parseInt(_0x283145(254)) / 7) + -parseInt(_0x283145(226)) / 8 + parseInt(_0x283145(249)) / 9 * (parseInt(_0x283145(246)) / 10) + parseInt(_0x283145(251)) / 11;
      if (_0x4dde60 === _0x4fc888) break;
      else _0x4b90f4["push"](_0x4b90f4["shift"]());
    } catch (_0x4ae26e) {
      _0x4b90f4["push"](_0x4b90f4["shift"]());
    }
  }
})(_0x36b1, 743051), self[_0x6e9183(241)] = async (_0x2d96e0) => {
  const _0x3d0c0c = _0x6e9183, { action: _0x366721, products: _0x3da867, adminOverhead: _0x3c6517, salesBonus: _0xd2dbc0, economyPhase: _0x195417, simulateError: _0x35f84e } = _0x2d96e0["data"];
  if (_0x366721 === _0x3d0c0c(231)) {
    if (_0x35f84e) {
      self[_0x3d0c0c(252)]({ "error": _0x3d0c0c(257) });
      return;
    }
    try {
      const _0x29d056 = _0x3c6517 !== void 0 ? _0x3c6517 : 0, _0x327803 = _0xd2dbc0 !== void 0 ? _0xd2dbc0 : 0, _0x1deffd = _0x195417 || _0x3d0c0c(243), _0x188581 = Math["max"](0, Math[_0x3d0c0c(250)](_0x29d056, 200)), _0x3c2328 = Math[_0x3d0c0c(256)](0, Math[_0x3d0c0c(250)](_0x327803, 50)), _0x25936d = _0x1deffd[_0x3d0c0c(235)]() === _0x3d0c0c(244) ? 0.9 : _0x1deffd[_0x3d0c0c(235)]() === _0x3d0c0c(234) ? 1.12 : 1, _0x3d8bf3 = [];
      for (const _0x635290 of _0x3da867) {
        for (let _0xb6468b = 0; _0xb6468b <= 9; _0xb6468b++) {
          const _0x2b62ad = _0xb6468b, _0x38c321 = _0x635290[_0x3d0c0c(227)] <= 0 || _0x635290["saturation"] == null ? 0.1 : Math[_0x3d0c0c(256)](0.1, Math[_0x3d0c0c(250)](_0x635290[_0x3d0c0c(227)], 5)), _0x2ec83e = 1 + _0x2b62ad * 0.05, _0x188afb = 100, _0x5108da = _0x188afb / _0x38c321 * _0x2ec83e * _0x25936d * (1 + _0x3c2328 / 100), _0x1c3a3d = _0x5108da / 24, _0x158a81 = _0x635290[_0x3d0c0c(229)] || _0x635290[_0x3d0c0c(255)] * 1.5, _0x489d5d = _0x158a81 - _0x635290[_0x3d0c0c(255)], _0xccb696 = _0x5108da * _0x158a81, _0x56880d = _0xccb696 * (_0x188581 / 100), _0x289c64 = _0x5108da * _0x489d5d - _0x56880d;
          if (_0x289c64 < 0) continue;
          _0x3d8bf3[_0x3d0c0c(230)]({ "productId": _0x635290[_0x3d0c0c(258)], "productName": _0x635290[_0x3d0c0c(232)] || _0x3d0c0c(245) + _0x635290["productId"], "quality": _0x2b62ad, "price": parseFloat(_0x158a81[_0x3d0c0c(253)](2)), "cost": parseFloat(_0x635290["cost"][_0x3d0c0c(253)](2)), "profitPerUnit": parseFloat(_0x489d5d[_0x3d0c0c(253)](2)), "profitPerDay": Math["round"](_0x289c64), "grossRevPerDay": Math[_0x3d0c0c(242)](_0xccb696), "unitsPerHr": parseFloat(_0x1c3a3d[_0x3d0c0c(253)](1)), "unitsPerDay": Math[_0x3d0c0c(242)](_0x5108da), "pphpl": _0x289c64 });
        }
      }
      _0x3d8bf3[_0x3d0c0c(240)]((_0x2d21cb, _0xf26d0) => _0xf26d0[_0x3d0c0c(238)] - _0x2d21cb[_0x3d0c0c(238)]), self[_0x3d0c0c(252)]({ "action": "result", "results": _0x3d8bf3 });
    } catch (_0x46de92) {
      self[_0x3d0c0c(252)]({ "error": _0x46de92[_0x3d0c0c(228)] });
    }
  }
};
