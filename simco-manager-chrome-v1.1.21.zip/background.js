const _0x319b78 = _0xd4c0;
(function(_0x34733c, _0x17fc02) {
  const _0x1eebf7 = _0xd4c0, _0x3327ab = _0x34733c();
  while (!![]) {
    try {
      const _0x2a476c = -parseInt(_0x1eebf7(308)) / 1 * (parseInt(_0x1eebf7(312)) / 2) + parseInt(_0x1eebf7(287)) / 3 + parseInt(_0x1eebf7(318)) / 4 + parseInt(_0x1eebf7(261)) / 5 + -parseInt(_0x1eebf7(215)) / 6 + parseInt(_0x1eebf7(262)) / 7 + -parseInt(_0x1eebf7(245)) / 8 * (parseInt(_0x1eebf7(252)) / 9);
      if (_0x2a476c === _0x17fc02) break;
      else _0x3327ab["push"](_0x3327ab["shift"]());
    } catch (_0x64b36d) {
      _0x3327ab["push"](_0x3327ab["shift"]());
    }
  }
})(_0xf9bd, 597213);
const REPO_OWNER = _0x319b78(275), REPO_NAME = _0x319b78(334);
function parseVersion(_0x14eb3b) {
  const _0x5c2a07 = _0x319b78, _0x52b7a6 = String(_0x14eb3b || "")["replace"](/^v/i, "")[_0x5c2a07(263)](".");
  return [Number(_0x52b7a6[0] || 0), Number(_0x52b7a6[1] || 0), Number(_0x52b7a6[2] || 0)];
}
function compareVersions(_0x578d95, _0x5f4d42) {
  const [_0x5804b6, _0x103267, _0x5510b6] = parseVersion(_0x578d95), [_0x211731, _0x249b34, _0x3deec1] = parseVersion(_0x5f4d42);
  if (_0x5804b6 !== _0x211731) return _0x5804b6 - _0x211731;
  if (_0x103267 !== _0x249b34) return _0x103267 - _0x249b34;
  return _0x5510b6 - _0x3deec1;
}
function minorKey(_0x3ed8cf) {
  const _0x3c15cd = _0x319b78, _0xea4a3f = String(_0x3ed8cf || "")[_0x3c15cd(263)]("."), _0x14ab67 = _0xea4a3f[0] || "0", _0x7cb77a = _0xea4a3f[1] || "0";
  return _0x14ab67 + "." + _0x7cb77a;
}
function _0xf9bd() {
  const _0x470bc0 = ["DgfI", "CMvZCg9UC2u", "B2jQzwn0", "C2n4", "rKvuq0HFu0Lnq09ut09mu19wv0fq", "zMLUAxnOvgLTzu1Z", "C2v0", "y29TCgfUEuLK", "y2vPBa", "BwfW", "rKvuq0HFu0Lnq09ut09mu19qseftrvm", "C3rVCMfNzq", "Bwf0y2G", "yNvPBgrPBMCTywXHCM1Z", "vxbKyxrLza", "DhLWzq", "Ahr0Chm6lY9NAxrODwiUy29TlW", "veLnru9vva", "BgLZDej5uhjLzML4", "C2nVCgu", "D2LUzg93CW", "sfruuca", "B21PDa", "BwvZC2fNzq", "uMvXDwvZDcb0Aw1LB3v0", "mJi1mZC4rvzUD2vb", "u0nsqvbfx0npt1bfuL9srvrbsuW", "C2n4oG", "C2LTy290B29SCW", "yxjYyxLcDwzMzxi", "Bwf4", "zg9JCW", "CMvHBg1jza", "D2LUzg93swq", "Cg9WDxa", "ChjLCMvSzwfZzq", "l2v4zwn1DgL2zxm/", "ywXHCM1Z", "C2LNBMfS", "CMfUzg9T", "Bgv2zwXjBMzV", "zMvHDa", "C3rHDhvZ", "Bg9JywW", "igHHCYbMAw5PC2HLzcbWCM9KDwn0Aw9Uiq", "AxnbCNjHEq", "rML4zwq", "Ahr0Chm6lY9JB29WzxjPBMmUEhL6l2fWAs9PBML0AwfSlwrHDge/CMvHBg09", "C2v0sxrLBq", "zgvSzxrL", "CgvYzG", "zMLSDgvY", "Bg9HzgLUzW", "CMvHC29U", "l21HCMTLDc92D2fWCW", "ndyXntm2ywHoBefQ", "CNvUDgLTzq", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "DgHLBG", "CMvWBgfJzq", "CgfYyw1Z", "Bgv2zwW", "otbYvwnLExq", "u2LTq28GtwfUywDLCG", "C3rHCNrZv2L0Aa", "uKfurv9msu1jvf9dt09mre9xtJO", "CMvTB3zL", "C2nVCgvlzxK", "C2n4lwfSyxjTlq", "zw50CMLLCW", "AgfZ", "mJu3mti0nxfZtKLJtq", "ndq4mdaWu09hswrL", "C3bSAxq", "yMXVy2TLza", "A2v5", "Bwv0Ag9K", "AgfZu2nVCgu", "zxjYB3i", "BMfTzq", "r0vu", "z2v0", "B25nzxnZywDL", "sfruuf9fuLjpuG", "CMvTB3zLsxrLBq", "txvOyw1TzxrgDxjRyw5zAwXTyxO", "DMvYC2LVBG", "C2n4lxDOyxrZlw5LDY1Syxn0lw5VDgLMAwvKlw1PBM9Y", "y2XLyw51Ca", "yNvPBgrPBMDoyw1L", "u0vux0jvsuXesu5hx0fmqvjn", "Aw5JBhvKzq", "z2L0AhvIlxjLBgvHC2vZ", "DhrStxm", "y29Kzq", "z2v0sxrLBq", "BgvUz3rO", "nZK2ndG1qvv4BunJ", "Dw5KzwzPBMvK", "y29HBgvZy2u", "zgf0yq", "CMvZB2X2zq", "y2XLyxi", "Bg9HzgvK", "AxngAw5PDgu", "y29HBgvZy2vlzxK", "C2n4lwj1AwXKAw5NCW", "B25bBgfYBq", "y2f0y2G", "C3rYAw5N", "zgvMyxvSDa", "ywXHCM1jza", "rKvuq0HFu0Lnq09ut09mu19fwevdvvrjvKvt", "q29VCgvYiefqssbLCNjVCJOG", "ChvZAa", "DhjPBq", "B25jBNn0ywXSzwq", "DxbKyxrL", "mtm3nJzjCuvkALO", "yM9KEq", "yNvPBgrPBMDjza", "y29TCgfUEq", "odH5D0Djr08", "yMXVyG", "C2XPy2u", "CMvTywLUAw5Ntxm", "yxv0Aa", "ChjLDMLVDxnwzxjZAw9U", "mZG5ndyYne9qDLnRra", "zxHWzxjPzw5Jzq", "l3jLBgvHC2vZl3rHzY92", "BwLUB3jlzxK", "C3rYAw5NAwz5", "C29YDa", "DxjS", "y2HYB21L", "AwnVBNmVndGUCg5N", "tKvuv09ss19fuLjpuG", "ywrKtgLZDgvUzxi", "qujpuLrfra", "zMLUza", "D2HHDhmTBMv3", "zMXVB3i", "C2fSzxnnB2rPzMLLCG", "C2LTy28TBwfUywDLCG", "zNvUy3rPB24", "Ahr0Chm6lY9HCgKUC2LTy290B29SCY5JB20VDJeVCMvHBg1ZlW", "BNvSBa", "zMLUywXSEq", "C2nVCgvK", "z2XVyMfS", "DgfNx25HBwu", "DgvZDa", "BM90AwzPy2f0Aw9UCW", "vgLTzw91Dcb3ywL0Aw5NigzVCIbdB29WzxjjBMmGD2LUzg93ihrVihjLDhvYBIbKyxrHlG", "BM93", "q0foq0vmx0jvsuXesu5hx0fmqvjn", "l3bOyxnLCW", "CMvTB3zLuMf3", "uMvXDwvZDcbMywLSzwq", "DMfSDwu", "CgfYC2u", "ANnVBG", "y3jLyxrL", "zML4", "C2n4lxDOyxrZlw5LDY1Syxn0lxzLCNnPB24", "Dgv4Da", "rMfPBgvKihrVigzLDgnOihjLBgvHC2uGBM90zxm6"];
  _0xf9bd = function() {
    return _0x470bc0;
  };
  return _0xf9bd();
}
function releasePageUrl(_0x2ceb2f) {
  const _0x1f4334 = _0x319b78, _0x5b68cc = String(_0x2ceb2f || "")[_0x1f4334(305)]();
  return _0x1f4334(206) + REPO_OWNER + "/" + REPO_NAME + _0x1f4334(320) + encodeURIComponent(_0x5b68cc);
}
function stripMarkdown(_0x315620) {
  const _0x37806f = _0x319b78;
  let _0xdf6a6 = String(_0x315620 || "");
  return _0xdf6a6 = _0xdf6a6[_0x37806f(249)](/\[([^\]]+)\]\([^)]+\)/g, "$1"), _0xdf6a6 = _0xdf6a6[_0x37806f(249)](/https?:\/\/\S+/gi, ""), _0xdf6a6 = _0xdf6a6[_0x37806f(249)](/[`*_>#]/g, ""), _0xdf6a6 = _0xdf6a6[_0x37806f(249)](/\s+/g, " ")[_0x37806f(305)](), _0xdf6a6;
}
function humanizeHighlight(_0x1dcbb4) {
  const _0x599e93 = _0x319b78;
  let _0x5326aa = stripMarkdown(_0x1dcbb4);
  _0x5326aa = _0x5326aa["replace"](/\s+by\s+@?[a-z0-9_-]+/gi, ""), _0x5326aa = _0x5326aa[_0x599e93(249)](/\s+in\s*$/i, ""), _0x5326aa = _0x5326aa[_0x599e93(249)](/\s*\(#?\d+\)\s*$/i, "");
  const _0x4ef234 = _0x5326aa[_0x599e93(202)](/^([a-z]+)(\([^)]+\))?:\s*(.+)$/i);
  if (_0x4ef234) {
    const _0xffa4db = _0x4ef234[1]["toLowerCase"](), _0xbe0b00 = _0x4ef234[3], _0x1bf5c7 = _0xffa4db === _0x599e93(231) ? "New" : _0xffa4db === _0x599e93(186) ? _0x599e93(236) : _0xffa4db === _0x599e93(240) ? "Improved" : _0xffa4db === _0x599e93(221) ? _0x599e93(204) : null;
    if (_0x1bf5c7) _0x5326aa = _0x1bf5c7 + ": " + _0xbe0b00;
  }
  return _0x5326aa = _0x5326aa["replace"](/\s+/g, " ")[_0x599e93(305)](), _0x5326aa;
}
function extractHighlights(_0x48273f, { limit = 5 } = {}) {
  const _0x3989ba = _0x319b78, _0x32dbd2 = String(_0x48273f || ""), _0x214121 = _0x32dbd2[_0x3989ba(263)](/\r?\n/), _0x50bb1e = [];
  let _0x26c5db = ![];
  for (const _0x4781b2 of _0x214121) {
    const _0x5a993c = _0x4781b2[_0x3989ba(305)]();
    if (_0x5a993c["startsWith"]("```")) {
      _0x26c5db = !_0x26c5db;
      continue;
    }
    if (_0x26c5db) continue;
    if (!_0x5a993c) continue;
    if (/^#+\s+/[_0x3989ba(174)](_0x5a993c)) continue;
    const _0x3bd2ac = _0x5a993c["match"](/^(\*|-|•|\d+\.)\s+(.*)$/);
    if (_0x3bd2ac) {
      const _0x1a2c39 = humanizeHighlight(_0x3bd2ac[2]);
      if (_0x1a2c39) _0x50bb1e["push"](_0x1a2c39);
    }
    if (_0x50bb1e[_0x3989ba(286)] >= limit) break;
  }
  return _0x50bb1e[_0x3989ba(314)](0, limit);
}
function collectHighlightsFromReleases(_0x47bc5d, _0x3bb6e7, _0x26ddd9, { limit = 10 } = {}) {
  const _0x2c5554 = _0x319b78, _0x21040b = (Array[_0x2c5554(235)](_0x47bc5d) ? _0x47bc5d : [])[_0x2c5554(241)]((_0x354111) => !(_0x354111 == null ? void 0 : _0x354111[_0x2c5554(225)]))[_0x2c5554(199)]((_0x5049eb) => ({ ..._0x5049eb, "tag_name": String((_0x5049eb == null ? void 0 : _0x5049eb[_0x2c5554(173)]) || "") }))[_0x2c5554(241)]((_0x18aad0) => /^v?\d+\.\d+\.\d+$/[_0x2c5554(174)](_0x18aad0["tag_name"]))[_0x2c5554(241)]((_0x38b7a0) => compareVersions(_0x38b7a0[_0x2c5554(173)], _0x3bb6e7) > 0)[_0x2c5554(241)]((_0x3becf1) => compareVersions(_0x3becf1["tag_name"], _0x26ddd9) <= 0)[_0x2c5554(323)]((_0x5448dd, _0x2dd6c3) => compareVersions(_0x5448dd[_0x2c5554(173)], _0x2dd6c3[_0x2c5554(173)])), _0x5b5720 = [];
  for (const _0x1b08b2 of _0x21040b) {
    const _0x5e4af0 = extractHighlights(_0x1b08b2[_0x2c5554(309)], { "limit": limit });
    for (const _0x4edf1f of _0x5e4af0) {
      _0x5b5720["push"](_0x4edf1f);
      if (_0x5b5720[_0x2c5554(286)] >= limit) return _0x5b5720;
    }
  }
  return _0x5b5720[_0x2c5554(314)](0, limit);
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x451a20) {
  return new Promise((_0x3d75e3) => setTimeout(_0x3d75e3, _0x451a20));
}
function normalizeDomain$1(_0x20408b) {
  const _0x53031d = _0x319b78;
  return String(_0x20408b || _0x53031d(300))["trim"]()["toLowerCase"]();
}
function makeError(_0x195cae, _0x3d2f53 = {}) {
  const _0x567a32 = new Error(_0x195cae);
  return Object["assign"](_0x567a32, _0x3d2f53), _0x567a32;
}
function buildInflightKey(_0x6d237c, _0x2966f2, _0x1b811d, _0x554d23) {
  if (_0x2966f2) return _0x6d237c + ":" + _0x2966f2;
  return _0x6d237c + ":" + _0x554d23 + ":" + _0x1b811d;
}
function getRateLimitStatus(_0x45cb64 = _0x319b78(300)) {
  const _0x184c86 = _0x319b78, _0x3edcf7 = normalizeDomain$1(_0x45cb64), _0x1a731b = Number(rateLimitByDomain[_0x184c86(271)](_0x3edcf7) || 0), _0x551414 = Math[_0x184c86(220)](0, _0x1a731b - Date[_0x184c86(177)]());
  return { "blocked": _0x551414 > 0, "remainingMs": _0x551414, "blockedUntil": _0x1a731b };
}
async function parseResponse(_0x45ee3a, _0x3048f8) {
  const _0x1f2f11 = _0x319b78;
  if (_0x3048f8 === _0x1f2f11(191)) return _0x45ee3a;
  if (_0x3048f8 === _0x1f2f11(188)) return _0x45ee3a["text"]();
  if (_0x3048f8 === _0x1f2f11(313)) return _0x45ee3a[_0x1f2f11(313)]();
  if (_0x3048f8 === _0x1f2f11(219)) return _0x45ee3a[_0x1f2f11(219)]();
  return _0x45ee3a[_0x1f2f11(184)]();
}
async function doRequest(_0x5a1956, _0x3f7d95, _0x3667da = 0) {
  const _0x561805 = _0x319b78, { url: _0x187ee1, method = "GET", headers: _0x59364a, body: _0x1be270, credentials = _0x561805(281), signal: _0x1d8158, responseType = _0x561805(184), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x3f7d95, _0x162ba7 = getRateLimitStatus(_0x5a1956);
  if (_0x162ba7[_0x561805(264)]) throw makeError(_0x561805(255) + Math[_0x561805(198)](_0x162ba7["remainingMs"] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x5a1956, "remainingMs": _0x162ba7[_0x561805(315)], "status": 429 });
  const _0x37e24f = timeoutMs > 0 ? new AbortController() : null, _0x14fbba = _0x37e24f && timeoutMs > 0 ? setTimeout(() => _0x37e24f["abort"](makeError(_0x561805(214), { "code": _0x561805(207), "domain": _0x5a1956 })), timeoutMs) : null, _0x1d2a7c = _0x37e24f ? _0x37e24f[_0x561805(228)] : _0x1d8158;
  try {
    const _0x4f41f6 = await fetch(_0x187ee1, { "method": method, "headers": _0x59364a, "body": _0x1be270, "credentials": credentials, "signal": _0x1d2a7c });
    if (_0x4f41f6[_0x561805(232)] === 429 && rateLimitCooldownMs > 0) {
      const _0xfb52a4 = (rateLimitHitCount[_0x561805(271)](_0x5a1956) || 0) + 1;
      rateLimitHitCount[_0x561805(196)](_0x5a1956, _0xfb52a4);
      const _0x404789 = _0xfb52a4 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x561805(196)](_0x5a1956, Date[_0x561805(177)]() + _0x404789);
    }
    if (!_0x4f41f6["ok"]) {
      const _0xfee882 = _0x3667da < retries && retryStatuses["includes"](_0x4f41f6[_0x561805(232)]);
      if (_0xfee882) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x5a1956, _0x3f7d95, _0x3667da + 1);
      }
      throw makeError(_0x561805(211) + _0x4f41f6[_0x561805(232)], { "code": _0x561805(273), "domain": _0x5a1956, "status": _0x4f41f6[_0x561805(232)] });
    }
    return rateLimitHitCount["delete"](_0x5a1956), parseResponse(_0x4f41f6, responseType);
  } catch (_0x25c924) {
    const _0x4c8e0a = (_0x25c924 == null ? void 0 : _0x25c924[_0x561805(269)]) === "AbortError", _0x1a45ed = !_0x4c8e0a && _0x3667da < retries;
    if (_0x1a45ed) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x5a1956, _0x3f7d95, _0x3667da + 1);
    }
    if (_0x25c924 instanceof Error && _0x25c924[_0x561805(284)]) throw _0x25c924;
    throw makeError(String((_0x25c924 == null ? void 0 : _0x25c924[_0x561805(213)]) || _0x25c924 || _0x561805(181)), { "code": _0x4c8e0a ? _0x561805(329) : _0x561805(327), "domain": _0x5a1956, "status": Number((_0x25c924 == null ? void 0 : _0x25c924[_0x561805(232)]) || 0) || null, "cause": _0x25c924 });
  } finally {
    if (_0x14fbba) clearTimeout(_0x14fbba);
  }
}
async function request(_0x4cf2b3, _0x1196e0) {
  const _0x5976c7 = _0x319b78, _0x4c5beb = normalizeDomain$1(_0x4cf2b3), _0x5d3432 = buildInflightKey(_0x4c5beb, _0x1196e0 == null ? void 0 : _0x1196e0[_0x5976c7(295)], _0x1196e0 == null ? void 0 : _0x1196e0[_0x5976c7(324)], (_0x1196e0 == null ? void 0 : _0x1196e0[_0x5976c7(266)]) || _0x5976c7(270));
  if ((_0x1196e0 == null ? void 0 : _0x1196e0[_0x5976c7(289)]) && inflightByKey[_0x5976c7(260)](_0x5d3432)) return inflightByKey[_0x5976c7(271)](_0x5d3432);
  const _0x460144 = doRequest(_0x4c5beb, _0x1196e0 || {})[_0x5976c7(170)](() => {
    const _0x2484e1 = _0x5976c7;
    inflightByKey[_0x2484e1(239)](_0x5d3432);
  });
  return (_0x1196e0 == null ? void 0 : _0x1196e0["coalesce"]) && inflightByKey[_0x5976c7(196)](_0x5d3432, _0x460144), _0x460144;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x308c03) {
  const _0x28b86d = _0x319b78, _0x1abc30 = _0x308c03 == null ? void 0 : _0x308c03["authCompany"];
  STATE[_0x28b86d(316)]["companyId"] = (_0x1abc30 == null ? void 0 : _0x1abc30[_0x28b86d(197)]) ?? null, STATE[_0x28b86d(316)][_0x28b86d(222)] = (_0x1abc30 == null ? void 0 : _0x1abc30[_0x28b86d(222)]) ?? null, STATE[_0x28b86d(316)]["productionModifier"] = (_0x1abc30 == null ? void 0 : _0x1abc30["productionModifier"]) ?? null, STATE[_0x28b86d(316)][_0x28b86d(333)] = (_0x1abc30 == null ? void 0 : _0x1abc30[_0x28b86d(333)]) ?? null, STATE["auth"][_0x28b86d(293)] = !![];
  const _0xe1a9fe = _0x308c03 == null ? void 0 : _0x308c03[_0x28b86d(230)];
  STATE["levelInfo"]["level"] = (_0xe1a9fe == null ? void 0 : _0xe1a9fe[_0x28b86d(251)]) ?? null, STATE["levelInfo"][_0x28b86d(319)] = (_0xe1a9fe == null ? void 0 : _0xe1a9fe["experience"]) ?? null, STATE[_0x28b86d(230)][_0x28b86d(247)] = (_0xe1a9fe == null ? void 0 : _0xe1a9fe[_0x28b86d(247)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x58ee53 = _0x319b78;
  if (!force && STATE[_0x58ee53(316)][_0x58ee53(293)] || STATE[_0x58ee53(316)][_0x58ee53(242)]) return;
  STATE[_0x58ee53(316)][_0x58ee53(242)] = !![], STATE[_0x58ee53(316)][_0x58ee53(268)] = null;
  try {
    const _0x10bc54 = await request(_0x58ee53(316), { "url": "https://www.simcompanies.com/api/v3/companies/auth-data/", "credentials": _0x58ee53(281), "responseType": _0x58ee53(184), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x10bc54);
  } catch (_0x2d0693) {
    STATE[_0x58ee53(316)][_0x58ee53(268)] = String((_0x2d0693 == null ? void 0 : _0x2d0693[_0x58ee53(213)]) || _0x2d0693);
  } finally {
    STATE[_0x58ee53(316)][_0x58ee53(242)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x319b78(171), _0x319b78(311), _0x319b78(172)]);
function normalizeScopeMode(_0x454856) {
  const _0x5574db = _0x319b78;
  if (VALID_SCOPE_MODES[_0x5574db(260)](_0x454856)) return _0x454856;
  return "scoped";
}
function numericOrNull(_0x1a2408) {
  const _0xa694b1 = _0x319b78;
  if (_0x1a2408 === null || _0x1a2408 === void 0 || _0x1a2408 === "") return null;
  const _0x2938ed = Number(_0x1a2408);
  return Number[_0xa694b1(294)](_0x2938ed) ? _0x2938ed : null;
}
function resolveScopeSync(_0x5d9e58 = _0x319b78(171)) {
  var _a, _b;
  const _0x43a0a7 = _0x319b78, _0x2c4bde = normalizeScopeMode(_0x5d9e58), _0x26f77c = numericOrNull((_a = STATE[_0x43a0a7(316)]) == null ? void 0 : _a[_0x43a0a7(197)]), _0xc630d2 = numericOrNull((_b = STATE[_0x43a0a7(316)]) == null ? void 0 : _b[_0x43a0a7(222)]);
  if (_0x2c4bde === _0x43a0a7(172)) return { "mode": _0x2c4bde, "companyId": _0x26f77c, "realmId": _0xc630d2, "hasScope": !![], "scopeKey": _0x43a0a7(172) };
  if (_0x2c4bde === "company") return { "mode": _0x2c4bde, "companyId": _0x26f77c, "realmId": _0xc630d2, "hasScope": Number[_0x43a0a7(294)](_0x26f77c), "scopeKey": Number["isFinite"](_0x26f77c) ? String(_0x26f77c) : null };
  const _0x17f205 = Number[_0x43a0a7(294)](_0x26f77c) && Number[_0x43a0a7(294)](_0xc630d2);
  return { "mode": _0x2c4bde, "companyId": _0x26f77c, "realmId": _0xc630d2, "hasScope": _0x17f205, "scopeKey": _0x17f205 ? _0x26f77c + "-" + _0xc630d2 : null };
}
async function resolveScope(_0x4a3e3b = _0x319b78(171), { refreshAuth = ![] } = {}) {
  const _0x2921f4 = _0x319b78, _0x90828e = normalizeScopeMode(_0x4a3e3b);
  return refreshAuth && _0x90828e !== _0x2921f4(172) && await loadAuthDataOnce(), resolveScopeSync(_0x90828e);
}
const DEFAULT_PREFIX = _0x319b78(193);
function hasLocalStorage() {
  const _0x1d9704 = _0x319b78;
  try {
    return typeof localStorage !== _0x1d9704(288) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x2bbeb2 = _0x319b78;
  try {
    return typeof chrome !== _0x2bbeb2(288) && Boolean((_a = chrome == null ? void 0 : chrome["storage"]) == null ? void 0 : _a[_0x2bbeb2(233)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x557319) {
  const _0x107a5a = _0x319b78;
  if (_0x557319 == null) return null;
  if (typeof _0x557319 === _0x107a5a(192)) return _0x557319;
  try {
    return JSON["parse"](String(_0x557319));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x50e179, _0x14e665) {
  const _0x476707 = _0x319b78;
  if (_0x50e179 === _0x476707(325)) return _0x14e665;
  return JSON[_0x476707(322)](_0x14e665);
}
function isEnvelopeValid(_0x32ef9e) {
  const _0x5d08fb = _0x319b78;
  return Boolean(_0x32ef9e && typeof _0x32ef9e === "object" && Number[_0x5d08fb(294)](Number(_0x32ef9e["v"])));
}
function isExpired(_0x6a7ab9, _0xd100ca = null, _0x4e06c4 = Date[_0x319b78(177)]()) {
  const _0x31911c = _0x319b78, _0x210900 = Number((_0x6a7ab9 == null ? void 0 : _0x6a7ab9["ts"]) || 0), _0x5e590c = Number(_0x6a7ab9 == null ? void 0 : _0x6a7ab9[_0x31911c(283)]), _0x5053a8 = Number[_0x31911c(294)](_0x5e590c) ? _0x5e590c : Number["isFinite"](Number(_0xd100ca)) ? Number(_0xd100ca) : null;
  if (!Number[_0x31911c(294)](_0x210900) || _0x210900 <= 0) return ![];
  if (!Number["isFinite"](_0x5053a8) || _0x5053a8 <= 0) return ![];
  return _0x210900 + _0x5053a8 < _0x4e06c4;
}
function normalizeBackend(_0xb8230a) {
  const _0x3f8ffa = _0x319b78;
  return _0xb8230a === "chrome" ? _0x3f8ffa(325) : _0x3f8ffa(233);
}
function normalizePrefix(_0x4cad0a) {
  const _0x5c4378 = _0x319b78, _0x3c7396 = String(_0x4cad0a || DEFAULT_PREFIX)[_0x5c4378(305)]();
  return _0x3c7396[_0x5c4378(286)] > 0 ? _0x3c7396 : DEFAULT_PREFIX;
}
function normalizeDomain(_0x16a312) {
  const _0x35f495 = _0x319b78;
  return String(_0x16a312 || "unknown")[_0x35f495(305)]()[_0x35f495(249)](/\s+/g, "-")["toLowerCase"]();
}
function buildStorageKey({ domain: _0x8ee774, version: _0x5842a0, scopeKey: _0x40d76d, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x8ee774) + ":v" + Number(_0x5842a0) + ":" + _0x40d76d;
}
async function chromeGet(_0x5071b0) {
  const _0x47c353 = _0x319b78;
  if (!hasChromeStorage()) return {};
  const _0x59d7bf = chrome["storage"]["local"];
  try {
    const _0x3247e1 = _0x59d7bf["get"](_0x5071b0);
    if (_0x3247e1 && typeof _0x3247e1[_0x47c353(248)] === _0x47c353(335)) return _0x3247e1;
  } catch {
  }
  return new Promise((_0x302245) => {
    const _0x50c9ff = _0x47c353;
    try {
      _0x59d7bf[_0x50c9ff(271)](_0x5071b0, (_0x1c2302) => _0x302245(_0x1c2302 || {}));
    } catch {
      _0x302245({});
    }
  });
}
async function chromeSet(_0x5ba936) {
  const _0x427891 = _0x319b78;
  if (!hasChromeStorage()) return ![];
  const _0x1470b4 = chrome["storage"]["local"];
  try {
    const _0x4ac3b9 = _0x1470b4[_0x427891(196)](_0x5ba936);
    if (_0x4ac3b9 && typeof _0x4ac3b9["then"] === "function") return await _0x4ac3b9, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x1da21f) => {
    const _0x39a1a5 = _0x427891;
    try {
      _0x1470b4[_0x39a1a5(196)](_0x5ba936, () => _0x1da21f(!![]));
    } catch {
      _0x1da21f(![]);
    }
  });
}
async function chromeRemove(_0x47fb80) {
  const _0x11f5ea = _0x319b78;
  if (!hasChromeStorage()) return ![];
  const _0x39eb22 = chrome[_0x11f5ea(201)][_0x11f5ea(233)];
  try {
    const _0x543fa4 = _0x39eb22["remove"](_0x47fb80);
    if (_0x543fa4 && typeof _0x543fa4[_0x11f5ea(248)] === _0x11f5ea(335)) return await _0x543fa4, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x2bc487) => {
    const _0x2e3eb9 = _0x11f5ea;
    try {
      _0x39eb22[_0x2e3eb9(256)](_0x47fb80, () => _0x2bc487(!![]));
    } catch {
      _0x2bc487(![]);
    }
  });
}
async function getRaw(_0x4f0c42, _0x2d418b) {
  const _0x2415b4 = _0x319b78, _0x5e998d = normalizeBackend(_0x4f0c42);
  if (_0x5e998d === _0x2415b4(233)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x2415b4(285)](_0x2d418b);
    } catch {
      return null;
    }
  }
  const _0x19b9be = await chromeGet(_0x2d418b);
  return (_0x19b9be == null ? void 0 : _0x19b9be[_0x2d418b]) ?? null;
}
function localGetItemSync(_0x1b6843) {
  const _0x155ff1 = _0x319b78;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x155ff1(285)](_0x1b6843);
  } catch {
    return null;
  }
}
function localSetItemSync(_0xf2060a, _0x16f0c7) {
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage["setItem"](_0xf2060a, String(_0x16f0c7)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x18abc6) {
  const _0x4ee474 = _0x319b78;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x4ee474(274)](_0x18abc6), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x7c6a23 = "") {
  const _0x358a0b = _0x319b78;
  if (!hasLocalStorage()) return [];
  const _0x3690ea = [], _0x59b7e0 = String(_0x7c6a23 || "");
  try {
    for (let _0x4d39d1 = 0; _0x4d39d1 < localStorage[_0x358a0b(286)]; _0x4d39d1 += 1) {
      const _0x52fc37 = localStorage[_0x358a0b(265)](_0x4d39d1);
      if (!_0x52fc37 || _0x59b7e0 && !_0x52fc37[_0x358a0b(254)](_0x59b7e0)) continue;
      _0x3690ea["push"]({ "key": _0x52fc37, "value": localStorage["getItem"](_0x52fc37) });
    }
  } catch {
    return [];
  }
  return _0x3690ea;
}
async function setRaw(_0x2fb1c, _0x3c67fe, _0x4f4a02) {
  const _0x85b01e = _0x319b78, _0x3264f8 = normalizeBackend(_0x2fb1c);
  if (_0x3264f8 === _0x85b01e(233)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x85b01e(238)](_0x3c67fe, String(_0x4f4a02)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x3c67fe]: _0x4f4a02 });
}
async function removeRaw(_0x2c43ab, _0x38cb29) {
  const _0x39d5f8 = _0x319b78, _0x1caf58 = normalizeBackend(_0x2c43ab);
  if (_0x1caf58 === _0x39d5f8(233)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["removeItem"](_0x38cb29), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x38cb29);
}
async function listByPrefix({ backend = _0x319b78(233), prefix = "" } = {}) {
  const _0x59a089 = _0x319b78, _0x5df54e = normalizeBackend(backend), _0x3a8ca2 = String(prefix || "");
  if (_0x5df54e === _0x59a089(233)) {
    if (!hasLocalStorage()) return [];
    const _0x180be3 = [];
    try {
      for (let _0xa64b32 = 0; _0xa64b32 < localStorage[_0x59a089(286)]; _0xa64b32 += 1) {
        const _0x2707b3 = localStorage[_0x59a089(265)](_0xa64b32);
        if (!_0x2707b3 || _0x3a8ca2 && !_0x2707b3[_0x59a089(254)](_0x3a8ca2)) continue;
        _0x180be3[_0x59a089(304)]({ "key": _0x2707b3, "value": localStorage[_0x59a089(285)](_0x2707b3) });
      }
    } catch {
      return [];
    }
    return _0x180be3;
  }
  const _0x47f587 = await chromeGet(null);
  return Object[_0x59a089(259)](_0x47f587 || {})[_0x59a089(241)](([_0x2d031d]) => _0x3a8ca2 ? _0x2d031d[_0x59a089(254)](_0x3a8ca2) : !![])[_0x59a089(199)](([_0xd18b34, _0x50948c]) => ({ "key": _0xd18b34, "value": _0x50948c }));
}
async function get({ domain: _0x588094, version: _0x30e00c, scope = _0x319b78(171), backend = _0x319b78(233), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x3dc36b = _0x319b78, _0x539d94 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x539d94[_0x3dc36b(267)] || !_0x539d94["scopeKey"]) return null;
  const _0x1a5256 = buildStorageKey({ "domain": _0x588094, "version": _0x30e00c, "scopeKey": _0x539d94[_0x3dc36b(257)], "prefix": prefix }), _0x3043ce = await getRaw(backend, _0x1a5256);
  if (_0x3043ce == null) return null;
  const _0x4f7475 = parseJson(_0x3043ce);
  if (!isEnvelopeValid(_0x4f7475)) return await removeRaw(backend, _0x1a5256), null;
  const _0x259c17 = Number(_0x4f7475["v"]);
  if (_0x259c17 !== Number(_0x30e00c)) return _0x259c17 < Number(_0x30e00c) && await removeRaw(backend, _0x1a5256), null;
  if (isExpired(_0x4f7475, ttlMs)) return await removeRaw(backend, _0x1a5256), null;
  const _0x30c5b8 = _0x539d94[_0x3dc36b(257)], _0x2c622e = String(((_a = _0x4f7475 == null ? void 0 : _0x4f7475[_0x3dc36b(209)]) == null ? void 0 : _a["scopeKey"]) || "");
  if (_0x30c5b8 && _0x2c622e && _0x30c5b8 !== _0x2c622e) return await removeRaw(backend, _0x1a5256), null;
  return _0x4f7475[_0x3dc36b(290)] ?? null;
}
async function set({ domain: _0x332d1c, version: _0x202c42, scope = _0x319b78(171), backend = _0x319b78(233), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x2359a8 } = {}) {
  const _0x6b7197 = _0x319b78, _0x12a45a = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x12a45a[_0x6b7197(267)] || !_0x12a45a[_0x6b7197(257)]) return ![];
  const _0x16b191 = buildStorageKey({ "domain": _0x332d1c, "version": _0x202c42, "scopeKey": _0x12a45a["scopeKey"], "prefix": prefix }), _0x29eb19 = { "v": Number(_0x202c42), "ts": Date[_0x6b7197(177)](), "ttlMs": Number[_0x6b7197(294)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x12a45a["mode"], "scopeKey": _0x12a45a[_0x6b7197(257)], "companyId": _0x12a45a[_0x6b7197(197)], "realmId": _0x12a45a[_0x6b7197(222)] }, "data": _0x2359a8 };
  return setRaw(backend, _0x16b191, toStorageRaw(normalizeBackend(backend), _0x29eb19));
}
async function remove({ domain: _0x24de67, version: _0x1df51e, scope = "scoped", backend = _0x319b78(233), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x16407c = _0x319b78, _0xf0b35a = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0xf0b35a[_0x16407c(267)] || !_0xf0b35a[_0x16407c(257)]) return ![];
  const _0x22fb91 = buildStorageKey({ "domain": _0x24de67, "version": _0x1df51e, "scopeKey": _0xf0b35a["scopeKey"], "prefix": prefix });
  return removeRaw(backend, _0x22fb91);
}
async function migrate({ domain: _0x3a9284, version: _0x1dc69c, scope = _0x319b78(171), backend = _0x319b78(233), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x17d725, cleanupLegacy = !![] } = {}) {
  const _0x39dabc = _0x319b78, _0x3313e8 = await get({ "domain": _0x3a9284, "version": _0x1dc69c, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x3313e8 !== null && _0x3313e8 !== void 0) return { "data": _0x3313e8, "migrated": ![] };
  if (typeof _0x17d725 !== _0x39dabc(335)) return { "data": null, "migrated": ![] };
  const _0x5e0ec4 = await _0x17d725({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x1f4af3 = _0x5e0ec4 == null ? void 0 : _0x5e0ec4[_0x39dabc(290)];
  if (_0x1f4af3 === null || _0x1f4af3 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x3a9284, "version": _0x1dc69c, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x1f4af3 }), cleanupLegacy && typeof (_0x5e0ec4 == null ? void 0 : _0x5e0ec4[_0x39dabc(278)]) === _0x39dabc(335) && await _0x5e0ec4["cleanup"](), { "data": _0x1f4af3, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x319b78(296), "scx-buildings-ts"];
let migrationsRan = ![];
function parseDomainAndVersion(_0x5f4358) {
  const _0x3f4a67 = _0x319b78, _0x1521b1 = String(_0x5f4358 || "")["split"](":");
  if (_0x1521b1["length"] < 4) return null;
  if (_0x1521b1[0] !== _0x3f4a67(193)) return null;
  const _0x13ae7b = _0x1521b1[1], _0xbe98c6 = _0x1521b1[2] || "";
  if (!_0xbe98c6[_0x3f4a67(254)]("v")) return null;
  const _0xc47ed4 = Number(_0xbe98c6[_0x3f4a67(314)](1));
  if (!Number["isFinite"](_0xc47ed4)) return null;
  return { "domain": _0x13ae7b, "version": _0xc47ed4 };
}
function _0xd4c0(_0x35cfda, _0x1e0a0a) {
  _0x35cfda = _0x35cfda - 170;
  const _0xf9bd5d = _0xf9bd();
  let _0xd4c04b = _0xf9bd5d[_0x35cfda];
  if (_0xd4c0["ItXdzG"] === void 0) {
    var _0x27fe2c = function(_0x29c0d8) {
      const _0x44eeac = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x14eb3b = "", _0x52b7a6 = "";
      for (let _0x578d95 = 0, _0x5f4d42, _0x5804b6, _0x103267 = 0; _0x5804b6 = _0x29c0d8["charAt"](_0x103267++); ~_0x5804b6 && (_0x5f4d42 = _0x578d95 % 4 ? _0x5f4d42 * 64 + _0x5804b6 : _0x5804b6, _0x578d95++ % 4) ? _0x14eb3b += String["fromCharCode"](255 & _0x5f4d42 >> (-2 * _0x578d95 & 6)) : 0) {
        _0x5804b6 = _0x44eeac["indexOf"](_0x5804b6);
      }
      for (let _0x5510b6 = 0, _0x211731 = _0x14eb3b["length"]; _0x5510b6 < _0x211731; _0x5510b6++) {
        _0x52b7a6 += "%" + ("00" + _0x14eb3b["charCodeAt"](_0x5510b6)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x52b7a6);
    };
    _0xd4c0["xVUdOP"] = _0x27fe2c, _0xd4c0["MJmMnK"] = {}, _0xd4c0["ItXdzG"] = !![];
  }
  const _0x450830 = _0xf9bd5d[0], _0x499005 = _0x35cfda + _0x450830, _0x528edc = _0xd4c0["MJmMnK"][_0x499005];
  return !_0x528edc ? (_0xd4c04b = _0xd4c0["xVUdOP"](_0xd4c04b), _0xd4c0["MJmMnK"][_0x499005] = _0xd4c04b) : _0xd4c04b = _0x528edc, _0xd4c04b;
}
async function cleanupVersionedEnvelopes(_0x1d1878) {
  const _0x449237 = _0x319b78, _0x4dbefb = await storage[_0x449237(208)]({ "backend": _0x1d1878, "prefix": _0x449237(217) });
  for (const _0x3eb9d5 of _0x4dbefb) {
    const _0x36f05a = parseDomainAndVersion(_0x3eb9d5[_0x449237(265)]);
    if (!_0x36f05a) continue;
    const _0x489c02 = Number(MIN_DOMAIN_VERSION[_0x36f05a["domain"]] || 1);
    if (_0x36f05a[_0x449237(276)] < _0x489c02) {
      await storage[_0x449237(180)](_0x1d1878, _0x3eb9d5["key"]);
      continue;
    }
    if (_0x3eb9d5["value"] == null) {
      await storage[_0x449237(180)](_0x1d1878, _0x3eb9d5[_0x449237(265)]);
      continue;
    }
    const _0x2be15e = typeof _0x3eb9d5[_0x449237(182)] === _0x449237(299) ? (() => {
      const _0x38f21e = _0x449237;
      try {
        return JSON[_0x38f21e(183)](_0x3eb9d5["value"] || _0x38f21e(337));
      } catch {
        return null;
      }
    })() : _0x3eb9d5[_0x449237(182)];
    if (!_0x2be15e || typeof _0x2be15e !== _0x449237(192) || !Number[_0x449237(294)](Number(_0x2be15e["v"]))) {
      await storage["removeRaw"](_0x1d1878, _0x3eb9d5[_0x449237(265)]);
      continue;
    }
    Number(_0x2be15e["v"]) < _0x489c02 && await storage[_0x449237(180)](_0x1d1878, _0x3eb9d5[_0x449237(265)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x3f7944 = _0x319b78;
  for (const _0x5f3c23 of LEGACY_GLOBAL_KEYS) {
    await storage[_0x3f7944(180)](_0x3f7944(233), _0x5f3c23), await storage[_0x3f7944(180)](_0x3f7944(325), _0x5f3c23);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x5868b2 = _0x319b78;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x5868b2(233)), await cleanupVersionedEnvelopes(_0x5868b2(325)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
async function scrapeCooperRetail(_0x4d57c3, _0x5982cb) {
  return new Promise((_0x776c32, _0x209bba) => {
    const _0x5621dc = _0xd4c0;
    let _0x1cf0df = null;
    const _0x883823 = (_0x311e1b, _0x22c426, _0x449e76) => {
      const _0x24bcd4 = _0xd4c0;
      if (_0x1cf0df !== null && _0x22c426["tab"] && _0x22c426[_0x24bcd4(190)][_0x24bcd4(223)] !== _0x1cf0df) return;
      _0x311e1b[_0x24bcd4(205)] === "COOPER_IFRAME_RESULT" && (_0xedbd18(), _0x311e1b[_0x24bcd4(268)] ? _0x209bba(new Error(_0x311e1b[_0x24bcd4(268)])) : _0x311e1b[_0x24bcd4(290)] && _0x311e1b["data"][_0x24bcd4(286)] === 0 ? _0x776c32([]) : _0x776c32(_0x311e1b[_0x24bcd4(290)]));
    };
    chrome["runtime"][_0x5621dc(272)][_0x5621dc(328)](_0x883823);
    const _0x54e5f6 = setTimeout(() => {
      const _0x236f7d = _0x5621dc;
      _0xedbd18(), _0x209bba(new Error(_0x236f7d(176)));
    }, 25e3), _0xedbd18 = () => {
      const _0x26f6bb = _0x5621dc;
      clearTimeout(_0x54e5f6), chrome["runtime"][_0x26f6bb(272)]["removeListener"](_0x883823), _0x1cf0df !== null && chrome[_0x26f6bb(210)][_0x26f6bb(256)](_0x1cf0df)["catch"](() => {
      });
    }, _0x5bff06 = encodeURIComponent(JSON[_0x5621dc(322)](_0x4d57c3)), _0x29d9a4 = "https://cooperinc.xyz/retail?scx_params=" + _0x5bff06;
    chrome[_0x5621dc(210)]["create"]({ "url": _0x29d9a4, "type": _0x5621dc(224), "width": 1, "height": 1, "left": 9999, "top": 9999, "focused": ![] })[_0x5621dc(248)]((_0x4084b) => {
      _0x1cf0df = _0x4084b["id"];
    })["catch"]((_0x369d42) => {
      _0xedbd18(), _0x209bba(_0x369d42);
    });
  });
}
const DOMAIN = _0x319b78(203), VERSION = 1;
async function getActiveAlarms() {
  const _0x8c5210 = _0x319b78, _0x5496f2 = await storage["get"]({ "domain": DOMAIN, "version": VERSION, "scope": _0x8c5210(172), "backend": _0x8c5210(325) });
  return (_0x5496f2 == null ? void 0 : _0x5496f2[_0x8c5210(227)]) || [];
}
async function saveActiveAlarms(_0x2a77a3) {
  const _0x2971ae = _0x319b78;
  await storage["set"]({ "domain": DOMAIN, "version": VERSION, "scope": "global", "backend": _0x2971ae(325), "data": { "alarms": _0x2a77a3 } });
}
let addAlarmQueue = Promise[_0x319b78(291)]();
function addAlarm(_0x2c483e, _0xb1065b, _0x2416c5, _0x3c9e44, _0x21603c) {
  const _0x4c51fe = _0x319b78;
  return addAlarmQueue = addAlarmQueue[_0x4c51fe(248)](async () => {
    const _0x131c2e = _0x4c51fe, _0x45f11d = await getActiveAlarms(), _0x2963ed = _0x45f11d[_0x131c2e(241)]((_0x1a38b5) => {
      const _0x91f898 = _0x131c2e;
      if (_0x2416c5 && _0x1a38b5[_0x91f898(310)]) return _0x1a38b5[_0x91f898(310)] !== _0x2416c5;
      return _0x1a38b5[_0x91f898(301)] !== _0x2c483e;
    });
    _0x2963ed["push"]({ "alarmId": _0x2c483e, "buildingName": _0xb1065b, "buildingId": _0x2416c5, "finishTimeMs": _0x3c9e44, "translatedMessage": _0x21603c }), await saveActiveAlarms(_0x2963ed);
  })[_0x4c51fe(298)](console["error"]), addAlarmQueue;
}
async function removeAlarm(_0x2f030d) {
  const _0x404832 = _0x319b78, _0x105df6 = await getActiveAlarms(), _0x30ceeb = _0x105df6[_0x404832(241)]((_0xb190ad) => _0xb190ad[_0x404832(301)] !== _0x2f030d);
  _0x105df6["length"] !== _0x30ceeb[_0x404832(286)] && await saveActiveAlarms(_0x30ceeb);
}
async function clearExpiredAlarms() {
  const _0x284462 = _0x319b78, _0xfc8378 = await getActiveAlarms(), _0x1ab6e4 = Date[_0x284462(177)](), _0x2b6943 = _0xfc8378[_0x284462(241)]((_0x5dfe5d) => _0x5dfe5d[_0x284462(195)] > _0x1ab6e4);
  _0xfc8378["length"] !== _0x2b6943["length"] && await saveActiveAlarms(_0x2b6943);
}
const KEY_WHATS_NEW = "scx-whats-new", KEY_LAST_MINOR = _0x319b78(277), KEY_LAST_VERSION = _0x319b78(187), STORAGE_DOMAIN_WHATS_NEW = _0x319b78(331), STORAGE_DOMAIN_WHATS_NEW_META = "whats-new-meta", STORAGE_VERSION = 1;
async function setWhatsNew(_0x24b02a) {
  const _0x47af6b = _0x319b78;
  await storage["set"]({ "domain": STORAGE_DOMAIN_WHATS_NEW, "version": STORAGE_VERSION, "scope": _0x47af6b(172), "backend": _0x47af6b(325), "refreshAuth": ![], "data": _0x24b02a }), await storage["set"]({ "domain": STORAGE_DOMAIN_WHATS_NEW_META, "version": STORAGE_VERSION, "scope": _0x47af6b(172), "backend": _0x47af6b(325), "refreshAuth": ![], "data": { "minorKey": _0x24b02a[_0x47af6b(321)], "lastVersion": _0x24b02a["lastVersion"] } }), await storage[_0x47af6b(180)](_0x47af6b(325), KEY_WHATS_NEW), await storage["removeRaw"](_0x47af6b(325), KEY_LAST_MINOR), await storage[_0x47af6b(180)](_0x47af6b(325), KEY_LAST_VERSION);
}
async function fetchAllReleases() {
  const _0x22ad5d = _0x319b78;
  return request(_0x22ad5d(282), { "url": "https://api.github.com/repos/MuhammetFurkanYilmaz/simco-manager/releases?per_page=100", "credentials": _0x22ad5d(212), "responseType": "json", "retries": 1, "retryDelayMs": 300 });
}
chrome[_0x319b78(246)][_0x319b78(306)][_0x319b78(328)](async (_0xda9265) => {
  const _0x17ed58 = _0x319b78;
  await initializeDataPlatform();
  _0xda9265[_0x17ed58(243)] === "install" && await storage[_0x17ed58(196)]({ "domain": "welcome-message", "version": 1, "scope": "global", "backend": _0x17ed58(325), "refreshAuth": ![], "data": { "show": !![] } });
  if (_0xda9265[_0x17ed58(243)] === _0x17ed58(307) && _0xda9265[_0x17ed58(317)]) {
    const _0x4cc6c8 = chrome[_0x17ed58(246)]["getManifest"]()[_0x17ed58(276)];
    if (_0x4cc6c8 !== _0xda9265[_0x17ed58(317)]) try {
      const _0x5f4d88 = await fetchAllReleases();
      let _0x260b0d = [];
      const _0x3c610e = releasePageUrl(_0x4cc6c8);
      _0x5f4d88 && Array["isArray"](_0x5f4d88) && (_0x260b0d = collectHighlightsFromReleases(_0x5f4d88, _0xda9265[_0x17ed58(317)], _0x4cc6c8)), await setWhatsNew({ "show": !![], "version": _0x4cc6c8, "url": _0x3c610e, "highlights": _0x260b0d, "error": !_0x5f4d88 || !Array[_0x17ed58(235)](_0x5f4d88), "minorKey": minorKey(_0x4cc6c8), "lastVersion": _0x4cc6c8 });
    } catch (_0x1731a2) {
      console["error"](_0x17ed58(189), _0x1731a2), await setWhatsNew({ "show": !![], "version": _0x4cc6c8, "url": releasePageUrl(_0x4cc6c8), "highlights": [], "error": !![], "minorKey": minorKey(_0x4cc6c8), "lastVersion": _0x4cc6c8 });
    }
  }
});
let cooperDataCache = {}, cooperDataCacheTs = {};
const COOPER_CACHE_TTL = 5 * 60 * 1e3;
async function fetchCooperData(_0x55dca8) {
  const _0x125571 = _0x319b78, _0x2e5967 = Date["now"]();
  if (cooperDataCache[_0x55dca8] && cooperDataCacheTs[_0x55dca8] && _0x2e5967 - cooperDataCacheTs[_0x55dca8] < COOPER_CACHE_TTL) return cooperDataCache[_0x55dca8];
  const _0x19366f = "r" + (_0x55dca8 + 1), _0x56c3ad = await fetch(_0x125571(237) + _0x19366f);
  if (!_0x56c3ad["ok"]) throw new Error(_0x125571(303) + _0x56c3ad["status"]);
  const _0x1476c8 = await _0x56c3ad[_0x125571(184)]();
  return cooperDataCache[_0x55dca8] = _0x1476c8, cooperDataCacheTs[_0x55dca8] = _0x2e5967, _0x1476c8;
}
chrome[_0x319b78(246)]["onMessage"][_0x319b78(328)]((_0x385d3e, _0x1b6e48, _0x4d777c) => {
  const _0x4903b2 = _0x319b78;
  if (_0x385d3e[_0x4903b2(205)] === "FETCH_COOPER_DATA") return fetchCooperData(_0x385d3e[_0x4903b2(222)])[_0x4903b2(248)]((_0x48ca87) => _0x4d777c({ "success": !![], "data": _0x48ca87 }))[_0x4903b2(298)]((_0x6322ab) => _0x4d777c({ "success": ![], "error": _0x6322ab[_0x4903b2(213)] })), !![];
  if (_0x385d3e[_0x4903b2(205)] === _0x4903b2(194)) {
    const _0x1360d0 = _0x385d3e[_0x4903b2(222)], _0x547f65 = _0x4903b2(336) + _0x1360d0 + _0x4903b2(244);
    return request(_0x4903b2(218), { "url": _0x547f65, "method": _0x4903b2(270), "credentials": _0x4903b2(212), "responseType": "json", "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x45e52f) => _0x4d777c({ "success": !![], "data": _0x45e52f }))["catch"]((_0x167867) => _0x4d777c({ "success": ![], "error": _0x167867[_0x4903b2(213)] || String(_0x167867) })), !![];
  }
  if (_0x385d3e[_0x4903b2(205)] === _0x4903b2(302)) {
    const { realmId: _0x2a542e, queryParams: _0x96171a, headers: _0x523b19 } = _0x385d3e, _0x30275b = _0x4903b2(336) + _0x2a542e + _0x4903b2(226) + _0x96171a;
    return request(_0x4903b2(218), { "url": _0x30275b, "method": _0x4903b2(270), "headers": _0x523b19, "credentials": _0x4903b2(212), "responseType": _0x4903b2(184), "retries": 2, "retryDelayMs": 1e3 })[_0x4903b2(248)]((_0x363cc8) => _0x4d777c({ "success": !![], "data": _0x363cc8 }))[_0x4903b2(298)]((_0x23141c) => _0x4d777c({ "success": ![], "error": _0x23141c[_0x4903b2(213)] || String(_0x23141c) })), !![];
  }
  if (_0x385d3e[_0x4903b2(205)] === "FETCH_SIMCOTOOLS_STATS_BUILDINGS") {
    const { realmId: _0xf8ba06, headers: _0x3a1ecd } = _0x385d3e, _0x48277a = "https://api.simcotools.com/v1/realms/" + _0xf8ba06 + "/stats/buildings";
    return request(_0x4903b2(218), { "url": _0x48277a, "method": _0x4903b2(270), "headers": _0x3a1ecd, "credentials": _0x4903b2(212), "responseType": _0x4903b2(184), "retries": 2, "retryDelayMs": 1e3 })["then"]((_0x4600ed) => _0x4d777c({ "success": !![], "data": _0x4600ed }))["catch"]((_0x1d5ba4) => _0x4d777c({ "success": ![], "error": _0x1d5ba4[_0x4903b2(213)] || String(_0x1d5ba4) })), !![];
  }
  if (_0x385d3e[_0x4903b2(205)] === _0x4903b2(200)) {
    const { realmId: _0x5e928c, headers: _0x6d754d } = _0x385d3e, _0x3a979c = "https://api.simcotools.com/v1/realms/" + _0x5e928c + _0x4903b2(179);
    return request(_0x4903b2(218), { "url": _0x3a979c, "method": _0x4903b2(270), "headers": _0x6d754d, "credentials": "omit", "responseType": _0x4903b2(184), "retries": 2, "retryDelayMs": 1e3 })[_0x4903b2(248)]((_0x4a6d7f) => _0x4d777c({ "success": !![], "data": _0x4a6d7f }))[_0x4903b2(298)]((_0x14c462) => _0x4d777c({ "success": ![], "error": _0x14c462["message"] || String(_0x14c462) })), !![];
  }
  if (_0x385d3e[_0x4903b2(205)] === _0x4903b2(216)) return scrapeCooperRetail(_0x385d3e[_0x4903b2(250)])[_0x4903b2(248)]((_0x1b11f5) => _0x4d777c({ "success": !![], "data": _0x1b11f5 }))[_0x4903b2(298)]((_0x171fd9) => _0x4d777c({ "success": ![], "error": _0x171fd9[_0x4903b2(213)] })), !![];
  if (_0x385d3e[_0x4903b2(205)] === _0x4903b2(280)) {
    const { buildingName: _0x5a0cbb, buildingId: _0x4e0c00, finishTimeMs: _0x42ab33, translatedMessage: _0x4d75f0 } = _0x385d3e[_0x4903b2(290)], _0x14fe50 = _0x4903b2(258) + Date["now"]() + "-" + Math[_0x4903b2(332)](Math[_0x4903b2(229)]() * 1e3);
    return chrome[_0x4903b2(227)]["create"](_0x14fe50, { "when": _0x42ab33 }), addAlarm(_0x14fe50, _0x5a0cbb, _0x4e0c00, _0x42ab33, _0x4d75f0)[_0x4903b2(298)](console[_0x4903b2(268)]), _0x4d777c({ "success": !![], "alarmId": _0x14fe50 }), !![];
  }
  if (_0x385d3e["type"] === _0x4903b2(178)) {
    const { alarmId: _0x4662f1 } = _0x385d3e[_0x4903b2(290)];
    return chrome[_0x4903b2(227)][_0x4903b2(292)](_0x4662f1), removeAlarm(_0x4662f1)["catch"](console[_0x4903b2(268)]), _0x4d777c({ "success": !![] }), !![];
  }
}), chrome["alarms"][_0x319b78(297)]["addListener"](async (_0x31f2ae) => {
  const _0x3ea0f3 = _0x319b78;
  if (_0x31f2ae[_0x3ea0f3(269)][_0x3ea0f3(254)]("scx-alarm-")) {
    const _0x47e55c = await getActiveAlarms(), _0x64474a = _0x47e55c[_0x3ea0f3(330)]((_0x2f4c20) => _0x2f4c20["alarmId"] === _0x31f2ae[_0x3ea0f3(269)]), _0x218558 = _0x64474a ? _0x64474a[_0x3ea0f3(279)] : "A building", _0x186563 = (_0x64474a == null ? void 0 : _0x64474a["translatedMessage"]) || _0x218558 + _0x3ea0f3(234);
    chrome[_0x3ea0f3(175)]["create"](_0x31f2ae[_0x3ea0f3(269)], { "type": "basic", "iconUrl": _0x3ea0f3(326), "title": _0x3ea0f3(253), "message": _0x186563, "priority": 2 }), await removeAlarm(_0x31f2ae[_0x3ea0f3(269)]);
  }
}), chrome["alarms"][_0x319b78(185)]("scx-cleanup-alarms", { "periodInMinutes": 60 }), chrome[_0x319b78(227)][_0x319b78(297)][_0x319b78(328)]((_0x546ccc) => {
  const _0x463338 = _0x319b78;
  _0x546ccc[_0x463338(269)] === "scx-cleanup-alarms" && clearExpiredAlarms()["catch"](console["error"]);
});
