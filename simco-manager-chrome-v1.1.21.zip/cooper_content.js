(function(_0xf3694, _0x352254) {
  var _0x2ac579 = _0x4ebf, _0x76e364 = _0xf3694();
  while (!![]) {
    try {
      var _0x57964b = -parseInt(_0x2ac579(228)) / 1 + parseInt(_0x2ac579(225)) / 2 * (-parseInt(_0x2ac579(229)) / 3) + parseInt(_0x2ac579(233)) / 4 * (parseInt(_0x2ac579(224)) / 5) + parseInt(_0x2ac579(223)) / 6 + -parseInt(_0x2ac579(232)) / 7 * (parseInt(_0x2ac579(227)) / 8) + -parseInt(_0x2ac579(234)) / 9 * (-parseInt(_0x2ac579(231)) / 10) + parseInt(_0x2ac579(230)) / 11 * (-parseInt(_0x2ac579(226)) / 12);
      if (_0x57964b === _0x352254) break;
      else _0x76e364["push"](_0x76e364["shift"]());
    } catch (_0x270428) {
      _0x76e364["push"](_0x76e364["shift"]());
    }
  }
})(_0x25e2, 213709);
function _0x25e2() {
  var _0x44ea5 = ["mJq1mJK0BLLoCNHX", "mJaXntq0sNbUCM1Z", "mtqXm2P1vvrQEa", "mJe1mdaXmhz1BxPAtW", "ndbpsMjvAfG", "ohr2AMv3Da", "mZzeywH4Eue", "ogn5DLfTsG", "mtyYmJG5BM1Lt09p", "mtiXmZeXz2XrteXd", "mtuYody4muTAt01nqW", "mtq1ndbhy09SEwm"];
  _0x25e2 = function() {
    return _0x44ea5;
  };
  return _0x25e2();
}
(async function() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function _0x4ebf(_0x1ffc46, _0x40e8c7) {
  _0x1ffc46 = _0x1ffc46 - 223;
  var _0x25e22d = _0x25e2();
  var _0x4ebf18 = _0x25e22d[_0x1ffc46];
  if (_0x4ebf["OizMWG"] === void 0) {
    var _0x3db13f = function(_0x59c6fe) {
      var _0x3abf1f = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0xc0eafa = "", _0x1d95c3 = "";
      for (var _0x1da536 = 0, _0x5ca743, _0x57a93f, _0x2bc791 = 0; _0x57a93f = _0x59c6fe["charAt"](_0x2bc791++); ~_0x57a93f && (_0x5ca743 = _0x1da536 % 4 ? _0x5ca743 * 64 + _0x57a93f : _0x57a93f, _0x1da536++ % 4) ? _0xc0eafa += String["fromCharCode"](255 & _0x5ca743 >> (-2 * _0x1da536 & 6)) : 0) {
        _0x57a93f = _0x3abf1f["indexOf"](_0x57a93f);
      }
      for (var _0x492735 = 0, _0xa53eb5 = _0xc0eafa["length"]; _0x492735 < _0xa53eb5; _0x492735++) {
        _0x1d95c3 += "%" + ("00" + _0xc0eafa["charCodeAt"](_0x492735)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x1d95c3);
    };
    _0x4ebf["aPueNT"] = _0x3db13f, _0x4ebf["TfKqRZ"] = {}, _0x4ebf["OizMWG"] = !![];
  }
  var _0x3df218 = _0x25e22d[0], _0x30c2d3 = _0x1ffc46 + _0x3df218, _0x59b78a = _0x4ebf["TfKqRZ"][_0x30c2d3];
  return !_0x59b78a ? (_0x4ebf18 = _0x4ebf["aPueNT"](_0x4ebf18), _0x4ebf["TfKqRZ"][_0x30c2d3] = _0x4ebf18) : _0x4ebf18 = _0x59b78a, _0x4ebf18;
}
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
