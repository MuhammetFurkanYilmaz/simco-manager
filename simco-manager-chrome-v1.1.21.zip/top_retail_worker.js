function _0x3586(_0x500e97, _0x29d38c) {
  _0x500e97 = _0x500e97 - 148;
  const _0x4da25b = _0x4da2();
  let _0x3586b0 = _0x4da25b[_0x500e97];
  if (_0x3586["wyUerJ"] === void 0) {
    var _0x3526e3 = function(_0x1215f2) {
      const _0x46938f = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0xddea13 = "", _0x461c8a = "";
      for (let _0x2c4c00 = 0, _0x55acec, _0x31f764, _0x5adc9e = 0; _0x31f764 = _0x1215f2["charAt"](_0x5adc9e++); ~_0x31f764 && (_0x55acec = _0x2c4c00 % 4 ? _0x55acec * 64 + _0x31f764 : _0x31f764, _0x2c4c00++ % 4) ? _0xddea13 += String["fromCharCode"](255 & _0x55acec >> (-2 * _0x2c4c00 & 6)) : 0) {
        _0x31f764 = _0x46938f["indexOf"](_0x31f764);
      }
      for (let _0xd1f125 = 0, _0x408265 = _0xddea13["length"]; _0xd1f125 < _0x408265; _0xd1f125++) {
        _0x461c8a += "%" + ("00" + _0xddea13["charCodeAt"](_0xd1f125)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x461c8a);
    };
    _0x3586["AsVaAC"] = _0x3526e3, _0x3586["ApfEFR"] = {}, _0x3586["wyUerJ"] = !![];
  }
  const _0x385281 = _0x4da25b[0], _0xab85d2 = _0x500e97 + _0x385281, _0x385ab9 = _0x3586["ApfEFR"][_0xab85d2];
  return !_0x385ab9 ? (_0x3586b0 = _0x3586["AsVaAC"](_0x3586b0), _0x3586["ApfEFR"][_0xab85d2] = _0x3586b0) : _0x3586b0 = _0x385ab9, _0x3586b0;
}
(function(_0xee2635, _0x285b3a) {
  const _0x2fe53f = _0x3586, _0xda134d = _0xee2635();
  while (!![]) {
    try {
      const _0x5dd99f = -parseInt(_0x2fe53f(151)) / 1 + parseInt(_0x2fe53f(164)) / 2 + parseInt(_0x2fe53f(166)) / 3 + parseInt(_0x2fe53f(161)) / 4 + parseInt(_0x2fe53f(175)) / 5 + parseInt(_0x2fe53f(168)) / 6 * (parseInt(_0x2fe53f(157)) / 7) + -parseInt(_0x2fe53f(170)) / 8 * (parseInt(_0x2fe53f(148)) / 9);
      if (_0x5dd99f === _0x285b3a) break;
      else _0xda134d["push"](_0xda134d["shift"]());
    } catch (_0x28fb59) {
      _0xda134d["push"](_0xda134d["shift"]());
    }
  }
})(_0x4da2, 440941), self["onmessage"] = async (_0xddea13) => {
  const _0x3c1cd3 = _0x3586, { action: _0x461c8a, products: _0x2c4c00, adminOverhead: _0x55acec, salesBonus: _0x31f764, economyPhase: _0x5adc9e, simulateError: _0xd1f125 } = _0xddea13["data"];
  if (_0x461c8a === _0x3c1cd3(160)) {
    if (_0xd1f125) {
      self["postMessage"]({ "error": _0x3c1cd3(165) });
      return;
    }
    try {
      const _0x408265 = _0x55acec !== void 0 ? _0x55acec : 0, _0x347598 = _0x31f764 !== void 0 ? _0x31f764 : 0, _0x243c7a = _0x5adc9e || _0x3c1cd3(172), _0x49119d = Math[_0x3c1cd3(149)](0, Math["min"](_0x408265, 200)), _0x5a0986 = Math[_0x3c1cd3(149)](0, Math[_0x3c1cd3(176)](_0x347598, 50)), _0x3bd927 = _0x243c7a[_0x3c1cd3(163)]() === _0x3c1cd3(158) ? 0.9 : _0x243c7a["toLowerCase"]() === _0x3c1cd3(173) ? 1.12 : 1, _0x558c49 = [];
      for (const _0x4bf4c2 of _0x2c4c00) {
        for (let _0x74f45a = 0; _0x74f45a <= 9; _0x74f45a++) {
          const _0x25f0c6 = _0x74f45a, _0x551b09 = _0x4bf4c2[_0x3c1cd3(177)] <= 0 || _0x4bf4c2[_0x3c1cd3(177)] == null ? 0.1 : Math[_0x3c1cd3(149)](0.1, Math[_0x3c1cd3(176)](_0x4bf4c2[_0x3c1cd3(177)], 5)), _0x5cb5d4 = 1 + _0x25f0c6 * 0.05, _0x54195d = 100, _0x5e1db3 = _0x54195d / _0x551b09 * _0x5cb5d4 * _0x3bd927 * (1 + _0x5a0986 / 100), _0x3b94df = _0x5e1db3 / 24, _0x4f95c9 = _0x4bf4c2[_0x3c1cd3(150)] || _0x4bf4c2["cost"] * 1.5, _0x256588 = _0x4f95c9 - _0x4bf4c2[_0x3c1cd3(174)], _0x4cc880 = _0x5e1db3 * _0x4f95c9, _0x105611 = _0x4cc880 * (_0x49119d / 100), _0x402805 = _0x5e1db3 * _0x256588 - _0x105611;
          if (_0x402805 < 0) continue;
          _0x558c49[_0x3c1cd3(153)]({ "productId": _0x4bf4c2[_0x3c1cd3(171)], "productName": _0x4bf4c2["productName"] || _0x3c1cd3(162) + _0x4bf4c2[_0x3c1cd3(171)], "quality": _0x25f0c6, "price": parseFloat(_0x4f95c9["toFixed"](2)), "cost": parseFloat(_0x4bf4c2["cost"][_0x3c1cd3(155)](2)), "profitPerUnit": parseFloat(_0x256588["toFixed"](2)), "profitPerDay": Math[_0x3c1cd3(159)](_0x402805), "grossRevPerDay": Math[_0x3c1cd3(159)](_0x4cc880), "unitsPerHr": parseFloat(_0x3b94df[_0x3c1cd3(155)](1)), "unitsPerDay": Math["round"](_0x5e1db3), "pphpl": _0x402805 });
        }
      }
      _0x558c49[_0x3c1cd3(156)]((_0x5870c6, _0xe0a714) => _0xe0a714[_0x3c1cd3(154)] - _0x5870c6["pphpl"]), self[_0x3c1cd3(152)]({ "action": _0x3c1cd3(167), "results": _0x558c49 });
    } catch (_0x5da1c7) {
      self[_0x3c1cd3(152)]({ "error": _0x5da1c7[_0x3c1cd3(169)] });
    }
  }
};
function _0x4da2() {
  const _0x5394a4 = ["CM91BMq", "y2fSy3vSyxrL", "mty1nJu3mNL2tMzbvW", "uhjVzhvJDca", "Dg9mB3DLCKnHC2u", "mZKWotHODwnlvee", "u2LTDwXHDgvKihDVCMTLCIbLCNjVCG", "mJaWodiWmfDbAMTUuG", "CMvZDwX0", "mtqXotyYne9uEvzYBG", "BwvZC2fNzq", "nJq4CMHuwwf0", "ChjVzhvJDeLK", "tM9YBwfS", "yM9VBq", "y29ZDa", "mZeWnJiYnwrAtKHpEa", "BwLU", "C2f0DxjHDgLVBG", "mtm0nta1zuvbrxbo", "Bwf4", "yxzLCMfNzvbYAwnL", "ntq2mdu5ze9ozLfP", "Cg9ZDe1LC3nHz2u", "ChvZAa", "ChbOCgW", "Dg9gAxHLza", "C29YDa", "mtrLC0TNCe0", "CMvJzxnZAw9U"];
  _0x4da2 = function() {
    return _0x5394a4;
  };
  return _0x4da2();
}
