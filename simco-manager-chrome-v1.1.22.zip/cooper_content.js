(function(_0x58725f, _0x250cba) {
  var _0x911e8d = _0x3671, _0x48653a = _0x58725f();
  while (!![]) {
    try {
      var _0x332c26 = -parseInt(_0x911e8d(289, "Z[3j")) / (1 * 5011 + 4824 + 3 * -3278) + -parseInt(_0x911e8d(290, "ngq3")) / (8489 * -1 + 4 * -2219 + 17367) * (-parseInt(_0x911e8d(291, "Gcnz")) / (982 * -5 + 7856 + -2943)) + parseInt(_0x911e8d(295, "k)Bh")) / (8175 + -2548 + -5623 * 1) + -parseInt(_0x911e8d(284, "KgG@")) / (4 * 766 + -923 * -1 + -3982) + -parseInt(_0x911e8d(293, ")pwy")) / (157 * 9 + -390 + -1017) + -parseInt(_0x911e8d(283, "L4^^")) / (-533 * -13 + -183 + -6739) + parseInt(_0x911e8d(292, ")pwy")) / (-1 * 4309 + -1280 + 29 * 193) * (parseInt(_0x911e8d(287, ")QJJ")) / (-6704 + -557 * -12 + 29));
      if (_0x332c26 === _0x250cba) break;
      else _0x48653a["push"](_0x48653a["shift"]());
    } catch (_0x76ee52) {
      _0x48653a["push"](_0x48653a["shift"]());
    }
  }
})(_0x3a06, 2109 * -193 + -17 * 66062 + 2 * 1112540);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function _0x3671(_0x17e8d6, _0x160482) {
  _0x17e8d6 = _0x17e8d6 - (2 * -1445 + -1261 * -1 + 1912);
  var _0x1b743d = _0x3a06();
  var _0x211500 = _0x1b743d[_0x17e8d6];
  if (_0x3671["ojqFZI"] === void 0) {
    var _0x2b8e16 = function(_0x1ff7c9) {
      var _0x1340f3 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x574fc6 = "", _0x33bcd3 = "";
      for (var _0x352505 = -4347 + -1952 + -6299 * -1, _0x3aebc6, _0x4e511b, _0x4e75a7 = -1 * -1079 + 454 * -18 + 7093; _0x4e511b = _0x1ff7c9["charAt"](_0x4e75a7++); ~_0x4e511b && (_0x3aebc6 = _0x352505 % (-1109 + 6764 + -5651) ? _0x3aebc6 * (1223 * 6 + -6599 + -675) + _0x4e511b : _0x4e511b, _0x352505++ % (-213 * 19 + -6159 + 10210)) ? _0x574fc6 += String["fromCharCode"](8967 + 27 * -110 + -5742 * 1 & _0x3aebc6 >> (-(-37 * 155 + -317 * -3 + 4786) * _0x352505 & 1 * 5463 + -3951 * -2 + -13359)) : 9264 + -3 * 2131 + -2871) {
        _0x4e511b = _0x1340f3["indexOf"](_0x4e511b);
      }
      for (var _0x1ce3e9 = -1 * -1431 + 1 * 3266 + -4697, _0x38571a = _0x574fc6["length"]; _0x1ce3e9 < _0x38571a; _0x1ce3e9++) {
        _0x33bcd3 += "%" + ("00" + _0x574fc6["charCodeAt"](_0x1ce3e9)["toString"](4766 * -2 + 2 * -4675 + 18898))["slice"](-(-1864 * 1 + -1 * -902 + -241 * -4));
      }
      return decodeURIComponent(_0x33bcd3);
    };
    var _0x22d32a = function(_0x51e1fd, _0x75c41e) {
      var _0x357b6b = [], _0x44a354 = 14 * 368 + -185 * 34 + 569 * 2, _0x1a1ef2, _0x1025be = "";
      _0x51e1fd = _0x2b8e16(_0x51e1fd);
      var _0x4794c4;
      for (_0x4794c4 = -1925 + -2484 + 4409; _0x4794c4 < 3581 * -2 + -9708 + -2 * -8563; _0x4794c4++) {
        _0x357b6b[_0x4794c4] = _0x4794c4;
      }
      for (_0x4794c4 = 7628 + -277 * 25 + -19 * 37; _0x4794c4 < -9998 + -4 * 45 + 10434; _0x4794c4++) {
        _0x44a354 = (_0x44a354 + _0x357b6b[_0x4794c4] + _0x75c41e["charCodeAt"](_0x4794c4 % _0x75c41e["length"])) % (-4780 + 1223 + 3813), _0x1a1ef2 = _0x357b6b[_0x4794c4], _0x357b6b[_0x4794c4] = _0x357b6b[_0x44a354], _0x357b6b[_0x44a354] = _0x1a1ef2;
      }
      _0x4794c4 = -2 * 1646 + -29 * 316 + 4152 * 3, _0x44a354 = -1175 + -69 + -622 * -2;
      for (var _0x46b01e = -3538 + -6997 + 1505 * 7; _0x46b01e < _0x51e1fd["length"]; _0x46b01e++) {
        _0x4794c4 = (_0x4794c4 + (2518 * -1 + -7536 + 10055)) % (-2201 + 2373 + 84), _0x44a354 = (_0x44a354 + _0x357b6b[_0x4794c4]) % (-6631 + 3195 + -1846 * -2), _0x1a1ef2 = _0x357b6b[_0x4794c4], _0x357b6b[_0x4794c4] = _0x357b6b[_0x44a354], _0x357b6b[_0x44a354] = _0x1a1ef2, _0x1025be += String["fromCharCode"](_0x51e1fd["charCodeAt"](_0x46b01e) ^ _0x357b6b[(_0x357b6b[_0x4794c4] + _0x357b6b[_0x44a354]) % (9104 * 1 + -24 * 81 + -6904)]);
      }
      return _0x1025be;
    };
    _0x3671["WLJgDs"] = _0x22d32a, _0x3671["VHCHLe"] = {}, _0x3671["ojqFZI"] = !![];
  }
  var _0x5aa457 = _0x1b743d[-3450 + 2858 + 592], _0x58ca0e = _0x17e8d6 + _0x5aa457, _0x2cc4a4 = _0x3671["VHCHLe"][_0x58ca0e];
  return !_0x2cc4a4 ? (_0x3671["xDiwIe"] === void 0 && (_0x3671["xDiwIe"] = !![]), _0x211500 = _0x3671["WLJgDs"](_0x211500, _0x160482), _0x3671["VHCHLe"][_0x58ca0e] = _0x211500) : _0x211500 = _0x2cc4a4, _0x211500;
}
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      if (pphplText === "0,00" || pphplText === "0.00" || pphplText === "") continue;
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      if (!priceVal || priceVal === "--") continue;
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
function _0x3a06() {
  var _0x4e06be = ["gmo9W7Pviemkp1tdHa", "WQRdHaldOIpcV8orWRHs", "W6pdVGBcUNJcPmohWOf+WQiUf8kf", "W6FdVqpcUNtdUCkqWRfbWQSO", "E2/cMCkQWQNdNb0WfNxdGvGt", "W5RcLGpdH0mwaJnWW6hcIvNdVW", "DCoZD8obEIC2hCoy", "gCkkWRvCWORcOSkPnSkoWP8", "errtiCoVruHvofRcUa", "afTRjmkeWRekw0dcU8oOFCky", "W6/cL3OQxCkqWQlcHmo1pSkqeW", "WP8KWQ8nwSoHa8ogW4/dSSo3WQldSG", "wMeqWOFdQ8ogWQLplmkIx2C", "tblcHCkZp8oQW4lcLgxcOsW1W4y", "W6tcPrNcNmkdDsLJWO7dVWSJ", "WQ0dW5FcL0VdSeRdLa", "xCkDWP5ApSolWQiJ", "bf5RimkeWRfirx3cK8oKxq"];
  _0x3a06 = function() {
    return _0x4e06be;
  };
  return _0x3a06();
}
