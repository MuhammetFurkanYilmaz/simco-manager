const _0x50b2e0 = _0x35cd;
function _0x4e63() {
  const _0x4c112e = ["z1JcPCkvhSoHAaxcT1JcMehdSW", "FmooWQRcK23dQYCtW7ddR8k3E8o4", "oSk3W75gCSkYW6FcOSoG", "k8okjJXT", "oSkvW5BdJclcUM0jW5ZdUa", "W5zDySoXiq", "pCoEDCocdCoxWQNdNMRcSmkJW7W", "m8onivRdLW", "uSolxSopWRC", "F8k0qmoVja", "WRm5iSkhtmomW4pcNrCGW7npjW", "W6ZdHmk3sx8", "jCk7W7m", "WOOzvCkHra", "d8ogldK", "D8ocW6GsiW", "trJcTW", "ymknBcddLv8CWPhcRmkx", "obBcGq", "W7uzWPlcNSoudbyd", "W6/dTvxdMtq", "tvPyASk6W7RcHSoG", "WRuxECo5", "yeJcN0VcJCkKWQnR", "W4SynW", "dJZdSLPN", "bvhcPv3cMCoBWOVcLmo6", "omknftldRq", "krVdJmoSrW", "eCoHW4FcSmoE", "vZzbmda", "nSonfXv/", "zeNdMcZdJmoLWPX1iSk1WOhdTW", "rCkHo8oGW5vuW6a3dW", "jColW4VcQ8oG", "W5uhlXRdIW", "W4RdGvtdJ8o8", "vCkYyCodemktWOBdLSofWOa", "uYNcRbhcKG", "WOZdQw/cL3BcSgldHG", "W4ldMuxdPCosWQ9mtmoTbG", "eSoYtf3dSSkpDSk8rMW", "W5FdGgBdVSolWQ1n", "W7BdGmkFqKDk", "WQldLmkOWONcRG", "WRxcOXZcJejkv8kKW7JcV8kXnga", "euNdULVdHbZcNcKoaIj4WRO", "xSkBBhNdLmoirCoNW6/dVIG", "r3emW6BcGG", "fSkqvmoAumo0WQVdKmooWPa", "CWmAW5RdTmodghlcMq", "mmompeddJa", "r1/dGa1DjYJcR8oX", "p1agbIRdLXG1W6S", "hsldOhPz", "W6ldTv/dIa", "WPVcJ3CbW5FdSmodW77cGmklFq", "EmoiWQlcKI/cSwC/W77dPq", "uHBcUGBcLq", "WPhcJNebW5hdTSo8W6NcG8kdtq", "Dmk0ECoyga", "WORdTGNdVtFdRNy2ySkZ", "WPqskG8zsstdHCkgWRddLW", "y8kijeldL0aVWOi", "W4JcOmkkrSov", "DSk7l8kSEmk8FG", "zmoqumoa", "eXBcVNZcSG", "cZ3dJxXi", "pmoyCSolaCoBW5FdLNBcOSkHW6uS", "xqVcQmo6", "DSkPy8oscCkrWOBdVCoaW40", "sHbMjbu", "tmokW5XLf0JcGudcICkqq8ke", "jCouW5dcR8obw1VcVmovW4y", "z3CyW5NcGW", "j8oEW5dcRSoGsG", "W5G0W73cPW0", "W6RdIw7dPSoG", "uSkHdXhcTmowrmkeEhtdIWa", "DSk0F8ocmCkxWOhdGmoaW4C", "fKZcUu0", "vbBcIqhcIuZdGq", "ESkBbCkmvW", "WRzdWPJcVSoKme8TpSkR", "aCoijW", "wGVcLSoHamkCiHPWDa", "veZdGWPDkd3cKSoW", "WQvRWQFcT8oY", "DSoktmof", "W40EkIddKa", "geBcUuRcJCoFWPO", "qgG8W7BcQW1X"];
  _0x4e63 = function() {
    return _0x4c112e;
  };
  return _0x4e63();
}
function _0x35cd(_0x435cac, _0x2af2a4) {
  _0x435cac = _0x435cac - (3 * -645 + -3 * 97 + 271 * 9);
  const _0x3d6175 = _0x4e63();
  let _0x48b9c5 = _0x3d6175[_0x435cac];
  if (_0x35cd["BgYFLH"] === void 0) {
    var _0x4338b0 = function(_0x25fb02) {
      const _0x5ecdaf = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x3a0d98 = "", _0xee029f = "";
      for (let _0x4e36c6 = -1 * 6139 + 6386 + -247, _0x753e6a, _0x3bccdf, _0x5e5ec7 = 4265 * -1 + 318 + 1 * 3947; _0x3bccdf = _0x25fb02["charAt"](_0x5e5ec7++); ~_0x3bccdf && (_0x753e6a = _0x4e36c6 % (471 * -9 + -438 + 4681) ? _0x753e6a * (802 + -4733 + 3995) + _0x3bccdf : _0x3bccdf, _0x4e36c6++ % (2 * 1129 + -4041 + -1 * -1787)) ? _0x3a0d98 += String["fromCharCode"](7143 + 122 * -34 + -685 * 4 & _0x753e6a >> (-(8887 + 1116 + -10001) * _0x4e36c6 & 8303 + 6042 * 1 + 14339 * -1)) : -1 * 8669 + -5999 + -7334 * -2) {
        _0x3bccdf = _0x5ecdaf["indexOf"](_0x3bccdf);
      }
      for (let _0x23c0f8 = 7 * -1003 + -12 * 394 + 11749 * 1, _0x2fd101 = _0x3a0d98["length"]; _0x23c0f8 < _0x2fd101; _0x23c0f8++) {
        _0xee029f += "%" + ("00" + _0x3a0d98["charCodeAt"](_0x23c0f8)["toString"](-1 * 2273 + 58 * 31 + 491))["slice"](-(4 * -51 + 13 * -281 + 3859));
      }
      return decodeURIComponent(_0xee029f);
    };
    const _0x210b9e = function(_0x327083, _0x385307) {
      let _0xbb827 = [], _0x5d0e0e = -723 + 657 * 2 + -591, _0xdaafa8, _0x53cb90 = "";
      _0x327083 = _0x4338b0(_0x327083);
      let _0x238267;
      for (_0x238267 = -1 * 5591 + -7648 + 3 * 4413; _0x238267 < -1 * 1646 + 242 * -36 + 10614; _0x238267++) {
        _0xbb827[_0x238267] = _0x238267;
      }
      for (_0x238267 = 872 + 932 * 1 + -1804; _0x238267 < -7997 + -2715 + 10968; _0x238267++) {
        _0x5d0e0e = (_0x5d0e0e + _0xbb827[_0x238267] + _0x385307["charCodeAt"](_0x238267 % _0x385307["length"])) % (-1 * -6301 + -9801 + -2 * -1878), _0xdaafa8 = _0xbb827[_0x238267], _0xbb827[_0x238267] = _0xbb827[_0x5d0e0e], _0xbb827[_0x5d0e0e] = _0xdaafa8;
      }
      _0x238267 = -4149 + -709 + 4858, _0x5d0e0e = 9082 + 5737 + -14819;
      for (let _0x19c221 = -9011 + 4946 + 4065; _0x19c221 < _0x327083["length"]; _0x19c221++) {
        _0x238267 = (_0x238267 + (-4871 + -4518 + 10 * 939)) % (5243 + 8173 + -13160), _0x5d0e0e = (_0x5d0e0e + _0xbb827[_0x238267]) % (-8669 * 1 + 2335 + 6590), _0xdaafa8 = _0xbb827[_0x238267], _0xbb827[_0x238267] = _0xbb827[_0x5d0e0e], _0xbb827[_0x5d0e0e] = _0xdaafa8, _0x53cb90 += String["fromCharCode"](_0x327083["charCodeAt"](_0x19c221) ^ _0xbb827[(_0xbb827[_0x238267] + _0xbb827[_0x5d0e0e]) % (-2246 * -1 + -2980 + 990)]);
      }
      return _0x53cb90;
    };
    _0x35cd["bJEFzt"] = _0x210b9e, _0x35cd["lJvxWo"] = {}, _0x35cd["BgYFLH"] = !![];
  }
  const _0x3974c2 = _0x3d6175[-9432 + 8639 + 793], _0x4f4a25 = _0x435cac + _0x3974c2, _0x2a0f71 = _0x35cd["lJvxWo"][_0x4f4a25];
  return !_0x2a0f71 ? (_0x35cd["ohTqxY"] === void 0 && (_0x35cd["ohTqxY"] = !![]), _0x48b9c5 = _0x35cd["bJEFzt"](_0x48b9c5, _0x2af2a4), _0x35cd["lJvxWo"][_0x4f4a25] = _0x48b9c5) : _0x48b9c5 = _0x2a0f71, _0x48b9c5;
}
(function(_0x1c80d7, _0x1d5e09) {
  const _0x499015 = _0x35cd, _0x4b59f4 = _0x1c80d7();
  while (!![]) {
    try {
      const _0x9a2d61 = parseInt(_0x499015(281, "wvx!")) / (2572 + 5414 + -7985) + parseInt(_0x499015(291, "s1u)")) / (-8701 * 1 + 1518 + 7185) * (parseInt(_0x499015(298, "]e0u")) / (222 * -32 + -8837 + 15944)) + -parseInt(_0x499015(236, "VQZX")) / (-26 * 323 + -11 * 706 + -2021 * -8) + parseInt(_0x499015(274, "rrbQ")) / (2 * 2872 + -218 * -37 + -13805) * (-parseInt(_0x499015(241, "9wnp")) / (2 * 4813 + 81 * -3 + 9377 * -1)) + parseInt(_0x499015(280, "(go5")) / (-12 * 785 + -2 * 4603 + 18633 * 1) + -parseInt(_0x499015(288, "TKlp")) / (9561 + -7601 + -1952) * (-parseInt(_0x499015(215, "mHTR")) / (5595 + -2 * -4546 + -82 * 179)) + -parseInt(_0x499015(282, "@c$a")) / (-197 * -48 + 3283 * -1 + 6163 * -1) * (parseInt(_0x499015(252, "]e0u")) / (5245 + -7317 + 2083));
      if (_0x9a2d61 === _0x1d5e09) break;
      else _0x4b59f4["push"](_0x4b59f4["shift"]());
    } catch (_0x58a4e) {
      _0x4b59f4["push"](_0x4b59f4["shift"]());
    }
  }
})(_0x4e63, -1053713 * -1 + -439 * 2157 + -2192 * -220), self[_0x50b2e0(268, "eU[b")] = async (_0x406a9c) => {
  const _0x18471f = _0x50b2e0, _0x176355 = { "FpVMy": function(_0x2dee1e, _0x15c156) {
    return _0x2dee1e === _0x15c156;
  }, "SpbFP": _0x18471f(229, "92K*"), "CqikV": _0x18471f(272, "$e1a") + _0x18471f(226, "Gz5g") + "or", "DZdkR": function(_0x77ac55, _0x2e8512) {
    return _0x77ac55 !== _0x2e8512;
  }, "dhnTD": function(_0x3c0510, _0x390672) {
    return _0x3c0510 || _0x390672;
  }, "TTuEX": _0x18471f(278, "Jgqv"), "DwVWf": _0x18471f(237, "%ags"), "ohDGv": function(_0x1a1182, _0x1f1b8f) {
    return _0x1a1182 === _0x1f1b8f;
  }, "YQqCC": _0x18471f(231, "1rl1"), "svvyQ": function(_0x51e82d, _0x1f6633) {
    return _0x51e82d <= _0x1f6633;
  }, "intXO": function(_0x355834, _0x277665) {
    return _0x355834 == _0x277665;
  }, "noyeA": function(_0x5672f1, _0x2087b6) {
    return _0x5672f1 + _0x2087b6;
  }, "dGMbs": function(_0x22d809, _0x846af3) {
    return _0x22d809 * _0x846af3;
  }, "sPcyc": function(_0x10d6c7, _0xc61c61) {
    return _0x10d6c7 * _0xc61c61;
  }, "eruKx": function(_0x2e2c42, _0x16a271) {
    return _0x2e2c42 * _0x16a271;
  }, "KFRws": function(_0x193c1a, _0x5a6038) {
    return _0x193c1a / _0x5a6038;
  }, "FiQdG": function(_0x3c1c46, _0x2511b5) {
    return _0x3c1c46 + _0x2511b5;
  }, "BEadh": function(_0x17d349, _0x2f06e6) {
    return _0x17d349 / _0x2f06e6;
  }, "fshQc": function(_0xbf2f3, _0x4c80a3) {
    return _0xbf2f3 * _0x4c80a3;
  }, "WHPYi": function(_0xca24bc, _0x4ae4ff) {
    return _0xca24bc - _0x4ae4ff;
  }, "zzYIn": function(_0x5130f4, _0x43f822) {
    return _0x5130f4 * _0x43f822;
  }, "xOlIW": function(_0x261f40, _0x4a3c8c) {
    return _0x261f40 - _0x4a3c8c;
  }, "TkZfY": function(_0x32e8ec, _0x42fc8f) {
    return _0x32e8ec * _0x42fc8f;
  }, "UnDmG": function(_0xcbf22a, _0x4b5247) {
    return _0xcbf22a < _0x4b5247;
  }, "yoLYX": function(_0x1a3276, _0x2432e1) {
    return _0x1a3276(_0x2432e1);
  }, "kosCJ": function(_0x32955f, _0x46a860) {
    return _0x32955f(_0x46a860);
  }, "IfNqS": _0x18471f(218, "M2p#") }, { action: _0x55eef9, products: _0x4cbdb8, adminOverhead: _0x525fb3, salesBonus: _0x53d139, economyPhase: _0x32e62a, simulateError: _0x46c56d } = _0x406a9c[_0x18471f(257, "6*5A")];
  if (_0x176355[_0x18471f(260, "dj5e")](_0x55eef9, _0x176355[_0x18471f(217, "3Xjk")])) {
    if (_0x46c56d) {
      self[_0x18471f(222, "$e1a") + "e"]({ "error": _0x176355[_0x18471f(303, "dj5e")] });
      return;
    }
    try {
      const _0xc71e53 = _0x525fb3 !== void 0 ? _0x525fb3 : -4564 + -7434 + -5999 * -2, _0x36c780 = _0x176355[_0x18471f(264, "M2p#")](_0x53d139, void 0) ? _0x53d139 : 4712 * -1 + -318 * -1 + 4394, _0x2e96b2 = _0x176355[_0x18471f(219, "p0)q")](_0x32e62a, _0x176355[_0x18471f(240, "*ZmV")]), _0x285e68 = Math[_0x18471f(251, "wvx!")](39 * 22 + -1204 * 1 + 346, Math[_0x18471f(247, "%ags")](_0xc71e53, 6775 + -3533 * -1 + -38 * 266)), _0x210fde = Math[_0x18471f(251, "wvx!")](1 * 8881 + -9700 + 91 * 9, Math[_0x18471f(259, "Ed4n")](_0x36c780, 9523 + -2151 + -1046 * 7)), _0x2fcc06 = _0x2e96b2[_0x18471f(228, "K#S@") + "e"]() === _0x176355[_0x18471f(214, "TKlp")] ? 3906 + -5 * 1880 + 5494 + 0.9 : _0x176355[_0x18471f(238, "r^qG")](_0x2e96b2[_0x18471f(239, "VQZX") + "e"](), _0x176355[_0x18471f(265, "TKlp")]) ? 58 * -137 + -5774 + 1 * 13721 + 0.1200000000000001 : 1 * -5722 + -4001 * 1 + 1 * 9724, _0x1ea7c3 = [];
      for (const _0x56c052 of _0x4cbdb8) {
        for (let _0x22a93e = 2126 + -2227 * -1 + -4353; _0x176355[_0x18471f(283, "3Xjk")](_0x22a93e, -2 * -4610 + 1422 + -10633); _0x22a93e++) {
          const _0x59a4c1 = _0x22a93e, _0x5b4205 = _0x176355[_0x18471f(270, "Ed4n")](_0x56c052[_0x18471f(276, "VeJ!")], -8830 + -3 * -723 + 6661) || _0x176355[_0x18471f(271, "AWa6")](_0x56c052[_0x18471f(296, "L5##")], null) ? -299 * -13 + -5321 + 1434 + 0.1 : Math[_0x18471f(227, "@c$a")](-445 * 8 + 38 * -235 + 12490 + 0.1, Math[_0x18471f(253, "oR]B")](_0x56c052[_0x18471f(284, "vgqD")], 739 * 3 + 3 * -3134 + 7190)), _0x3421c6 = _0x176355[_0x18471f(255, "(go5")](5157 + -17 * -370 + -5723 * 2, _0x59a4c1 * (-2897 + 4065 + -1168 + 0.05)), _0xdef344 = 7803 * 1 + 4 * -303 + -6491, _0x4b9b4b = _0x176355[_0x18471f(230, "Gz5g")](_0x176355[_0x18471f(273, "wvx!")](_0x176355[_0x18471f(242, "]e0u")](_0x176355[_0x18471f(243, "AvRU")](_0xdef344, _0x5b4205), _0x3421c6), _0x2fcc06), _0x176355[_0x18471f(302, "oR]B")](159 * -19 + -2 * -386 + 250 * 9, _0x176355[_0x18471f(262, "S)BD")](_0x210fde, -1349 * 1 + -3 * -349 + -201 * -2))), _0x5bc6d0 = _0x176355[_0x18471f(248, "dbKZ")](_0x4b9b4b, 7672 + -2593 + 5 * -1011), _0x1915a4 = _0x56c052[_0x18471f(275, "AWa6") + "ce"] || _0x176355[_0x18471f(286, "]e0u")](_0x56c052[_0x18471f(249, "@c$a")], -119 * -44 + 1 * 8563 + -13798 * 1 + 0.5), _0x20230f = _0x176355[_0x18471f(299, "zh3T")](_0x1915a4, _0x56c052[_0x18471f(223, "zEmr")]), _0x148e68 = _0x176355[_0x18471f(263, "pXFe")](_0x4b9b4b, _0x1915a4), _0x3baaa2 = _0x148e68 * (_0x285e68 / (-5981 * -1 + 38 * 4 + -6033)), _0x371a9d = _0x176355[_0x18471f(225, "p0Nm")](_0x176355[_0x18471f(246, "Jgqv")](_0x4b9b4b, _0x20230f), _0x3baaa2);
          if (_0x176355[_0x18471f(289, "dj5e")](_0x371a9d, -6362 + -7615 * 1 + 13977)) continue;
          _0x1ea7c3[_0x18471f(301, "1rl1")]({ "productId": _0x56c052[_0x18471f(287, "92K*")], "productName": _0x56c052[_0x18471f(213, "$e1a") + "e"] || _0x18471f(256, "%t1I") + _0x56c052[_0x18471f(261, "zEmr")], "quality": _0x59a4c1, "price": _0x176355[_0x18471f(279, "]^1!")](parseFloat, _0x1915a4[_0x18471f(224, "wvx!")](697 * -9 + 7324 + -1049)), "cost": _0x176355[_0x18471f(232, "Ed4n")](parseFloat, _0x56c052[_0x18471f(290, "(go5")][_0x18471f(277, "AWa6")](2336 + -6914 + 4580)), "profitPerUnit": parseFloat(_0x20230f[_0x18471f(234, "3Xjk")](567 + -5716 + 5151)), "profitPerDay": Math[_0x18471f(295, "$e1a")](_0x371a9d), "grossRevPerDay": Math[_0x18471f(266, "r^qG")](_0x148e68), "unitsPerHr": _0x176355[_0x18471f(244, "$e1a")](parseFloat, _0x5bc6d0[_0x18471f(300, "p0Nm")](204 * -6 + -1 * 5464 + 6689)), "unitsPerDay": Math[_0x18471f(293, "wvx!")](_0x4b9b4b), "pphpl": _0x371a9d });
        }
      }
      _0x1ea7c3[_0x18471f(305, "K#S@")]((_0x4639a6, _0x5857f8) => _0x5857f8[_0x18471f(250, "m[9N")] - _0x4639a6[_0x18471f(269, "M2p#")]), self[_0x18471f(216, "M2p#") + "e"]({ "action": _0x176355[_0x18471f(220, "AWa6")], "results": _0x1ea7c3 });
    } catch (_0xb33044) {
      self[_0x18471f(216, "M2p#") + "e"]({ "error": _0xb33044[_0x18471f(233, "zEmr")] });
    }
  }
};
