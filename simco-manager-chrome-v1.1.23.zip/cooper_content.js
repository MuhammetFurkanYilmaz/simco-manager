function _0x2c83(_0x334e43, _0x63a3b3) {
  _0x334e43 = _0x334e43 - (-3 * 1672 + 2 * -1773 + 8808);
  var _0x5ea001 = _0x556e();
  var _0x2bbfd5 = _0x5ea001[_0x334e43];
  if (_0x2c83["QZxtMj"] === void 0) {
    var _0x4c3eed = function(_0x179a4a) {
      var _0x32b1aa = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x1b6541 = "", _0x58ece2 = "";
      for (var _0x2eee6d = -1 * 3991 + 7790 + -3799, _0x1d39fd, _0x5befb0, _0x26f367 = 1 * 5989 + -3735 + -2254 * 1; _0x5befb0 = _0x179a4a["charAt"](_0x26f367++); ~_0x5befb0 && (_0x1d39fd = _0x2eee6d % (1212 + 83 * -55 + -1119 * -3) ? _0x1d39fd * (-5763 + -4 * -1699 + -969) + _0x5befb0 : _0x5befb0, _0x2eee6d++ % (4551 * -2 + 9789 + 683 * -1)) ? _0x1b6541 += String["fromCharCode"](253 + -2231 + -2233 * -1 & _0x1d39fd >> (-(8472 * -1 + -1 * 9055 + -5843 * -3) * _0x2eee6d & -6191 + -7744 + 3 * 4647)) : -427 * 6 + -9215 + -1 * -11777) {
        _0x5befb0 = _0x32b1aa["indexOf"](_0x5befb0);
      }
      for (var _0x318557 = -2700 + 362 * -8 + 5596, _0xbacf24 = _0x1b6541["length"]; _0x318557 < _0xbacf24; _0x318557++) {
        _0x58ece2 += "%" + ("00" + _0x1b6541["charCodeAt"](_0x318557)["toString"](-7807 * 1 + -9658 + 17481))["slice"](-(134 * 65 + 1043 + 199 * -49));
      }
      return decodeURIComponent(_0x58ece2);
    };
    var _0x4b9941 = function(_0xd58f4, _0x567055) {
      var _0x6d243e = [], _0x2407e0 = 956 * -6 + 4 * -1681 + -1246 * -10, _0x4265e2, _0x303a9b = "";
      _0xd58f4 = _0x4c3eed(_0xd58f4);
      var _0x5a4102;
      for (_0x5a4102 = 2627 + 1160 + -3787; _0x5a4102 < -3 * 1755 + -6533 + -574 * -21; _0x5a4102++) {
        _0x6d243e[_0x5a4102] = _0x5a4102;
      }
      for (_0x5a4102 = 212 * 13 + 4410 + 3583 * -2; _0x5a4102 < -254 * 2 + -2 * -2011 + -3258; _0x5a4102++) {
        _0x2407e0 = (_0x2407e0 + _0x6d243e[_0x5a4102] + _0x567055["charCodeAt"](_0x5a4102 % _0x567055["length"])) % (2806 + 3 * 1762 + -4 * 1959), _0x4265e2 = _0x6d243e[_0x5a4102], _0x6d243e[_0x5a4102] = _0x6d243e[_0x2407e0], _0x6d243e[_0x2407e0] = _0x4265e2;
      }
      _0x5a4102 = 4 * -166 + -4847 + -11 * -501, _0x2407e0 = -16 * 551 + -48 * -128 + 8 * 334;
      for (var _0x8fb0a4 = -62 * 66 + -3514 + -3803 * -2; _0x8fb0a4 < _0xd58f4["length"]; _0x8fb0a4++) {
        _0x5a4102 = (_0x5a4102 + (-406 + -21 * -38 + -1 * 391)) % (-3 * -631 + 1231 * -7 + -698 * -10), _0x2407e0 = (_0x2407e0 + _0x6d243e[_0x5a4102]) % (-7753 + 3625 + 4384), _0x4265e2 = _0x6d243e[_0x5a4102], _0x6d243e[_0x5a4102] = _0x6d243e[_0x2407e0], _0x6d243e[_0x2407e0] = _0x4265e2, _0x303a9b += String["fromCharCode"](_0xd58f4["charCodeAt"](_0x8fb0a4) ^ _0x6d243e[(_0x6d243e[_0x5a4102] + _0x6d243e[_0x2407e0]) % (-7105 + 2 * 2633 + -2095 * -1)]);
      }
      return _0x303a9b;
    };
    _0x2c83["PSNBEi"] = _0x4b9941, _0x2c83["epKLan"] = {}, _0x2c83["QZxtMj"] = !![];
  }
  var _0x4c07cb = _0x5ea001[3011 + 2803 * 1 + -1938 * 3], _0x23a4ca = _0x334e43 + _0x4c07cb, _0x204a66 = _0x2c83["epKLan"][_0x23a4ca];
  return !_0x204a66 ? (_0x2c83["UaALPk"] === void 0 && (_0x2c83["UaALPk"] = !![]), _0x2bbfd5 = _0x2c83["PSNBEi"](_0x2bbfd5, _0x63a3b3), _0x2c83["epKLan"][_0x23a4ca] = _0x2bbfd5) : _0x2bbfd5 = _0x204a66, _0x2bbfd5;
}
(function(_0x3d3cd3, _0x57c725) {
  var _0x4d9eb7 = _0x2c83, _0x13896c = _0x3d3cd3();
  while (!![]) {
    try {
      var _0x4965ed = parseInt(_0x4d9eb7(249, "gho$")) / (-2555 + 431 * 17 + 1 * -4771) * (parseInt(_0x4d9eb7(251, "f(BR")) / (1 * 1979 + -2710 + 733)) + -parseInt(_0x4d9eb7(262, "B$yb")) / (-6185 * 1 + 52 * -118 + -3 * -4108) + parseInt(_0x4d9eb7(248, "SFhW")) / (5 * 641 + 9759 * -1 + -3 * -2186) + -parseInt(_0x4d9eb7(256, "iuCN")) / (-9002 * 1 + -167 * -38 + 2661) * (parseInt(_0x4d9eb7(253, "ijz2")) / (1 * 4937 + 3870 + -8801 * 1)) + -parseInt(_0x4d9eb7(263, "ijz2")) / (-297 * 28 + 1471 + 6852) * (-parseInt(_0x4d9eb7(258, ")7S&")) / (-8848 + 4498 + -1 * -4358)) + -parseInt(_0x4d9eb7(267, "8sdk")) / (-2729 + -9436 + -6 * -2029) * (parseInt(_0x4d9eb7(250, "gkpz")) / (-1948 * -2 + 2239 * -1 + -1647)) + parseInt(_0x4d9eb7(261, "iuCN")) / (6667 + 3 * 3102 + -694 * 23);
      if (_0x4965ed === _0x57c725) break;
      else _0x13896c["push"](_0x13896c["shift"]());
    } catch (_0x56e82c) {
      _0x13896c["push"](_0x13896c["shift"]());
    }
  }
})(_0x556e, 982034 + 130852 * 6 + -868348);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x556e() {
  var _0x1920de = ["eX4Mq8kLW6/dO8oHWRhcMSktWQxdRmoz", "W4pdVvvbCmo6WO4wECowWP3dVCo1", "WRtdJCkuq8kRjColWQm", "eXHBgmoAWOFcVmke", "W7ZdMImdWRmaWO3dO300amkwWPm", "tSkne3ddSSo1WR9mnKC", "WPNdRHbprq7dQG", "W6umWPFcLmk2C8obWRbAWPD7jq", "W6jGW7ZcLehcJCka", "dHZdSqJdMw7dNCoUWO/dLLvr", "WPZdHXxcPCkcjmopcsSvkq", "s8kEW7tcGCk7WODQW5xcHSkeW44dW4m", "wCo7BmohASk8WQFdICo7", "nItcGSoxsK/cGXOrWPxcOYLtAq", "WRddJCoUgmkRpCoaWRFcQ8o2", "t8kEW7VcHSocW7y3W7pcGSkt", "WO7dPX5GAmovbxug", "gHKHqCoRWPxcSmkOWOFcVq", "W4HfkNpcJCoCxeZdPmkrWOK", "i07cUSkKW4JcOLtcG8ozv8oXWOJdJa", "WOddPvdcJgq5hCkYu8omWPhcN8kL", "vSoHWP/cVrdcGSorW7RcLmo8W7G/WPK"];
  _0x556e = function() {
    return _0x1920de;
  };
  return _0x556e();
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
