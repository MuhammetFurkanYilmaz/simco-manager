function _0x1178() {
  const _0x54f105 = ["csn6BmkiWR5lWOS", "W7vcwJnZWRRdN1G2W6u", "xYtcIuiJ", "WRajWROQWRJcGchcKbPT", "W7vvW4udWP/cIdxcGWm", "W7vsW4zWW7RdKwBcNG1MW6xcKxu", "WQ7dHCobpwtdUX3cMNmTWP3cNq", "W4VcKhrEW4hdGW", "W6T1w8kzE05bW7PJxSoJCYK", "W4ZcTSoswW", "vuywdCoA", "WPvDhCk4", "kh9CvCoO", "kN9At8obkdtdVCkqrW", "bhDpW55R", "WOFcMhmjqG", "W5PBtsXZWRe", "WQJdOCknxaG", "WQjrk8k5jq", "ctz3C8kNWQOXWQuvWQBdSmo5ja", "saZcL2JcM8k+WQiQW58", "FCkDWQ4", "WRtcU8obWQ7cOq", "WRH6sW", "WR5ajmo+W7/dJNC", "WO4QWOuseSo9WQWk", "A2ZcVmo7WRi", "WP3dRmkthSkOCW3cK8ocWOPolCk+", "e1BdJtJdMmo/W7ebW7ihcuLD", "gmkBWQBcUCkl", "W5zLWPDzW4FcQ3n0vvi", "jbCLWR3dMq", "WPXKrIxdSXlcRW", "tCk9ESouW68", "W57cOmo+sSkQ", "u8k4W64qW60", "W4BcTqxcPG", "Cx5wW7HCW4lcVa4ZovCdW4qs", "xI/cJxtcGG", "WQ7dL8oxWR5A", "W5RcQCkVsI08W4KYW6qd", "w8k5ECow", "W5BcNmo3W7LY", "Eu7cI8ofWPJdSSko", "emouc8kj", "tmkyaZBdSq", "yedcTq", "W4PkWQSxba", "oXZcTq", "i11EqSoM", "WQfMW6q", "WOtdQWHZjG", "lCoXsM4C", "WQFdVmovW6DEW7dcKSkW", "WQedd3z1WOxdNh0tW6C", "rhbiW4BcOCkeywyvW5LAgSkl", "xmkjbtZdHq", "WO4QW5bSsCkIW5b2hfj9aSk4ta", "W67cMSkgyJi", "WQj8v8o6W4bsW5VdPCoQka", "W6pcUgX4W7K", "WQ9ig8oqW5m", "W5hcPxveW7S", "bZCyWOxdUa", "W4fRWRDvW4xcOMbduq", "WP/dSCoScqCbW5W0W5ip", "WRdcPSo9WQRcMq", "WP7dPCk4wrBcU8oFW5SXkq", "sxeXbCo6", "dCoaaa", "W7SFamoqW6xdHfJcOW", "ySkqW4GNW5a", "lCoMxuWdyeJcRZS", "WQvJtCoHW4K", "W6hcPCowW5HAW63cJSkZWRddHG", "mHtcR8oM", "WQtcPSoAWOq", "EmkKzmogW77dSNv2", "WQvHsSo1W5bdWO/dJSo5nW", "W4/cLJ8+WRpdSSo0EmonWO5SWPms", "z8kyW4GtW4S", "W4tcNCoWWPJcOvaNW7DsW5q", "WOz6smoKW4LbWO/dPCo8EG", "nSonyeNcLfXyydtdUCkbWPC", "mSoMtvOrDeq", "WRHGW4WPW4r9W7y", "BIqEdSk8F3xdGSk5uaVcMqe", "qmk1zSoSW60", "WO4PW5qtimo/WOevcG", "wSkhW7ynW7iOgmkSWQO", "wCkuW60CW7uQgmkmWQhdSG", "b8kiWRJcMCkpWRddK3VdGG"];
  _0x1178 = function() {
    return _0x54f105;
  };
  return _0x1178();
}
function _0x5c6d(_0x1d7d85, _0x35d6a7) {
  _0x1d7d85 = _0x1d7d85 - (-4152 + 4567 * -1 + 835 * 11);
  const _0x1e75fe = _0x1178();
  let _0x545dc0 = _0x1e75fe[_0x1d7d85];
  if (_0x5c6d["eAdWXy"] === void 0) {
    var _0x25ee6b = function(_0x4534b5) {
      const _0x50f208 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x4b86a5 = "", _0x54b8cd = "";
      for (let _0x3e5b04 = 1252 + 6721 + -469 * 17, _0x462463, _0x27518f, _0x1608a0 = 3117 * -1 + -3699 + 6816; _0x27518f = _0x4534b5["charAt"](_0x1608a0++); ~_0x27518f && (_0x462463 = _0x3e5b04 % (-2 * 1046 + -216 * 13 + 4904) ? _0x462463 * (-107 * 17 + 4933 + -1 * 3050) + _0x27518f : _0x27518f, _0x3e5b04++ % (4772 + -1412 + -3356)) ? _0x4b86a5 += String["fromCharCode"](-11 * -428 + -6980 + 2527 * 1 & _0x462463 >> (-(6949 + -6 * 1513 + 1 * 2131) * _0x3e5b04 & -9060 + -1111 * -9 + -3 * 311)) : 8705 + 6780 + -15485) {
        _0x27518f = _0x50f208["indexOf"](_0x27518f);
      }
      for (let _0x163572 = -8501 + -3 * 137 + 8912, _0x1d1459 = _0x4b86a5["length"]; _0x163572 < _0x1d1459; _0x163572++) {
        _0x54b8cd += "%" + ("00" + _0x4b86a5["charCodeAt"](_0x163572)["toString"](-430 + -39 * -41 + -1153))["slice"](-(3310 + -3866 + 558));
      }
      return decodeURIComponent(_0x54b8cd);
    };
    const _0x6ae5d4 = function(_0x228ce9, _0x2fc5a6) {
      let _0x5dfeb7 = [], _0x5d397f = -14 * 1 + 1706 + -1692, _0x6d0711, _0x5449b2 = "";
      _0x228ce9 = _0x25ee6b(_0x228ce9);
      let _0x902648;
      for (_0x902648 = 6 * -508 + 3637 * -1 + -1337 * -5; _0x902648 < -3625 + -9506 + 13387; _0x902648++) {
        _0x5dfeb7[_0x902648] = _0x902648;
      }
      for (_0x902648 = 1735 + 2628 + -4363; _0x902648 < 5311 * 1 + -1 * 8010 + 2955; _0x902648++) {
        _0x5d397f = (_0x5d397f + _0x5dfeb7[_0x902648] + _0x2fc5a6["charCodeAt"](_0x902648 % _0x2fc5a6["length"])) % (4801 * -1 + -928 * -2 + 3201), _0x6d0711 = _0x5dfeb7[_0x902648], _0x5dfeb7[_0x902648] = _0x5dfeb7[_0x5d397f], _0x5dfeb7[_0x5d397f] = _0x6d0711;
      }
      _0x902648 = 5693 + 4830 + -10523 * 1, _0x5d397f = 1661 + 2208 * -1 + 547 * 1;
      for (let _0xc86742 = 9800 + 6628 + -111 * 148; _0xc86742 < _0x228ce9["length"]; _0xc86742++) {
        _0x902648 = (_0x902648 + (-5446 + -3 * 2633 + -2 * -6673)) % (-1693 * 2 + 863 * -3 + -31 * -201), _0x5d397f = (_0x5d397f + _0x5dfeb7[_0x902648]) % (34 * -14 + 4585 + 1 * -3853), _0x6d0711 = _0x5dfeb7[_0x902648], _0x5dfeb7[_0x902648] = _0x5dfeb7[_0x5d397f], _0x5dfeb7[_0x5d397f] = _0x6d0711, _0x5449b2 += String["fromCharCode"](_0x228ce9["charCodeAt"](_0xc86742) ^ _0x5dfeb7[(_0x5dfeb7[_0x902648] + _0x5dfeb7[_0x5d397f]) % (611 + -1 * 2489 + 2134)]);
      }
      return _0x5449b2;
    };
    _0x5c6d["TaGaKz"] = _0x6ae5d4, _0x5c6d["DhYnNl"] = {}, _0x5c6d["eAdWXy"] = !![];
  }
  const _0x134185 = _0x1e75fe[2 * 1436 + -11 * -71 + -3653], _0x1bf58a = _0x1d7d85 + _0x134185, _0x50069e = _0x5c6d["DhYnNl"][_0x1bf58a];
  return !_0x50069e ? (_0x5c6d["NoecrS"] === void 0 && (_0x5c6d["NoecrS"] = !![]), _0x545dc0 = _0x5c6d["TaGaKz"](_0x545dc0, _0x35d6a7), _0x5c6d["DhYnNl"][_0x1bf58a] = _0x545dc0) : _0x545dc0 = _0x50069e, _0x545dc0;
}
const _0x3afe13 = _0x5c6d;
(function(_0x40cfaf, _0xcf4b6f) {
  const _0x4918b1 = _0x5c6d, _0x16331e = _0x40cfaf();
  while (!![]) {
    try {
      const _0x25fc3f = parseInt(_0x4918b1(536, "SMOz")) / (17 * 101 + 2317 + -4033) * (-parseInt(_0x4918b1(549, "$IzF")) / (1451 * -3 + -1801 + 6156)) + parseInt(_0x4918b1(504, "7^N@")) / (1 * 5849 + 4485 + -10331) + -parseInt(_0x4918b1(515, "@VB6")) / (94 * 94 + 9 * -233 + 1 * -6735) + parseInt(_0x4918b1(483, "@wNA")) / (-2393 + 6112 + 1 * -3714) + -parseInt(_0x4918b1(490, "(sXN")) / (-3380 + 4322 + -936) + parseInt(_0x4918b1(500, "#XUt")) / (-20 * 14 + 2 * 2253 + 4219 * -1) * (-parseInt(_0x4918b1(487, "k8WB")) / (-467 * 1 + -4221 + 4696)) + parseInt(_0x4918b1(533, "C)m%")) / (513 + -659 * 3 + 3 * 491) * (parseInt(_0x4918b1(474, "cI)6")) / (-2588 + 383 * -4 + 4130));
      if (_0x25fc3f === _0xcf4b6f) break;
      else _0x16331e["push"](_0x16331e["shift"]());
    } catch (_0xa98e5d) {
      _0x16331e["push"](_0x16331e["shift"]());
    }
  }
})(_0x1178, 245544 + 11 * 2698 + -1 * -105401), self[_0x3afe13(516, "rT*#")] = async (_0xc3e99a) => {
  const _0x5980d8 = _0x3afe13, _0x432ecb = { "yMwyj": function(_0x4f79e6, _0x7eb29d) {
    return _0x4f79e6 === _0x7eb29d;
  }, "hProV": _0x5980d8(468, "fe)8"), "XtWDc": function(_0x4f174d, _0x562757) {
    return _0x4f174d !== _0x562757;
  }, "fMqWR": function(_0x137280, _0x3635be) {
    return _0x137280 !== _0x3635be;
  }, "dywWt": function(_0x486207, _0x6eb36b) {
    return _0x486207 || _0x6eb36b;
  }, "EeApl": _0x5980d8(512, "DZ4v"), "GVRUe": _0x5980d8(476, "WN*K"), "hcmNf": _0x5980d8(480, "7sEd"), "nESOL": function(_0x34c225, _0x2cd56b) {
    return _0x34c225 <= _0x2cd56b;
  }, "TcEur": function(_0x4762d8, _0xcfae1c) {
    return _0x4762d8 == _0xcfae1c;
  }, "Nolfo": function(_0x1813a0, _0x26a16a) {
    return _0x1813a0 + _0x26a16a;
  }, "rrtGl": function(_0x136bd4, _0x4ef614) {
    return _0x136bd4 * _0x4ef614;
  }, "uPLBt": function(_0x1ef0d4, _0x270088) {
    return _0x1ef0d4 * _0x270088;
  }, "voHCT": function(_0x2bfcbd, _0x4dbbbb) {
    return _0x2bfcbd / _0x4dbbbb;
  }, "oaqDq": function(_0x1b8c71, _0x1db4c3) {
    return _0x1b8c71 + _0x1db4c3;
  }, "SPUHM": function(_0x4f6cfd, _0x2fc3e0) {
    return _0x4f6cfd / _0x2fc3e0;
  }, "egyGT": function(_0x2b919c, _0x206e37) {
    return _0x2b919c * _0x206e37;
  }, "MmQzL": function(_0x2d7ffd, _0x109dde) {
    return _0x2d7ffd - _0x109dde;
  }, "ZMkST": function(_0x1bcac4, _0x4eed94) {
    return _0x1bcac4 < _0x4eed94;
  }, "HeQNW": function(_0x2041c9, _0x5ea026) {
    return _0x2041c9(_0x5ea026);
  }, "ekqvd": _0x5980d8(503, "wU2B") }, { action: _0x199c62, products: _0x9e7bd6, adminOverhead: _0x16823e, salesBonus: _0x4378a8, economyPhase: _0x5eafe3, simulateError: _0x341405 } = _0xc3e99a[_0x5980d8(479, "v^GR")];
  if (_0x432ecb[_0x5980d8(531, "JTv)")](_0x199c62, _0x432ecb[_0x5980d8(466, "wU2B")])) {
    if (_0x341405) {
      self[_0x5980d8(509, "(sXN") + "e"]({ "error": _0x5980d8(486, "hhEt") + _0x5980d8(555, "hhEt") + "or" });
      return;
    }
    try {
      const _0x1e2404 = _0x432ecb[_0x5980d8(552, "k8WB")](_0x16823e, void 0) ? _0x16823e : 2861 + 9281 * -1 + 6420, _0x687a9b = _0x432ecb[_0x5980d8(522, "OFVU")](_0x4378a8, void 0) ? _0x4378a8 : 2594 * 2 + 6005 + -1 * 11193, _0x3e1aaa = _0x432ecb[_0x5980d8(547, "q#!y")](_0x5eafe3, _0x432ecb[_0x5980d8(513, "Xsbe")]), _0x445c13 = Math[_0x5980d8(473, "cZet")](6287 + 993 * 5 + -2 * 5626, Math[_0x5980d8(546, "u22Z")](_0x1e2404, -329 * 1 + -9391 * 1 + 40 * 248)), _0x3e94db = Math[_0x5980d8(542, "OFVU")](-5 * -435 + 6859 + -9034, Math[_0x5980d8(544, "v^GR")](_0x687a9b, 276 * -15 + -1453 + -171 * -33)), _0x57925b = _0x432ecb[_0x5980d8(534, "rT*#")](_0x3e1aaa[_0x5980d8(526, "fe)8") + "e"](), _0x432ecb[_0x5980d8(538, "$IzF")]) ? 263 * -1 + 3017 * 1 + 9 * -306 + 0.9 : _0x432ecb[_0x5980d8(545, "(sXN")](_0x3e1aaa[_0x5980d8(499, "#XUt") + "e"](), _0x432ecb[_0x5980d8(491, "6^RS")]) ? 4252 + 1060 + -47 * 113 + 0.1200000000000001 : -6667 + 4322 + 2346, _0x5bf72e = [];
      for (const _0xdb0aaa of _0x9e7bd6) {
        for (let _0x8b5821 = -284 * -5 + 3 * 2456 + -8788; _0x432ecb[_0x5980d8(506, "@VB6")](_0x8b5821, -31 * 97 + -5068 + 8084); _0x8b5821++) {
          const _0x14da82 = _0x8b5821, _0x1e6600 = _0xdb0aaa[_0x5980d8(494, "JTv)")] <= 8 * 964 + 1 * -5753 + -1959 || _0x432ecb[_0x5980d8(514, "Ixei")](_0xdb0aaa[_0x5980d8(485, "z^K]")], null) ? 1099 * 7 + 7701 * 1 + -15394 * 1 + 0.1 : Math[_0x5980d8(517, "xVVM")](1 * -1714 + 8867 + -7153 + 0.1, Math[_0x5980d8(519, "hhEt")](_0xdb0aaa[_0x5980d8(471, "Xsbe")], 8974 + -193 * 50 + 681 * 1)), _0x5d35ea = _0x432ecb[_0x5980d8(511, "]bO9")](5679 * 1 + -6401 * 1 + 723, _0x432ecb[_0x5980d8(518, "7sEd")](_0x14da82, 9581 * 1 + 8280 + -17861 + 0.05)), _0x45c714 = -320 * -17 + -6675 + -5 * -267, _0x398747 = _0x432ecb[_0x5980d8(472, "@VB6")](_0x432ecb[_0x5980d8(543, "%K@f")](_0x432ecb[_0x5980d8(470, "7sEd")](_0x45c714, _0x1e6600), _0x5d35ea), _0x57925b) * _0x432ecb[_0x5980d8(525, "4TZf")](6660 + -3524 * 1 + 1045 * -3, _0x432ecb[_0x5980d8(510, "KF4E")](_0x3e94db, 367 * 17 + -2 * -4457 + 1 * -15053)), _0x454f15 = _0x432ecb[_0x5980d8(527, "eVT[")](_0x398747, 366 + 8704 + -9046), _0x2f8822 = _0xdb0aaa[_0x5980d8(497, "DZ4v") + "ce"] || _0x432ecb[_0x5980d8(548, "WN*K")](_0xdb0aaa[_0x5980d8(505, "1(bz")], -7 * 995 + -187 * -17 + 541 * 7 + 0.5), _0x5530c4 = _0x2f8822 - _0xdb0aaa[_0x5980d8(532, "xfMv")], _0xdeb0dd = _0x398747 * _0x2f8822, _0x560528 = _0x432ecb[_0x5980d8(557, "cI)6")](_0xdeb0dd, _0x432ecb[_0x5980d8(498, "SB1e")](_0x445c13, -3618 + -3290 + 7008)), _0x319f05 = _0x432ecb[_0x5980d8(484, "JTv)")](_0x398747 * _0x5530c4, _0x560528);
          if (_0x432ecb[_0x5980d8(556, "wU2B")](_0x319f05, 9311 * 1 + 4796 + -14107)) continue;
          _0x5bf72e[_0x5980d8(540, "cZet")]({ "productId": _0xdb0aaa[_0x5980d8(493, "JTv)")], "productName": _0xdb0aaa[_0x5980d8(482, "hhEt") + "e"] || _0x5980d8(481, "6^RS") + _0xdb0aaa[_0x5980d8(495, "4TZf")], "quality": _0x14da82, "price": _0x432ecb[_0x5980d8(541, "k8WB")](parseFloat, _0x2f8822[_0x5980d8(489, "u22Z")](37 * -167 + -9977 + 16158 * 1)), "cost": _0x432ecb[_0x5980d8(535, "(Z4*")](parseFloat, _0xdb0aaa[_0x5980d8(507, "Ixei")][_0x5980d8(528, "xn(D")](8 * 983 + -2053 * -1 + -9915)), "profitPerUnit": _0x432ecb[_0x5980d8(475, "JTv)")](parseFloat, _0x5530c4[_0x5980d8(520, "cI)6")](-4977 + 4742 + 237)), "profitPerDay": Math[_0x5980d8(508, "(sXN")](_0x319f05), "grossRevPerDay": Math[_0x5980d8(554, "EVfJ")](_0xdeb0dd), "unitsPerHr": parseFloat(_0x454f15[_0x5980d8(539, "OFVU")](3312 + -5137 + 1826)), "unitsPerDay": Math[_0x5980d8(530, "^v^T")](_0x398747), "pphpl": _0x319f05 });
        }
      }
      _0x5bf72e[_0x5980d8(537, "6^RS")]((_0xdd9cf5, _0x2cdfeb) => _0x2cdfeb[_0x5980d8(477, "hhEt")] - _0xdd9cf5[_0x5980d8(467, "eVT[")]), self[_0x5980d8(469, "SMOz") + "e"]({ "action": _0x432ecb[_0x5980d8(529, "6^RS")], "results": _0x5bf72e });
    } catch (_0x3f7608) {
      self[_0x5980d8(478, "$IzF") + "e"]({ "error": _0x3f7608[_0x5980d8(488, "WN*K")] });
    }
  }
};
