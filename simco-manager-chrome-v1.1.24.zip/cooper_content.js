function _0x29b7(_0x522fa6, _0x4f46fa) {
  _0x522fa6 = _0x522fa6 - (2978 + 4127 + -1 * 6871);
  var _0x428ceb = _0x7969();
  var _0x41d227 = _0x428ceb[_0x522fa6];
  if (_0x29b7["uIPfMi"] === void 0) {
    var _0x4d57e4 = function(_0x5a9a07) {
      var _0x4d108e = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x4cdff8 = "", _0x54e693 = "";
      for (var _0xc7ba01 = -2891 + -5405 * 1 + -34 * -244, _0x3d3085, _0x4d1051, _0x1e1604 = -2800 + -2455 * 1 + 5255; _0x4d1051 = _0x5a9a07["charAt"](_0x1e1604++); ~_0x4d1051 && (_0x3d3085 = _0xc7ba01 % (3052 + -8533 + 5485) ? _0x3d3085 * (4024 + -358 * -21 + -11478) + _0x4d1051 : _0x4d1051, _0xc7ba01++ % (4897 + 1 * 5323 + -2554 * 4)) ? _0x4cdff8 += String["fromCharCode"](2 * -724 + -7 * 1097 + 9382 & _0x3d3085 >> (-(3 * -3198 + 1421 + 2725 * 3) * _0xc7ba01 & -4894 + -4592 + 9492)) : 1 * -7283 + 1 * -4014 + 11297) {
        _0x4d1051 = _0x4d108e["indexOf"](_0x4d1051);
      }
      for (var _0x4ce623 = -8350 + 3 * -3111 + -1 * -17683, _0x3baf0b = _0x4cdff8["length"]; _0x4ce623 < _0x3baf0b; _0x4ce623++) {
        _0x54e693 += "%" + ("00" + _0x4cdff8["charCodeAt"](_0x4ce623)["toString"](-6505 + 3780 + 2741 * 1))["slice"](-(-6836 + 8578 + -60 * 29));
      }
      return decodeURIComponent(_0x54e693);
    };
    var _0x1252cb = function(_0x5c286b, _0x281711) {
      var _0x234d4f = [], _0x50bd43 = -4357 + 1 * -6067 + 10424, _0x1c3de8, _0x1561aa = "";
      _0x5c286b = _0x4d57e4(_0x5c286b);
      var _0x3fc8b6;
      for (_0x3fc8b6 = -9250 + 4630 + -220 * -21; _0x3fc8b6 < 2349 + 81 * -37 + 904; _0x3fc8b6++) {
        _0x234d4f[_0x3fc8b6] = _0x3fc8b6;
      }
      for (_0x3fc8b6 = -4693 * -1 + 847 + -5540; _0x3fc8b6 < -1 * 9124 + 7 * 1117 + -1561 * -1; _0x3fc8b6++) {
        _0x50bd43 = (_0x50bd43 + _0x234d4f[_0x3fc8b6] + _0x281711["charCodeAt"](_0x3fc8b6 % _0x281711["length"])) % (2860 + -5196 + 2592), _0x1c3de8 = _0x234d4f[_0x3fc8b6], _0x234d4f[_0x3fc8b6] = _0x234d4f[_0x50bd43], _0x234d4f[_0x50bd43] = _0x1c3de8;
      }
      _0x3fc8b6 = 227 * 31 + -2 * 3951 + -1 * -865, _0x50bd43 = -9286 + -9439 + -2675 * -7;
      for (var _0x120f90 = -10 * 698 + -685 * 10 + 1 * 13830; _0x120f90 < _0x5c286b["length"]; _0x120f90++) {
        _0x3fc8b6 = (_0x3fc8b6 + (-2769 + -1535 + 4305)) % (20 * 248 + 9950 + 34 * -431), _0x50bd43 = (_0x50bd43 + _0x234d4f[_0x3fc8b6]) % (-401 + 8162 + -7505), _0x1c3de8 = _0x234d4f[_0x3fc8b6], _0x234d4f[_0x3fc8b6] = _0x234d4f[_0x50bd43], _0x234d4f[_0x50bd43] = _0x1c3de8, _0x1561aa += String["fromCharCode"](_0x5c286b["charCodeAt"](_0x120f90) ^ _0x234d4f[(_0x234d4f[_0x3fc8b6] + _0x234d4f[_0x50bd43]) % (1 * -268 + -51 * 43 + -247 * -11)]);
      }
      return _0x1561aa;
    };
    _0x29b7["opgSGx"] = _0x1252cb, _0x29b7["vrdQKJ"] = {}, _0x29b7["uIPfMi"] = !![];
  }
  var _0x3f50b0 = _0x428ceb[-914 * 7 + -406 * 16 + 12894], _0x2695d8 = _0x522fa6 + _0x3f50b0, _0x3b3f3c = _0x29b7["vrdQKJ"][_0x2695d8];
  return !_0x3b3f3c ? (_0x29b7["NfbECZ"] === void 0 && (_0x29b7["NfbECZ"] = !![]), _0x41d227 = _0x29b7["opgSGx"](_0x41d227, _0x4f46fa), _0x29b7["vrdQKJ"][_0x2695d8] = _0x41d227) : _0x41d227 = _0x3b3f3c, _0x41d227;
}
(function(_0x20300c, _0x6c6ad9) {
  var _0x2186e2 = _0x29b7, _0x32cc3e = _0x20300c();
  while (!![]) {
    try {
      var _0x1d1bce = parseInt(_0x2186e2(239, "96yb")) / (-9662 + -1 * -8158 + 1505) * (-parseInt(_0x2186e2(247, "gA^B")) / (1 * -2701 + -137 * 52 + 9827 * 1)) + parseInt(_0x2186e2(253, "1pd@")) / (-8751 + -167 * -41 + -1907 * -1) + parseInt(_0x2186e2(241, "@z(I")) / (-226 * 2 + 8360 + -416 * 19) * (parseInt(_0x2186e2(234, "SC1[")) / (4316 + -2 * 2413 + 515)) + -parseInt(_0x2186e2(255, "yy]k")) / (-8291 * -1 + -55 * -28 + 3275 * -3) * (-parseInt(_0x2186e2(243, "6T2q")) / (-1207 * -5 + -1988 + 2 * -2020)) + parseInt(_0x2186e2(244, "x1Tf")) / (7336 + 9970 + -17298) + -parseInt(_0x2186e2(251, "OiwN")) / (-3779 + -55 * 149 + 11983) * (parseInt(_0x2186e2(237, "p@z*")) / (-715 + -5328 + -1 * -6053)) + -parseInt(_0x2186e2(236, "qb1[")) / (944 + 1 * 6381 + -318 * 23);
      if (_0x1d1bce === _0x6c6ad9) break;
      else _0x32cc3e["push"](_0x32cc3e["shift"]());
    } catch (_0x4f3d64) {
      _0x32cc3e["push"](_0x32cc3e["shift"]());
    }
  }
})(_0x7969, -1 * -671642 + 290162 + -302713);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x7969() {
  var _0x3f351c = ["W4xdGu5gpGFdJu5RCeu", "W5pcNuqnygVcKCkl", "i3BcRMTmgCkkyXfSWQe", "WOncW4hdJSoDA8oGWOnwW7ddSmkKWPW", "iCkGe8k3W6lcRvVdUsnOW7pdLCoUW7S", "krBcKCkTAcVcQ8kXW7hdO8oG", "W43dTrtdNeSID8oAWQq", "WOb1qhNdKu7cKgBdJLW", "mCoVdMxcHCoXsKO", "W6rXWOdcU8ovd8otWPKS", "W5BdLbTOumkUWQ9ZWQ5iWRS7iW", "W45JWRpdI8oHWPjkxqNcRSkcst4", "WPRcNX0PwSoOW7FcJSkAW4xdGv1Q", "ed4eFYzEC8ovWPBcHW", "W4iYyb3dUmo0WOVcUCkSWQW2W7NcTW", "W43cLqnjW4pdJHBdK1K", "etmlEWjnxCo4WOdcKa", "WRZcHa0aw2PzWOzVW6HxW7DjWP8", "W5FcNYG5w0pcLCkkaW", "m8owWQVdHGxcRCoeC8k3WPu", "WQtdH8ocpxSHWOVdUSosC8oU", "tG7cMCkRWQpdQxNdNCkroWBdJ18"];
  _0x7969 = function() {
    return _0x3f351c;
  };
  return _0x7969();
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
