function _0x4307() {
  const _0x32dba7 = ["kWddUCo0WRa", "WRThWP5o", "W5DDthvtW6FcPmkmWO8CW6ddHKW", "WRZdSI5uW7jjy8o/B8kWW7vGFW", "cCkxWRFdPSoA", "WOdcMrZcG1r4yCo7ka", "W7uqwSk+", "lSk/WQJcTdCbW5TDW7O", "WP5mquhcLfGHESoC", "FqufW5BdJa", "W6NcPCkYb1G", "W4PDsCoGWOFcKSk1WQBcHa", "W6iqzCkLW6CWhCkuWPldRa", "dCofDM3dHIG", "W7GxW43dVSoisCo/eGNdR0y", "W7hcSCoaWPpcKZDV", "W6FcGmkiha", "WObPbe8", "lNxcV0ddL8kbWP3dPXhdOa", "pGtdOY0j", "oCoXW7qeumo1WRKVtJS", "W7KFWOJcJSktzSoqmG", "sY3cGCoUW44", "lxVcUehdQmkfWPRdVr/dQq", "gX7dOImYW71FWQyxWQa", "WO5Vgq", "WQLOW4BdKaj0WRxdSde", "W7pcRIpdSq", "W5qpcCkOWOu", "cSkLx8oWhJxdOXxcVJddJHhcNq", "WOzYWO0", "WQTNW5m", "WOztevFcIG", "gX7dQcu9W71j", "W5pcLCoXW588", "wxJdUMNdGa", "BJX4pCkl", "W7SDW5GkjmkGWR7cUh4OWQXZWPFcSG", "WQnogSo4WQDHxmkHWQFdHCoSxmoa", "WPidddmPWRBdPmkjWROH", "W7JdLZ3cTSoNDuyJ", "s8oSdSkWra", "WQ9khmo8WQjNw8kTWRddImozrCoO", "lGPvF0K", "q8ooh8kesW", "sh7dKvVdLG", "W7nQW6C1", "wmoViCkhqq", "WRZcQSkxE3W", "rdycWPHp", "WQDgemo6WQzMxmksWQddJCoUCmom", "m8kkWQFdR8oV", "bKXyW6eRySk6WPXYC2e", "W75HCSklWQq", "mCofCw7dGW", "E8k2WQTtfCkUW70cBqqvWQtdIq", "cmo5W4NdL8ocWRqTWO/dICkc", "g8oQW5/dKmopWQC", "b0fzW6KVjSooW4f2BujYnGq", "DSkNWR7dVa", "yHTOeSkE", "WR8gpSo5W7vFWQJdLWpcRZBcRSkZ", "wYvPlCkxnmkSDdhdGa", "W7pcK8ktgx46fmogWOa", "W7ZcOdq", "EKBcJSkaW6LIWQFcUrtcQmoJWO/cOW", "WQ8IomokWQC", "W47dHMNcUh0", "WPencZiwWRldO8ktWRqO", "WQFdUwqFqmk+jG", "WRtdP8kYW4ZdMwSZzJRdQZnxWO4", "W5dcJmoEWQRcIq", "iCoWW71uWRO", "W6pdKumrWR00W6tdIG", "W5vAzSk6WQSmW6JdIctdMa", "W5dcJmkEWOhdQW", "pSoSW6KlqmoKW60exsq", "vmogW6q", "WP0sxYBcPa", "lSodAG", "WRvNW5/dGanMWQddVJVcIG", "W6Wyjmk/WRS", "rHeoWRXVzmkwWP9q", "hCoGW6RdJmoBWRyS"];
  _0x4307 = function() {
    return _0x32dba7;
  };
  return _0x4307();
}
const _0x3c4fec = _0x1674;
function _0x1674(_0x586e44, _0x512424) {
  _0x586e44 = _0x586e44 - (-45 * -32 + -1 * -131 + 3 * -488);
  const _0x47854b = _0x4307();
  let _0x4821de = _0x47854b[_0x586e44];
  if (_0x1674["PazMhd"] === void 0) {
    var _0x2c8bfd = function(_0xbc060d) {
      const _0x13c18f = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0xa489c7 = "", _0x4cd350 = "";
      for (let _0x2408b9 = 769 * 5 + 7338 + -11183, _0x3352d4, _0x519186, _0x529ba1 = -8825 + 1 * 6652 + 41 * 53; _0x519186 = _0xbc060d["charAt"](_0x529ba1++); ~_0x519186 && (_0x3352d4 = _0x2408b9 % (2695 + -1 * -2245 + -4 * 1234) ? _0x3352d4 * (134 * -51 + -7591 + 14489) + _0x519186 : _0x519186, _0x2408b9++ % (301 + -1 * -3466 + -71 * 53)) ? _0xa489c7 += String["fromCharCode"](-1 * -6616 + -838 * 1 + -7 * 789 & _0x3352d4 >> (-(-4003 * 1 + 6337 * 1 + -2332) * _0x2408b9 & -4637 * -1 + 416 * -24 + 53 * 101)) : 1 * 4479 + -4703 * 1 + 224) {
        _0x519186 = _0x13c18f["indexOf"](_0x519186);
      }
      for (let _0x3e0331 = 2333 * -1 + 4833 + -2500, _0x305a48 = _0xa489c7["length"]; _0x3e0331 < _0x305a48; _0x3e0331++) {
        _0x4cd350 += "%" + ("00" + _0xa489c7["charCodeAt"](_0x3e0331)["toString"](3342 + 8273 * -1 + -1 * -4947))["slice"](-(429 + -973 * 3 + 2492));
      }
      return decodeURIComponent(_0x4cd350);
    };
    const _0x33c69b = function(_0x3d71b6, _0x40ff47) {
      let _0x504011 = [], _0x115a5f = 3 * 2558 + 751 * -2 + -6172, _0x35378d, _0x48922e = "";
      _0x3d71b6 = _0x2c8bfd(_0x3d71b6);
      let _0x2f3b15;
      for (_0x2f3b15 = -2 * 3566 + 1199 + 5933; _0x2f3b15 < -2358 + 5997 + -3383 * 1; _0x2f3b15++) {
        _0x504011[_0x2f3b15] = _0x2f3b15;
      }
      for (_0x2f3b15 = 119 * -65 + -2519 + 2 * 5127; _0x2f3b15 < 2039 + 9798 + 1 * -11581; _0x2f3b15++) {
        _0x115a5f = (_0x115a5f + _0x504011[_0x2f3b15] + _0x40ff47["charCodeAt"](_0x2f3b15 % _0x40ff47["length"])) % (-110 * 75 + 327 * -27 + 17335), _0x35378d = _0x504011[_0x2f3b15], _0x504011[_0x2f3b15] = _0x504011[_0x115a5f], _0x504011[_0x115a5f] = _0x35378d;
      }
      _0x2f3b15 = 352 + 9867 + -10219, _0x115a5f = -8503 + 19 * -475 + 17528;
      for (let _0x51acaa = -3683 + 458 + 3 * 1075; _0x51acaa < _0x3d71b6["length"]; _0x51acaa++) {
        _0x2f3b15 = (_0x2f3b15 + (-1254 + -898 + -2153 * -1)) % (1752 * -1 + 3919 * -1 + 1 * 5927), _0x115a5f = (_0x115a5f + _0x504011[_0x2f3b15]) % (7910 + 211 * 22 + -12296), _0x35378d = _0x504011[_0x2f3b15], _0x504011[_0x2f3b15] = _0x504011[_0x115a5f], _0x504011[_0x115a5f] = _0x35378d, _0x48922e += String["fromCharCode"](_0x3d71b6["charCodeAt"](_0x51acaa) ^ _0x504011[(_0x504011[_0x2f3b15] + _0x504011[_0x115a5f]) % (3487 + 9346 + -1 * 12577)]);
      }
      return _0x48922e;
    };
    _0x1674["jNYfrl"] = _0x33c69b, _0x1674["hxxPyh"] = {}, _0x1674["PazMhd"] = !![];
  }
  const _0x237123 = _0x47854b[827 * 3 + 1019 * 6 + -8595], _0x118d9a = _0x586e44 + _0x237123, _0x12f357 = _0x1674["hxxPyh"][_0x118d9a];
  return !_0x12f357 ? (_0x1674["QSeCgt"] === void 0 && (_0x1674["QSeCgt"] = !![]), _0x4821de = _0x1674["jNYfrl"](_0x4821de, _0x512424), _0x1674["hxxPyh"][_0x118d9a] = _0x4821de) : _0x4821de = _0x12f357, _0x4821de;
}
(function(_0x5c6ac0, _0x4709c9) {
  const _0x4ff23d = _0x1674, _0xea1c53 = _0x5c6ac0();
  while (!![]) {
    try {
      const _0x17a03d = -parseInt(_0x4ff23d(150, "cR2X")) / (7 * -11 + -1671 + -1 * -1749) + -parseInt(_0x4ff23d(186, "zU&T")) / (-5052 + 914 * -5 + 9624) + parseInt(_0x4ff23d(173, "(eB)")) / (37 * -101 + -9565 + -4435 * -3) * (parseInt(_0x4ff23d(129, "3Yoy")) / (-8928 * -1 + -5580 + -8 * 418)) + -parseInt(_0x4ff23d(110, "PapY")) / (8567 + -1840 + -6722) * (parseInt(_0x4ff23d(124, "PpIm")) / (5933 + 8691 + -14618)) + parseInt(_0x4ff23d(159, "4uZd")) / (185 * 29 + 8829 + 1 * -14187) + parseInt(_0x4ff23d(182, "FKUW")) / (1 * 4801 + -3893 + -900) + parseInt(_0x4ff23d(158, "HQUW")) / (-771 * 11 + -8743 * 1 + 17233);
      if (_0x17a03d === _0x4709c9) break;
      else _0xea1c53["push"](_0xea1c53["shift"]());
    } catch (_0x35f1c0) {
      _0xea1c53["push"](_0xea1c53["shift"]());
    }
  }
})(_0x4307, 754743 + -1370913 * -1 + -5 * 225737), self[_0x3c4fec(147, "x]ka")] = async (_0x437b5f) => {
  const _0x229ead = _0x3c4fec, _0x5ac5ec = { "JxXyZ": _0x229ead(111, "FKUW") + _0x229ead(113, "k]fA") + "or", "xRyDc": function(_0x37c065, _0x35ad37) {
    return _0x37c065 !== _0x35ad37;
  }, "QuMaL": function(_0xd2d8b8, _0x46814c) {
    return _0xd2d8b8 || _0x46814c;
  }, "TLGLn": _0x229ead(134, "Ai!p"), "ejEYI": _0x229ead(119, "(eB)"), "eUflT": function(_0x335962, _0x5636ee) {
    return _0x335962 === _0x5636ee;
  }, "DTsbt": function(_0x323def, _0x58e0cc) {
    return _0x323def <= _0x58e0cc;
  }, "IQrKD": function(_0x1b8430, _0x17dac8) {
    return _0x1b8430 == _0x17dac8;
  }, "LmFSr": function(_0x2ba9cb, _0x1498de) {
    return _0x2ba9cb + _0x1498de;
  }, "csGGi": function(_0x87c915, _0x1cc58d) {
    return _0x87c915 * _0x1cc58d;
  }, "tjKCw": function(_0x9c0ebb, _0x18af4e) {
    return _0x9c0ebb * _0x18af4e;
  }, "vpVZG": function(_0x13e964, _0x5e9019) {
    return _0x13e964 / _0x5e9019;
  }, "MoJNf": function(_0x17f618, _0x99f81b) {
    return _0x17f618 / _0x99f81b;
  }, "URXPb": function(_0x56210c, _0x9d4613) {
    return _0x56210c - _0x9d4613;
  }, "ytjkC": function(_0x3f80a7, _0x5d72c5) {
    return _0x3f80a7 / _0x5d72c5;
  }, "jDNzS": function(_0xfba21b, _0x2a60ff) {
    return _0xfba21b(_0x2a60ff);
  }, "pBoAS": function(_0x4b7ea3, _0x30d256) {
    return _0x4b7ea3(_0x30d256);
  }, "EvbdQ": _0x229ead(178, "H!Y4") }, { action: _0x51a9aa, products: _0x34db41, adminOverhead: _0x1fcd46, salesBonus: _0x12cebb, economyPhase: _0x6b36f5, simulateError: _0xf6e7f2 } = _0x437b5f[_0x229ead(137, "zMZy")];
  if (_0x51a9aa === _0x229ead(128, "5%Gw")) {
    if (_0xf6e7f2) {
      self[_0x229ead(183, "7FFx") + "e"]({ "error": _0x5ac5ec[_0x229ead(118, "I@iI")] });
      return;
    }
    try {
      const _0x566b18 = _0x5ac5ec[_0x229ead(174, "FKUW")](_0x1fcd46, void 0) ? _0x1fcd46 : -1 * 3077 + 9314 + -81 * 77, _0x5eb593 = _0x5ac5ec[_0x229ead(165, "cR2X")](_0x12cebb, void 0) ? _0x12cebb : -8295 + -1492 + -9787 * -1, _0x26c391 = _0x5ac5ec[_0x229ead(140, "von^")](_0x6b36f5, _0x5ac5ec[_0x229ead(187, "[3ar")]), _0x427428 = Math[_0x229ead(152, "x]ka")](2442 + -238 * 1 + 1102 * -2, Math[_0x229ead(146, "xXag")](_0x566b18, 237 * 5 + -2047 + 1062)), _0x3a45ad = Math[_0x229ead(151, "yB&S")](-134 * 55 + -15 * 10 + 7520, Math[_0x229ead(114, "%)Ic")](_0x5eb593, -2999 + -56 * -51 + 193)), _0x195ef9 = _0x26c391[_0x229ead(145, "von^") + "e"]() === _0x5ac5ec[_0x229ead(164, "4*q)")] ? -23 * -157 + 25 * 251 + -9886 + 0.9 : _0x5ac5ec[_0x229ead(153, "xXag")](_0x26c391[_0x229ead(133, "4uZd") + "e"](), _0x229ead(148, "4rvN")) ? -6390 + -9559 + 2 * 7975 + 0.1200000000000001 : 3171 + -6858 + 461 * 8, _0xa06c45 = [];
      for (const _0x11e339 of _0x34db41) {
        for (let _0x2fec41 = -475 * -5 + 5752 + -8127; _0x5ac5ec[_0x229ead(109, "(NDp")](_0x2fec41, 1 * 3389 + 15 * 503 + -10925); _0x2fec41++) {
          const _0x4667ee = _0x2fec41, _0x6a9ae0 = _0x5ac5ec[_0x229ead(156, "DGl(")](_0x11e339[_0x229ead(189, "Cn6K")], -1402 * -5 + 19 * 499 + -16491 * 1) || _0x5ac5ec[_0x229ead(181, "7FFx")](_0x11e339[_0x229ead(139, "nTkh")], null) ? -5621 + 2457 + -14 * -226 + 0.1 : Math[_0x229ead(185, "4rvN")](-4145 + -2 * -3403 + -2661 + 0.1, Math[_0x229ead(116, "Ai!p")](_0x11e339[_0x229ead(117, "x]ka")], -9842 + 17 * -47 + -2 * -5323)), _0x2f1746 = _0x5ac5ec[_0x229ead(125, "*LXd")](-2840 + 8271 + 1810 * -3, _0x4667ee * (1188 + 1 * -849 + -339 + 0.05)), _0x108c60 = -5407 + -141 * -19 + -1 * -2828, _0x218390 = _0x5ac5ec[_0x229ead(168, "cR2X")](_0x5ac5ec[_0x229ead(112, "Opo4")](_0x5ac5ec[_0x229ead(121, "zU&T")](_0x5ac5ec[_0x229ead(172, "*LXd")](_0x108c60, _0x6a9ae0), _0x2f1746), _0x195ef9), -4505 + 1 * -8583 + -13089 * -1 + _0x5ac5ec[_0x229ead(130, "0tN9")](_0x3a45ad, -1 * 9175 + 2636 + 3 * 2213)), _0x2f971e = _0x218390 / (2345 * 3 + 1344 + 557 * -15), _0x29c7ea = _0x11e339[_0x229ead(177, "H!Y4") + "ce"] || _0x11e339[_0x229ead(138, "xXag")] * (4450 + 3615 + -8064 + 0.5), _0x4eb3b1 = _0x5ac5ec[_0x229ead(166, "DGl(")](_0x29c7ea, _0x11e339[_0x229ead(180, "waii")]), _0x1a5cd9 = _0x218390 * _0x29c7ea, _0x3995d8 = _0x1a5cd9 * _0x5ac5ec[_0x229ead(188, "1liR")](_0x427428, 6238 + -254 * -35 + -15028), _0x4997f7 = _0x5ac5ec[_0x229ead(108, "5DU]")](_0x5ac5ec[_0x229ead(169, "UuvF")](_0x218390, _0x4eb3b1), _0x3995d8);
          if (_0x4997f7 < -3686 + -7093 + 3 * 3593) continue;
          _0xa06c45[_0x229ead(167, "L(1A")]({ "productId": _0x11e339[_0x229ead(126, "Qz$^")], "productName": _0x11e339[_0x229ead(141, "k]fA") + "e"] || _0x229ead(161, "K^jo") + _0x11e339[_0x229ead(184, "zMZy")], "quality": _0x4667ee, "price": _0x5ac5ec[_0x229ead(131, "zMZy")](parseFloat, _0x29c7ea[_0x229ead(120, "H!Y4")](-2 * 1977 + 3 * -2486 + 11414)), "cost": _0x5ac5ec[_0x229ead(170, "(eB)")](parseFloat, _0x11e339[_0x229ead(127, "4uZd")][_0x229ead(154, "von^")](9522 + 388 * -19 + 6 * -358)), "profitPerUnit": _0x5ac5ec[_0x229ead(115, "Ay&5")](parseFloat, _0x4eb3b1[_0x229ead(136, "5DU]")](-7281 + 2965 + 4318 * 1)), "profitPerDay": Math[_0x229ead(149, "I@iI")](_0x4997f7), "grossRevPerDay": Math[_0x229ead(155, "[[Cj")](_0x1a5cd9), "unitsPerHr": parseFloat(_0x2f971e[_0x229ead(136, "5DU]")](9154 * -1 + -17 * -247 + 4956)), "unitsPerDay": Math[_0x229ead(175, "Ai!p")](_0x218390), "pphpl": _0x4997f7 });
        }
      }
      _0xa06c45[_0x229ead(122, "HQUW")]((_0x59efbb, _0xf768bf) => _0xf768bf[_0x229ead(162, "cR2X")] - _0x59efbb[_0x229ead(143, "djQ5")]), self[_0x229ead(144, "nTkh") + "e"]({ "action": _0x5ac5ec[_0x229ead(157, "7FFx")], "results": _0xa06c45 });
    } catch (_0x69969e) {
      self[_0x229ead(160, "Cn6K") + "e"]({ "error": _0x69969e[_0x229ead(190, "xI&%")] });
    }
  }
};
