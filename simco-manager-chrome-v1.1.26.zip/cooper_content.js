function _0x4587(_0x373058, _0x417830) {
  _0x373058 = _0x373058 - (41 * 71 + 133 + -2865);
  var _0x67f6d8 = _0x4e6b();
  var _0x5b469e = _0x67f6d8[_0x373058];
  if (_0x4587["GhQFOu"] === void 0) {
    var _0x5080f1 = function(_0x258d73) {
      var _0x597326 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x3c6246 = "", _0x26fd71 = "";
      for (var _0x3fa432 = -508 * 1 + -810 + 1318, _0x2233f4, _0x457054, _0x231c4d = 1 * -8735 + -26 * -155 + -5 * -941; _0x457054 = _0x258d73["charAt"](_0x231c4d++); ~_0x457054 && (_0x2233f4 = _0x3fa432 % (-1638 + -9066 + 10708) ? _0x2233f4 * (-8440 + -1943 * 1 + 1 * 10447) + _0x457054 : _0x457054, _0x3fa432++ % (6187 + 3489 * -1 + -2694)) ? _0x3c6246 += String["fromCharCode"](3432 + 2 * 2191 + 7559 * -1 & _0x2233f4 >> (-(9158 + -4562 + -4594) * _0x3fa432 & -9269 + 5669 + 3606)) : -1214 * 4 + -425 * 15 + 11231) {
        _0x457054 = _0x597326["indexOf"](_0x457054);
      }
      for (var _0x46e085 = -1 * -3229 + -399 * 5 + 1 * -1234, _0x3330ab = _0x3c6246["length"]; _0x46e085 < _0x3330ab; _0x46e085++) {
        _0x26fd71 += "%" + ("00" + _0x3c6246["charCodeAt"](_0x46e085)["toString"](-6499 + -1127 * -7 + -1374))["slice"](-(-7453 + -8107 + 15562));
      }
      return decodeURIComponent(_0x26fd71);
    };
    var _0x10c83b = function(_0x11b9e4, _0x70b2db) {
      var _0x3c497b = [], _0x6bf715 = 1409 + 6475 + -7884, _0x143622, _0x4f5350 = "";
      _0x11b9e4 = _0x5080f1(_0x11b9e4);
      var _0x55bebf;
      for (_0x55bebf = 12 * -543 + -428 + 6944; _0x55bebf < -1 * -143 + -7509 + 7622; _0x55bebf++) {
        _0x3c497b[_0x55bebf] = _0x55bebf;
      }
      for (_0x55bebf = -8379 + 1396 + -6983 * -1; _0x55bebf < -3313 * -1 + -2842 + -215; _0x55bebf++) {
        _0x6bf715 = (_0x6bf715 + _0x3c497b[_0x55bebf] + _0x70b2db["charCodeAt"](_0x55bebf % _0x70b2db["length"])) % (-4114 + -11 * -227 + -1873 * -1), _0x143622 = _0x3c497b[_0x55bebf], _0x3c497b[_0x55bebf] = _0x3c497b[_0x6bf715], _0x3c497b[_0x6bf715] = _0x143622;
      }
      _0x55bebf = -6 * -94 + 7348 + -86 * 92, _0x6bf715 = 8159 * 1 + 1963 + -10122;
      for (var _0x21cf22 = -3554 * 2 + 9055 + -1947; _0x21cf22 < _0x11b9e4["length"]; _0x21cf22++) {
        _0x55bebf = (_0x55bebf + (4438 + -282 * 13 + -771)) % (2 * -4314 + -7662 + 16546), _0x6bf715 = (_0x6bf715 + _0x3c497b[_0x55bebf]) % (7580 + 991 * -7 + -387), _0x143622 = _0x3c497b[_0x55bebf], _0x3c497b[_0x55bebf] = _0x3c497b[_0x6bf715], _0x3c497b[_0x6bf715] = _0x143622, _0x4f5350 += String["fromCharCode"](_0x11b9e4["charCodeAt"](_0x21cf22) ^ _0x3c497b[(_0x3c497b[_0x55bebf] + _0x3c497b[_0x6bf715]) % (-907 * -10 + -1 * 8337 + -1 * 477)]);
      }
      return _0x4f5350;
    };
    _0x4587["qrcjpj"] = _0x10c83b, _0x4587["TJHdht"] = {}, _0x4587["GhQFOu"] = !![];
  }
  var _0x3f08b6 = _0x67f6d8[-3539 + 1818 + 1721], _0x586f38 = _0x373058 + _0x3f08b6, _0x9d8f11 = _0x4587["TJHdht"][_0x586f38];
  return !_0x9d8f11 ? (_0x4587["TZEowj"] === void 0 && (_0x4587["TZEowj"] = !![]), _0x5b469e = _0x4587["qrcjpj"](_0x5b469e, _0x417830), _0x4587["TJHdht"][_0x586f38] = _0x5b469e) : _0x5b469e = _0x9d8f11, _0x5b469e;
}
(function(_0x1a3c3e, _0x229f8c) {
  var _0x5e2562 = _0x4587, _0x445f08 = _0x1a3c3e();
  while (!![]) {
    try {
      var _0xb9deb7 = -parseInt(_0x5e2562(180, "tVFB")) / (-64 * -63 + 5248 * 1 + -9279) + -parseInt(_0x5e2562(188, "SeMt")) / (-3886 + 1413 + -165 * -15) * (-parseInt(_0x5e2562(194, "X^)I")) / (-3649 + -2 * -554 + 2544)) + -parseInt(_0x5e2562(182, "ewHL")) / (8660 + 1129 * -4 + -4140) + parseInt(_0x5e2562(189, "$ju5")) / (-37 + 3 * 3279 + -1959 * 5) * (parseInt(_0x5e2562(192, "p)Fe")) / (-258 + -797 * -6 + -251 * 18)) + parseInt(_0x5e2562(185, "l4*)")) / (-34 * 139 + -19 * 291 + 10262 * 1) + -parseInt(_0x5e2562(191, "X^)I")) / (-263 * 21 + 3189 + 2342) + parseInt(_0x5e2562(195, "$ju5")) / (5790 + 26 * 381 + -15687) * (parseInt(_0x5e2562(193, "5mLA")) / (-1 * -9931 + 1599 + -10 * 1152));
      if (_0xb9deb7 === _0x229f8c) break;
      else _0x445f08["push"](_0x445f08["shift"]());
    } catch (_0xd7b609) {
      _0x445f08["push"](_0x445f08["shift"]());
    }
  }
})(_0x4e6b, 1 * 585199 + 1241644 + -1126277 * 1);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function _0x4e6b() {
  var _0x1cda02 = ["WOSJW4FdRrBcPWK3W4SwWQVdPx4", "WO1/W7yWWPNdI8o8W6e9nmoEg3q", "WQaJu8kKWQuQW5pcVrdcPK8B", "WRuQWQhdMqKzWOa", "CfT0W6GRWOxcNZWWdKpcQmoz", "W7hdS8oEW79+W70ytCo/hSoIW7u", "W5BcM1ODwJ1xlCot", "hfL1dMdcPmkMgbytWQmh", "W7BdSCoDW7n8W7eDB8oegmoEW5C", "dI7dICofquxcVICDcCoxW5u", "a8kJaqCOymkWeCkZW6JcH8o6W4y", "CebCFSo/lMGpW7hdUCkJWRO", "WRftW5RcKe9gWPeOoSk6W4lcMa", "W7tdT8oEW7HZW7XEtCokkmoEW40I", "WO97WOjIW5VcQ8krW6q", "WOyYW4eDxCkJcSkSia", "W7dcJmkHWRe9WQ8i", "D0jFCSo9iM0TW4RdV8kFWPG", "pCoBWOdcICoWW7hdJmki", "W6FcI0SzeNSCWOVdN0GKcLC"];
  _0x4e6b = function() {
    return _0x1cda02;
  };
  return _0x4e6b();
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
