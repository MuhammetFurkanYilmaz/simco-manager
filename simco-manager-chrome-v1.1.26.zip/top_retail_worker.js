const _0x26cdd9 = _0x5c24;
function _0x2658() {
  const _0x41e941 = ["WORdTXZcNCkR", "qdjiWPyTDXvVWRJdJW", "o8ozsW", "WRLichfBoCk2", "uSodW7S", "WRhcJxi9lq", "kmkdW7pdTCoX", "W57dSYdcKSkD", "W5tdUY8MW58", "n8kIuSkLsCk6WRS", "hCo5dviDoCox", "oSoNn8k6W7KAqSo5", "vZtdRHFdVCodW7W", "WOJdQahcG8kJ", "xLOkb8kfWQNdHW", "v8oMW7FdGGe", "t8kFhmk5W6u", "WQnIvLddOq", "uwBdHehdVhdcOhihdG", "WRVcMfqgoaJcQmkHW4bW", "WQniC3ZdSa", "kmkTemo5WPmoWRVcISk0", "h8obW7JcL8oQWQ81p8kGaLGi", "BSkOW4tdJdakEghcGcK", "lSkSBa", "WO3cMdiTW63dSqDz", "eSoZeuW", "W5xcOJmvsSoQdY0hWPpcVCobBq", "W7b5nulcLCkbiaaRia", "oCoTr8o3FmkXwCkKW6FdQmoSzW", "qCkUsbrfACkdWOZcGSkCBuZcHSke", "uSo1khlcRq", "W7WvEc0AA8oJW4VcLrdcKJNcSmoq", "zb19WO0o", "B8k2kCks", "m8k/W7BdGW", "WQ/dISojW65eDCkox8kiW6hdPIZcRG", "smonW7hdGtxcOhuKuKq", "vSkeW7u", "m8kIz8k4Fmk6WQZdSNVcIa", "gSoYDCkRWPK", "ovFcV1TrW63dGSoDW5K7W718", "W4JdUYVcOq", "j8owoKC3", "WPFdSxrxc8kYssuJWRi", "t8oqW6ZdJIxcSseira", "WQboia", "vCoWASoiWPm", "wvq4g8kpWQ3dL8ojxtG", "oumwW6RdQq", "vqNcHINdKG", "W6/dGturW6xdKJL0WR3cVa", "mYiMWRm7", "agddOrBdM8kpALj1lq", "WORdQaFcMCkkWOOKW5ewWPq", "aMSnW5rUifjkWO7dPCoyW4iw", "WR/cMgSDaGJcQCkrW4bK", "WPNdQaFcMq", "pmoKB8ohWQTGzmo3pdyfWQm", "iKRcNqtdVSkNW65j", "WQD/uSkEWP4rWQFcSCkN", "W6tdUXunW54", "Bmo2uCooWO0", "WQLVqfVdQCok", "W4NdRaSaW6W", "o13dOIFdMa", "nhxdNsK", "CSo7F8k7CSklWRFdMq", "lmo1E35d", "qabtW7ldP0CRW6jW", "aNFdVqFdGSky", "wSkDWR/dJCk4", "jKyiW4/dQgKlWRC", "aSkTWPHO", "WO/cKgfCW6BdHHrzWPJdVW", "ECkYpSkwW64RyCoEgW", "wmkaWQxdH8kPW7qTmmkn", "rCkRtHDibmorW4VcNmkdya", "at/cKrRdPMNcMe4J", "WRVcH08cgq", "WP/cM2lcRmkg", "vCo8D8oYWP0", "iCozxL9A", "y8khfCovW6jxs8oeWQmgWP0", "WPRcRgNdOSoAxCouWOlcS8k5W50XW4G", "WRtdVq3cO8kv", "wbxcUbVdHW", "DSoMyCoRua", "jHldJdtdKW", "zXpcSbRdHCkwW6i", "D8kUW6y", "lmoYxmobWRaqWOi"];
  _0x2658 = function() {
    return _0x41e941;
  };
  return _0x2658();
}
function _0x5c24(_0x74ac00, _0x15645e) {
  _0x74ac00 = _0x74ac00 - (-3677 + -1 * 3761 + 7803);
  const _0x26dd24 = _0x2658();
  let _0x5d6e3a = _0x26dd24[_0x74ac00];
  if (_0x5c24["eilQfm"] === void 0) {
    var _0x72c185 = function(_0x187168) {
      const _0x4eb52e = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x4c861c = "", _0x286520 = "";
      for (let _0x2ca7a3 = -19 * -15 + 2627 + -2912, _0x4db838, _0x11855f, _0x581b82 = 7807 * 1 + -1 * 7621 + 2 * -93; _0x11855f = _0x187168["charAt"](_0x581b82++); ~_0x11855f && (_0x4db838 = _0x2ca7a3 % (-32 * 88 + 2 * -1858 + 1634 * 4) ? _0x4db838 * (2 * 2279 + 10 * -169 + -701 * 4) + _0x11855f : _0x11855f, _0x2ca7a3++ % (7 * 371 + -8501 + 5908)) ? _0x4c861c += String["fromCharCode"](9904 + -4319 + -5330 & _0x4db838 >> (-(411 * 10 + -8269 + 57 * 73) * _0x2ca7a3 & -7670 + -6127 + 13803)) : -25 * -107 + -1569 + 553 * -2) {
        _0x11855f = _0x4eb52e["indexOf"](_0x11855f);
      }
      for (let _0xcfbf1e = 5881 + 6361 * -1 + 480, _0x35f605 = _0x4c861c["length"]; _0xcfbf1e < _0x35f605; _0xcfbf1e++) {
        _0x286520 += "%" + ("00" + _0x4c861c["charCodeAt"](_0xcfbf1e)["toString"](1185 + 7131 + 166 * -50))["slice"](-(-7211 + -4969 * 2 + 17151 * 1));
      }
      return decodeURIComponent(_0x286520);
    };
    const _0x3090e0 = function(_0x2339aa, _0xe04064) {
      let _0x4d4913 = [], _0x591d51 = 7844 + -490 * 2 + -6864, _0x271435, _0x559730 = "";
      _0x2339aa = _0x72c185(_0x2339aa);
      let _0x340c7c;
      for (_0x340c7c = -2582 * 3 + 523 * -13 + 14545; _0x340c7c < 7 * -71 + 2509 * 2 + -4265; _0x340c7c++) {
        _0x4d4913[_0x340c7c] = _0x340c7c;
      }
      for (_0x340c7c = 3785 + 2855 * 2 + -9495; _0x340c7c < 3923 * 1 + 1209 + -2 * 2438; _0x340c7c++) {
        _0x591d51 = (_0x591d51 + _0x4d4913[_0x340c7c] + _0xe04064["charCodeAt"](_0x340c7c % _0xe04064["length"])) % (2171 * -2 + -16 * 193 + 7686), _0x271435 = _0x4d4913[_0x340c7c], _0x4d4913[_0x340c7c] = _0x4d4913[_0x591d51], _0x4d4913[_0x591d51] = _0x271435;
      }
      _0x340c7c = -9278 + 9300 + -22 * 1, _0x591d51 = 2723 + -1 * 2131 + -592;
      for (let _0x475ae9 = 11 + 424 * -6 + 2533; _0x475ae9 < _0x2339aa["length"]; _0x475ae9++) {
        _0x340c7c = (_0x340c7c + (-2 * -1791 + 781 * -9 + 2 * 1724)) % (-1318 * -3 + -6618 + 146 * 20), _0x591d51 = (_0x591d51 + _0x4d4913[_0x340c7c]) % (2 * 733 + 3043 + -4253), _0x271435 = _0x4d4913[_0x340c7c], _0x4d4913[_0x340c7c] = _0x4d4913[_0x591d51], _0x4d4913[_0x591d51] = _0x271435, _0x559730 += String["fromCharCode"](_0x2339aa["charCodeAt"](_0x475ae9) ^ _0x4d4913[(_0x4d4913[_0x340c7c] + _0x4d4913[_0x591d51]) % (5564 + 17 * -3 + 751 * -7)]);
      }
      return _0x559730;
    };
    _0x5c24["vuAHUO"] = _0x3090e0, _0x5c24["rBZOhG"] = {}, _0x5c24["eilQfm"] = !![];
  }
  const _0x15490d = _0x26dd24[-1 * 1711 + -11 * 542 + 7673], _0x585584 = _0x74ac00 + _0x15490d, _0x485068 = _0x5c24["rBZOhG"][_0x585584];
  return !_0x485068 ? (_0x5c24["xtanml"] === void 0 && (_0x5c24["xtanml"] = !![]), _0x5d6e3a = _0x5c24["vuAHUO"](_0x5d6e3a, _0x15645e), _0x5c24["rBZOhG"][_0x585584] = _0x5d6e3a) : _0x5d6e3a = _0x485068, _0x5d6e3a;
}
(function(_0x7e0fb8, _0x547ce0) {
  const _0x1ded4c = _0x5c24, _0x52bf95 = _0x7e0fb8();
  while (!![]) {
    try {
      const _0x408919 = parseInt(_0x1ded4c(408, "R]2t")) / (905 * 2 + -4293 * -1 + -6102) * (-parseInt(_0x1ded4c(378, "WrPo")) / (358 * -23 + 6416 + 1820)) + -parseInt(_0x1ded4c(451, "lXez")) / (6 * 301 + 4276 * -1 + 2473) + parseInt(_0x1ded4c(455, "o&m[")) / (-109 + -1 * 6564 + -11 * -607) * (-parseInt(_0x1ded4c(437, "9cYc")) / (515 * 2 + -241 + -784)) + parseInt(_0x1ded4c(454, "^rPp")) / (5 * -301 + -11 * -673 + -491 * 12) + -parseInt(_0x1ded4c(373, "%9x*")) / (731 * 5 + -49 * 134 + 2918) * (-parseInt(_0x1ded4c(381, "pPe6")) / (-363 * -5 + 113 + -1920)) + parseInt(_0x1ded4c(432, "spsB")) / (604 * 3 + 99 * -96 + 17 * 453) * (-parseInt(_0x1ded4c(421, "WrPo")) / (-226 * 7 + 1529 * 1 + 63)) + parseInt(_0x1ded4c(428, "w9B*")) / (8772 + -2965 * -1 + 533 * -22);
      if (_0x408919 === _0x547ce0) break;
      else _0x52bf95["push"](_0x52bf95["shift"]());
    } catch (_0x4ded4d) {
      _0x52bf95["push"](_0x52bf95["shift"]());
    }
  }
})(_0x2658, 737414 + -553884 + 1168 * 288), self[_0x26cdd9(456, "AbTu")] = async (_0x567f87) => {
  const _0x2bde58 = _0x26cdd9, _0x51b926 = { "CGWjG": function(_0xd43359, _0x3a9491) {
    return _0xd43359 === _0x3a9491;
  }, "FupZo": _0x2bde58(382, "43@l"), "KeSRt": _0x2bde58(447, "WrPo") + _0x2bde58(433, "Eeb%") + "or", "ugxGv": function(_0x291162, _0x2067ff) {
    return _0x291162 !== _0x2067ff;
  }, "TTPjz": function(_0x57a104, _0x417d7f) {
    return _0x57a104 || _0x417d7f;
  }, "uDSde": _0x2bde58(367, "2HpW"), "Dbdfi": _0x2bde58(379, "^rPp"), "NzyNR": function(_0x2a8a51, _0x194d92) {
    return _0x2a8a51 === _0x194d92;
  }, "KOlUv": function(_0x7ee16b, _0x5115c1) {
    return _0x7ee16b == _0x5115c1;
  }, "YxuKc": function(_0x5cf8af, _0x140516) {
    return _0x5cf8af + _0x140516;
  }, "OwqAt": function(_0x46f6ba, _0x170acb) {
    return _0x46f6ba * _0x170acb;
  }, "hSwBV": function(_0x142402, _0x156587) {
    return _0x142402 * _0x156587;
  }, "KiNhz": function(_0x58353e, _0x459ae1) {
    return _0x58353e * _0x459ae1;
  }, "DHAJx": function(_0xcaaa43, _0x4a75f0) {
    return _0xcaaa43 / _0x4a75f0;
  }, "zzUOX": function(_0x3719e5, _0x100053) {
    return _0x3719e5 + _0x100053;
  }, "WNAnQ": function(_0x4a72e9, _0x14774d) {
    return _0x4a72e9 - _0x14774d;
  }, "hDthQ": function(_0x2d87ec, _0x22ff31) {
    return _0x2d87ec / _0x22ff31;
  }, "CMZBw": function(_0x2a3168, _0x3d7e3a) {
    return _0x2a3168 - _0x3d7e3a;
  }, "LBPHO": function(_0x56d774, _0x1acf70) {
    return _0x56d774 < _0x1acf70;
  }, "kAodv": function(_0x214283, _0x4f9969) {
    return _0x214283(_0x4f9969);
  }, "WJDfK": function(_0x25ff04, _0x16e451) {
    return _0x25ff04(_0x16e451);
  }, "JIZWF": function(_0x5cdfa5, _0x1341a1) {
    return _0x5cdfa5(_0x1341a1);
  }, "XSMiW": _0x2bde58(374, "uxkE") }, { action: _0x1e4fb2, products: _0xd3c85e, adminOverhead: _0x1ad485, salesBonus: _0x4acca2, economyPhase: _0xc6c43b, simulateError: _0x39a006 } = _0x567f87[_0x2bde58(430, "^rPp")];
  if (_0x51b926[_0x2bde58(427, "L9Tw")](_0x1e4fb2, _0x51b926[_0x2bde58(446, "o&m[")])) {
    if (_0x39a006) {
      self[_0x2bde58(450, "CIGJ") + "e"]({ "error": _0x51b926[_0x2bde58(385, "olA&")] });
      return;
    }
    try {
      const _0x20abea = _0x1ad485 !== void 0 ? _0x1ad485 : 31 * 283 + 359 * -6 + 1 * -6619, _0x16e2f6 = _0x51b926[_0x2bde58(403, "b#R#")](_0x4acca2, void 0) ? _0x4acca2 : -104 * -67 + -23 * -153 + 10487 * -1, _0x15327e = _0x51b926[_0x2bde58(386, "fIC!")](_0xc6c43b, _0x51b926[_0x2bde58(368, "WrPo")]), _0x52137b = Math[_0x2bde58(420, "bm5u")](-5317 + 2710 + 2607, Math[_0x2bde58(442, "w9B*")](_0x20abea, -31 * -35 + 6644 + -1 * 7529)), _0x330740 = Math[_0x2bde58(434, "uENa")](6114 + 3380 + -9494, Math[_0x2bde58(398, "EAkF")](_0x16e2f6, 6581 * -1 + -10 * -400 + 2631)), _0x4786a4 = _0x15327e[_0x2bde58(419, "Ujcd") + "e"]() === _0x51b926[_0x2bde58(413, "2HpW")] ? -410 * -13 + -5717 * 1 + 387 + 0.9 : _0x51b926[_0x2bde58(389, "CIGJ")](_0x15327e[_0x2bde58(452, "@821") + "e"](), _0x2bde58(422, "pPe6")) ? -2618 + -8650 + 59 * 191 + 0.1200000000000001 : 78 * 95 + -6589 + -2 * 410, _0x5256b7 = [];
      for (const _0x58c6ca of _0xd3c85e) {
        for (let _0x5e47e2 = -7144 + 5919 + -1225 * -1; _0x5e47e2 <= -109 * -79 + 2249 * -4 + 197 * 2; _0x5e47e2++) {
          const _0x73cef6 = _0x5e47e2, _0x43870c = _0x58c6ca[_0x2bde58(397, "lXez")] <= 172 * -57 + -9076 + 18880 || _0x51b926[_0x2bde58(369, "uxkE")](_0x58c6ca[_0x2bde58(444, "11V5")], null) ? 4073 + 3944 * 2 + -443 * 27 + 0.1 : Math[_0x2bde58(400, "Eeb%")](7798 + 365 * -9 + -4513 + 0.1, Math[_0x2bde58(394, "Ujcd")](_0x58c6ca[_0x2bde58(440, "J^Le")], -1 * -6278 + -1475 + -1 * 4798)), _0x4ffca2 = _0x51b926[_0x2bde58(372, "fIC!")](-1423 + -6105 + 7529, _0x51b926[_0x2bde58(445, "%9x*")](_0x73cef6, -9963 + -3539 + 2 * 6751 + 0.05)), _0x43117a = 4357 * 1 + -141 * 2 + 1325 * -3, _0x2abeaa = _0x51b926[_0x2bde58(404, "WrPo")](_0x51b926[_0x2bde58(390, "o&m[")](_0x51b926[_0x2bde58(412, "^rPp")](_0x43117a, _0x43870c), _0x4ffca2), _0x4786a4) * _0x51b926[_0x2bde58(401, "@821")](-240 * -15 + -7118 + -3 * -1173, _0x51b926[_0x2bde58(416, "2HpW")](_0x330740, 9028 + -191 * -8 + 8 * -1307)), _0x4fc60a = _0x2abeaa / (1 * 4581 + 20 * 49 + -5537), _0x731b52 = _0x58c6ca[_0x2bde58(424, "EkMe") + "ce"] || _0x51b926[_0x2bde58(402, "p!xr")](_0x58c6ca[_0x2bde58(377, "nblk")], -1 * 2046 + 9765 + -454 * 17 + 0.5), _0x3d6fd2 = _0x51b926[_0x2bde58(429, "lXez")](_0x731b52, _0x58c6ca[_0x2bde58(438, "b#R#")]), _0x5f514a = _0x2abeaa * _0x731b52, _0x59edae = _0x51b926[_0x2bde58(391, "JYUj")](_0x5f514a, _0x51b926[_0x2bde58(411, "Eeb%")](_0x52137b, 212 * -41 + -1 * 225 + 9017)), _0xa5d03f = _0x51b926[_0x2bde58(392, "R]2t")](_0x51b926[_0x2bde58(443, "olA&")](_0x2abeaa, _0x3d6fd2), _0x59edae);
          if (_0x51b926[_0x2bde58(436, "EAkF")](_0xa5d03f, -5810 + -8893 + 87 * 169)) continue;
          _0x5256b7[_0x2bde58(370, "EqN!")]({ "productId": _0x58c6ca[_0x2bde58(380, "cJ&9")], "productName": _0x58c6ca[_0x2bde58(449, "uxkE") + "e"] || _0x2bde58(376, "%9x*") + _0x58c6ca[_0x2bde58(441, "Eeb%")], "quality": _0x73cef6, "price": _0x51b926[_0x2bde58(448, "dYVk")](parseFloat, _0x731b52[_0x2bde58(399, "w9B*")](2168 * -3 + -11 * -323 + -2953 * -1)), "cost": _0x51b926[_0x2bde58(439, "pPe6")](parseFloat, _0x58c6ca[_0x2bde58(453, "CIGJ")][_0x2bde58(393, "o&m[")](1613 * 4 + 4784 + 274 * -41)), "profitPerUnit": parseFloat(_0x3d6fd2[_0x2bde58(405, "bm5u")](1168 + -30 * 285 + -104 * -71)), "profitPerDay": Math[_0x2bde58(366, "olA&")](_0xa5d03f), "grossRevPerDay": Math[_0x2bde58(375, "cJ&9")](_0x5f514a), "unitsPerHr": _0x51b926[_0x2bde58(384, "D[E2")](parseFloat, _0x4fc60a[_0x2bde58(410, "11V5")](-2 * 3351 + -14 * 701 + -83 * -199)), "unitsPerDay": Math[_0x2bde58(409, "CIGJ")](_0x2abeaa), "pphpl": _0xa5d03f });
        }
      }
      _0x5256b7[_0x2bde58(431, "p!xr")]((_0x1b63be, _0x4ca9a4) => _0x4ca9a4[_0x2bde58(396, "CIGJ")] - _0x1b63be[_0x2bde58(383, "@821")]), self[_0x2bde58(415, "@821") + "e"]({ "action": _0x51b926[_0x2bde58(365, "WrPo")], "results": _0x5256b7 });
    } catch (_0x1b20f6) {
      self[_0x2bde58(435, "bm5u") + "e"]({ "error": _0x1b20f6[_0x2bde58(406, "pPe6")] });
    }
  }
};
