(function(_0x568d41, _0x455b4a) {
  var _0x48763c = _0x20a5, _0x3e4ede = _0x568d41();
  while (!![]) {
    try {
      var _0x3d1d84 = -parseInt(_0x48763c(390, "bHXq")) / (-1 * 350 + 83 * 117 + -9360) + parseInt(_0x48763c(387, "%0d1")) / (-1 * 3821 + 316 + 501 * 7) + parseInt(_0x48763c(393, "]m[6")) / (-1 * -3793 + -2683 * 2 + 788 * 2) + parseInt(_0x48763c(383, "#]PL")) / (4042 + -5 * -769 + -7883) + parseInt(_0x48763c(391, "kzl*")) / (631 * 7 + -7890 + 3478) + -parseInt(_0x48763c(385, "wXPh")) / (-8444 + 4508 + 3942) + -parseInt(_0x48763c(382, "O9uB")) / (-157 * 59 + 8512 + 758);
      if (_0x3d1d84 === _0x455b4a) break;
      else _0x3e4ede["push"](_0x3e4ede["shift"]());
    } catch (_0x535db2) {
      _0x3e4ede["push"](_0x3e4ede["shift"]());
    }
  }
})(_0x497b, -378484 + 657515 + -189898 * -1);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function _0x20a5(_0x3e6c47, _0x55ff6c) {
  _0x3e6c47 = _0x3e6c47 - (-2236 * -1 + 56 * 5 + -2134);
  var _0x36b0d9 = _0x497b();
  var _0x54f0ba = _0x36b0d9[_0x3e6c47];
  if (_0x20a5["KNTlNW"] === void 0) {
    var _0x13d4b8 = function(_0x19d00f) {
      var _0x1365f9 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0xdcda82 = "", _0x4df210 = "";
      for (var _0x5d1733 = -324 * 23 + -6 * 109 + 6 * 1351, _0x272075, _0x4e4edc, _0x15de4e = 8 * -45 + -5172 + -12 * -461; _0x4e4edc = _0x19d00f["charAt"](_0x15de4e++); ~_0x4e4edc && (_0x272075 = _0x5d1733 % (-1611 * 3 + 3115 + -246 * -7) ? _0x272075 * (3347 * -2 + 1436 + -6 * -887) + _0x4e4edc : _0x4e4edc, _0x5d1733++ % (-105 * -73 + 8930 + -16591 * 1)) ? _0xdcda82 += String["fromCharCode"](-2 * -3251 + 1 * 4660 + -1 * 10907 & _0x272075 >> (-(-2 * -2144 + -1 * 3310 + -976) * _0x5d1733 & 5429 + -2373 + -3050)) : 9392 * 1 + 1 * 2759 + -12151) {
        _0x4e4edc = _0x1365f9["indexOf"](_0x4e4edc);
      }
      for (var _0x116a84 = 7657 + -4317 + -3340, _0x1e8f37 = _0xdcda82["length"]; _0x116a84 < _0x1e8f37; _0x116a84++) {
        _0x4df210 += "%" + ("00" + _0xdcda82["charCodeAt"](_0x116a84)["toString"](8 * -694 + 13 * -681 + -19 * -759))["slice"](-(1 * -4453 + 2 * 89 + 4277));
      }
      return decodeURIComponent(_0x4df210);
    };
    var _0x17e468 = function(_0x1c720f, _0x10f93a) {
      var _0x5abd7d = [], _0x11e750 = 7 * -134 + -35 * 107 + 4683, _0x12bddc, _0x126ff3 = "";
      _0x1c720f = _0x13d4b8(_0x1c720f);
      var _0x190104;
      for (_0x190104 = 286 * -2 + -1 * 1739 + 2311; _0x190104 < 47 * -54 + -4168 + 59 * 118; _0x190104++) {
        _0x5abd7d[_0x190104] = _0x190104;
      }
      for (_0x190104 = 509 * -13 + 2237 + 4380; _0x190104 < -2595 + -818 + 3669; _0x190104++) {
        _0x11e750 = (_0x11e750 + _0x5abd7d[_0x190104] + _0x10f93a["charCodeAt"](_0x190104 % _0x10f93a["length"])) % (-5026 + 10 + 2636 * 2), _0x12bddc = _0x5abd7d[_0x190104], _0x5abd7d[_0x190104] = _0x5abd7d[_0x11e750], _0x5abd7d[_0x11e750] = _0x12bddc;
      }
      _0x190104 = 3883 + 17 * -47 + -6 * 514, _0x11e750 = 3693 + 1 * -2105 + 397 * -4;
      for (var _0x3b13df = 1 * -1379 + 4661 * -2 + 10701; _0x3b13df < _0x1c720f["length"]; _0x3b13df++) {
        _0x190104 = (_0x190104 + (-1 * -5857 + -1 * -4273 + -10129)) % (3711 + -2266 * 4 + 5609), _0x11e750 = (_0x11e750 + _0x5abd7d[_0x190104]) % (-2 * 977 + -54 + 2264), _0x12bddc = _0x5abd7d[_0x190104], _0x5abd7d[_0x190104] = _0x5abd7d[_0x11e750], _0x5abd7d[_0x11e750] = _0x12bddc, _0x126ff3 += String["fromCharCode"](_0x1c720f["charCodeAt"](_0x3b13df) ^ _0x5abd7d[(_0x5abd7d[_0x190104] + _0x5abd7d[_0x11e750]) % (-1 * 5477 + 509 * -17 + 14386)]);
      }
      return _0x126ff3;
    };
    _0x20a5["KBTvaE"] = _0x17e468, _0x20a5["EelYlA"] = {}, _0x20a5["KNTlNW"] = !![];
  }
  var _0x179559 = _0x36b0d9[-463 * -7 + -8 * 620 + 1719], _0x28ae57 = _0x3e6c47 + _0x179559, _0xcea069 = _0x20a5["EelYlA"][_0x28ae57];
  return !_0xcea069 ? (_0x20a5["ZUAgPu"] === void 0 && (_0x20a5["ZUAgPu"] = !![]), _0x54f0ba = _0x20a5["KBTvaE"](_0x54f0ba, _0x55ff6c), _0x20a5["EelYlA"][_0x28ae57] = _0x54f0ba) : _0x54f0ba = _0xcea069, _0x54f0ba;
}
function _0x497b() {
  var _0x35254a = ["W6Dlu1ldJmkbf1BdUezgca", "yHDlW5jrWONdRfadW7bhW7Lc", "eSowWQdcRKtdLSoYWODUD21myG", "ySorB8osr0bzW51jWQVcGmocW4y", "W4FcUmkIpmkMk8k+otvknhdcIa", "WOiiWPJdImkjW7/cIHRdLx9JWPLK", "dexcKKBdUapdUeBcPmkkWPS9WR4", "WRTyc1FcLbdcQmkslSkGW6GZ", "bqxdV1uZWOPhW6ldVa9RWRlcGa", "WPeHW4iLfSoRmZKHW7a2W7RdNW", "ct7dLGlcLt7dTmkzqwSDAa", "W5KGW6pcK1ilcSk7WP3dRCkoya", "W5dcLSkWl1NdT8kasSoCWOPkmG", "cKJcLeBdUqdcSKpcH8kwWPWO"];
  _0x497b = function() {
    return _0x35254a;
  };
  return _0x497b();
}
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
