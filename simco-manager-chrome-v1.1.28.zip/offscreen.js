// Hosts the CooperInc retail page in a hidden iframe so the scraper runs without opening a window.
// cooper_content.js (all_frames) does the work inside the iframe and messages the background.
const src = new URLSearchParams(location.search).get("src");
if (src && src.startsWith("https://cooperinc.xyz/")) {
  document.getElementById("cooper").src = src;
}
