const _0x264be2 = _0x1176;
function _0x1176(_0x1052ab, _0x4430b0) {
  _0x1052ab = _0x1052ab - (-292 * 21 + -569 * -1 + 5737);
  const _0x59ba20 = _0x483e();
  let _0xd37113 = _0x59ba20[_0x1052ab];
  if (_0x1176["ynFoKV"] === void 0) {
    var _0x90e0d7 = function(_0x5bd350) {
      const _0x4bf03f = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x6f9ca9 = "", _0x373b3f = "";
      for (let _0xed4f3 = 22 * 193 + 37 * 251 + -347 * 39, _0x492b3b, _0x28add8, _0x1c5a5a = -3720 + -446 * 8 + 1 * 7288; _0x28add8 = _0x5bd350["charAt"](_0x1c5a5a++); ~_0x28add8 && (_0x492b3b = _0xed4f3 % (3748 + 9795 + -13539) ? _0x492b3b * (-66 * 73 + -3584 + -3 * -2822) + _0x28add8 : _0x28add8, _0xed4f3++ % (-503 * 11 + -3576 + 9113)) ? _0x6f9ca9 += String["fromCharCode"](-9661 + -1 * 7148 + 17064 & _0x492b3b >> (-(-820 * 11 + 251 * -24 + 15046) * _0xed4f3 & -8920 + -3206 + 2 * 6066)) : 1 * 4313 + -4 * -1987 + -12261) {
        _0x28add8 = _0x4bf03f["indexOf"](_0x28add8);
      }
      for (let _0x346600 = 7730 + 9037 * 1 + -16767, _0x5e9573 = _0x6f9ca9["length"]; _0x346600 < _0x5e9573; _0x346600++) {
        _0x373b3f += "%" + ("00" + _0x6f9ca9["charCodeAt"](_0x346600)["toString"](-461 * -17 + -7789 + -2 * 16))["slice"](-(5619 + 3 * 1723 + 5393 * -2));
      }
      return decodeURIComponent(_0x373b3f);
    };
    const _0x1ed172 = function(_0x299ea5, _0x502501) {
      let _0x4a4a4b = [], _0x58c7fa = -4947 + -9526 + 14473, _0x204a7b, _0x533fa7 = "";
      _0x299ea5 = _0x90e0d7(_0x299ea5);
      let _0x22d1a5;
      for (_0x22d1a5 = -137 + -6213 + -635 * -10; _0x22d1a5 < -1350 + -1318 * 1 + -2 * -1462; _0x22d1a5++) {
        _0x4a4a4b[_0x22d1a5] = _0x22d1a5;
      }
      for (_0x22d1a5 = -1072 * -7 + -7664 + 160; _0x22d1a5 < -6847 + 6869 + 234; _0x22d1a5++) {
        _0x58c7fa = (_0x58c7fa + _0x4a4a4b[_0x22d1a5] + _0x502501["charCodeAt"](_0x22d1a5 % _0x502501["length"])) % (-89 * 85 + -43 * 1 + -1 * -7864), _0x204a7b = _0x4a4a4b[_0x22d1a5], _0x4a4a4b[_0x22d1a5] = _0x4a4a4b[_0x58c7fa], _0x4a4a4b[_0x58c7fa] = _0x204a7b;
      }
      _0x22d1a5 = -1131 * 1 + 2012 + -881, _0x58c7fa = -709 * -5 + -1316 + -2229 * 1;
      for (let _0x562279 = -1 * 6681 + 6214 + -467 * -1; _0x562279 < _0x299ea5["length"]; _0x562279++) {
        _0x22d1a5 = (_0x22d1a5 + (998 + 1062 * 7 + -8431)) % (8815 * 1 + -4191 + -8 * 546), _0x58c7fa = (_0x58c7fa + _0x4a4a4b[_0x22d1a5]) % (2 * 4978 + 54 * 72 + -13588), _0x204a7b = _0x4a4a4b[_0x22d1a5], _0x4a4a4b[_0x22d1a5] = _0x4a4a4b[_0x58c7fa], _0x4a4a4b[_0x58c7fa] = _0x204a7b, _0x533fa7 += String["fromCharCode"](_0x299ea5["charCodeAt"](_0x562279) ^ _0x4a4a4b[(_0x4a4a4b[_0x22d1a5] + _0x4a4a4b[_0x58c7fa]) % (1 * -7682 + 8798 + 172 * -5)]);
      }
      return _0x533fa7;
    };
    _0x1176["XNZabW"] = _0x1ed172, _0x1176["kOsGWV"] = {}, _0x1176["ynFoKV"] = !![];
  }
  const _0x3bff23 = _0x59ba20[1233 * -6 + -1 * 1379 + 8777], _0xc72a0d = _0x1052ab + _0x3bff23, _0xa81f46 = _0x1176["kOsGWV"][_0xc72a0d];
  return !_0xa81f46 ? (_0x1176["znMdwW"] === void 0 && (_0x1176["znMdwW"] = !![]), _0xd37113 = _0x1176["XNZabW"](_0xd37113, _0x4430b0), _0x1176["kOsGWV"][_0xc72a0d] = _0xd37113) : _0xd37113 = _0xa81f46, _0xd37113;
}
(function(_0x4db792, _0x405f98) {
  const _0x15a967 = _0x1176, _0x2cc69f = _0x4db792();
  while (!![]) {
    try {
      const _0x3bb4e3 = parseInt(_0x15a967(264, "vJ(d")) / (1476 + 806 + -2281) * (-parseInt(_0x15a967(180, "jSN#")) / (5683 + 4915 + -10596)) + parseInt(_0x15a967(258, "oUx2")) / (1062 + 1 * -5010 + 3951 * 1) + parseInt(_0x15a967(223, "Q1GV")) / (2133 + 8369 * 1 + -362 * 29) * (-parseInt(_0x15a967(249, "NMYG")) / (-10 * -578 + 7023 + -12798)) + -parseInt(_0x15a967(242, "]gUw")) / (3042 * -1 + 79 * -43 + 6445) * (-parseInt(_0x15a967(205, "]gUw")) / (-116 * 13 + 83 * 22 + 1 * -311)) + -parseInt(_0x15a967(255, "rSl]")) / (-1 * -9598 + 1839 * -1 + 23 * -337) + parseInt(_0x15a967(179, "Z*Fz")) / (7 * -651 + 7557 + -2991) * (parseInt(_0x15a967(207, "Qo2z")) / (-2200 + 337 * -5 + 3895)) + parseInt(_0x15a967(210, "8geV")) / (1770 + -7030 + 5271);
      if (_0x3bb4e3 === _0x405f98) break;
      else _0x2cc69f["push"](_0x2cc69f["shift"]());
    } catch (_0x384c62) {
      _0x2cc69f["push"](_0x2cc69f["shift"]());
    }
  }
})(_0x483e, 23 * 56391 + -1677448 + -1345051 * -1), self[_0x264be2(225, "hMkS")] = async (_0x3454d0) => {
  const _0x2ecb86 = _0x264be2, _0x34ad41 = { "TvlqN": function(_0x1e4309, _0x333b96) {
    return _0x1e4309 === _0x333b96;
  }, "vahyJ": _0x2ecb86(185, "oUx2"), "kQgLN": _0x2ecb86(251, "5!t3") + _0x2ecb86(202, "CzqA") + "or", "rpgYC": function(_0x212dec, _0x4ad83e) {
    return _0x212dec !== _0x4ad83e;
  }, "nqUXi": function(_0x1a784a, _0x5e6734) {
    return _0x1a784a || _0x5e6734;
  }, "yUfVm": _0x2ecb86(212, "Q1GV"), "nbhgt": function(_0x5d9603, _0x47a679) {
    return _0x5d9603 === _0x47a679;
  }, "oAhww": _0x2ecb86(187, "hMkS"), "iRhfe": function(_0x153966, _0x200746) {
    return _0x153966 <= _0x200746;
  }, "wHmfX": function(_0x45f344, _0x267fe7) {
    return _0x45f344 + _0x267fe7;
  }, "GygQf": function(_0xeb23ba, _0x160c31) {
    return _0xeb23ba * _0x160c31;
  }, "VoWpL": function(_0x3f07f9, _0x149f72) {
    return _0x3f07f9 * _0x149f72;
  }, "vZKJC": function(_0x3bbc25, _0x15131c) {
    return _0x3bbc25 * _0x15131c;
  }, "ugWTB": function(_0x14277b, _0x1f9042) {
    return _0x14277b / _0x1f9042;
  }, "SgwYU": function(_0x5f2937, _0x5cdc70) {
    return _0x5f2937 + _0x5cdc70;
  }, "aNwpC": function(_0x3b9a08, _0x374ceb) {
    return _0x3b9a08 * _0x374ceb;
  }, "sUVwG": function(_0x19ebd7, _0x1e4d90) {
    return _0x19ebd7 * _0x1e4d90;
  }, "WBFGQ": function(_0xa10224, _0x4a3ebb) {
    return _0xa10224 < _0x4a3ebb;
  }, "yCXFT": function(_0x222116, _0xc6e6eb) {
    return _0x222116(_0xc6e6eb);
  }, "jZHMq": function(_0x359e60, _0x227c03) {
    return _0x359e60(_0x227c03);
  }, "vWyrZ": function(_0x53bdab, _0x5907aa) {
    return _0x53bdab(_0x5907aa);
  }, "sytjk": _0x2ecb86(216, "vJ(d") }, { action: _0x49db85, products: _0x324623, adminOverhead: _0x4e85fc, salesBonus: _0x47741b, economyPhase: _0x2ab089, simulateError: _0x1896d7 } = _0x3454d0[_0x2ecb86(177, "X$)C")];
  if (_0x34ad41[_0x2ecb86(200, "N@FM")](_0x49db85, _0x34ad41[_0x2ecb86(192, "iGDA")])) {
    if (_0x1896d7) {
      self[_0x2ecb86(262, "RO)c") + "e"]({ "error": _0x34ad41[_0x2ecb86(208, "BymY")] });
      return;
    }
    try {
      const _0x29159f = _0x34ad41[_0x2ecb86(253, "5!t3")](_0x4e85fc, void 0) ? _0x4e85fc : 9139 + -5314 + 51 * -75, _0x2055f8 = _0x47741b !== void 0 ? _0x47741b : -1029 * 3 + 6515 + 4 * -857, _0x5c6631 = _0x34ad41[_0x2ecb86(201, "GqgG")](_0x2ab089, _0x34ad41[_0x2ecb86(176, "N@FM")]), _0x78acba = Math[_0x2ecb86(233, "vBVS")](-4439 + 2058 + -2381 * -1, Math[_0x2ecb86(257, "8#4q")](_0x29159f, -5182 + -2547 * -3 + -2259)), _0x2c7ce6 = Math[_0x2ecb86(218, "zRZt")](6513 + -2649 + -3864, Math[_0x2ecb86(227, "T8)m")](_0x2055f8, 3250 + -203 + -2997)), _0xa54a11 = _0x34ad41[_0x2ecb86(184, "iGDA")](_0x5c6631[_0x2ecb86(178, "vJ(d") + "e"](), _0x34ad41[_0x2ecb86(217, "vBVS")]) ? 22 * -397 + 1564 + -2 * -3585 + 0.9 : _0x34ad41[_0x2ecb86(252, "vLW7")](_0x5c6631[_0x2ecb86(256, "Q1GV") + "e"](), _0x2ecb86(195, "sU)%")) ? -1 * 6521 + -58 * 127 + -1736 * -8 + 0.1200000000000001 : 4 * 64 + -116 * -41 + -1 * 5011, _0x55f3fd = [];
      for (const _0x48b31f of _0x324623) {
        for (let _0x4a9d7e = 6540 + 1 * 3286 + -9826; _0x34ad41[_0x2ecb86(221, "Q1GV")](_0x4a9d7e, -6 * 769 + -7282 + 2381 * 5); _0x4a9d7e++) {
          const _0x454846 = _0x4a9d7e, _0x173c39 = _0x34ad41[_0x2ecb86(213, "T8)m")](_0x48b31f[_0x2ecb86(238, "GqgG")], -4440 + -7723 * -1 + -3283) || _0x48b31f[_0x2ecb86(241, "Q@cb")] == null ? 1923 * -3 + 5701 + 1 * 68 + 0.1 : Math[_0x2ecb86(203, "oUx2")](1363 * -3 + 3624 + 1 * 465 + 0.1, Math[_0x2ecb86(174, "zRZt")](_0x48b31f[_0x2ecb86(237, "T8)m")], 9419 * 1 + -6478 + 2936 * -1)), _0x2f61ff = _0x34ad41[_0x2ecb86(228, "pXFq")](7 * 356 + -61 * -53 + -5724, _0x34ad41[_0x2ecb86(234, "t19a")](_0x454846, 59 * 37 + 1117 * -5 + 3402 + 0.05)), _0x512bdb = -1076 * 5 + 1782 + -3698 * -1, _0x3e5b38 = _0x34ad41[_0x2ecb86(175, "hMkS")](_0x34ad41[_0x2ecb86(191, "jSN#")](_0x34ad41[_0x2ecb86(248, "Q@cb")](_0x512bdb, _0x173c39), _0x2f61ff) * _0xa54a11, _0x34ad41[_0x2ecb86(194, "KylY")](-3274 + 309 * 11 + -124, _0x34ad41[_0x2ecb86(240, "8#4q")](_0x2c7ce6, -701 * 3 + 8226 + -6023))), _0x50195d = _0x3e5b38 / (9780 + 1 * 7226 + -1 * 16982), _0x1e10c5 = _0x48b31f[_0x2ecb86(260, "vJ(d") + "ce"] || _0x34ad41[_0x2ecb86(224, "NMYG")](_0x48b31f[_0x2ecb86(186, "rSl]")], 5642 * 1 + 2412 + -1 * 8053 + 0.5), _0x55b82d = _0x1e10c5 - _0x48b31f[_0x2ecb86(222, "7iyC")], _0x2131f7 = _0x3e5b38 * _0x1e10c5, _0x4868f5 = _0x34ad41[_0x2ecb86(244, "vJ(d")](_0x2131f7, _0x34ad41[_0x2ecb86(204, "rSl]")](_0x78acba, 4 * -911 + -9421 + -5 * -2633)), _0x22ceff = _0x34ad41[_0x2ecb86(250, "c@sM")](_0x3e5b38, _0x55b82d) - _0x4868f5;
          if (_0x34ad41[_0x2ecb86(231, "8geV")](_0x22ceff, 2742 + 1865 * -3 + -1 * -2853)) continue;
          _0x55f3fd[_0x2ecb86(259, "nQhA")]({ "productId": _0x48b31f[_0x2ecb86(199, "KylY")], "productName": _0x48b31f[_0x2ecb86(246, "vLW7") + "e"] || _0x2ecb86(196, "oUx2") + _0x48b31f[_0x2ecb86(247, "N%9[")], "quality": _0x454846, "price": _0x34ad41[_0x2ecb86(209, "Q@cb")](parseFloat, _0x1e10c5[_0x2ecb86(206, "jSN#")](9091 + 8e3 + -17089)), "cost": parseFloat(_0x48b31f[_0x2ecb86(197, "u[L9")][_0x2ecb86(236, "vJ(d")](46 * 193 + -8312 + -94 * 6)), "profitPerUnit": _0x34ad41[_0x2ecb86(245, "85qE")](parseFloat, _0x55b82d[_0x2ecb86(230, "JQBS")](2741 * 3 + 7483 + -15704)), "profitPerDay": Math[_0x2ecb86(189, "sgC[")](_0x22ceff), "grossRevPerDay": Math[_0x2ecb86(215, "85qE")](_0x2131f7), "unitsPerHr": _0x34ad41[_0x2ecb86(261, "BymY")](parseFloat, _0x50195d[_0x2ecb86(206, "jSN#")](-634 * -7 + 7957 + -1 * 12394)), "unitsPerDay": Math[_0x2ecb86(181, "GqgG")](_0x3e5b38), "pphpl": _0x22ceff });
        }
      }
      _0x55f3fd[_0x2ecb86(220, "pXFq")]((_0x410371, _0x491249) => _0x491249[_0x2ecb86(190, "nQhA")] - _0x410371[_0x2ecb86(226, "JXOM")]), self[_0x2ecb86(232, "KylY") + "e"]({ "action": _0x34ad41[_0x2ecb86(198, "RO)c")], "results": _0x55f3fd });
    } catch (_0x167a2e) {
      self[_0x2ecb86(239, "]gUw") + "e"]({ "error": _0x167a2e[_0x2ecb86(214, "JXOM")] });
    }
  }
};
function _0x483e() {
  const _0x1a50d9 = ["W7dcHwyZW7tdRmkAW54NFCoUWPFcGW", "W5PFWP/cHxb3xa", "W7zHhbNdH2CBWPhdUbi", "ewqVW5jgphDxW6RcHW", "W5XXkhLNax1umG0", "WOxdVZddPJ4", "W503WR86WRRcRWipb3q", "WPqQBtSFudHgnGxdKexdMG", "sdJcTuldMcVcRenLjCkOrSoF", "W49+WQ7cNeS", "BSkXFMJcTW", "W44BW40GW6nIW6BcKGZdKW", "sCkQW6i5WOqpbYqv", "W5SXWPWBWOO", "s1FdOt/cOvFdLa", "W5JcJ3FcICkO", "t8kgWRf4WRVdLWLPdHa", "W5alW4OJW6i", "BSkFWRTuWPq", "lSowW6W+W6pcHeS1lMbzWQahW4q", "xmoiW78tW7ddLmkICmkfxbaYpYW", "W6GKW6K1ev8KjSkriG", "WP3dSqK", "gM9FW5JdK8kfWOvmF19sCqO", "W5hcUCkyrG", "W49gWRZcNML1xCk8WQ3cPW", "t8kRWP0IWPW", "W5aJjfVcN8kdWRVcKmkdWPi", "W4FdN8kcoSkDnSoe", "WPGcW67dNtGKD8k6WPdcV8oFka", "xYOJ", "WP7dSSo4FCot", "kCk2WR87cq", "W5pdH2r+", "W5PFWPxcG393sSkVWR7cVq", "xK/dT8k5W6yioXhdH8os", "nYZdNSkjWORdICol", "egOUW4Lq", "nCoCbbxcQ8k1uHzNW7u", "wvNdHSo8WOryW58", "WP7dLSkGj8k+", "sdyeWORcL8ozW5rixq", "dSkvWRLq", "WRRdUmomAmoSW5JcTWNdRq", "WOzSW5GPsmkpW7FcN8oWCLrq", "W6NcMWJcJSoe", "W5hcVmkdxSkc", "CZRdTmkMWPO", "WOBdLCkGoCka", "wJfTWPebAtvFW6dcHMq1Aq", "W5mWW5TuFG", "WPDjpu0", "EYuhWO3cL8owW4eC", "WQ4aW4es", "W5m1i0xcUq", "W7aLW4nPxHpdLSkTnq", "bmkvWRuCkG", "dhqoW79D", "DmotWQSagSoSC8kvWQ5j", "rJyq", "gmkDWP1WWOa", "WPT1exD9aNG", "Cq/dUCkfWQhdNSoS", "W7dcIMmYWQJcPCoWW70vtW", "uSkTWOmCWOG", "W5CvWPmjWPW", "WOjNW58RtmklWO7dSmo7u2HuWQya", "W4b+nMtcJcqB", "W5iKW5C3b1y", "W6XsaaRdKa", "W7tcLCk7WOjCW7BdHa", "DSkeq0VcOG", "W5XvWQRcMwrM", "WORdVMBcUmkJ", "xYi1", "WOdcSIz5W4bKWQpdQfZdSqNdOmkvW6u", "sZ5LWOm", "W7uzW408aW", "C8kOWQFcKG", "WQP8WPvJuGnGaSkgf8kMtSka", "oxBdOIRcIG", "WQFdS8ocAmoSW5JcVWhdPG", "W6NcGmkGWOfr", "W6HPbG", "tXL6WPep", "aColW5rJWRyPW7ddTCknWQW", "WOzXvvFcJCoQW40", "W6CCWQLFkq", "W7a4W595zHxdKCkxmmoj", "WOJdNNy", "W6jKWR95WP4"];
  _0x483e = function() {
    return _0x1a50d9;
  };
  return _0x483e();
}
