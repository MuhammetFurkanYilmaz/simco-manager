(function(_0x4af4fb, _0x3f9537) {
  var _0x1c3d08 = _0x4d5f, _0x4b004c = _0x4af4fb();
  while (!![]) {
    try {
      var _0x32ded3 = -parseInt(_0x1c3d08(509, "]H!N")) / (3845 + -11 * 746 + -2181 * -2) + parseInt(_0x1c3d08(502, "wvS&")) / (-566 * 7 + 3982 + -3 * 6) + -parseInt(_0x1c3d08(491, "0L^m")) / (235 * 19 + 5604 + -10066) * (parseInt(_0x1c3d08(508, "bVE]")) / (327 * -7 + 8208 + -13 * 455)) + -parseInt(_0x1c3d08(493, "G@qc")) / (-4254 * -1 + 1 * -1459 + -2790) * (-parseInt(_0x1c3d08(500, "D9xg")) / (877 + -1295 * -1 + -2166)) + -parseInt(_0x1c3d08(499, "n7RJ")) / (-6 * 942 + -2092 * 2 + -579 * -17) + -parseInt(_0x1c3d08(506, "V51F")) / (-497 + -1133 * -6 + -6293) + parseInt(_0x1c3d08(498, "j5oa")) / (-1492 + -105 * 51 + 6856) * (parseInt(_0x1c3d08(495, "j@5j")) / (4143 + -267 + -3866));
      if (_0x32ded3 === _0x3f9537) break;
      else _0x4b004c["push"](_0x4b004c["shift"]());
    } catch (_0xfb2310) {
      _0x4b004c["push"](_0x4b004c["shift"]());
    }
  }
})(_0xac7f, 182164 * 2 + -18 * -14343 + -263017);
function _0x4d5f(_0x2b178e, _0x45e403) {
  _0x2b178e = _0x2b178e - (1742 + -382 * -1 + 1 * -1633);
  var _0x269201 = _0xac7f();
  var _0x3fd6e1 = _0x269201[_0x2b178e];
  if (_0x4d5f["otLgiL"] === void 0) {
    var _0x694337 = function(_0x13b80c) {
      var _0x4c07b7 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0xdc001f = "", _0x66792f = "";
      for (var _0x28821b = -11 * 252 + 1437 + 1335, _0x329337, _0x336d72, _0x596b13 = -4 * -1597 + -2063 * -1 + -8451; _0x336d72 = _0x13b80c["charAt"](_0x596b13++); ~_0x336d72 && (_0x329337 = _0x28821b % (-2070 + -6971 + -1 * -9045) ? _0x329337 * (-1 * 1105 + 89 * -1 + 1258) + _0x336d72 : _0x336d72, _0x28821b++ % (-2080 + 211 * 37 + -5723)) ? _0xdc001f += String["fromCharCode"](7356 + 8568 + 5223 * -3 & _0x329337 >> (-(226 * -10 + 3183 + -921) * _0x28821b & -8343 + 1209 * -4 + -4395 * -3)) : -4 * -2012 + 8069 * -1 + 21) {
        _0x336d72 = _0x4c07b7["indexOf"](_0x336d72);
      }
      for (var _0x21922e = 7558 + -7069 + -163 * 3, _0x34f23d = _0xdc001f["length"]; _0x21922e < _0x34f23d; _0x21922e++) {
        _0x66792f += "%" + ("00" + _0xdc001f["charCodeAt"](_0x21922e)["toString"](-853 * 1 + -9192 * -1 + -8323))["slice"](-(1 * -615 + 2477 * -1 + 3094));
      }
      return decodeURIComponent(_0x66792f);
    };
    var _0x301874 = function(_0x38958a, _0x492c61) {
      var _0x88d58a = [], _0xbaeec = -1 * 932 + 9132 + -2050 * 4, _0x5b1571, _0x3fa097 = "";
      _0x38958a = _0x694337(_0x38958a);
      var _0x2a18bf;
      for (_0x2a18bf = 3898 * -1 + 4684 + -786; _0x2a18bf < -9757 + -5435 + -1931 * -8; _0x2a18bf++) {
        _0x88d58a[_0x2a18bf] = _0x2a18bf;
      }
      for (_0x2a18bf = 8038 * -1 + 2694 + 16 * 334; _0x2a18bf < 2027 * 4 + 5529 + -1 * 13381; _0x2a18bf++) {
        _0xbaeec = (_0xbaeec + _0x88d58a[_0x2a18bf] + _0x492c61["charCodeAt"](_0x2a18bf % _0x492c61["length"])) % (8954 + 1491 * -3 + -4225), _0x5b1571 = _0x88d58a[_0x2a18bf], _0x88d58a[_0x2a18bf] = _0x88d58a[_0xbaeec], _0x88d58a[_0xbaeec] = _0x5b1571;
      }
      _0x2a18bf = 1036 + 2199 + -3235 * 1, _0xbaeec = 25 * -37 + 1 * -9349 + 934 * 11;
      for (var _0x265e08 = 2 * -3326 + 53 * 182 + 1 * -2994; _0x265e08 < _0x38958a["length"]; _0x265e08++) {
        _0x2a18bf = (_0x2a18bf + (-1 * -5690 + 6969 + -12658)) % (1666 * -3 + 8 * 62 + 2379 * 2), _0xbaeec = (_0xbaeec + _0x88d58a[_0x2a18bf]) % (17 * 102 + -113 * -52 + -2 * 3677), _0x5b1571 = _0x88d58a[_0x2a18bf], _0x88d58a[_0x2a18bf] = _0x88d58a[_0xbaeec], _0x88d58a[_0xbaeec] = _0x5b1571, _0x3fa097 += String["fromCharCode"](_0x38958a["charCodeAt"](_0x265e08) ^ _0x88d58a[(_0x88d58a[_0x2a18bf] + _0x88d58a[_0xbaeec]) % (-268 * 22 + -185 * -41 + 1433 * -1)]);
      }
      return _0x3fa097;
    };
    _0x4d5f["NwLRdX"] = _0x301874, _0x4d5f["EOAAov"] = {}, _0x4d5f["otLgiL"] = !![];
  }
  var _0x17e314 = _0x269201[3045 + -1068 + -1977], _0x108c8a = _0x2b178e + _0x17e314, _0x2c8385 = _0x4d5f["EOAAov"][_0x108c8a];
  return !_0x2c8385 ? (_0x4d5f["DZCRhR"] === void 0 && (_0x4d5f["DZCRhR"] = !![]), _0x3fd6e1 = _0x4d5f["NwLRdX"](_0x3fd6e1, _0x45e403), _0x4d5f["EOAAov"][_0x108c8a] = _0x3fd6e1) : _0x3fd6e1 = _0x2c8385, _0x3fd6e1;
}
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function _0xac7f() {
  var _0x6a39e3 = ["cSoMWQldVmkaWOtcR0dcMCkHWP7dOa", "gMT8W4ddISk8f8kVWQhdKXSu", "W7lcQCoDqXxcPCkTsSoIpu1V", "nCoNdIVdKq/dJd8LWPZdHhel", "ACo0tcrezmokkvu+", "qqiiamoOWOaPW6ZdNCkDbhTE", "W5e/W4xdI29DW5i", "eSkDxmoNW6HqyYCQ", "neTdWRWZW5znW5NcIcxcHG", "W6LfaxH3WOK2Fmk5W50", "mCoFta7cLa3dLL5oW6GoWPhdQa", "m8osW7NdNrLdCcmZEs/cUG", "aCkxctWlWQ1OW7tdTW", "W6JdPSk+WRVcHujoW7lcRgSFaSk4", "WRKLiSkTW4z9W5hcRZhdUmkLW58q", "j8kkW7e9W5lcLZddUJJcULO", "W6tdV08OW5q1rW", "W41zWQLZdG8OmSkUqIBcSNG", "tLldL8o6vXFcUmoJ"];
  _0xac7f = function() {
    return _0x6a39e3;
  };
  return _0xac7f();
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
