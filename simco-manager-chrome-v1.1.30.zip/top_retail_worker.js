function _0x3442(_0x190546, _0x4581ee) {
  _0x190546 = _0x190546 - (-8724 * -1 + 2578 * 2 + -13636);
  const _0x740774 = _0x5b65();
  let _0x2fa033 = _0x740774[_0x190546];
  if (_0x3442["XuywkL"] === void 0) {
    var _0x8dee45 = function(_0x2d44eb) {
      const _0x16a76d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x14bca1 = "", _0x59924b = "";
      for (let _0x1cc086 = 201 + -6212 + 6011, _0x196d49, _0x22b3a0, _0xf3235a = -2 * 4814 + 1 * -1249 + 10877; _0x22b3a0 = _0x2d44eb["charAt"](_0xf3235a++); ~_0x22b3a0 && (_0x196d49 = _0x1cc086 % (-625 * 5 + -1348 * 3 + -9 * -797) ? _0x196d49 * (2 * -4612 + -4966 + -2 * -7127) + _0x22b3a0 : _0x22b3a0, _0x1cc086++ % (-7687 * 1 + -9967 + 17658)) ? _0x14bca1 += String["fromCharCode"](13 * -146 + 5 * -1893 + 11618 & _0x196d49 >> (-(-85 + -29 * -29 + -754) * _0x1cc086 & -2 * -3351 + 2089 + -8785)) : 2566 + -8392 * 1 + 5826) {
        _0x22b3a0 = _0x16a76d["indexOf"](_0x22b3a0);
      }
      for (let _0x419d6e = -133 * -69 + -23 * -4 + -9269, _0xdd2ae9 = _0x14bca1["length"]; _0x419d6e < _0xdd2ae9; _0x419d6e++) {
        _0x59924b += "%" + ("00" + _0x14bca1["charCodeAt"](_0x419d6e)["toString"](-7729 + -2161 * 2 + 12067))["slice"](-(61 * -163 + -8007 + -2992 * -6));
      }
      return decodeURIComponent(_0x59924b);
    };
    const _0x24df24 = function(_0x594622, _0x37f8e2) {
      let _0x85107f = [], _0x284543 = -5784 + -1389 + 7173, _0x29e15c, _0x4b825a = "";
      _0x594622 = _0x8dee45(_0x594622);
      let _0x94f769;
      for (_0x94f769 = -4781 * -1 + 9349 + -14130; _0x94f769 < -1 * 7142 + 4 * -1616 + 13862; _0x94f769++) {
        _0x85107f[_0x94f769] = _0x94f769;
      }
      for (_0x94f769 = 58 * -133 + 50 * 129 + 2 * 632; _0x94f769 < 1460 + -7538 + -3167 * -2; _0x94f769++) {
        _0x284543 = (_0x284543 + _0x85107f[_0x94f769] + _0x37f8e2["charCodeAt"](_0x94f769 % _0x37f8e2["length"])) % (-61 * 27 + 496 * 17 + -6529), _0x29e15c = _0x85107f[_0x94f769], _0x85107f[_0x94f769] = _0x85107f[_0x284543], _0x85107f[_0x284543] = _0x29e15c;
      }
      _0x94f769 = -2966 * 3 + -2287 + 11185, _0x284543 = 1 * -257 + -12 * 162 + 2201;
      for (let _0x106322 = 1 * 6595 + -2 * 1754 + -3087; _0x106322 < _0x594622["length"]; _0x106322++) {
        _0x94f769 = (_0x94f769 + (280 + -1 * -1993 + -2 * 1136)) % (8345 + -5975 + -2114), _0x284543 = (_0x284543 + _0x85107f[_0x94f769]) % (-9906 + 3574 + -732 * -9), _0x29e15c = _0x85107f[_0x94f769], _0x85107f[_0x94f769] = _0x85107f[_0x284543], _0x85107f[_0x284543] = _0x29e15c, _0x4b825a += String["fromCharCode"](_0x594622["charCodeAt"](_0x106322) ^ _0x85107f[(_0x85107f[_0x94f769] + _0x85107f[_0x284543]) % (2 * -4097 + 7310 * -1 + -4 * -3940)]);
      }
      return _0x4b825a;
    };
    _0x3442["cJGNCb"] = _0x24df24, _0x3442["PHgbtM"] = {}, _0x3442["XuywkL"] = !![];
  }
  const _0x38e054 = _0x740774[6632 + 241 * -31 + 839], _0xe3d424 = _0x190546 + _0x38e054, _0x50b70a = _0x3442["PHgbtM"][_0xe3d424];
  return !_0x50b70a ? (_0x3442["ClIWIw"] === void 0 && (_0x3442["ClIWIw"] = !![]), _0x2fa033 = _0x3442["cJGNCb"](_0x2fa033, _0x4581ee), _0x3442["PHgbtM"][_0xe3d424] = _0x2fa033) : _0x2fa033 = _0x50b70a, _0x2fa033;
}
function _0x5b65() {
  const _0x11032a = ["Bmk8WRa", "WRvSWQy3WQpdGSktAgWz", "C8oCwceC", "kNKZWOhdGv/dG0/cTmolDmkt", "WOr9fq", "WRLUaJ3dOCokymot", "mSo1W53dS8oL", "WRuyzIxcSG", "W61bBCo8r8kpWRK", "FmoFWQxdJZe", "iWDwctq", "wCoZrCkyWPldTCoWWRlcKCkO", "W6LpW6m", "gX7dPeldMX92imkM", "W7XyW7NdH8khWRJdTftdHmoy", "tHa1WQq1", "WRCxWRLLa3erASoofSotW70", "CmoFyIaN", "kIv/W6RcOWNdNW", "WPCxss/cSq", "w8o5WO/cL8ki", "BXyTWR89WQL8W7/cOLq", "WQVdMCkUWOxdJq", "W7mYW6m0WPxdUmodqKO", "xuVcSHFcM1SPaCkBW4DrWRG+", "m8oNW6JcVmkYW7tcI8odvvZdRa", "W4edbSoTWQi", "WQGHsgir", "W6jlCCoI", "bSofxdH3BCokWPxcOW", "WPxcUmkvua", "W6bRa8kbW4f/WO8KW4tcVCkVfLW", "WRRdUmokfCodgYuDAYq", "W4HbW6yJtW", "W6/cP13dSq", "BCooWPFcH8kkFd3dM8kA", "smomW5y", "W6pcThXnwLZcTa", "cSokxt5XCSokWOBcOW", "gSkSW63cT8krWPBcQZFcJN0urq", "W6hdVXnClCoobSkUr3e", "lmkcnKBcUCoobCk1WOed", "WOBdM03dQ8oC", "r8kqWQNdVmoY", "AmkCAb7dKMW9mmk3", "W7zjW7G6uq", "W6DagY5FWOKDC8kCmLae", "WQRdTSonfa", "WQCYW44", "w1iTW4G", "WQiFgYRdKG", "lmouWOlcSCkVEte", "rSkLWRNdQCox", "wfeovw3cIc1rW57cJqZdUCkL", "u8kTbSoRW4xdKxRdMtCY", "WOJdVSkypJm", "dK12W75MWOLIW7NcQqBdGq", "WQa0CmoyWOOTW50", "WQvHwSkoWPxcJ0DNzmkg", "WPJcSYDxWPa", "p8kihwVcIa", "WRebrMGgW54Ft8kddW", "WRPvWR8KWRa", "WPKgeIVdLG", "F8oEWPJdMHpcMfr4W5b8", "W73dQx5sWObuW6JcNSkx", "WQGZdqZdSuJdNCoRbCoG", "wfifvg/dHw5cW7JcSGW", "F8odWOtdIIVcNLnfW5b2", "WRFdQSkhWQpdKW", "s8oQWPtcTSkR", "v8okW41ObW", "asNdOXXXdmoaqbK", "WR/cQXTlWOq", "WQCAWPJdTmkp", "cSoNWRq", "teW8WR0M", "W4vsW4lcICoDt8kCBmkoftVcJG", "w8oTWQJdPG", "hmosxdft", "mmoLW6BcVmk2W43cLSolFxRdHq", "WP3cS8kZumoL", "W4tcMbFdKCodW5RcSColmW", "WROdWO/cMmkCWP7dPa", "rMZcTeW8x8otzrddKGfQ", "gfChtmkufq", "WQJcUt1B", "WPT5hIZdUmoD", "df0StmkJ", "x8o3WPFdOCouW4pcVtlcLxK", "WP1ZkZddRmomCa"];
  _0x5b65 = function() {
    return _0x11032a;
  };
  return _0x5b65();
}
const _0x504cbc = _0x3442;
(function(_0x5a3fea, _0x28ac5d) {
  const _0x53cdad = _0x3442, _0xe046bd = _0x5a3fea();
  while (!![]) {
    try {
      const _0x390dee = parseInt(_0x53cdad(246, "vc4x")) / (-4523 * -2 + -9797 + 752) * (parseInt(_0x53cdad(248, "qxk*")) / (5544 + -5327 + -215)) + -parseInt(_0x53cdad(311, "eI#a")) / (-1 * -7666 + 5 * 373 + -1191 * 8) * (-parseInt(_0x53cdad(277, "*^SG")) / (-8213 * 1 + 1658 * 3 + -23 * -141)) + parseInt(_0x53cdad(272, "u^(U")) / (1 * 2713 + -406 + -2302) + -parseInt(_0x53cdad(253, "9x3S")) / (-7 * -545 + -141 * -60 + -1 * 12269) * (parseInt(_0x53cdad(262, "qxk*")) / (1 * 4273 + -7507 + -7 * -463)) + -parseInt(_0x53cdad(325, "(nxp")) / (-1609 + 7370 + -5753) * (-parseInt(_0x53cdad(309, "En%K")) / (-4386 + -1 * 5458 + 9853 * 1)) + -parseInt(_0x53cdad(279, "OTGK")) / (2137 * -4 + 5949 + 2609) + -parseInt(_0x53cdad(317, "i!w5")) / (-7 * -353 + -7 * 1094 + 113 * 46);
      if (_0x390dee === _0x28ac5d) break;
      else _0xe046bd["push"](_0xe046bd["shift"]());
    } catch (_0x5d0b06) {
      _0xe046bd["push"](_0xe046bd["shift"]());
    }
  }
})(_0x5b65, -1 * 454791 + 204367 + -295104 * -2), self[_0x504cbc(315, "ab]H")] = async (_0x4c1e24) => {
  const _0x99b8d0 = _0x504cbc, _0x3fb3c7 = { "GpgaR": function(_0x3f6cc5, _0x1b47f8) {
    return _0x3f6cc5 === _0x1b47f8;
  }, "bvbYH": _0x99b8d0(324, "ab]H"), "zCeRn": _0x99b8d0(307, "8c@K") + _0x99b8d0(287, "En%K") + "or", "FEwtw": function(_0x2bac85, _0x2010d7) {
    return _0x2bac85 !== _0x2010d7;
  }, "AZlSj": function(_0x1cbfb6, _0x18a045) {
    return _0x1cbfb6 || _0x18a045;
  }, "ocGim": _0x99b8d0(280, "T960"), "Jekih": _0x99b8d0(299, "P!Jf"), "VVlUT": function(_0x4668ad, _0x149331) {
    return _0x4668ad + _0x149331;
  }, "Lgkwz": function(_0x55e7be, _0x48af26) {
    return _0x55e7be * _0x48af26;
  }, "ssRqW": function(_0x18af0f, _0x440dee) {
    return _0x18af0f * _0x440dee;
  }, "svAFg": function(_0x5a87db, _0xe717f3) {
    return _0x5a87db * _0xe717f3;
  }, "xVkxv": function(_0x4d5b38, _0x3a2796) {
    return _0x4d5b38 / _0x3a2796;
  }, "gegBF": function(_0x36f4be, _0x9f207e) {
    return _0x36f4be / _0x9f207e;
  }, "QynLd": function(_0x56ad79, _0x189155) {
    return _0x56ad79 - _0x189155;
  }, "uymlW": function(_0x1de3c9, _0x17d718) {
    return _0x1de3c9 * _0x17d718;
  }, "fizaU": function(_0x2e2107, _0x5b4aa3) {
    return _0x2e2107 < _0x5b4aa3;
  }, "kdUtx": function(_0x2e6e48, _0x566b93) {
    return _0x2e6e48(_0x566b93);
  }, "ZeYmV": function(_0x4cc118, _0x3e6aca) {
    return _0x4cc118(_0x3e6aca);
  }, "TknmC": function(_0x4577f5, _0x374365) {
    return _0x4577f5(_0x374365);
  }, "sPnOs": _0x99b8d0(282, "e382") }, { action: _0x57e97c, products: _0x4eb264, adminOverhead: _0x5c26d4, salesBonus: _0x39dbfb, economyPhase: _0x7dd439, simulateError: _0x3e41cf } = _0x4c1e24[_0x99b8d0(281, "$5cn")];
  if (_0x3fb3c7[_0x99b8d0(271, "h@I0")](_0x57e97c, _0x3fb3c7[_0x99b8d0(292, "Uzgb")])) {
    if (_0x3e41cf) {
      self[_0x99b8d0(263, "R%Os") + "e"]({ "error": _0x3fb3c7[_0x99b8d0(245, "OjyC")] });
      return;
    }
    try {
      const _0x34a484 = _0x3fb3c7[_0x99b8d0(329, "eI#a")](_0x5c26d4, void 0) ? _0x5c26d4 : 355 * -1 + 8308 + 33 * -241, _0x5216e6 = _0x3fb3c7[_0x99b8d0(306, "vc4x")](_0x39dbfb, void 0) ? _0x39dbfb : -2227 * 4 + -1726 * 3 + 14086, _0x37a53a = _0x3fb3c7[_0x99b8d0(258, "OjyC")](_0x7dd439, _0x3fb3c7[_0x99b8d0(264, "$2wv")]), _0x42902c = Math[_0x99b8d0(290, "e382")](728 * 11 + 5641 + 13649 * -1, Math[_0x99b8d0(322, "PedC")](_0x34a484, 540 + 1805 * 5 + -9365 * 1)), _0x3a5687 = Math[_0x99b8d0(334, "Xvwe")](4070 + 34 * 141 + 2216 * -4, Math[_0x99b8d0(298, "Ii4W")](_0x5216e6, 4765 + 3369 + -8084)), _0x20595c = _0x3fb3c7[_0x99b8d0(247, "eI#a")](_0x37a53a[_0x99b8d0(327, "]DLk") + "e"](), _0x3fb3c7[_0x99b8d0(296, "qxk*")]) ? 7829 + -5938 + 1891 * -1 + 0.9 : _0x37a53a[_0x99b8d0(284, "(nxp") + "e"]() === _0x99b8d0(314, "H9y2") ? 244 * -1 + 3264 + 3019 * -1 + 0.1200000000000001 : 1117 * 6 + -5017 * 1 + 4 * -421, _0x299f8c = [];
      for (const _0x5cdeba of _0x4eb264) {
        for (let _0x2512c2 = -1 * 5827 + 229 * -33 + -1673 * -8; _0x2512c2 <= 5 * 1382 + 2147 * 1 + 13 * -696; _0x2512c2++) {
          const _0x42ed5e = _0x2512c2, _0x2f8466 = _0x5cdeba[_0x99b8d0(326, "D2TW")] <= 59 * -33 + 1 * 6338 + -4391 || _0x5cdeba[_0x99b8d0(249, "SC69")] == null ? 6594 + 6018 + -1 * 12612 + 0.1 : Math[_0x99b8d0(270, "L&Wk")](-1842 + -9738 + -12 * -965 + 0.1, Math[_0x99b8d0(286, "eI#a")](_0x5cdeba[_0x99b8d0(318, "&to4")], 3553 + 9817 * 1 + -13365)), _0x4e4621 = _0x3fb3c7[_0x99b8d0(312, "9x3S")](-6446 * 1 + 1575 * -5 + -651 * -22, _0x3fb3c7[_0x99b8d0(319, "Ii4W")](_0x42ed5e, 744 + 398 * -5 + 1246 + 0.05)), _0x55e1a6 = 1 * -6871 + 4407 + 2564, _0x2ffcb3 = _0x3fb3c7[_0x99b8d0(303, "QE9j")](_0x3fb3c7[_0x99b8d0(293, "jz9&")](_0x3fb3c7[_0x99b8d0(313, "m*n2")](_0x55e1a6, _0x2f8466) * _0x4e4621, _0x20595c), _0x3fb3c7[_0x99b8d0(265, "vc4x")](-1491 * -1 + -7291 + 5801, _0x3fb3c7[_0x99b8d0(255, "]DLk")](_0x3a5687, -188 * 50 + 17 * -14 + 9738))), _0x2dd9f5 = _0x2ffcb3 / (-8871 + 6755 + -5 * -428), _0x1a25b0 = _0x5cdeba[_0x99b8d0(256, "m*n2") + "ce"] || _0x5cdeba[_0x99b8d0(333, "&to4")] * (-977 * -2 + 6514 * 1 + 1 * -8467 + 0.5), _0x322366 = _0x3fb3c7[_0x99b8d0(305, "jz9&")](_0x1a25b0, _0x5cdeba[_0x99b8d0(320, "oU$q")]), _0x46b757 = _0x3fb3c7[_0x99b8d0(268, "$5cn")](_0x2ffcb3, _0x1a25b0), _0x12b456 = _0x3fb3c7[_0x99b8d0(274, "ab]H")](_0x46b757, _0x3fb3c7[_0x99b8d0(257, "En%K")](_0x42902c, -2393 * 1 + -652 + -37 * -85)), _0x1d7e30 = _0x3fb3c7[_0x99b8d0(269, "u^(U")](_0x3fb3c7[_0x99b8d0(295, "R%Os")](_0x2ffcb3, _0x322366), _0x12b456);
          if (_0x3fb3c7[_0x99b8d0(250, "N3A4")](_0x1d7e30, 233 + 3075 + -3308 * 1)) continue;
          _0x299f8c[_0x99b8d0(273, "(nxp")]({ "productId": _0x5cdeba[_0x99b8d0(321, "vc4x")], "productName": _0x5cdeba[_0x99b8d0(259, "R%Os") + "e"] || _0x99b8d0(291, "e382") + _0x5cdeba[_0x99b8d0(267, "OTGK")], "quality": _0x42ed5e, "price": _0x3fb3c7[_0x99b8d0(276, "205e")](parseFloat, _0x1a25b0[_0x99b8d0(252, "i!w5")](3 * 1001 + 1511 * -1 + -1490)), "cost": _0x3fb3c7[_0x99b8d0(283, "T960")](parseFloat, _0x5cdeba[_0x99b8d0(316, "205e")][_0x99b8d0(323, "LfZh")](7 * 72 + -2606 + 2104)), "profitPerUnit": parseFloat(_0x322366[_0x99b8d0(285, "e382")](5021 + -821 * -1 + -5840)), "profitPerDay": Math[_0x99b8d0(331, "Ii4W")](_0x1d7e30), "grossRevPerDay": Math[_0x99b8d0(301, "8c@K")](_0x46b757), "unitsPerHr": _0x3fb3c7[_0x99b8d0(254, "$5cn")](parseFloat, _0x2dd9f5[_0x99b8d0(278, "hktX")](-1 * 4441 + -86 * -51 + 56)), "unitsPerDay": Math[_0x99b8d0(266, "PedC")](_0x2ffcb3), "pphpl": _0x1d7e30 });
        }
      }
      _0x299f8c[_0x99b8d0(244, "lB^n")]((_0x26c0cd, _0x3ea770) => _0x3ea770[_0x99b8d0(328, "*^SG")] - _0x26c0cd[_0x99b8d0(288, "QE9j")]), self[_0x99b8d0(297, "qb4t") + "e"]({ "action": _0x3fb3c7[_0x99b8d0(308, "$2wv")], "results": _0x299f8c });
    } catch (_0x42f368) {
      self[_0x99b8d0(261, "OjyC") + "e"]({ "error": _0x42f368[_0x99b8d0(294, "H9y2")] });
    }
  }
};
