function _0x44c7(_0x150fd0, _0x2e4760) {
  _0x150fd0 = _0x150fd0 - (57 * -99 + -4042 + 9963);
  var _0x16913c = _0x3c05();
  var _0x4bc5dc = _0x16913c[_0x150fd0];
  if (_0x44c7["mWONBA"] === void 0) {
    var _0x2e9eed = function(_0x4ce3c4) {
      var _0xb6f4c7 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x31c7ac = "", _0x1faea4 = "";
      for (var _0x54f11f = -1 * 8539 + -9327 + 17866, _0x285301, _0x528309, _0x3ee51c = -1 * -987 + -7 * 500 + 2513; _0x528309 = _0x4ce3c4["charAt"](_0x3ee51c++); ~_0x528309 && (_0x285301 = _0x54f11f % (49 * 158 + 9377 + -17115) ? _0x285301 * (491 * 5 + -2 * -2711 + 1 * -7813) + _0x528309 : _0x528309, _0x54f11f++ % (1759 * -5 + -6118 + 7 * 2131)) ? _0x31c7ac += String["fromCharCode"](3437 + 5069 + -8251 & _0x285301 >> (-(1982 * 2 + 1357 * -7 + -791 * -7) * _0x54f11f & -9010 + 8453 + 563)) : -6 * -505 + 4873 + 7 * -1129) {
        _0x528309 = _0xb6f4c7["indexOf"](_0x528309);
      }
      for (var _0x53514e = -11 * 65 + -1 * 7447 + -583 * -14, _0x41c4b6 = _0x31c7ac["length"]; _0x53514e < _0x41c4b6; _0x53514e++) {
        _0x1faea4 += "%" + ("00" + _0x31c7ac["charCodeAt"](_0x53514e)["toString"](-3856 * -1 + -11 * 64 + -3136))["slice"](-(727 * -5 + -4828 + -8465 * -1));
      }
      return decodeURIComponent(_0x1faea4);
    };
    var _0x1b5260 = function(_0x1e3133, _0x2bb528) {
      var _0x9c511f = [], _0x5bbbf4 = -4265 + 3438 + 827, _0x1dd212, _0x5d6699 = "";
      _0x1e3133 = _0x2e9eed(_0x1e3133);
      var _0x1d6b97;
      for (_0x1d6b97 = 1 * 724 + 151 * 51 + -1685 * 5; _0x1d6b97 < -26 * -78 + 1 * 9003 + -10775; _0x1d6b97++) {
        _0x9c511f[_0x1d6b97] = _0x1d6b97;
      }
      for (_0x1d6b97 = 8600 + 3673 * -1 + -4927; _0x1d6b97 < -9836 * -1 + 314 * -7 + -7382; _0x1d6b97++) {
        _0x5bbbf4 = (_0x5bbbf4 + _0x9c511f[_0x1d6b97] + _0x2bb528["charCodeAt"](_0x1d6b97 % _0x2bb528["length"])) % (-4146 * 1 + 1 * 3671 + -1 * -731), _0x1dd212 = _0x9c511f[_0x1d6b97], _0x9c511f[_0x1d6b97] = _0x9c511f[_0x5bbbf4], _0x9c511f[_0x5bbbf4] = _0x1dd212;
      }
      _0x1d6b97 = -21 * -29 + -5 * -480 + -3009, _0x5bbbf4 = 6516 + -404 * 11 + 2 * -1036;
      for (var _0x397a01 = -3288 + 3833 + -545; _0x397a01 < _0x1e3133["length"]; _0x397a01++) {
        _0x1d6b97 = (_0x1d6b97 + (-3533 + -9157 + 12691)) % (-1 * 7369 + 8685 + -106 * 10), _0x5bbbf4 = (_0x5bbbf4 + _0x9c511f[_0x1d6b97]) % (776 + -1 * -5552 + -6072), _0x1dd212 = _0x9c511f[_0x1d6b97], _0x9c511f[_0x1d6b97] = _0x9c511f[_0x5bbbf4], _0x9c511f[_0x5bbbf4] = _0x1dd212, _0x5d6699 += String["fromCharCode"](_0x1e3133["charCodeAt"](_0x397a01) ^ _0x9c511f[(_0x9c511f[_0x1d6b97] + _0x9c511f[_0x5bbbf4]) % (-413 * 1 + -9327 + -294 * -34)]);
      }
      return _0x5d6699;
    };
    _0x44c7["saJVUo"] = _0x1b5260, _0x44c7["PrIqus"] = {}, _0x44c7["mWONBA"] = !![];
  }
  var _0x2cc7eb = _0x16913c[-3306 + -7863 + 11169], _0xa1b21b = _0x150fd0 + _0x2cc7eb, _0xff80e0 = _0x44c7["PrIqus"][_0xa1b21b];
  return !_0xff80e0 ? (_0x44c7["PJryhD"] === void 0 && (_0x44c7["PJryhD"] = !![]), _0x4bc5dc = _0x44c7["saJVUo"](_0x4bc5dc, _0x2e4760), _0x44c7["PrIqus"][_0xa1b21b] = _0x4bc5dc) : _0x4bc5dc = _0xff80e0, _0x4bc5dc;
}
(function(_0x5cc425, _0x412252) {
  var _0x599084 = _0x44c7, _0x165a7d = _0x5cc425();
  while (!![]) {
    try {
      var _0x334c91 = -parseInt(_0x599084(288, "%egh")) / (6041 + 8630 + -14670) + -parseInt(_0x599084(279, "cyoH")) / (1253 + 3 * 45 + -1386) * (parseInt(_0x599084(284, "#lCc")) / (765 * 11 + 5807 + 14219 * -1)) + -parseInt(_0x599084(281, "#lCc")) / (-1505 + 44 * -32 + 1 * 2917) * (parseInt(_0x599084(285, "0&Yj")) / (-688 * -1 + -1 * 2815 + 1 * 2132)) + parseInt(_0x599084(287, "PFUS")) / (8014 + -3294 + -4714) * (-parseInt(_0x599084(293, "HbSO")) / (-2 * -205 + 7938 + -8341)) + parseInt(_0x599084(298, "P&7!")) / (-6 * -191 + 4501 + -5639 * 1) * (-parseInt(_0x599084(290, "VFyz")) / (-3861 + 478 * -18 + 12474)) + parseInt(_0x599084(295, "IV&a")) / (4405 + -1340 + -65 * 47) + parseInt(_0x599084(291, "OIoA")) / (4126 + 7 * -190 + -2785 * 1);
      if (_0x334c91 === _0x412252) break;
      else _0x165a7d["push"](_0x165a7d["shift"]());
    } catch (_0x2d0187) {
      _0x165a7d["push"](_0x165a7d["shift"]());
    }
  }
})(_0x3c05, 1 * 912727 + -5 * -118181 + -1 * 688567);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
function _0x3c05() {
  var _0x17360e = ["FCoPFK9brmo4fCo4WQ3dSW", "qMNcIJldKSknWOVcT2xdRCoPWPtcRa", "kHBdULhdTCkdWRm", "i8kJW4pcHNalWPJdT3L+W4VdSdG", "W6XZW6vguNxdHW", "DJuHW6f7rCkXWPRdRmkZ", "WQ/cULFdMmoMicZdQxJdGH4", "W7JcJmocf8kKxctdQ8kQFW", "W6TuztRdLSo2WP3cRfbLW5q", "fq/cVmoxWPvZW6ehW5nYW68CW6rt", "W5mbDLFcSSoAWQuOwmknDa", "W4JcMqFdHCowfYuLfCkysq", "fCkAE2iKDuO/cSoQW5K", "h8kvDMeVismGnCovW5VcGCkA", "zJldKL9JW6xcRIrt", "W4/cNGBdJmotsvXqeCkRs8ojw8o1", "aG9bWRZcQmkfemksrG", "W5voWPhcJSkdy8kjDHSfeZRdLq", "cIFdRg/cNdDuWPCOW6NdOG", "W7xdG3xcQZiBlf3cLLSB", "E8oPkHW2rmo4mG", "lNBdUwRdJ8kZWOmW"];
  _0x3c05 = function() {
    return _0x17360e;
  };
  return _0x3c05();
}
