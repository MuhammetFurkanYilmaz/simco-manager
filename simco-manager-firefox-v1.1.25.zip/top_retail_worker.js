function _0x492a(_0x356a5d, _0x7da83c) {
  _0x356a5d = _0x356a5d - (157 * -30 + -4098 + 89 * 101);
  const _0x5db3d4 = _0x31d9();
  let _0x40c61f = _0x5db3d4[_0x356a5d];
  if (_0x492a["FjYrEn"] === void 0) {
    var _0x1df0b4 = function(_0x4094f0) {
      const _0x18b2e5 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x300d92 = "", _0x139fc1 = "";
      for (let _0x2ef2e5 = -1 * -9001 + 2667 * -3 + 1 * -1e3, _0x1543ad, _0x3897ad, _0x382082 = 6289 + 6947 + -13236; _0x3897ad = _0x4094f0["charAt"](_0x382082++); ~_0x3897ad && (_0x1543ad = _0x2ef2e5 % (15 * 586 + -348 * 4 + -7394) ? _0x1543ad * (-7827 + -4 * -1873 + -19 * -21) + _0x3897ad : _0x3897ad, _0x2ef2e5++ % (-882 + 9697 * -1 + 19 * 557)) ? _0x300d92 += String["fromCharCode"](8320 + 7 * 416 + -10977 & _0x1543ad >> (-(4155 + 3503 * 1 + -1276 * 6) * _0x2ef2e5 & 5213 + 848 * -10 + 3 * 1091)) : -2142 + 7371 + -5229) {
        _0x3897ad = _0x18b2e5["indexOf"](_0x3897ad);
      }
      for (let _0x517eb5 = -9282 + 580 + -4351 * -2, _0x4e011c = _0x300d92["length"]; _0x517eb5 < _0x4e011c; _0x517eb5++) {
        _0x139fc1 += "%" + ("00" + _0x300d92["charCodeAt"](_0x517eb5)["toString"](-25 * -213 + -9 * -463 + -9476))["slice"](-(-8 * 440 + -8523 + 11 * 1095));
      }
      return decodeURIComponent(_0x139fc1);
    };
    const _0x2569af = function(_0xa3dbbd, _0x407fd9) {
      let _0x191c44 = [], _0x395d5d = -5040 + -1146 + 6186, _0x203597, _0x27a1c1 = "";
      _0xa3dbbd = _0x1df0b4(_0xa3dbbd);
      let _0x14cc1d;
      for (_0x14cc1d = 4759 + 1838 * -1 + -127 * 23; _0x14cc1d < 5495 + -4552 + 229 * -3; _0x14cc1d++) {
        _0x191c44[_0x14cc1d] = _0x14cc1d;
      }
      for (_0x14cc1d = 6307 + 3002 + -9309; _0x14cc1d < 6751 + -21 * -358 + 1557 * -9; _0x14cc1d++) {
        _0x395d5d = (_0x395d5d + _0x191c44[_0x14cc1d] + _0x407fd9["charCodeAt"](_0x14cc1d % _0x407fd9["length"])) % (2416 * -1 + 97 * -93 + 11693), _0x203597 = _0x191c44[_0x14cc1d], _0x191c44[_0x14cc1d] = _0x191c44[_0x395d5d], _0x191c44[_0x395d5d] = _0x203597;
      }
      _0x14cc1d = -5132 + -8462 * -1 + 30 * -111, _0x395d5d = 93 * -17 + -8387 + -4984 * -2;
      for (let _0x1e3e54 = -3790 + -4011 + -269 * -29; _0x1e3e54 < _0xa3dbbd["length"]; _0x1e3e54++) {
        _0x14cc1d = (_0x14cc1d + (-4 * 519 + -1 * -1939 + 138)) % (3734 + 1089 + -4567), _0x395d5d = (_0x395d5d + _0x191c44[_0x14cc1d]) % (-4969 * -2 + -8933 * 1 + 107 * -7), _0x203597 = _0x191c44[_0x14cc1d], _0x191c44[_0x14cc1d] = _0x191c44[_0x395d5d], _0x191c44[_0x395d5d] = _0x203597, _0x27a1c1 += String["fromCharCode"](_0xa3dbbd["charCodeAt"](_0x1e3e54) ^ _0x191c44[(_0x191c44[_0x14cc1d] + _0x191c44[_0x395d5d]) % (106 * 17 + 1 * 6271 + 1 * -7817)]);
      }
      return _0x27a1c1;
    };
    _0x492a["mOhneP"] = _0x2569af, _0x492a["dtdWfJ"] = {}, _0x492a["FjYrEn"] = !![];
  }
  const _0x5570d0 = _0x5db3d4[-5209 + 279 * -32 + -14137 * -1], _0x28339e = _0x356a5d + _0x5570d0, _0xb7bb8d = _0x492a["dtdWfJ"][_0x28339e];
  return !_0xb7bb8d ? (_0x492a["UGjJSG"] === void 0 && (_0x492a["UGjJSG"] = !![]), _0x40c61f = _0x492a["mOhneP"](_0x40c61f, _0x7da83c), _0x492a["dtdWfJ"][_0x28339e] = _0x40c61f) : _0x40c61f = _0xb7bb8d, _0x40c61f;
}
const _0x57be88 = _0x492a;
(function(_0x33683f, _0x5a1f69) {
  const _0x4ff966 = _0x492a, _0x33cd0f = _0x33683f();
  while (!![]) {
    try {
      const _0x14dc5a = parseInt(_0x4ff966(184, "fi5o")) / (97 * 93 + 8928 + -17948) + -parseInt(_0x4ff966(258, "y5!4")) / (-1 * -9577 + -9235 + -34 * 10) * (parseInt(_0x4ff966(211, "QSkk")) / (1492 + -3 * 2751 + 76 * 89)) + -parseInt(_0x4ff966(249, "eGZU")) / (5614 + 3268 + -8878) * (-parseInt(_0x4ff966(231, "JJi$")) / (14 + 5 * 1154 + 1 * -5779)) + -parseInt(_0x4ff966(206, "fi5o")) / (40 * 133 + -1 * 9609 + 4295) * (parseInt(_0x4ff966(219, "tN0H")) / (-2332 * -3 + 1546 * -2 + -3897)) + parseInt(_0x4ff966(190, "KzpQ")) / (-4543 * 1 + -545 + 5096) + parseInt(_0x4ff966(247, "fei@")) / (-5644 + 472 * -9 + 9901) + parseInt(_0x4ff966(213, "&2T(")) / (8375 + 1415 * 5 + -15440);
      if (_0x14dc5a === _0x5a1f69) break;
      else _0x33cd0f["push"](_0x33cd0f["shift"]());
    } catch (_0x30dd3f) {
      _0x33cd0f["push"](_0x33cd0f["shift"]());
    }
  }
})(_0x31d9, 366471 + -762265 + -1 * -1181633), self[_0x57be88(204, "ITw7")] = async (_0x45177b) => {
  const _0x3e86c3 = _0x57be88, _0x24abf8 = { "oxaeT": _0x3e86c3(191, "fM#P"), "VHzZD": _0x3e86c3(227, "vPAX") + _0x3e86c3(237, "EyEM") + "or", "JwAVJ": function(_0x5e0ff4, _0x206bb6) {
    return _0x5e0ff4 !== _0x206bb6;
  }, "TFJuT": function(_0xc3376d, _0x59afa8) {
    return _0xc3376d || _0x59afa8;
  }, "kbBfj": _0x3e86c3(236, "KzpQ"), "dTvlL": function(_0x3bdd3c, _0x59ad9d) {
    return _0x3bdd3c === _0x59ad9d;
  }, "rsoMv": _0x3e86c3(233, "Cwxw"), "EiOoi": function(_0x3a631d, _0x1ff506) {
    return _0x3a631d === _0x1ff506;
  }, "QHoee": _0x3e86c3(234, "&2T("), "XVOvm": function(_0x5b1633, _0x594346) {
    return _0x5b1633 == _0x594346;
  }, "VTtMb": function(_0x5ea0c5, _0x27b05a) {
    return _0x5ea0c5 + _0x27b05a;
  }, "sSkuF": function(_0x28c3a3, _0x349bf0) {
    return _0x28c3a3 * _0x349bf0;
  }, "cGhUe": function(_0x33f7c4, _0x5ad421) {
    return _0x33f7c4 / _0x5ad421;
  }, "EQCSK": function(_0x5b5e18, _0x237e19) {
    return _0x5b5e18 + _0x237e19;
  }, "mcgYR": function(_0x86122f, _0x42a63c) {
    return _0x86122f / _0x42a63c;
  }, "eZJqU": function(_0x2d48da, _0x220610) {
    return _0x2d48da / _0x220610;
  }, "nAkzl": function(_0x2099c8, _0x4b49d3) {
    return _0x2099c8 * _0x4b49d3;
  }, "cfJnF": function(_0x1be08b, _0x3f843d) {
    return _0x1be08b - _0x3f843d;
  }, "hxoYB": function(_0x1671dc, _0x58c025) {
    return _0x1671dc * _0x58c025;
  }, "dOMdO": function(_0x3dc426, _0x4ee385) {
    return _0x3dc426 < _0x4ee385;
  }, "YhGMN": function(_0x4c448f, _0x4f6737) {
    return _0x4c448f(_0x4f6737);
  }, "NigIQ": function(_0xc1c99f, _0x187da0) {
    return _0xc1c99f(_0x187da0);
  }, "HNLqf": function(_0x5e485a, _0x2dda38) {
    return _0x5e485a(_0x2dda38);
  }, "cVFGx": _0x3e86c3(245, "tN0H") }, { action: _0xa727ec, products: _0x4be409, adminOverhead: _0x81c2ed, salesBonus: _0x50f6c1, economyPhase: _0x168e08, simulateError: _0x18fbf6 } = _0x45177b[_0x3e86c3(265, "eaoY")];
  if (_0xa727ec === _0x24abf8[_0x3e86c3(202, "QYok")]) {
    if (_0x18fbf6) {
      self[_0x3e86c3(200, "^&*L") + "e"]({ "error": _0x24abf8[_0x3e86c3(253, "KzpQ")] });
      return;
    }
    try {
      const _0x3e30e8 = _0x24abf8[_0x3e86c3(250, "e7)0")](_0x81c2ed, void 0) ? _0x81c2ed : 3 * 2965 + -4221 + -82 * 57, _0x521857 = _0x50f6c1 !== void 0 ? _0x50f6c1 : -3 * -3047 + -17 * -157 + 10 * -1181, _0x53dcb6 = _0x24abf8[_0x3e86c3(193, "&2T(")](_0x168e08, _0x24abf8[_0x3e86c3(244, "#c32")]), _0x53575d = Math[_0x3e86c3(256, "4s!^")](-915 * -6 + -8782 + 3292, Math[_0x3e86c3(269, "e7)0")](_0x3e30e8, -3092 + -59 * 9 + 3823)), _0x52c659 = Math[_0x3e86c3(222, "3!j7")](-1300 + 860 + 440, Math[_0x3e86c3(226, "tN0H")](_0x521857, -439 + 9638 * 1 + 9149 * -1)), _0x1046f3 = _0x24abf8[_0x3e86c3(260, "6O46")](_0x53dcb6[_0x3e86c3(243, "OpBw") + "e"](), _0x24abf8[_0x3e86c3(209, "^&*L")]) ? -1 * 4607 + 4104 + 503 + 0.9 : _0x24abf8[_0x3e86c3(225, "&2T(")](_0x53dcb6[_0x3e86c3(214, "vPAX") + "e"](), _0x24abf8[_0x3e86c3(259, "eaoY")]) ? -2115 + -22 * 311 + 8958 + 0.1200000000000001 : -31 * -179 + -1 * 1063 + -115 * 39, _0x9ddf58 = [];
      for (const _0x4ae74b of _0x4be409) {
        for (let _0x4b977b = -2869 + 1 * 5527 + -2658; _0x4b977b <= 8437 + -528 + -7900; _0x4b977b++) {
          const _0xacba4e = _0x4b977b, _0x494cda = _0x4ae74b[_0x3e86c3(257, "3!j7")] <= 7772 * 1 + -2862 + -4910 || _0x24abf8[_0x3e86c3(199, "p4H4")](_0x4ae74b[_0x3e86c3(195, "fei@")], null) ? -9481 * -1 + 8561 + -291 * 62 + 0.1 : Math[_0x3e86c3(201, "8SFX")](9206 + -17 * 13 + -8985 + 0.1, Math[_0x3e86c3(181, "epDX")](_0x4ae74b[_0x3e86c3(223, "Yei^")], 3865 + 3473 * 1 + 1 * -7333)), _0x226ecf = _0x24abf8[_0x3e86c3(186, "siIt")](1838 + 4658 + -6495, _0x24abf8[_0x3e86c3(198, "jm6F")](_0xacba4e, 597 * 6 + 9303 + -12885 + 0.05)), _0x10cb37 = 1 * -8487 + -2914 + 11501, _0x2d4646 = _0x24abf8[_0x3e86c3(270, "#c32")](_0x24abf8[_0x3e86c3(217, "wHAo")](_0x24abf8[_0x3e86c3(242, "F2t(")](_0x10cb37, _0x494cda), _0x226ecf), _0x1046f3) * _0x24abf8[_0x3e86c3(267, "3!j7")](2002 + -4526 + 2525, _0x24abf8[_0x3e86c3(182, "fi5o")](_0x52c659, 8803 + 2 * -493 + -7717)), _0x29b8a0 = _0x24abf8[_0x3e86c3(215, "6O46")](_0x2d4646, -9562 + 4523 + -61 * -83), _0x430537 = _0x4ae74b[_0x3e86c3(224, "dzbs") + "ce"] || _0x24abf8[_0x3e86c3(229, "mitX")](_0x4ae74b[_0x3e86c3(188, "4s!^")], -486 + 2238 * -1 + 2725 + 0.5), _0x4b403f = _0x24abf8[_0x3e86c3(272, "QSkk")](_0x430537, _0x4ae74b[_0x3e86c3(262, "2l)Q")]), _0x3032b1 = _0x24abf8[_0x3e86c3(212, "97Ue")](_0x2d4646, _0x430537), _0x5698d9 = _0x24abf8[_0x3e86c3(220, "y5!4")](_0x3032b1, _0x53575d / (-7687 + -7641 + 15428)), _0x47ce2f = _0x24abf8[_0x3e86c3(208, "vPAX")](_0x2d4646, _0x4b403f) - _0x5698d9;
          if (_0x24abf8[_0x3e86c3(241, "7@vb")](_0x47ce2f, -3131 + 5043 + -1912)) continue;
          _0x9ddf58[_0x3e86c3(210, "QYok")]({ "productId": _0x4ae74b[_0x3e86c3(221, "oU$4")], "productName": _0x4ae74b[_0x3e86c3(207, "KzpQ") + "e"] || _0x3e86c3(185, "JJi$") + _0x4ae74b[_0x3e86c3(254, "kzl3")], "quality": _0xacba4e, "price": _0x24abf8[_0x3e86c3(268, "7Z5u")](parseFloat, _0x430537[_0x3e86c3(238, "97Ue")](-427 * -9 + 2613 + -6454)), "cost": _0x24abf8[_0x3e86c3(228, "epDX")](parseFloat, _0x4ae74b[_0x3e86c3(192, "Yei^")][_0x3e86c3(266, "fi5o")](-6416 + -1726 * 4 + 13322 * 1)), "profitPerUnit": _0x24abf8[_0x3e86c3(205, "2l)Q")](parseFloat, _0x4b403f[_0x3e86c3(255, "F2t(")](3167 * 1 + -158 * -2 + -3481)), "profitPerDay": Math[_0x3e86c3(246, "dzbs")](_0x47ce2f), "grossRevPerDay": Math[_0x3e86c3(189, "5Q!F")](_0x3032b1), "unitsPerHr": _0x24abf8[_0x3e86c3(239, "kzl3")](parseFloat, _0x29b8a0[_0x3e86c3(251, "epDX")](-9563 * -1 + -5409 + -4153)), "unitsPerDay": Math[_0x3e86c3(264, "2l)Q")](_0x2d4646), "pphpl": _0x47ce2f });
        }
      }
      _0x9ddf58[_0x3e86c3(261, "6O46")]((_0x40dc6f, _0x572921) => _0x572921[_0x3e86c3(197, "eGZU")] - _0x40dc6f[_0x3e86c3(271, "6O46")]), self[_0x3e86c3(230, "eaoY") + "e"]({ "action": _0x24abf8[_0x3e86c3(232, "kzl3")], "results": _0x9ddf58 });
    } catch (_0x375bac) {
      self[_0x3e86c3(187, "fei@") + "e"]({ "error": _0x375bac[_0x3e86c3(196, "eaoY")] });
    }
  }
};
function _0x31d9() {
  const _0x3e2819 = ["WQvEleiCpNfw", "oLWKWPxcMMRcIIDeWOZcMGWF", "hCobW60szq", "W5tcOSoBW7FdV8o+W7JdVvm", "W7KhdG", "WRWtC2S1W7XtEqBcGa", "W7L8ftxcN8oDW5ZdQSkxtG", "WPHUWPRcJmoY", "zan+", "WQRcNvxdMdhcIZxdOLKC", "W6nMWP/dIh8", "uCk4WOJcSWu", "AqqiW73cG8obW5xdK8oZW60", "WOBdRutcM8kiWPNdJCoM", "ubNcJ1ddKa", "qmkrW6FdJSkqW4miWPpdKq", "WR9OWRRcJG", "W4CWWOZcLZ7dM8o1WPFdGmkEWRFcHa", "WQVdKCoaadhdJa", "W7VcPaKCWR/cVmoyW4/cM8kw", "cCkbmmk0W77dMSkl", "EWhcHwBdJG", "W5FcJSoEfbxdLSo9tW", "W5HpWRJcGXO", "bmoluSoGsG", "WPOTv8k3WP4EW7tdSZHv", "W6lcM8kege0", "EW9JW5hdHcG", "W6PLbsNcMG", "BduYrYWpigXKaH8Xlq", "cCoiW5hdSve2W5DBW4FdM8o3WQ4", "WQRcII4vW6lcUmonWRGQWQRdSmoK", "dSkefWyJ", "W5LGWR7dQfyVoG", "v8kIs8oqW4ZdHvSPFCoRW6pdL1i", "WRpdTSoinXq", "qZ3cPNpdNCkRyxNdIa", "e8oJFmoCv8olBG", "W451WPa", "W6ChaMufc3vOwIm", "q8kiWRbZh1BdO8oAWRhdLCoGWOG", "scmuW6ZcQW", "fbDUW7ddHa", "aYXQW6G", "j1FdQmkk", "wemOWQJdTCkZWP7cVCkDW5nKCSkK", "nLFdRSkqeW", "FqOpW6G", "g8k2W6j9WO3cKv4", "W5e3num8", "WRr2x8oOla", "kCkAoa", "W7RcQSkTc2e", "adnWW6ZdPa", "WQ/dKu4IWQO", "W4bMWPy", "aSk6W4nnWQC", "W4P3W7pdGx7cHCok", "xSoRWPCHW4ZdGqiMdmoaD052", "W6tcR0FcHSk4WOZdKCki", "W5tcVKddJ8kE", "jgT0b1fzzxnTaq", "W4b7WPVdNa", "WQv8W6ZcG8o6", "W5hcI8kkwwNcKSkTCmkqW5VcV1FdRq", "cHbWW7pcUCoNW4/cPSkU", "WQWDDgO", "WOLbWP/cLSop", "WQ/cIIGxW6JcV8kzWPKPWQpdP8oWW4a", "j2vZbM5DyMLJca", "Da4iW7RcR8odW4m", "W67dIhnsWR0", "sCoEWRddPSk0", "WRWTxSk7jG", "W6dcQJFdPcTZyahdL8k7", "gWmr", "WOtdKZNcL8ki", "yhWiW5X+W5eaWO4kW47cGCoLkq", "W6RdK8omWRRdUSoeWPPofW", "dhBdL8kpeq", "xSoHW75gWP7cOeOj", "WPxdJmoDcsxdG8oHt8k0W5i", "WPhcJfFdTb8", "W6lcTIVdNra", "WPVdNIVcMG", "W7xdGK4TWP/dUSoQ", "dSk9hCkOW4a", "W6W1W6hdM8kIugysEcRdUcqb", "WO3cM3tdGIRcJZpdHfXp", "frLsW63dNq", "WOddNCkvWR3dGuHqomoQA3ShWQS", "WQhdImoZCZ8"];
  _0x31d9 = function() {
    return _0x3e2819;
  };
  return _0x31d9();
}
