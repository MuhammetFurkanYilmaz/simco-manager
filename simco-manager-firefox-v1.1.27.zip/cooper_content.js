(function(_0x5a25d5, _0x908d82) {
  var _0x3e1f24 = _0x3754, _0x36f36c = _0x5a25d5();
  while (!![]) {
    try {
      var _0x4e069f = -parseInt(_0x3e1f24(338, "TVEo")) / (5210 * -1 + -661 + 5872) + parseInt(_0x3e1f24(337, "C&&l")) / (-1883 * 2 + 4536 + -4 * 192) + parseInt(_0x3e1f24(325, "q!Gd")) / (-2767 + -5835 + 8605) * (parseInt(_0x3e1f24(323, "&cCt")) / (-9090 + -37 * 39 + 10537)) + -parseInt(_0x3e1f24(330, "zt&v")) / (7323 + -4960 * 2 + 2602) * (-parseInt(_0x3e1f24(334, "*Os&")) / (-4119 + 2 * -2191 + 8507)) + parseInt(_0x3e1f24(329, "4jU!")) / (1532 * 3 + 4153 + 8742 * -1) * (parseInt(_0x3e1f24(339, "Y&v5")) / (-6113 + -2 * -113 + 3 * 1965)) + -parseInt(_0x3e1f24(326, "2bXe")) / (-16 * -501 + -721 + -7286) * (-parseInt(_0x3e1f24(345, "&cCt")) / (94 + -2 * -3079 + -2 * 3121)) + parseInt(_0x3e1f24(346, "Ca&d")) / (-6865 + -3365 * 1 + 77 * 133) * (-parseInt(_0x3e1f24(340, "fCWJ")) / (-5585 + 3989 + 1608));
      if (_0x4e069f === _0x908d82) break;
      else _0x36f36c["push"](_0x36f36c["shift"]());
    } catch (_0x1e57c4) {
      _0x36f36c["push"](_0x36f36c["shift"]());
    }
  }
})(_0x5334, -252024 + 174430 + 880248);
function _0x3754(_0x20c9a5, _0x5006f6) {
  _0x20c9a5 = _0x20c9a5 - (1 * 2589 + 6233 + 2833 * -3);
  var _0x3e2c63 = _0x5334();
  var _0x58c3fc = _0x3e2c63[_0x20c9a5];
  if (_0x3754["lWEcwj"] === void 0) {
    var _0x74bc5a = function(_0x3dd09c) {
      var _0x5e7f6b = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x45b922 = "", _0x5c62c8 = "";
      for (var _0x23ee02 = 1648 + 1 * 8423 + 1119 * -9, _0x2d4cda, _0x5149bf, _0x550133 = -1 * 2476 + -1171 + -1 * -3647; _0x5149bf = _0x3dd09c["charAt"](_0x550133++); ~_0x5149bf && (_0x2d4cda = _0x23ee02 % (-2 * -153 + 8465 + -8767) ? _0x2d4cda * (-4033 + 11 * 909 + -5902) + _0x5149bf : _0x5149bf, _0x23ee02++ % (-13 * -383 + 3457 * -2 + 1 * 1939)) ? _0x45b922 += String["fromCharCode"](3576 + 4 * 433 + 31 * -163 & _0x2d4cda >> (-(-2021 + -130 * -67 + -6687) * _0x23ee02 & -8569 + 10 * -787 + 16445)) : -3471 * 1 + -2 * 39 + 3549) {
        _0x5149bf = _0x5e7f6b["indexOf"](_0x5149bf);
      }
      for (var _0x3977ce = 19 * 419 + 2 * -2667 + -2627, _0x289cae = _0x45b922["length"]; _0x3977ce < _0x289cae; _0x3977ce++) {
        _0x5c62c8 += "%" + ("00" + _0x45b922["charCodeAt"](_0x3977ce)["toString"](-9637 + -796 + 10449))["slice"](-(5236 + -1 * 8923 + 119 * 31));
      }
      return decodeURIComponent(_0x5c62c8);
    };
    var _0x45a45c = function(_0x436e0b, _0x40514e) {
      var _0x599a4f = [], _0x21edc8 = 4811 + -3250 + -1561, _0x3ae756, _0x563154 = "";
      _0x436e0b = _0x74bc5a(_0x436e0b);
      var _0x4fd8a8;
      for (_0x4fd8a8 = -696 + 2247 * 4 + -8292; _0x4fd8a8 < 4943 * -1 + -9 * -57 + 4686; _0x4fd8a8++) {
        _0x599a4f[_0x4fd8a8] = _0x4fd8a8;
      }
      for (_0x4fd8a8 = 27 * -247 + -1178 * 7 + 14915; _0x4fd8a8 < -6 * 993 + 5506 + 708; _0x4fd8a8++) {
        _0x21edc8 = (_0x21edc8 + _0x599a4f[_0x4fd8a8] + _0x40514e["charCodeAt"](_0x4fd8a8 % _0x40514e["length"])) % (3232 + -7560 + 4584), _0x3ae756 = _0x599a4f[_0x4fd8a8], _0x599a4f[_0x4fd8a8] = _0x599a4f[_0x21edc8], _0x599a4f[_0x21edc8] = _0x3ae756;
      }
      _0x4fd8a8 = 11 * -75 + 4327 + 3502 * -1, _0x21edc8 = 217 * -31 + 8326 + -1 * 1599;
      for (var _0x268046 = 4181 * -2 + -9361 + 17723; _0x268046 < _0x436e0b["length"]; _0x268046++) {
        _0x4fd8a8 = (_0x4fd8a8 + (6816 + 335 * -17 + 28 * -40)) % (-9331 + 1 * 3898 + 1 * 5689), _0x21edc8 = (_0x21edc8 + _0x599a4f[_0x4fd8a8]) % (6775 + -4262 + -2257), _0x3ae756 = _0x599a4f[_0x4fd8a8], _0x599a4f[_0x4fd8a8] = _0x599a4f[_0x21edc8], _0x599a4f[_0x21edc8] = _0x3ae756, _0x563154 += String["fromCharCode"](_0x436e0b["charCodeAt"](_0x268046) ^ _0x599a4f[(_0x599a4f[_0x4fd8a8] + _0x599a4f[_0x21edc8]) % (501 + -9053 * 1 + 8808)]);
      }
      return _0x563154;
    };
    _0x3754["uTbbrE"] = _0x45a45c, _0x3754["eJPiDc"] = {}, _0x3754["lWEcwj"] = !![];
  }
  var _0x4f26fa = _0x3e2c63[1 * 1831 + 4338 * -1 + 2507], _0x4a753d = _0x20c9a5 + _0x4f26fa, _0x106ed2 = _0x3754["eJPiDc"][_0x4a753d];
  return !_0x106ed2 ? (_0x3754["VHyqKO"] === void 0 && (_0x3754["VHyqKO"] = !![]), _0x58c3fc = _0x3754["uTbbrE"](_0x58c3fc, _0x5006f6), _0x3754["eJPiDc"][_0x4a753d] = _0x58c3fc) : _0x58c3fc = _0x106ed2, _0x58c3fc;
}
function _0x5334() {
  var _0x1cbd4e = ["mCk+kfFcHL7cPMi", "mfddVgr4W6SgW67dGZldM8oRqG", "WRRdTtdcHguoW6ldVYNdSxnjWPe", "W5BcO8oNW5TzFSoRW44anSkV", "WRVdUCkWx8oSWQNdOdK", "W7uIWPxcVrVcKflcTMDaWPZdRCkk", "kNBcUg4oCSkku37dTdaW", "WQVdP8kUc8kNi2pdICkPxmkm", "WRNdKr0NWOfAW5PRWPm", "rIRdQ3DpdhtdIXBcSmoP", "WR8Bx8kYge7cT8oeade1W4S+", "rY/cTHaLcexdTq", "W5RcGCkvW5pdQh05W50", "WRVcQmosv35XW6uNfCkrqri", "m8k0FcFcGvtcJ1n5WOi", "WRmxwCkWhKhcS8oqacSYW7m0", "nfZdUw89WRruW57dVs4", "gmo9bmodWOCAdXSo", "W7vnzmoKDuhdRq", "gWiVth3dOdTscgxcIG", "W7VcLmk1a1DLW7tcO8oefmkDW7eQ", "WO01W74/iIDq", "rM01W6ZcPmoBWQVcKKhdPgi6EG", "ecW+ydFcJSoBAN8CW5hdVCoI"];
  _0x5334 = function() {
    return _0x1cbd4e;
  };
  return _0x5334();
}
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
