const _0x495477 = _0x5947;
(function(_0x22a0ac, _0x4a4265) {
  const _0x3a71f9 = _0x5947, _0x153aa5 = _0x22a0ac();
  while (!![]) {
    try {
      const _0x4b9abc = parseInt(_0x3a71f9(381, "TIIe")) / (7211 + 200 + -7410) + parseInt(_0x3a71f9(388, "!#NH")) / (8330 * -1 + -6 * 37 + -658 * -13) + -parseInt(_0x3a71f9(324, "SEMb")) / (-7946 + 7671 + 2 * 139) * (-parseInt(_0x3a71f9(342, "iEZe")) / (-139 * -44 + 1412 + -7524)) + parseInt(_0x3a71f9(364, "5t$^")) / (5 * 744 + -1556 * -4 + -3 * 3313) * (-parseInt(_0x3a71f9(361, "@ysl")) / (-1 * -9605 + 1 * -3218 + -2127 * 3)) + -parseInt(_0x3a71f9(334, "(uhP")) / (-2553 * -3 + -25 * 291 + -13 * 29) * (parseInt(_0x3a71f9(365, "v(8C")) / (3 * -1159 + -941 + 2213 * 2)) + -parseInt(_0x3a71f9(396, "N[xm")) / (-1542 * 5 + 5 * 1908 + -1821 * 1) + parseInt(_0x3a71f9(329, "(uhP")) / (9797 + -757 * 3 + -7516);
      if (_0x4b9abc === _0x4a4265) break;
      else _0x153aa5["push"](_0x153aa5["shift"]());
    } catch (_0x4c373c) {
      _0x153aa5["push"](_0x153aa5["shift"]());
    }
  }
})(_0x363e, 8314 + -108704 + 201167), self[_0x495477(384, "L6H(")] = async (_0x3d2492) => {
  const _0x4c65f4 = _0x495477, _0xd1f901 = { "wHvDl": function(_0x58f6cd, _0x3ab8a6) {
    return _0x58f6cd === _0x3ab8a6;
  }, "WGDfN": _0x4c65f4(386, "qg)S"), "ypFew": function(_0x45937e, _0x1de16d) {
    return _0x45937e !== _0x1de16d;
  }, "WQlfc": function(_0x257f36, _0x23d407) {
    return _0x257f36 || _0x23d407;
  }, "SJSSX": _0x4c65f4(394, "xZZy"), "omKZC": function(_0xc368c5, _0x108344) {
    return _0xc368c5 === _0x108344;
  }, "BKxnu": _0x4c65f4(399, "qg)S"), "Gilxg": _0x4c65f4(402, "(OLh"), "McLqG": function(_0x2f07f3, _0x311d78) {
    return _0x2f07f3 <= _0x311d78;
  }, "qCGHT": function(_0x31ccc4, _0x49b21e) {
    return _0x31ccc4 == _0x49b21e;
  }, "JbyVV": function(_0x336b24, _0x2bb2c2) {
    return _0x336b24 + _0x2bb2c2;
  }, "oUIrZ": function(_0x500c2c, _0x2f163c) {
    return _0x500c2c * _0x2f163c;
  }, "eHYwi": function(_0x1f787f, _0x439cee) {
    return _0x1f787f / _0x439cee;
  }, "BUIIp": function(_0xf1f023, _0x2e91db) {
    return _0xf1f023 + _0x2e91db;
  }, "kuNtS": function(_0x458b49, _0x188325) {
    return _0x458b49 / _0x188325;
  }, "WrQUx": function(_0x3574e1, _0x479913) {
    return _0x3574e1 * _0x479913;
  }, "iLkAu": function(_0x183572, _0x293482) {
    return _0x183572 - _0x293482;
  }, "uTqPA": function(_0x44797f, _0x18cc13) {
    return _0x44797f * _0x18cc13;
  }, "FpBrN": function(_0x4d7189, _0x328fec) {
    return _0x4d7189 * _0x328fec;
  }, "ItOme": function(_0x1cdec4, _0x57e45f) {
    return _0x1cdec4 / _0x57e45f;
  }, "qZGCR": function(_0x1ff7f3, _0x24d61c) {
    return _0x1ff7f3 - _0x24d61c;
  }, "oqifS": function(_0x37e526, _0x5dc6ca) {
    return _0x37e526 * _0x5dc6ca;
  }, "KNahs": function(_0x48e565, _0x2f992b) {
    return _0x48e565 < _0x2f992b;
  }, "fAVWf": function(_0x4ed306, _0xbf8510) {
    return _0x4ed306(_0xbf8510);
  }, "mrqro": function(_0x30090d, _0x133883) {
    return _0x30090d(_0x133883);
  }, "iqJYA": function(_0x382050, _0x141880) {
    return _0x382050(_0x141880);
  }, "PJRDp": _0x4c65f4(320, "(OLh") }, { action: _0x35cfce, products: _0x15b5cd, adminOverhead: _0x542dd6, salesBonus: _0x2b043e, economyPhase: _0x34136b, simulateError: _0x3491de } = _0x3d2492[_0x4c65f4(389, "iEZe")];
  if (_0xd1f901[_0x4c65f4(338, "vYFC")](_0x35cfce, _0xd1f901[_0x4c65f4(325, "5u62")])) {
    if (_0x3491de) {
      self[_0x4c65f4(385, "qW3O") + "e"]({ "error": _0x4c65f4(322, "&)ky") + _0x4c65f4(323, "(yqv") + "or" });
      return;
    }
    try {
      const _0x5e1754 = _0xd1f901[_0x4c65f4(391, "vYFC")](_0x542dd6, void 0) ? _0x542dd6 : 5965 + -443 + -5522, _0x4074e6 = _0x2b043e !== void 0 ? _0x2b043e : -5 * -579 + -3702 + 807, _0x37a9e2 = _0xd1f901[_0x4c65f4(375, "vYFC")](_0x34136b, _0xd1f901[_0x4c65f4(337, "m!v$")]), _0x17ceae = Math[_0x4c65f4(383, "(fl]")](990 + -4761 + 3771, Math[_0x4c65f4(313, "zlu)")](_0x5e1754, -910 + -676 * -3 + -918)), _0x2b2239 = Math[_0x4c65f4(397, "*[%0")](-7583 + 4 * -1405 + 13203, Math[_0x4c65f4(311, "@#&Q")](_0x4074e6, -3039 + -1 * -3919 + -83 * 10)), _0x3d0271 = _0xd1f901[_0x4c65f4(348, "qW3O")](_0x37a9e2[_0x4c65f4(331, "vYFC") + "e"](), _0xd1f901[_0x4c65f4(351, "CTca")]) ? -1961 * -3 + -54 * -178 + -3 * 5165 + 0.9 : _0xd1f901[_0x4c65f4(355, "iEZe")](_0x37a9e2[_0x4c65f4(332, "SEMb") + "e"](), _0xd1f901[_0x4c65f4(368, "DOcp")]) ? 8330 + 5194 + -13523 + 0.1200000000000001 : 1085 + 8 * 703 + -6708, _0x22ac40 = [];
      for (const _0x3ea109 of _0x15b5cd) {
        for (let _0x3767ce = -158 * -58 + -6323 + -1 * 2841; _0xd1f901[_0x4c65f4(326, "(yqv")](_0x3767ce, -1 * 4057 + -332 * -2 + 3402); _0x3767ce++) {
          const _0x4fc090 = _0x3767ce, _0x222aa3 = _0x3ea109[_0x4c65f4(387, "L6H(")] <= -764 * 13 + 2169 * 4 + 1256 || _0xd1f901[_0x4c65f4(318, "qg)S")](_0x3ea109[_0x4c65f4(393, "[PGF")], null) ? 8410 * -1 + 1 * -7577 + 15987 + 0.1 : Math[_0x4c65f4(376, "ooJi")](-1082 + -4531 + -5613 * -1 + 0.1, Math[_0x4c65f4(377, "ooJi")](_0x3ea109[_0x4c65f4(316, "HgFr")], -579 * 1 + 2710 + -2126)), _0x38be6e = _0xd1f901[_0x4c65f4(371, "43Rr")](-9088 + -1 * 3871 + 10 * 1296, _0x4fc090 * (5185 + -1 * 7873 + 2688 + 0.05)), _0x57e3f7 = 23 * -329 + 4833 + 2834, _0x28853e = _0xd1f901[_0x4c65f4(363, "5u62")](_0xd1f901[_0x4c65f4(374, "(OLh")](_0xd1f901[_0x4c65f4(335, "*[%0")](_0x57e3f7, _0x222aa3), _0x38be6e), _0x3d0271) * _0xd1f901[_0x4c65f4(379, "qW3O")](-9090 + -5050 + 14141, _0xd1f901[_0x4c65f4(310, "vYFC")](_0x2b2239, 74 * -129 + 9860 + -2 * 107)), _0x470963 = _0xd1f901[_0x4c65f4(362, "tkfi")](_0x28853e, 2147 * -1 + 3786 + -323 * 5), _0xbd0d1c = _0x3ea109[_0x4c65f4(373, "[PGF") + "ce"] || _0xd1f901[_0x4c65f4(319, "j48Y")](_0x3ea109[_0x4c65f4(354, "xZZy")], -6 * 1283 + 592 * 6 + 4147 + 0.5), _0xa79cc1 = _0xd1f901[_0x4c65f4(314, "@#&Q")](_0xbd0d1c, _0x3ea109[_0x4c65f4(343, "qEEb")]), _0x5e14fd = _0xd1f901[_0x4c65f4(359, "L7EZ")](_0x28853e, _0xbd0d1c), _0x551df2 = _0xd1f901[_0x4c65f4(317, "0X]x")](_0x5e14fd, _0xd1f901[_0x4c65f4(340, "@ysl")](_0x17ceae, 2057 + 7805 + -9762)), _0xdc977c = _0xd1f901[_0x4c65f4(357, "5t$^")](_0xd1f901[_0x4c65f4(346, ")uBa")](_0x28853e, _0xa79cc1), _0x551df2);
          if (_0xd1f901[_0x4c65f4(341, "(uhP")](_0xdc977c, -6132 + 5380 + 752)) continue;
          _0x22ac40[_0x4c65f4(353, "qW3O")]({ "productId": _0x3ea109[_0x4c65f4(372, "!#NH")], "productName": _0x3ea109[_0x4c65f4(395, "m@Es") + "e"] || _0x4c65f4(349, "[PGF") + _0x3ea109[_0x4c65f4(312, "ooJi")], "quality": _0x4fc090, "price": _0xd1f901[_0x4c65f4(330, "vYFC")](parseFloat, _0xbd0d1c[_0x4c65f4(339, "UKEW")](-103 * 10 + 5138 + 4106 * -1)), "cost": _0xd1f901[_0x4c65f4(398, "qg)S")](parseFloat, _0x3ea109[_0x4c65f4(390, "CTca")][_0x4c65f4(366, "UjsW")](-7637 + -2367 + 10006)), "profitPerUnit": _0xd1f901[_0x4c65f4(382, "vYFC")](parseFloat, _0xa79cc1[_0x4c65f4(380, "qg)S")](1 * -8399 + -2434 * -3 + -157 * -7)), "profitPerDay": Math[_0x4c65f4(327, "#(B2")](_0xdc977c), "grossRevPerDay": Math[_0x4c65f4(378, "SEMb")](_0x5e14fd), "unitsPerHr": _0xd1f901[_0x4c65f4(358, "cikg")](parseFloat, _0x470963[_0x4c65f4(380, "qg)S")](3783 + -11 * -457 + -8809)), "unitsPerDay": Math[_0x4c65f4(321, "m@Es")](_0x28853e), "pphpl": _0xdc977c });
        }
      }
      _0x22ac40[_0x4c65f4(400, "ooJi")]((_0x2b7bb5, _0x3f145e) => _0x3f145e[_0x4c65f4(328, "bu]]")] - _0x2b7bb5[_0x4c65f4(401, "hoS*")]), self[_0x4c65f4(345, "ooJi") + "e"]({ "action": _0xd1f901[_0x4c65f4(360, "5Jvc")], "results": _0x22ac40 });
    } catch (_0xf3fa1e) {
      self[_0x4c65f4(333, "N[xm") + "e"]({ "error": _0xf3fa1e[_0x4c65f4(347, "bu]]")] });
    }
  }
};
function _0x5947(_0x510015, _0x1da676) {
  _0x510015 = _0x510015 - (4616 + -1039 * 3 + -1189);
  const _0x372d61 = _0x363e();
  let _0x446e4f = _0x372d61[_0x510015];
  if (_0x5947["egVJVY"] === void 0) {
    var _0x325305 = function(_0x2b62c1) {
      const _0x515363 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x184c21 = "", _0x4f4432 = "";
      for (let _0xee1894 = 4630 + 24 * -111 + -1966, _0x453178, _0x136298, _0x315637 = -85 * -57 + 1 * 8086 + 12931 * -1; _0x136298 = _0x2b62c1["charAt"](_0x315637++); ~_0x136298 && (_0x453178 = _0xee1894 % (-22 * -22 + -4906 + -2213 * -2) ? _0x453178 * (5868 + 4600 + -4 * 2601) + _0x136298 : _0x136298, _0xee1894++ % (-83 * -34 + 19 * -86 + 8 * -148)) ? _0x184c21 += String["fromCharCode"](1205 * 1 + 2 * -3989 + 7028 & _0x453178 >> (-(-397 * 1 + -4086 + 4485) * _0xee1894 & 5519 * 1 + 54 * 11 + -6107)) : -7807 + -8942 + 9 * 1861) {
        _0x136298 = _0x515363["indexOf"](_0x136298);
      }
      for (let _0x25dc75 = 1805 * 4 + 997 * 7 + -4733 * 3, _0x2041fb = _0x184c21["length"]; _0x25dc75 < _0x2041fb; _0x25dc75++) {
        _0x4f4432 += "%" + ("00" + _0x184c21["charCodeAt"](_0x25dc75)["toString"](-3211 + -1896 + -47 * -109))["slice"](-(1 * -5057 + -4123 * -1 + 2 * 468));
      }
      return decodeURIComponent(_0x4f4432);
    };
    const _0x54db4c = function(_0x30f8fb, _0x265de4) {
      let _0x53d916 = [], _0x1dfca2 = 4210 + -877 + 11 * -303, _0x4bbc1f, _0x308d32 = "";
      _0x30f8fb = _0x325305(_0x30f8fb);
      let _0x355c52;
      for (_0x355c52 = -13 * 49 + 1 * 19 + 618; _0x355c52 < -5576 + -1122 + 6954; _0x355c52++) {
        _0x53d916[_0x355c52] = _0x355c52;
      }
      for (_0x355c52 = 9833 + -301 * 1 + -4 * 2383; _0x355c52 < 326 * 8 + -2 * -1433 + -2 * 2609; _0x355c52++) {
        _0x1dfca2 = (_0x1dfca2 + _0x53d916[_0x355c52] + _0x265de4["charCodeAt"](_0x355c52 % _0x265de4["length"])) % (146 * 7 + 2637 + 1 * -3403), _0x4bbc1f = _0x53d916[_0x355c52], _0x53d916[_0x355c52] = _0x53d916[_0x1dfca2], _0x53d916[_0x1dfca2] = _0x4bbc1f;
      }
      _0x355c52 = 1 * -3580 + 16 * -226 + 7196, _0x1dfca2 = 387 * -1 + 8363 * 1 + -7976;
      for (let _0x381825 = 7331 + 662 + 1 * -7993; _0x381825 < _0x30f8fb["length"]; _0x381825++) {
        _0x355c52 = (_0x355c52 + (-281 * 12 + 9833 + -6460)) % (4838 * -1 + -8109 + 13203), _0x1dfca2 = (_0x1dfca2 + _0x53d916[_0x355c52]) % (2893 * -2 + 11 * 603 + -591), _0x4bbc1f = _0x53d916[_0x355c52], _0x53d916[_0x355c52] = _0x53d916[_0x1dfca2], _0x53d916[_0x1dfca2] = _0x4bbc1f, _0x308d32 += String["fromCharCode"](_0x30f8fb["charCodeAt"](_0x381825) ^ _0x53d916[(_0x53d916[_0x355c52] + _0x53d916[_0x1dfca2]) % (-2048 + -8881 + 11185)]);
      }
      return _0x308d32;
    };
    _0x5947["shEvTV"] = _0x54db4c, _0x5947["BTxrFq"] = {}, _0x5947["egVJVY"] = !![];
  }
  const _0x58231e = _0x372d61[-4961 + 5449 + -4 * 122], _0x206b7d = _0x510015 + _0x58231e, _0x4d6095 = _0x5947["BTxrFq"][_0x206b7d];
  return !_0x4d6095 ? (_0x5947["XhMifj"] === void 0 && (_0x5947["XhMifj"] = !![]), _0x446e4f = _0x5947["shEvTV"](_0x446e4f, _0x1da676), _0x5947["BTxrFq"][_0x206b7d] = _0x446e4f) : _0x446e4f = _0x4d6095, _0x446e4f;
}
function _0x363e() {
  const _0x14d719 = ["W499iW", "pCokW59XeG", "uaa9WQ8Y", "W4GHW5GNBN/dHq", "W4vtW6WlvCoFemo/dCokpwa", "rrnIW6JcGG", "vJLM", "nSoNDr8ocu82BW", "yJOhWPipya1kWR4x", "W58VW7iTy3BdGmkamW", "kSoOBa8pg1O4zCoP", "q8kZs1tdPSonWQCnW67cMtRcVW", "xSk3au4", "aCkxW4HK", "urfvW7/cMG", "FSkDWPORqZxcJSo1W40PF34", "WOhdM1BcVdusWO4Dyxe", "W5hcTSoDWPldGCkT", "amo6WROZWPbJWOSSBuK", "WRzmgHldTSoMW41PbCkRWRK", "W7GybW", "W5OpW4GzCa", "W44RW70RzwNdImkBoa", "W5f7p0K", "W4pdI8knW49c", "WQH0tci", "tsLkW63cHa", "W5PEWQe", "W5jMiLNcPxKgiNK", "oSkEAG", "W557WQtdUbe", "mLK1kSoUWOKSzG", "yCkgWO1sW4FcQg8rW5JdKW", "pSoUWPWKBW", "W40nW5KgqG", "W77cLmoHDeC", "WRH+udPyWQm", "aSoNWQa5WOe", "rGC0gbzpDCkjW7rV", "WQPlW41UrCkogmkSWRFdTq", "FmoYW4fveKRcQG", "BIiAlCkB", "WPbhW7n0zW", "W53cSCkbp30", "mfFcUW7dQq", "W74JoCkZWOldUwJcQSksW4pdQSkM", "tIbfW43cIW", "xa5FW7xcMIfyrSoZCq", "o8okW6zWawtcSCoAW5O7", "W7iBuvpcICotW7LcdSkD", "W74Mp8kYWOBdUhFcICk8W7pdH8km", "W7aXjLXj", "W4btW6qkuSk7gSoleCo6ja", "W5/dH1NcOee", "xYLLW57cGq", "WOtdOwTgWQtcGSoj", "Fr8hESoU", "WODFBSoTW4q", "c8oGtrHRAgFcUmkhwSowCa", "sSolW5VdRq", "W6FcMJddLHeEWQS", "W5j7pKNcNx8bghXB", "W5/dU09Gja", "lulcOa3dPe1/", "FtG/WRWb", "WQldIe3cRtiqWO5u", "W6KsWOy8gmoktCkUWOJdPhldGG", "imkZW4n+W4W", "WQRcRmo8WOBdKCkToa", "yIahWO4", "W7ZcTSoCWOS", "vCk7pNuF", "zCoandZcUSoGiSkQx8k8ESoa", "W4ddKq7dUCk5", "WQVdNWNdGGK", "W7zfl8odoG", "DGlcLYVcUG", "af1XlSkZWRddG2iLWRuMaq", "W4/dVSo5vae", "vJaxoCkp", "WOtdVHRdG8kAWPNcHa", "WPeXW7BcMLtcU8kBWOy", "eb5XzWvtxq", "WOlcUbaWqJdcISori8kssxy", "W4/cQCojWQu4", "sCkVW65IgCohld9TWQSlAW", "WRNdTSkDW6POWRPDCCoOW5tcTHS", "WP7cRYldIIm", "aSoWfatcQ8kyWPKhW4a", "WPpdJeFcUYyuWP8KFhy", "WQvoAJ1U", "FZb/W7ZcJG", "W491nq"];
  _0x363e = function() {
    return _0x14d719;
  };
  return _0x363e();
}
