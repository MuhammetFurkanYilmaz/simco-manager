(function(_0x3294ff, _0x558816) {
  var _0x327d94 = _0x26d5, _0x1b1490 = _0x3294ff();
  while (!![]) {
    try {
      var _0x4b1e87 = parseInt(_0x327d94(335, "J3u&")) / (113 * -33 + 48 * 80 + -110) + parseInt(_0x327d94(328, "upB@")) / (-1 * -5197 + -17 * -141 + 3796 * -2) * (-parseInt(_0x327d94(337, "Qs(K")) / (-3891 * -1 + 192 * -16 + -816)) + parseInt(_0x327d94(340, "E^FT")) / (535 * 8 + 2 * -1763 + -750) * (-parseInt(_0x327d94(325, "K#B%")) / (-4875 + -7335 + 12215)) + parseInt(_0x327d94(332, "6ugi")) / (-7 * -841 + -2841 + 32 * -95) * (-parseInt(_0x327d94(343, "PJLl")) / (9108 + 5173 + -14274)) + parseInt(_0x327d94(336, "Kg93")) / (10 * -450 + -8053 + 237 * 53) + -parseInt(_0x327d94(331, "Qs(K")) / (1 * 1901 + -881 + -1011) + parseInt(_0x327d94(341, "or^H")) / (-1266 * 1 + -3801 + 1 * 5077);
      if (_0x4b1e87 === _0x558816) break;
      else _0x1b1490["push"](_0x1b1490["shift"]());
    } catch (_0x4d6c45) {
      _0x1b1490["push"](_0x1b1490["shift"]());
    }
  }
})(_0x435c, -735 * -349 + -573939 + -226763 * -3);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function _0x435c() {
  var _0x4c8325 = ["pmkSsHbKjCoY", "W5ijW7TTCSkJWPnZm1hcUSo/WQa", "WOrSf3PWW4NcLCkfW7H6", "n8k7W6yXWQFdMGRcO8kHv8kRja", "ws54WOlcLsvzW7hcI8oTpq9v", "W58OW5C9A8oGWPdcSGC", "seZcQWXZWQ0XcKm", "WPJdUhNcG8oyWRCcW5RcRImhW6K", "WOjSbgldLxVcJSo7WQBdV8kGmmkB", "F8klWQfVWR4ZpbpcN8o+W7DQkG", "bSkKzsVdNqNcI8opW7ZcPXKfqG", "lN7cLCkYCHSJDmozamkrWRNcMq", "W7DjkmoOt38r", "xCkcWPZdIKhdH8ox", "p1VcMLuKWRr0D8kFbWBdVtW", "Fej/W6BcNcldIMiTWQPUq2W", "WQ/dKCkiu8k6zIepW4uF", "owjSvrpdNCoD", "WOdcPsXIawzaWOzCg8kVW6fl", "W5GOW5julSkFW6lcHIRdGmolWQOt"];
  _0x435c = function() {
    return _0x4c8325;
  };
  return _0x435c();
}
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function _0x26d5(_0x3c138c, _0x2bfd82) {
  _0x3c138c = _0x3c138c - (-2 * -2519 + -5223 + 509);
  var _0x52e82e = _0x435c();
  var _0x4bc093 = _0x52e82e[_0x3c138c];
  if (_0x26d5["ycbmaQ"] === void 0) {
    var _0x1bdc69 = function(_0x4dd388) {
      var _0x8d9dad = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x2c0e90 = "", _0x38d78f = "";
      for (var _0x4ace1e = -217 * 17 + 1 * -805 + 4494, _0x345669, _0x5725e5, _0x45e954 = 9249 + -129 + -9120; _0x5725e5 = _0x4dd388["charAt"](_0x45e954++); ~_0x5725e5 && (_0x345669 = _0x4ace1e % (26 * -215 + 9428 + -3834) ? _0x345669 * (-49 * -127 + -4366 * -2 + -14891 * 1) + _0x5725e5 : _0x5725e5, _0x4ace1e++ % (-870 + 6559 * -1 + 7433 * 1)) ? _0x2c0e90 += String["fromCharCode"](6014 + -1 * -7457 + -13216 & _0x345669 >> (-(-209 + -289 * -15 + -4124) * _0x4ace1e & -7563 + -334 * -27 + 7 * -207)) : 6330 + 93 * -43 + -2331) {
        _0x5725e5 = _0x8d9dad["indexOf"](_0x5725e5);
      }
      for (var _0x38288d = -1640 + -6130 + 7770, _0x215f19 = _0x2c0e90["length"]; _0x38288d < _0x215f19; _0x38288d++) {
        _0x38d78f += "%" + ("00" + _0x2c0e90["charCodeAt"](_0x38288d)["toString"](4253 + -1 * -9331 + -2 * 6784))["slice"](-(-1 * 8424 + -3 * 2542 + -8026 * -2));
      }
      return decodeURIComponent(_0x38d78f);
    };
    var _0x1f74b0 = function(_0x2393a8, _0xabc34c) {
      var _0x4651dc = [], _0xf5599a = 2445 * 1 + -887 + -1558, _0x394932, _0x47c429 = "";
      _0x2393a8 = _0x1bdc69(_0x2393a8);
      var _0x672ba;
      for (_0x672ba = 2449 * -2 + 8113 + 1 * -3215; _0x672ba < -1533 + 9232 * -1 + 11021; _0x672ba++) {
        _0x4651dc[_0x672ba] = _0x672ba;
      }
      for (_0x672ba = -11 * 186 + 59 * 13 + -1279 * -1; _0x672ba < 6713 + 8131 + 2084 * -7; _0x672ba++) {
        _0xf5599a = (_0xf5599a + _0x4651dc[_0x672ba] + _0xabc34c["charCodeAt"](_0x672ba % _0xabc34c["length"])) % (4629 * -1 + 127 * -1 + 4 * 1253), _0x394932 = _0x4651dc[_0x672ba], _0x4651dc[_0x672ba] = _0x4651dc[_0xf5599a], _0x4651dc[_0xf5599a] = _0x394932;
      }
      _0x672ba = 2101 + -2 * -3747 + -9595, _0xf5599a = -9057 + -11 * -219 + 2 * 3324;
      for (var _0x35fd01 = -9989 * -1 + -13 * -45 + -10574; _0x35fd01 < _0x2393a8["length"]; _0x35fd01++) {
        _0x672ba = (_0x672ba + (339 + 1776 + -1 * 2114)) % (-9151 + -4112 + 13519), _0xf5599a = (_0xf5599a + _0x4651dc[_0x672ba]) % (-1553 * -6 + -1 * 3093 + -5969), _0x394932 = _0x4651dc[_0x672ba], _0x4651dc[_0x672ba] = _0x4651dc[_0xf5599a], _0x4651dc[_0xf5599a] = _0x394932, _0x47c429 += String["fromCharCode"](_0x2393a8["charCodeAt"](_0x35fd01) ^ _0x4651dc[(_0x4651dc[_0x672ba] + _0x4651dc[_0xf5599a]) % (-2 * -3126 + -5336 + -660)]);
      }
      return _0x47c429;
    };
    _0x26d5["wjWgSv"] = _0x1f74b0, _0x26d5["cVqAml"] = {}, _0x26d5["ycbmaQ"] = !![];
  }
  var _0x5f0e53 = _0x52e82e[1 * 2707 + 3201 + -28 * 211], _0x19d535 = _0x3c138c + _0x5f0e53, _0xde2d63 = _0x26d5["cVqAml"][_0x19d535];
  return !_0xde2d63 ? (_0x26d5["AIzXDv"] === void 0 && (_0x26d5["AIzXDv"] = !![]), _0x4bc093 = _0x26d5["wjWgSv"](_0x4bc093, _0x2bfd82), _0x26d5["cVqAml"][_0x19d535] = _0x4bc093) : _0x4bc093 = _0xde2d63, _0x4bc093;
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
