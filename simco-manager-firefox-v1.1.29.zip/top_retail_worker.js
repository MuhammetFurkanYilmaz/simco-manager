const _0x40b656 = _0x4ac6;
function _0x4ac6(_0x2a3258, _0x6a5564) {
  _0x2a3258 = _0x2a3258 - (113 * -4 + -7120 + 8067);
  const _0x347bc5 = _0x5a8b();
  let _0x31643a = _0x347bc5[_0x2a3258];
  if (_0x4ac6["PslKxn"] === void 0) {
    var _0x3c734c = function(_0x40164a) {
      const _0x4619f4 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x160c2e = "", _0x18f8f0 = "";
      for (let _0x272659 = -11 * 263 + -3230 + 471 * 13, _0x37b9ad, _0x4c6550, _0x2266b5 = -611 * -12 + -1833 + -5499; _0x4c6550 = _0x40164a["charAt"](_0x2266b5++); ~_0x4c6550 && (_0x37b9ad = _0x272659 % (-3045 + -2 * 1697 + 6443) ? _0x37b9ad * (1 * 1599 + 672 * 8 + -6911 * 1) + _0x4c6550 : _0x4c6550, _0x272659++ % (-8171 + -2 * -3221 + -1733 * -1)) ? _0x160c2e += String["fromCharCode"](-2711 + -9652 + 12618 & _0x37b9ad >> (-(525 + -9298 * -1 + 9821 * -1) * _0x272659 & 5576 + -8539 + 2969)) : 9542 + 4 * 139 + -10098) {
        _0x4c6550 = _0x4619f4["indexOf"](_0x4c6550);
      }
      for (let _0x135081 = -166 + 7669 + -7503, _0x332aa5 = _0x160c2e["length"]; _0x135081 < _0x332aa5; _0x135081++) {
        _0x18f8f0 += "%" + ("00" + _0x160c2e["charCodeAt"](_0x135081)["toString"](-3548 * 2 + -3228 + 10340))["slice"](-(32 * -168 + 282 * -33 + 3671 * 4));
      }
      return decodeURIComponent(_0x18f8f0);
    };
    const _0x72c747 = function(_0x5ef8dd, _0x5c54e9) {
      let _0x5c1fbc = [], _0xc1d916 = 435 * 22 + 2 * -4855 + -70 * -2, _0x411151, _0x4aba5a = "";
      _0x5ef8dd = _0x3c734c(_0x5ef8dd);
      let _0x4441f6;
      for (_0x4441f6 = -1253 * 4 + -4453 + 1 * 9465; _0x4441f6 < 9126 + -5676 + 1 * -3194; _0x4441f6++) {
        _0x5c1fbc[_0x4441f6] = _0x4441f6;
      }
      for (_0x4441f6 = -5228 + -292 * 12 + -4 * -2183; _0x4441f6 < 67 * 101 + 3352 * -2 + 193; _0x4441f6++) {
        _0xc1d916 = (_0xc1d916 + _0x5c1fbc[_0x4441f6] + _0x5c54e9["charCodeAt"](_0x4441f6 % _0x5c54e9["length"])) % (-2630 + 127 * -52 + 9490), _0x411151 = _0x5c1fbc[_0x4441f6], _0x5c1fbc[_0x4441f6] = _0x5c1fbc[_0xc1d916], _0x5c1fbc[_0xc1d916] = _0x411151;
      }
      _0x4441f6 = 3410 + -1664 + 9 * -194, _0xc1d916 = -2848 + 4043 + -1195;
      for (let _0x1c5dfe = -6661 + -151 * -7 + -1 * -5604; _0x1c5dfe < _0x5ef8dd["length"]; _0x1c5dfe++) {
        _0x4441f6 = (_0x4441f6 + (2066 + 7245 + -9310)) % (1 * 1433 + -1 * -8828 + -10005), _0xc1d916 = (_0xc1d916 + _0x5c1fbc[_0x4441f6]) % (11 * -625 + -9193 + 16324), _0x411151 = _0x5c1fbc[_0x4441f6], _0x5c1fbc[_0x4441f6] = _0x5c1fbc[_0xc1d916], _0x5c1fbc[_0xc1d916] = _0x411151, _0x4aba5a += String["fromCharCode"](_0x5ef8dd["charCodeAt"](_0x1c5dfe) ^ _0x5c1fbc[(_0x5c1fbc[_0x4441f6] + _0x5c1fbc[_0xc1d916]) % (-143 * -11 + 6877 + -8194)]);
      }
      return _0x4aba5a;
    };
    _0x4ac6["eMDbgb"] = _0x72c747, _0x4ac6["eoUsJL"] = {}, _0x4ac6["PslKxn"] = !![];
  }
  const _0x178891 = _0x347bc5[99 * 82 + 2199 + -181 * 57], _0x2865e5 = _0x2a3258 + _0x178891, _0x5b3040 = _0x4ac6["eoUsJL"][_0x2865e5];
  return !_0x5b3040 ? (_0x4ac6["GbwIqR"] === void 0 && (_0x4ac6["GbwIqR"] = !![]), _0x31643a = _0x4ac6["eMDbgb"](_0x31643a, _0x6a5564), _0x4ac6["eoUsJL"][_0x2865e5] = _0x31643a) : _0x31643a = _0x5b3040, _0x31643a;
}
(function(_0x576fa9, _0xd0754c) {
  const _0x18dc74 = _0x4ac6, _0x10a35d = _0x576fa9();
  while (!![]) {
    try {
      const _0x3cc3e0 = parseInt(_0x18dc74(505, "GcEi")) / (-9796 + 7691 + -9 * -234) * (parseInt(_0x18dc74(517, "CL$F")) / (3 * 505 + -6776 + 5263)) + -parseInt(_0x18dc74(540, "7J$u")) / (-7865 + -1 * 5326 + 13194) * (-parseInt(_0x18dc74(576, "8#ec")) / (-2599 + -7542 + 1 * 10145)) + parseInt(_0x18dc74(519, "1aH(")) / (1716 + -2095 * 3 + 4574) * (parseInt(_0x18dc74(523, "5GAG")) / (-8423 + 7816 + 1 * 613)) + -parseInt(_0x18dc74(516, "Juy5")) / (9221 + -581 * 12 + 59 * -38) * (-parseInt(_0x18dc74(521, "Nx(C")) / (132 * 71 + 2954 + -12318)) + -parseInt(_0x18dc74(507, "G#$w")) / (-4215 + 40 * 107 + -2 * 28) * (parseInt(_0x18dc74(544, "MdpZ")) / (-766 * 11 + -7104 + -28 * -555)) + parseInt(_0x18dc74(499, "V@oT")) / (9403 + -164 * 8 + -8080) * (parseInt(_0x18dc74(556, "]pOt")) / (-4297 * -2 + -3037 + -5545)) + parseInt(_0x18dc74(522, "]pOt")) / (1 * -3809 + -8032 + -5927 * -2) * (-parseInt(_0x18dc74(577, "MdpZ")) / (6693 * 1 + 344 * 16 + -393 * 31));
      if (_0x3cc3e0 === _0xd0754c) break;
      else _0x10a35d["push"](_0x10a35d["shift"]());
    } catch (_0x5cd90b) {
      _0x10a35d["push"](_0x10a35d["shift"]());
    }
  }
})(_0x5a8b, 1123816 + 1 * -317881 + -7 * -16491), self[_0x40b656(569, "CL$F")] = async (_0x8b7b7f) => {
  const _0x1bbf56 = _0x40b656, _0x586bbc = { "eQhIp": _0x1bbf56(506, "FH)K"), "atzyB": _0x1bbf56(562, "fQ!!") + _0x1bbf56(571, "8Rv0") + "or", "dzTfm": function(_0x486c70, _0x190861) {
    return _0x486c70 === _0x190861;
  }, "Wfiem": _0x1bbf56(573, "Fnwk"), "dmoRf": function(_0x305d08, _0x57289a) {
    return _0x305d08 == _0x57289a;
  }, "DmqmA": function(_0x5cf5bf, _0x390860) {
    return _0x5cf5bf + _0x390860;
  }, "RiPMI": function(_0x51221c, _0x59fa30) {
    return _0x51221c * _0x59fa30;
  }, "veyFK": function(_0x477946, _0xd06f9) {
    return _0x477946 / _0xd06f9;
  }, "obxiC": function(_0x431ce3, _0x56cde5) {
    return _0x431ce3 + _0x56cde5;
  }, "cbnDW": function(_0x1e6b78, _0x5a635e) {
    return _0x1e6b78 / _0x5a635e;
  }, "cHGfb": function(_0x435173, _0x5800fb) {
    return _0x435173 - _0x5800fb;
  }, "YglyV": function(_0x32cd8c, _0x3f19e5) {
    return _0x32cd8c * _0x3f19e5;
  }, "NbIkx": function(_0x28c783, _0x2cbe0e) {
    return _0x28c783 * _0x2cbe0e;
  }, "AGmwX": function(_0x5df39b, _0x50e10b) {
    return _0x5df39b / _0x50e10b;
  }, "mnbEP": function(_0x13ffcc, _0x1b1285) {
    return _0x13ffcc - _0x1b1285;
  }, "LayLh": function(_0x4bef84, _0x36d982) {
    return _0x4bef84(_0x36d982);
  }, "IDtzD": function(_0x248b17, _0x5b536a) {
    return _0x248b17(_0x5b536a);
  }, "huArY": function(_0x323a13, _0x32ee01) {
    return _0x323a13(_0x32ee01);
  }, "wrQjq": _0x1bbf56(565, "kFx$") }, { action: _0x5ff87b, products: _0x5bec28, adminOverhead: _0x49bd7f, salesBonus: _0x37acf7, economyPhase: _0xe21947, simulateError: _0x133193 } = _0x8b7b7f[_0x1bbf56(582, "74!l")];
  if (_0x5ff87b === _0x586bbc[_0x1bbf56(538, "oUCa")]) {
    if (_0x133193) {
      self[_0x1bbf56(527, "C[rS") + "e"]({ "error": _0x586bbc[_0x1bbf56(510, "G#$w")] });
      return;
    }
    try {
      const _0x10ce09 = _0x49bd7f !== void 0 ? _0x49bd7f : 2223 + -2927 + 8 * 88, _0x36cc9a = _0x37acf7 !== void 0 ? _0x37acf7 : 313 * 1 + 6579 + -6892, _0x2b0ee9 = _0xe21947 || _0x1bbf56(553, "Y)aY"), _0x3f1796 = Math[_0x1bbf56(495, "@%GM")](-178 * 31 + 6344 + -826, Math[_0x1bbf56(567, "qsoA")](_0x10ce09, 1260 + 3458 + -9 * 502)), _0x14ce94 = Math[_0x1bbf56(500, "&Soy")](-9989 + -3356 + 13345, Math[_0x1bbf56(503, "CL$F")](_0x36cc9a, -5831 * 1 + 5956 + -75)), _0xb45173 = _0x586bbc[_0x1bbf56(524, "7J$u")](_0x2b0ee9[_0x1bbf56(525, "5LK!") + "e"](), _0x586bbc[_0x1bbf56(537, "kFx$")]) ? 9961 + 2036 * 3 + -16069 + 0.9 : _0x2b0ee9[_0x1bbf56(549, "G4x2") + "e"]() === _0x1bbf56(546, "Xn@2") ? -1 * 8686 + 2117 * -3 + -206 * -73 + 0.1200000000000001 : 2669 * -1 + 6043 * -1 + 8713, _0x5f117a = [];
      for (const _0x1bce7c of _0x5bec28) {
        for (let _0x2d9f47 = -1 * 2453 + 1 * 4339 + -1886; _0x2d9f47 <= -54 * 86 + -6 * 553 + -7971 * -1; _0x2d9f47++) {
          const _0x100150 = _0x2d9f47, _0x266457 = _0x1bce7c[_0x1bbf56(570, "GcEi")] <= 1 * -4022 + -2245 + 6267 || _0x586bbc[_0x1bbf56(497, "qsoA")](_0x1bce7c[_0x1bbf56(585, "7J$u")], null) ? 7 * -1222 + 2034 + -4 * -1630 + 0.1 : Math[_0x1bbf56(502, "BNAY")](-2198 + -1359 + 3557 + 0.1, Math[_0x1bbf56(578, "FH)K")](_0x1bce7c[_0x1bbf56(575, "Ox8J")], 3 * 757 + -2752 + 486)), _0x287270 = _0x586bbc[_0x1bbf56(528, "]pOt")](2221 + 7271 + -9491, _0x586bbc[_0x1bbf56(560, "(4pr")](_0x100150, 8830 + 9579 + -18409 + 0.05)), _0x162bc2 = -4730 + 4006 * 2 + -3182 * 1, _0x180b1e = _0x586bbc[_0x1bbf56(534, "G4x2")](_0x586bbc[_0x1bbf56(555, "32&3")](_0x162bc2, _0x266457) * _0x287270 * _0xb45173, _0x586bbc[_0x1bbf56(579, "qsoA")](1 * -5181 + 9531 + -4349, _0x586bbc[_0x1bbf56(508, "BNAY")](_0x14ce94, 1699 * -5 + 41 * 210 + -15))), _0x4180e5 = _0x586bbc[_0x1bbf56(530, "#sjZ")](_0x180b1e, 354 * 21 + -1 * 7014 + 36 * -11), _0x426e9a = _0x1bce7c[_0x1bbf56(539, "8#ec") + "ce"] || _0x1bce7c[_0x1bbf56(515, "C[rS")] * (-253 + 6646 + -6392 + 0.5), _0x55f287 = _0x586bbc[_0x1bbf56(586, "1aH(")](_0x426e9a, _0x1bce7c[_0x1bbf56(554, "#sjZ")]), _0xc634d0 = _0x586bbc[_0x1bbf56(542, "Fnwk")](_0x180b1e, _0x426e9a), _0x372769 = _0x586bbc[_0x1bbf56(514, "m4ID")](_0xc634d0, _0x586bbc[_0x1bbf56(583, "Y)aY")](_0x3f1796, 8930 + -1227 + -7603)), _0x35731e = _0x586bbc[_0x1bbf56(498, "]pOt")](_0x586bbc[_0x1bbf56(518, "GcEi")](_0x180b1e, _0x55f287), _0x372769);
          if (_0x35731e < -1124 + 7501 + -6377) continue;
          _0x5f117a[_0x1bbf56(496, "Xn@2")]({ "productId": _0x1bce7c[_0x1bbf56(563, "g*Zu")], "productName": _0x1bce7c[_0x1bbf56(558, "G#$w") + "e"] || _0x1bbf56(513, "m4ID") + _0x1bce7c[_0x1bbf56(509, "]pOt")], "quality": _0x100150, "price": _0x586bbc[_0x1bbf56(511, "R71*")](parseFloat, _0x426e9a[_0x1bbf56(512, "FH)K")](-8728 + -408 + 3046 * 3)), "cost": parseFloat(_0x1bce7c[_0x1bbf56(550, "]pOt")][_0x1bbf56(581, "AtR^")](1 * 4673 + 4156 + 97 * -91)), "profitPerUnit": _0x586bbc[_0x1bbf56(501, "AtR^")](parseFloat, _0x55f287[_0x1bbf56(568, "Juy5")](-3690 + -2 * -3401 + -3110)), "profitPerDay": Math[_0x1bbf56(580, "5GAG")](_0x35731e), "grossRevPerDay": Math[_0x1bbf56(572, "LBdQ")](_0xc634d0), "unitsPerHr": _0x586bbc[_0x1bbf56(551, "kFx$")](parseFloat, _0x4180e5[_0x1bbf56(548, "Ox8J")](-1689 + -236 + -3 * -642)), "unitsPerDay": Math[_0x1bbf56(559, "R71*")](_0x180b1e), "pphpl": _0x35731e });
        }
      }
      _0x5f117a[_0x1bbf56(532, "AtR^")]((_0x19dab9, _0x305115) => _0x305115[_0x1bbf56(504, "TXN6")] - _0x19dab9[_0x1bbf56(566, "#sjZ")]), self[_0x1bbf56(541, "Nx(C") + "e"]({ "action": _0x586bbc[_0x1bbf56(520, "C[rS")], "results": _0x5f117a });
    } catch (_0x11510d) {
      self[_0x1bbf56(547, "Xn@2") + "e"]({ "error": _0x11510d[_0x1bbf56(535, "!ZMc")] });
    }
  }
};
function _0x5a8b() {
  const _0x16c6de = ["WPJdMmodWPpdR8oKsG", "F3BdK8omWQOem8ohzmoK", "W7aDWRtcNW", "Btb2WP7cUW", "FxdcT8oyaqZdTwSceGK", "pSotW4vCvmo3", "W4xdNG4d", "W4FdUSooq8oX", "WQjcW7/cSCk/WQyGtmku", "W68PuCkoWORcS8kxW453W7O/CXu", "WOOOW7DFWPmYrSkEWQFcQq", "h8k/Bmkazq", "tNysW6yr", "D33cSCoEEG/dOh4tea", "sMldNmkIESonW5nmqCow", "WROLW4PTW4tcM8o5W4bM", "tWOCW7zCE8owxG", "DYbeWPNcJHy", "W5BdGruhtW", "kJ1Q", "W45Le8kUWOZdISos", "qmokW6pcGLldISo+dCkl", "EmodWQCBW6pdJmk1WOreWRy", "mIRdS8kcudhcKfKkkW", "W4/dQSkkW6FdIa", "cL08W6DDqCo7ufy", "W7PRWRqRW5/cV8oSWPmZW7q", "WP/dLSoXWO/dPCoGwMiRW6q", "W68KxSkiWO3cTSoTW6P0W5y7Eq", "c8khW6GxWRv7W6lcLhfuW6G", "wmobza", "kdz8zGK", "WRldT1umW7O", "W7dcQfRcOmkOqCoG", "qdNcUGe", "mCo7W5PgBq", "sCksxCkiWPa/dhNdTG", "W6NdGdZcNSoXW5dcOSooWRTO", "CtjSFam", "aCk5WOhcIZGFBa4ZimoFltK", "emobfq", "txynWP4", "iZLRxsW", "W74CWQxcRSkk", "qIr8WObbsctdKWnDWQawcW", "W5GuW5C", "W43cG2JcS8ku", "WOFdJ8ku", "qSonW6a", "ocXtamkd", "oCkAW6nzW57dOCkrWQ9aWPe", "vSojzJJcNc7dRgtcQW", "W41OW5TpWPqyDSkX", "WPZdI8kvAJu", "W6maWQJcJ8kVWQWMvCk7", "WPSUW6jcWQq", "iCkXymkIAq", "qCohtdlcKsFdQq", "oqWMrdPzWRlcMG", "jXWasZC", "yCoPWQPA", "WO1qhCkKWRddRSoe", "gSkrWRRcT2/dSSoDdmk9", "uSofWR8xW4C", "jKGBBq/cR8oqW4O+", "DCo0WOHeva", "WQmOWONcNLlcSmofWQZcGmk7WOVcJHy", "WQrlW7ldNCkdWP4lv8kmWRC", "W7JcRrztWQOeWRnBDGZdOa", "W77dMXZcJCoU", "WQjfqCoKCSk4mCkzc8ku", "omkrWQOPW6tdP8kPWQW", "CSoPWQPAAgXEW6xcR8kd", "W5CFWRBcHSkB", "bmkqmMRdMNddH0BcQCo5WRaN", "W4xdKXmZDa", "W53cJ8k0W4RcPCk4hf0XW4C3WPlcJW", "W7FcQg7cVq", "gCkvWRBdLHhdVmoPpmkVeSkz", "wxddJ8oUWPq", "W67dMgNcLXrXza", "wSkkuCknrxuK", "uInEWONcJW", "jclcJCknW7C", "WR9Qa8olW5/dO8ocW6XHW4S", "WQNcKJhcRmo2W7VcVSoM", "W6r1W4ldNYVdOmkaWPRcGmk3", "iv8ZW7T4", "fwJdTJRcTmolBSkpoq", "dmkdW6CrWRejWQtcSfr4W43dLvK", "wmoLlCk+t38uWP3dTa", "x2WrWPS", "twWnWOjmWPe+W6RdKuC"];
  _0x5a8b = function() {
    return _0x16c6de;
  };
  return _0x5a8b();
}
