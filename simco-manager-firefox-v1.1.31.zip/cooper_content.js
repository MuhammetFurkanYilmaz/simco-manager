(function(_0x22e77a, _0x5fdf4a) {
  var _0x3c6535 = _0x30ca, _0x3719df = _0x22e77a();
  while (!![]) {
    try {
      var _0x391b9e = -parseInt(_0x3c6535(141, "chp[")) / (-4534 * -2 + 6259 + -2 * 7663) + -parseInt(_0x3c6535(137, "c(XC")) / (-2759 + -2 + -1 * -2763) + -parseInt(_0x3c6535(133, "dae2")) / (9956 + 27 * -5 + -1 * 9818) + -parseInt(_0x3c6535(131, "84U*")) / (5303 + -401 * 13 + -86) + parseInt(_0x3c6535(126, "(Q1y")) / (2499 + -3457 * -1 + -5951) + parseInt(_0x3c6535(127, "$tRr")) / (2 * 789 + 1904 + -3476) * (parseInt(_0x3c6535(130, "fGr4")) / (1 * -1322 + 171 + 1158)) + parseInt(_0x3c6535(138, "^Z8[")) / (4748 * -1 + -9046 * -1 + -4290);
      if (_0x391b9e === _0x5fdf4a) break;
      else _0x3719df["push"](_0x3719df["shift"]());
    } catch (_0x5339a9) {
      _0x3719df["push"](_0x3719df["shift"]());
    }
  }
})(_0xc679, -1 * 12235 + 14 * 15199 + 794616);
(async function() {
  try {
    const urlParams = new window.URLSearchParams(window.location.search);
    const paramStr = urlParams.get("scx_params");
    if (!paramStr) return;
    const params = JSON.parse(paramStr);
    await delay(3e3);
    const revertBtns = document.querySelectorAll(".revert-cost-btn");
    if (revertBtns.length > 0) {
      for (let i = 0; i < revertBtns.length; i++) {
        revertBtns[i].click();
      }
      await delay(1e3);
    }
    fillForm(params);
    await delay(3e3);
    const resultStr = readResults();
    const parsed = JSON.parse(resultStr);
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", data: parsed.data });
  } catch (err) {
    chrome.runtime.sendMessage({ type: "COOPER_IFRAME_RESULT", error: err.message || err.toString() });
  }
})();
function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function fillForm(params) {
  function setReactValue(element, value) {
    var _a, _b;
    if (!element) return;
    const nativeSetter = (_a = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")) == null ? void 0 : _a.set;
    const selectSetter = (_b = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")) == null ? void 0 : _b.set;
    if (element.tagName === "SELECT") {
      if (selectSetter) selectSetter.call(element, value);
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      if (nativeSetter) nativeSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  const realmButtons = document.querySelectorAll(".realm-btn-optimizer");
  if (realmButtons.length >= 2) {
    if (params.realm === 0 && !realmButtons[0].classList.contains("active")) {
      realmButtons[0].click();
    } else if (params.realm === 1 && !realmButtons[1].classList.contains("active")) {
      realmButtons[1].click();
    }
  }
  setReactValue(document.querySelector("#building-select"), params.buildingLetter);
  setReactValue(document.querySelector("#sales-bonus"), params.salesBonus.toString());
  setReactValue(document.querySelector("#total-levels"), params.totalLevels.toString());
  setReactValue(document.querySelector("#admin-oh"), params.adminOh.toString());
  setReactValue(document.querySelector("#economy-phase-select"), params.economyPhase);
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var pid = firstInput.getAttribute("data-product-id");
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var q = parseInt(qText.replace("Q", "")).toString();
      var costEl = row.querySelector(".cost-input-field");
      var priceEl = row.querySelector(".price-input-field");
      if (!costEl || !priceEl) continue;
      var key = pid + "_" + q;
      var hasCustomCost = params.customPrices && params.customPrices[key] && params.customPrices[key].cost !== void 0 && params.customPrices[key].cost !== null;
      var hasCustomPrice = params.customPrices && params.customPrices[key] && params.customPrices[key].price !== void 0 && params.customPrices[key].price !== null;
      var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
      if (hasCustomPrice) {
        setReactValue(priceEl, params.customPrices[key].price.toString().replace(".", decimalSep));
      }
      if (hasCustomCost) {
        setReactValue(costEl, params.customPrices[key].cost.toString().replace(".", decimalSep));
      } else if (params.discount) {
        var baseCostStr = costEl.getAttribute("data-default-cost");
        var baseCost = parseFloat(baseCostStr);
        if (!isNaN(baseCost) && baseCost > 0) {
          var newCost = baseCost * (1 - params.discount / 100);
          setReactValue(costEl, newCost.toFixed(3).replace(".", decimalSep));
        }
      }
    }
  }
}
function _0x30ca(_0x3252b8, _0x3dc550) {
  _0x3252b8 = _0x3252b8 - (-6922 + 1 * -9263 + 16311);
  var _0x507aaf = _0xc679();
  var _0x5095e0 = _0x507aaf[_0x3252b8];
  if (_0x30ca["rFlGur"] === void 0) {
    var _0x194209 = function(_0x18d65b) {
      var _0x2f54d8 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x704516 = "", _0x4b252a = "";
      for (var _0x514b2b = -3518 + -292 + 3810, _0x43a90c, _0x1d6369, _0x21ac45 = 4854 + -1 * 1676 + 14 * -227; _0x1d6369 = _0x18d65b["charAt"](_0x21ac45++); ~_0x1d6369 && (_0x43a90c = _0x514b2b % (2186 * -1 + -1 * -4150 + -1960) ? _0x43a90c * (-2175 + -913 * 9 + -8 * -1307) + _0x1d6369 : _0x1d6369, _0x514b2b++ % (3776 + -9216 + 1 * 5444)) ? _0x704516 += String["fromCharCode"](-8077 + 144 + 8188 & _0x43a90c >> (-(727 * -8 + -7291 + 13109) * _0x514b2b & -94 * -25 + -16 * 84 + -1e3)) : -5113 * -1 + 2737 + -7850) {
        _0x1d6369 = _0x2f54d8["indexOf"](_0x1d6369);
      }
      for (var _0x1f73a5 = -3454 * -1 + -283 + -21 * 151, _0x94b7e7 = _0x704516["length"]; _0x1f73a5 < _0x94b7e7; _0x1f73a5++) {
        _0x4b252a += "%" + ("00" + _0x704516["charCodeAt"](_0x1f73a5)["toString"](7624 + -3092 * 2 + -1424))["slice"](-(-4 * -2026 + -7638 + -464));
      }
      return decodeURIComponent(_0x4b252a);
    };
    var _0x5edaf8 = function(_0x5b9304, _0x3c40d5) {
      var _0x40acd4 = [], _0x1f3918 = 913 * -3 + -13 * -435 + -2916, _0x22c21d, _0x189396 = "";
      _0x5b9304 = _0x194209(_0x5b9304);
      var _0x4d9734;
      for (_0x4d9734 = -8873 + -9461 + -9167 * -2; _0x4d9734 < 4 * 827 + -2606 + -446 * 1; _0x4d9734++) {
        _0x40acd4[_0x4d9734] = _0x4d9734;
      }
      for (_0x4d9734 = 2812 * 3 + 2298 + -10734; _0x4d9734 < 5567 + 1 * 5406 + -10717; _0x4d9734++) {
        _0x1f3918 = (_0x1f3918 + _0x40acd4[_0x4d9734] + _0x3c40d5["charCodeAt"](_0x4d9734 % _0x3c40d5["length"])) % (-7804 + 1 * -3394 + 11454), _0x22c21d = _0x40acd4[_0x4d9734], _0x40acd4[_0x4d9734] = _0x40acd4[_0x1f3918], _0x40acd4[_0x1f3918] = _0x22c21d;
      }
      _0x4d9734 = -9803 + -4495 * 1 + 14298, _0x1f3918 = -22 * 194 + -1 * -3871 + 397;
      for (var _0xf65959 = -9559 + -4 * 43 + 37 * 263; _0xf65959 < _0x5b9304["length"]; _0xf65959++) {
        _0x4d9734 = (_0x4d9734 + (8679 + -9594 + 916 * 1)) % (9821 * 1 + 8149 * -1 + -1416), _0x1f3918 = (_0x1f3918 + _0x40acd4[_0x4d9734]) % (6528 + -1958 + -4314), _0x22c21d = _0x40acd4[_0x4d9734], _0x40acd4[_0x4d9734] = _0x40acd4[_0x1f3918], _0x40acd4[_0x1f3918] = _0x22c21d, _0x189396 += String["fromCharCode"](_0x5b9304["charCodeAt"](_0xf65959) ^ _0x40acd4[(_0x40acd4[_0x4d9734] + _0x40acd4[_0x1f3918]) % (6 * 1554 + -1 * 6734 + 2334 * -1)]);
      }
      return _0x189396;
    };
    _0x30ca["pYXVgB"] = _0x5edaf8, _0x30ca["uNYwOx"] = {}, _0x30ca["rFlGur"] = !![];
  }
  var _0x1feb5b = _0x507aaf[-4 * 1657 + -3190 + 4909 * 2], _0x550f02 = _0x3252b8 + _0x1feb5b, _0x432414 = _0x30ca["uNYwOx"][_0x550f02];
  return !_0x432414 ? (_0x30ca["jMuygm"] === void 0 && (_0x30ca["jMuygm"] = !![]), _0x5095e0 = _0x30ca["pYXVgB"](_0x5095e0, _0x3dc550), _0x30ca["uNYwOx"][_0x550f02] = _0x5095e0) : _0x5095e0 = _0x432414, _0x5095e0;
}
function _0xc679() {
  var _0x2c0505 = ["W5tdVuRdIdGAW6rIW5FdLmk3fmk4", "W6xdUgRcUSkxW60NnSo4emkW", "dSkEyKjJWQddUJGCamo2hCoQwW", "W5BdVuldJZ0AW6vLW5NdGCkfd8kc", "W7Svu8kmqmoXWQddKspdJSkN", "WRJcNI9jBNJcGSowW6ddJHy3", "j8onW6Kmv8kZAetdQmkFW71DW4S", "W7GzxCoxnCowWQddPJu", "nSkdW7hcJSkPWRdcJSodzxZcH8kkjW", "WOFdKmkDDeiPqmk/wW", "nJqGWQn/W7akbYuvWP0c", "W44bimoXiqSgWRxdIqHpWQf8", "bCkEzK5RWQtcUMqgjmofnW", "WRtcJCoXemo4W6tdQstcNx4WECkg", "W6RcJmo8ueNcRYemW4ZdNCocgW", "zCk4qCoNac3cPY/cGmoFWQ92x0q"];
  _0xc679 = function() {
    return _0x2c0505;
  };
  return _0xc679();
}
function readResults() {
  function parseLocaleNumber(s) {
    if (!s) return 0;
    s = String(s).trim().replace(/\s+/g, "");
    var match = s.match(/[\d.,]+/);
    if (!match) return 0;
    var isNegative = s.slice(0, match.index).includes("-");
    s = match[0];
    var decimalSep = 1.1.toLocaleString().includes(",") ? "," : ".";
    var thousandSep = decimalSep === "," ? "." : ",";
    s = s.split(thousandSep).join("").replace(decimalSep, ".");
    return (isNegative ? -1 : 1) * parseFloat(s);
  }
  var results = [];
  var productGroups = document.querySelectorAll(".product-group");
  for (var g = 0; g < productGroups.length; g++) {
    var group = productGroups[g];
    var firstInput = group.querySelector("[data-product-id]");
    if (!firstInput) continue;
    var productId = parseInt(firstInput.getAttribute("data-product-id"));
    var h3 = group.querySelector("h3");
    var productName = h3 ? h3.textContent.trim() : "Product " + productId;
    var rows = group.querySelectorAll("tbody tr");
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var qCell = row.querySelector(".cell-left");
      if (!qCell) continue;
      var qText = qCell.textContent.trim();
      var quality = parseInt(qText.replace("Q", ""));
      if (isNaN(quality)) continue;
      var pphplEl = row.querySelector(".cell-pphpl");
      var pphplText = pphplEl ? pphplEl.textContent.trim() : "0";
      var priceInput = row.querySelector(".price-input-field");
      var priceVal = priceInput ? priceInput.value : "";
      var costInput = row.querySelector(".cost-input-field");
      var costVal = costInput ? costInput.value : "0";
      var price = parseLocaleNumber(priceVal);
      var cost = parseLocaleNumber(costVal);
      var profitEl = row.querySelector(".cell-profit");
      var usphEl = row.querySelector(".cell-usph");
      var uspdEl = row.querySelector(".cell-uspd");
      var revEl = row.querySelector(".cell-revenue");
      results.push({ productId, productName, quality, price, cost, profitPerUnit: price - cost, profitPerDay: parseLocaleNumber(profitEl ? profitEl.textContent : "0"), unitsPerHr: parseLocaleNumber(usphEl ? usphEl.textContent : "0"), unitsPerDay: parseLocaleNumber(uspdEl ? uspdEl.textContent : "0"), grossRevPerDay: parseLocaleNumber(revEl ? revEl.textContent : "0"), pphpl: parseLocaleNumber(pphplText) });
    }
  }
  results.sort(function(a, b) {
    return b.pphpl - a.pphpl;
  });
  return JSON.stringify({ data: results });
}
