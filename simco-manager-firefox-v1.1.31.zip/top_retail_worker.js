function _0x2ce4(_0x5c0110, _0x5db97e) {
  _0x5c0110 = _0x5c0110 - (-7638 + 8209 + -148);
  const _0x122ecb = _0x169b();
  let _0x433eec = _0x122ecb[_0x5c0110];
  if (_0x2ce4["SMlkim"] === void 0) {
    var _0x120335 = function(_0x64be33) {
      const _0x2c2417 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x30bc2f = "", _0x540f74 = "";
      for (let _0x2e14d9 = 373 * 5 + 67 * 107 + -9034, _0xf4c689, _0x56dfdf, _0x27f768 = 101 * -93 + 6576 + 3 * 939; _0x56dfdf = _0x64be33["charAt"](_0x27f768++); ~_0x56dfdf && (_0xf4c689 = _0x2e14d9 % (-5462 * 1 + 1 * 5891 + -425) ? _0xf4c689 * (8 * -1113 + 8434 + 178 * 3) + _0x56dfdf : _0x56dfdf, _0x2e14d9++ % (-11 * -35 + 33 * 173 + -30 * 203)) ? _0x30bc2f += String["fromCharCode"](1 * 1413 + 9721 + -10879 & _0xf4c689 >> (-(102 + 1357 + -1457) * _0x2e14d9 & 1304 + 1854 + -3152)) : -3 * -1730 + 5765 + -10955) {
        _0x56dfdf = _0x2c2417["indexOf"](_0x56dfdf);
      }
      for (let _0xe628ca = 2988 + -6149 + 1 * 3161, _0x11482f = _0x30bc2f["length"]; _0xe628ca < _0x11482f; _0xe628ca++) {
        _0x540f74 += "%" + ("00" + _0x30bc2f["charCodeAt"](_0xe628ca)["toString"](5831 + -6651 + 836))["slice"](-(-113 * 31 + -2 * -4511 + -5517));
      }
      return decodeURIComponent(_0x540f74);
    };
    const _0x26778f = function(_0x42b714, _0xee1dbc) {
      let _0x4c8362 = [], _0x9694a4 = 575 * 6 + -5128 + 1678, _0x25d94a, _0x5d6cf1 = "";
      _0x42b714 = _0x120335(_0x42b714);
      let _0x5acec1;
      for (_0x5acec1 = 9512 + -4 * -1427 + -7610 * 2; _0x5acec1 < -3319 + -1213 + 4788; _0x5acec1++) {
        _0x4c8362[_0x5acec1] = _0x5acec1;
      }
      for (_0x5acec1 = -101 * -17 + 67 * 55 + -146 * 37; _0x5acec1 < -6465 + 5599 + -561 * -2; _0x5acec1++) {
        _0x9694a4 = (_0x9694a4 + _0x4c8362[_0x5acec1] + _0xee1dbc["charCodeAt"](_0x5acec1 % _0xee1dbc["length"])) % (1 * -5689 + -5 * -1263 + -370), _0x25d94a = _0x4c8362[_0x5acec1], _0x4c8362[_0x5acec1] = _0x4c8362[_0x9694a4], _0x4c8362[_0x9694a4] = _0x25d94a;
      }
      _0x5acec1 = -8045 + -891 + 8936, _0x9694a4 = 1858 * 2 + 256 * 31 + -11652;
      for (let _0x3773b1 = -14 * 126 + -2 * -3860 + -5956; _0x3773b1 < _0x42b714["length"]; _0x3773b1++) {
        _0x5acec1 = (_0x5acec1 + (-1328 + -456 + 1785)) % (-6533 * -1 + 9012 + -15289), _0x9694a4 = (_0x9694a4 + _0x4c8362[_0x5acec1]) % (-7037 + -1854 * 5 + 16563), _0x25d94a = _0x4c8362[_0x5acec1], _0x4c8362[_0x5acec1] = _0x4c8362[_0x9694a4], _0x4c8362[_0x9694a4] = _0x25d94a, _0x5d6cf1 += String["fromCharCode"](_0x42b714["charCodeAt"](_0x3773b1) ^ _0x4c8362[(_0x4c8362[_0x5acec1] + _0x4c8362[_0x9694a4]) % (3616 + 9461 * 1 + 1 * -12821)]);
      }
      return _0x5d6cf1;
    };
    _0x2ce4["HnAnYb"] = _0x26778f, _0x2ce4["LfYcZY"] = {}, _0x2ce4["SMlkim"] = !![];
  }
  const _0x1a5196 = _0x122ecb[8871 * 1 + 937 + -9808], _0x3e090a = _0x5c0110 + _0x1a5196, _0x24c017 = _0x2ce4["LfYcZY"][_0x3e090a];
  return !_0x24c017 ? (_0x2ce4["woAtbt"] === void 0 && (_0x2ce4["woAtbt"] = !![]), _0x433eec = _0x2ce4["HnAnYb"](_0x433eec, _0x5db97e), _0x2ce4["LfYcZY"][_0x3e090a] = _0x433eec) : _0x433eec = _0x24c017, _0x433eec;
}
const _0xa8a381 = _0x2ce4;
function _0x169b() {
  const _0x1ac796 = ["WQ7cImoilSkcWPfTW4GpW7G", "W6tcPCkMpSkAja", "W6fGW7dcKG", "WP7dJSkhW6ldU3yXWOtcVG", "W6y7y8oyW6P9xCogWOK", "WOtdNCkGW7pdUW", "p8ozuxO", "vey/W7Hm", "D8kSW73dO8kSW5FdLJOJW78", "cXeuiSoiW6pdSIldGxu", "emoDxdRcSKjfWPJdGG", "WP3dJt/dKmoItSkoW4KreK8kW68", "W4j6jSksWQLnW5i", "WQRdLYGCWO5qvgJdGmoJC8oqWQXn", "h3FcLCo9eCoLFa", "yxxdQmk5fCoDWQWXDSo3", "WROfkSk6W5BdImk9WOG", "W4zYE8oVpZDwW4HLkb8M", "kwnf", "pMRcOmonmW", "W5JcNhxcVmkI", "hmkFW7fLqG", "efpcSxHb", "W5vMW6pdImkEW6tcQ8kjz1O", "l1tcMXm", "vCkckHFcV1ff", "WR3dTSkuhmol", "E3RdTSkRfG", "gmo5WR/cP2RdPYL/yg/dMq", "FfSL", "WRPgWQFcL8oZWRBdUG", "xGFdJGhcRSkugMe", "CLmNW4DhsftcJgK", "ASkQW6a", "heldIYa", "WPRdJJ3dN8oRsmkkW4aejwuLW7u", "W5ZdTSoReSkN", "W6G/W5i", "W77dLYiTW68", "gxFcPSo6dq", "kZiReq", "WORdICoyWP3dRHhcOmoNW7W0", "W5Hhm8kxW4ldKCkbW7i", "WPRdRSkgmSo9", "mSoFW7xcGXpcS3bQq2C", "xvfnrmkS", "sG3cGSo6DCo5", "WQZdOCkpjmoa", "FCk6W4Kddq", "gmo3WRVcQwhcMKLcFKxdTmkRqW", "mKdcLSombG", "WOa4k8k4W7i", "hSomWRr5wSoeW78wWPZdM3xcKa", "FuJcJmobW60FW4Ke", "hdCBW5tdVa", "WPygW61OW5JdHuPHW7xdN8ouW63dMSop", "W4NdTgZdN8oCb8oNxNO", "D8kXW6hdS8kuW5hdKqaM", "DmkdW7BcHZRcH0bF", "dWW3kCokW6xdTc/dGwS", "W73cKgdcNmk+hCokW58tqq", "WOJdNvSWfHaKqmoK", "yw5VuedcVSkEs8kSBSkBWQG", "W5fMW5ZdK8kKW6tcQSk5z04", "Ca3cTSo+BmoWWRa", "WPNcSeK", "W5tcHWrSvvf1vmoNW4tdOgpdPG", "W6GzW7/cSSkF", "hCo2WRNcRMVcNK9Ox3ddPSkMzq", "WPNcUf8", "WQbNnmkfWQThymoUWORcPbi", "W6yVW5BcPwy", "WOPjWPldMsBcISk5oHeCWRSS", "kc0Xfru", "WQCCySonW61VEq", "pdWTba", "yLm/W5faruhcKwpcPa", "bCooW67cUwi", "wmkehWVcLG", "WQZdG8k9aCo0", "DHxcG8oGBq", "yHRcK8oLEq", "W7NcIhjf", "AwTRveRcVmoTwSkYtSkhWRuI", "WO7cRdBdKmoa", "D0bFWOfIuSks", "W4hdTdGpW58", "ENv6xCkY"];
  _0x169b = function() {
    return _0x1ac796;
  };
  return _0x169b();
}
(function(_0x1e1728, _0x475833) {
  const _0x4c7d4b = _0x2ce4, _0x59cf3d = _0x1e1728();
  while (!![]) {
    try {
      const _0x1ce248 = parseInt(_0x4c7d4b(507, "EVvt")) / (-1181 * 3 + 4457 * 1 + -913) + parseInt(_0x4c7d4b(470, "Sa*]")) / (-7 * 242 + 73 * -51 + 1 * 5419) + -parseInt(_0x4c7d4b(487, "WU95")) / (2983 + -2439 + -541 * 1) * (-parseInt(_0x4c7d4b(437, "J!s#")) / (5836 * -1 + -4711 * -1 + 1129)) + parseInt(_0x4c7d4b(458, "DxaX")) / (1 * 3943 + 7239 + -11177) * (parseInt(_0x4c7d4b(472, "MkxE")) / (-4 * 1082 + -7663 * -1 + 1 * -3329)) + -parseInt(_0x4c7d4b(468, "D3AO")) / (9578 * -1 + 8926 + 659 * 1) + parseInt(_0x4c7d4b(474, "4[30")) / (-5 * -1064 + 1301 * -5 + -1193 * -1) * (parseInt(_0x4c7d4b(455, "W!r4")) / (-143 * 52 + 9936 + -2491)) + parseInt(_0x4c7d4b(444, "9yfy")) / (-8067 + -3151 * -2 + 1775) * (-parseInt(_0x4c7d4b(457, "cDPP")) / (9160 + -1 * 9073 + -19 * 4));
      if (_0x1ce248 === _0x475833) break;
      else _0x59cf3d["push"](_0x59cf3d["shift"]());
    } catch (_0x1ac124) {
      _0x59cf3d["push"](_0x59cf3d["shift"]());
    }
  }
})(_0x169b, -433723 * 3 + -133022 + -1 * -2271023), self[_0xa8a381(463, "D3AO")] = async (_0x59ff5b) => {
  const _0x52360e = _0xa8a381, _0x476e2c = { "QAOLn": function(_0x4730fb, _0x35f797) {
    return _0x4730fb === _0x35f797;
  }, "DZHDp": _0x52360e(462, "J!s#") + _0x52360e(490, "(Wt2") + "or", "DxzaD": function(_0x3ac8f8, _0x10dac0) {
    return _0x3ac8f8 !== _0x10dac0;
  }, "injgq": function(_0x489ca9, _0x5935da) {
    return _0x489ca9 === _0x5935da;
  }, "UoaYO": _0x52360e(484, "RmFX"), "rwswy": function(_0x45a079, _0xe06dfd) {
    return _0x45a079 <= _0xe06dfd;
  }, "jOnfQ": function(_0x4d7a8b, _0x57d0e8) {
    return _0x4d7a8b == _0x57d0e8;
  }, "fxcrm": function(_0x1e9541, _0x2215f8) {
    return _0x1e9541 + _0x2215f8;
  }, "UUrIy": function(_0xbc7013, _0x359aa6) {
    return _0xbc7013 * _0x359aa6;
  }, "yisuQ": function(_0x1bb82f, _0x58f8b3) {
    return _0x1bb82f / _0x58f8b3;
  }, "mGUHF": function(_0x5b2772, _0x336c6c) {
    return _0x5b2772 * _0x336c6c;
  }, "UrsYZ": function(_0x131ca4, _0x29ad8f) {
    return _0x131ca4 - _0x29ad8f;
  }, "jaHuu": function(_0x49d974, _0x48fe4c) {
    return _0x49d974 * _0x48fe4c;
  }, "vhjKi": function(_0x33580f, _0x6e7b13) {
    return _0x33580f - _0x6e7b13;
  }, "YXEXo": function(_0x5e25a5, _0x561800) {
    return _0x5e25a5 < _0x561800;
  }, "FJiWa": function(_0x31dca1, _0x5e0408) {
    return _0x31dca1(_0x5e0408);
  }, "vexUp": function(_0x43e467, _0x168f27) {
    return _0x43e467(_0x168f27);
  }, "zyZTf": function(_0x5c51c2, _0x230872) {
    return _0x5c51c2(_0x230872);
  } }, { action: _0x203f3a, products: _0x135451, adminOverhead: _0x548042, salesBonus: _0x5b6a02, economyPhase: _0x456022, simulateError: _0x41e7c7 } = _0x59ff5b[_0x52360e(477, "C9xK")];
  if (_0x476e2c[_0x52360e(450, ")ZcT")](_0x203f3a, _0x52360e(434, "5MUp"))) {
    if (_0x41e7c7) {
      self[_0x52360e(446, "01Yw") + "e"]({ "error": _0x476e2c[_0x52360e(481, "GCd^")] });
      return;
    }
    try {
      const _0x4699c2 = _0x476e2c[_0x52360e(449, "GCd^")](_0x548042, void 0) ? _0x548042 : 10 * 831 + -206 * 17 + -601 * 8, _0x2df5da = _0x476e2c[_0x52360e(424, "I7ES")](_0x5b6a02, void 0) ? _0x5b6a02 : 59 * -97 + -9674 + 173 * 89, _0xfe4ca9 = _0x456022 || _0x52360e(448, "3N7G"), _0x4da5b7 = Math[_0x52360e(439, "HT9b")](-30 * 30 + -59 * -109 + 1 * -5531, Math[_0x52360e(431, "5MUp")](_0x4699c2, -1624 + 5748 + -327 * 12)), _0x24c5d1 = Math[_0x52360e(508, "WU95")](5 * -811 + 6869 * 1 + -2814, Math[_0x52360e(435, "PC&o")](_0x2df5da, 3399 + 2747 + 6096 * -1)), _0x267296 = _0x476e2c[_0x52360e(429, "^X%9")](_0xfe4ca9[_0x52360e(461, "HjIh") + "e"](), _0x52360e(494, "MkxE")) ? -1 * 2437 + -7888 + 10325 + 0.9 : _0x476e2c[_0x52360e(489, "bBc1")](_0xfe4ca9[_0x52360e(425, ")rbo") + "e"](), _0x476e2c[_0x52360e(428, "GCd^")]) ? 5244 + 3719 + -8962 + 0.1200000000000001 : 7632 + -2096 + -5535, _0x5223cc = [];
      for (const _0x1276ad of _0x135451) {
        for (let _0xdc3ada = -5207 * 1 + -1 * -7483 + 1138 * -2; _0x476e2c[_0x52360e(445, "GCd^")](_0xdc3ada, 5473 + 3 * 63 + -1 * 5653); _0xdc3ada++) {
          const _0x45e829 = _0xdc3ada, _0x5f4a27 = _0x476e2c[_0x52360e(482, "3N7G")](_0x1276ad[_0x52360e(505, "^X%9")], 5742 + 4685 * -1 + -1 * 1057) || _0x476e2c[_0x52360e(453, "9yfy")](_0x1276ad[_0x52360e(478, "5MUp")], null) ? 6756 + -7 * -15 + -6861 + 0.1 : Math[_0x52360e(467, "q11s")](8492 + 4362 * 2 + -17216 + 0.1, Math[_0x52360e(471, "q11s")](_0x1276ad[_0x52360e(478, "5MUp")], 2221 * 1 + -2 * -4804 + 16 * -739)), _0x3f6c25 = _0x476e2c[_0x52360e(483, "3N7G")](6764 + -1 * 2780 + -3983, _0x45e829 * (-19 * -17 + -9245 + 4461 * 2 + 0.05)), _0x186e1f = -2582 * 3 + 558 * 9 + -2824 * -1, _0x52978c = _0x476e2c[_0x52360e(473, "4[30")](_0x476e2c[_0x52360e(480, "RvQ#")](_0x186e1f, _0x5f4a27), _0x3f6c25) * _0x267296 * (31 * -30 + -9341 + 10272 + _0x476e2c[_0x52360e(488, "gMcJ")](_0x24c5d1, -8178 + -4754 + 13032)), _0x244747 = _0x476e2c[_0x52360e(488, "gMcJ")](_0x52978c, 8771 + -79 * 57 + -4244), _0x12cec1 = _0x1276ad[_0x52360e(443, "inQz") + "ce"] || _0x476e2c[_0x52360e(469, "HT9b")](_0x1276ad[_0x52360e(492, "S2b0")], -1 * -5755 + 3 * 2 + -5760 + 0.5), _0x42f3dd = _0x476e2c[_0x52360e(509, "ZxMY")](_0x12cec1, _0x1276ad[_0x52360e(496, "@seE")]), _0x2012ae = _0x476e2c[_0x52360e(495, "Ul5Q")](_0x52978c, _0x12cec1), _0x6afaf3 = _0x476e2c[_0x52360e(423, "!DET")](_0x2012ae, _0x4da5b7 / (679 * -3 + 1193 + 944)), _0x1cc5d7 = _0x476e2c[_0x52360e(486, "DxaX")](_0x52978c * _0x42f3dd, _0x6afaf3);
          if (_0x476e2c[_0x52360e(452, "ZxMY")](_0x1cc5d7, -4079 + -1 * 8045 + -14 * -866)) continue;
          _0x5223cc[_0x52360e(436, "RHlU")]({ "productId": _0x1276ad[_0x52360e(459, "PC&o")], "productName": _0x1276ad[_0x52360e(499, "HjIh") + "e"] || _0x52360e(506, "9yfy") + _0x1276ad[_0x52360e(493, "Ul5Q")], "quality": _0x45e829, "price": _0x476e2c[_0x52360e(440, "gMcJ")](parseFloat, _0x12cec1[_0x52360e(427, "RvQ#")](-838 * -4 + 751 * -8 + 3 * 886)), "cost": _0x476e2c[_0x52360e(510, "J!s#")](parseFloat, _0x1276ad[_0x52360e(426, "W!d*")][_0x52360e(466, "3N7G")](-9 * -1011 + -196 * -35 + -15957)), "profitPerUnit": _0x476e2c[_0x52360e(497, "hlaJ")](parseFloat, _0x42f3dd[_0x52360e(504, "ZxMY")](-192 + -3786 + 3980 * 1)), "profitPerDay": Math[_0x52360e(438, "^j3T")](_0x1cc5d7), "grossRevPerDay": Math[_0x52360e(441, "ZxMY")](_0x2012ae), "unitsPerHr": _0x476e2c[_0x52360e(447, "bBc1")](parseFloat, _0x244747[_0x52360e(502, "sAW^")](-413 * 21 + 2550 + -6124 * -1)), "unitsPerDay": Math[_0x52360e(479, "VpgT")](_0x52978c), "pphpl": _0x1cc5d7 });
        }
      }
      _0x5223cc[_0x52360e(442, "C9xK")]((_0x10bac4, _0x20308f) => _0x20308f[_0x52360e(456, ")HOW")] - _0x10bac4[_0x52360e(475, "C9xK")]), self[_0x52360e(465, ")rbo") + "e"]({ "action": _0x52360e(491, "]Yt*"), "results": _0x5223cc });
    } catch (_0x339d56) {
      self[_0x52360e(498, "PC&o") + "e"]({ "error": _0x339d56[_0x52360e(432, "rY$f")] });
    }
  }
};
