const _0x5dec67 = _0x1138;
(function(_0x2f5f1f, _0x15162d) {
  const _0x45edc8 = _0x1138, _0x51f554 = _0x2f5f1f();
  while (!![]) {
    try {
      const _0x464507 = -parseInt(_0x45edc8(418)) / 1 + -parseInt(_0x45edc8(494)) / 2 * (parseInt(_0x45edc8(420)) / 3) + -parseInt(_0x45edc8(473)) / 4 * (-parseInt(_0x45edc8(456)) / 5) + parseInt(_0x45edc8(416)) / 6 + -parseInt(_0x45edc8(424)) / 7 + parseInt(_0x45edc8(449)) / 8 + parseInt(_0x45edc8(427)) / 9 * (-parseInt(_0x45edc8(489)) / 10);
      if (_0x464507 === _0x15162d) break;
      else _0x51f554["push"](_0x51f554["shift"]());
    } catch (_0x348ff3) {
      _0x51f554["push"](_0x51f554["shift"]());
    }
  }
})(_0x58bf, 432512);
function _0x1138(_0x5e2c7d, _0x3f9765) {
  _0x5e2c7d = _0x5e2c7d - 398;
  const _0x58bf1a = _0x58bf();
  let _0x1138f9 = _0x58bf1a[_0x5e2c7d];
  if (_0x1138["rKcVLm"] === void 0) {
    var _0x14449a = function(_0x533fbb) {
      const _0x341004 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0xcfe22c = "", _0x35f7ea = "";
      for (let _0x59732a = 0, _0xd00d07, _0x53e6a7, _0x3545a7 = 0; _0x53e6a7 = _0x533fbb["charAt"](_0x3545a7++); ~_0x53e6a7 && (_0xd00d07 = _0x59732a % 4 ? _0xd00d07 * 64 + _0x53e6a7 : _0x53e6a7, _0x59732a++ % 4) ? _0xcfe22c += String["fromCharCode"](255 & _0xd00d07 >> (-2 * _0x59732a & 6)) : 0) {
        _0x53e6a7 = _0x341004["indexOf"](_0x53e6a7);
      }
      for (let _0x176170 = 0, _0x4c1a52 = _0xcfe22c["length"]; _0x176170 < _0x4c1a52; _0x176170++) {
        _0x35f7ea += "%" + ("00" + _0xcfe22c["charCodeAt"](_0x176170)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x35f7ea);
    };
    _0x1138["wbvMph"] = _0x14449a, _0x1138["afcmOk"] = {}, _0x1138["rKcVLm"] = !![];
  }
  const _0x23a91e = _0x58bf1a[0], _0x57b68d = _0x5e2c7d + _0x23a91e, _0xfd8dbf = _0x1138["afcmOk"][_0x57b68d];
  return !_0xfd8dbf ? (_0x1138f9 = _0x1138["wbvMph"](_0x1138f9), _0x1138["afcmOk"][_0x57b68d] = _0x1138f9) : _0x1138f9 = _0xfd8dbf, _0x1138f9;
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0xcfe22c) {
  return new Promise((_0x35f7ea) => setTimeout(_0x35f7ea, _0xcfe22c));
}
function normalizeDomain$1(_0x59732a) {
  const _0x1a60fb = _0x1138;
  return String(_0x59732a || _0x1a60fb(434))[_0x1a60fb(486)]()[_0x1a60fb(428)]();
}
function makeError(_0xd00d07, _0x53e6a7 = {}) {
  const _0x3545a7 = new Error(_0xd00d07);
  return Object["assign"](_0x3545a7, _0x53e6a7), _0x3545a7;
}
function buildInflightKey(_0x176170, _0x4c1a52, _0x1a20bc, _0x2ade6c) {
  if (_0x4c1a52) return _0x176170 + ":" + _0x4c1a52;
  return _0x176170 + ":" + _0x2ade6c + ":" + _0x1a20bc;
}
function getRateLimitStatus(_0x4634a5 = "default") {
  const _0x1bc231 = _0x1138, _0x58f720 = normalizeDomain$1(_0x4634a5), _0x46062f = Number(rateLimitByDomain[_0x1bc231(414)](_0x58f720) || 0), _0x5c1453 = Math[_0x1bc231(430)](0, _0x46062f - Date[_0x1bc231(405)]());
  return { "blocked": _0x5c1453 > 0, "remainingMs": _0x5c1453, "blockedUntil": _0x46062f };
}
async function parseResponse(_0x124ea5, _0x389287) {
  const _0x4ca6a7 = _0x1138;
  if (_0x389287 === _0x4ca6a7(488)) return _0x124ea5;
  if (_0x389287 === "text") return _0x124ea5[_0x4ca6a7(464)]();
  if (_0x389287 === _0x4ca6a7(466)) return _0x124ea5[_0x4ca6a7(466)]();
  if (_0x389287 === _0x4ca6a7(479)) return _0x124ea5[_0x4ca6a7(479)]();
  return _0x124ea5[_0x4ca6a7(480)]();
}
async function doRequest(_0x51528f, _0x43ee19, _0x32b89a = 0) {
  const _0x20836d = _0x1138, { url: _0x487834, method = "GET", headers: _0x4cc8f3, body: _0xc889c8, credentials = _0x20836d(417), signal: _0x30971b, responseType = _0x20836d(480), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x43ee19, _0x27c166 = getRateLimitStatus(_0x51528f);
  if (_0x27c166[_0x20836d(398)]) throw makeError(_0x20836d(471) + Math[_0x20836d(463)](_0x27c166[_0x20836d(407)] / 1e3), { "code": _0x20836d(490), "domain": _0x51528f, "remainingMs": _0x27c166[_0x20836d(407)], "status": 429 });
  const _0x2e9be7 = timeoutMs > 0 ? new AbortController() : null, _0x4c6fce = _0x2e9be7 && timeoutMs > 0 ? setTimeout(() => _0x2e9be7[_0x20836d(403)](makeError(_0x20836d(415), { "code": _0x20836d(413), "domain": _0x51528f })), timeoutMs) : null, _0x1c13ec = _0x2e9be7 ? _0x2e9be7[_0x20836d(431)] : _0x30971b;
  try {
    const _0xed2cba = await fetch(_0x487834, { "method": method, "headers": _0x4cc8f3, "body": _0xc889c8, "credentials": credentials, "signal": _0x1c13ec });
    if (_0xed2cba[_0x20836d(495)] === 429 && rateLimitCooldownMs > 0) {
      const _0x5abe0f = (rateLimitHitCount[_0x20836d(414)](_0x51528f) || 0) + 1;
      rateLimitHitCount[_0x20836d(478)](_0x51528f, _0x5abe0f);
      const _0x162eae = _0x5abe0f <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x20836d(478)](_0x51528f, Date["now"]() + _0x162eae);
    }
    if (!_0xed2cba["ok"]) {
      const _0x166ec9 = _0x32b89a < retries && retryStatuses[_0x20836d(493)](_0xed2cba[_0x20836d(495)]);
      if (_0x166ec9) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x51528f, _0x43ee19, _0x32b89a + 1);
      }
      throw makeError(_0x20836d(421) + _0xed2cba["status"], { "code": _0x20836d(444), "domain": _0x51528f, "status": _0xed2cba["status"] });
    }
    return rateLimitHitCount[_0x20836d(451)](_0x51528f), parseResponse(_0xed2cba, responseType);
  } catch (_0x1b5ed6) {
    const _0x5b76f0 = (_0x1b5ed6 == null ? void 0 : _0x1b5ed6[_0x20836d(450)]) === _0x20836d(475), _0x4b6dac = !_0x5b76f0 && _0x32b89a < retries;
    if (_0x4b6dac) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x51528f, _0x43ee19, _0x32b89a + 1);
    }
    if (_0x1b5ed6 instanceof Error && _0x1b5ed6[_0x20836d(435)]) throw _0x1b5ed6;
    throw makeError(String((_0x1b5ed6 == null ? void 0 : _0x1b5ed6[_0x20836d(465)]) || _0x1b5ed6 || _0x20836d(412)), { "code": _0x5b76f0 ? _0x20836d(497) : "NETWORK_ERROR", "domain": _0x51528f, "status": Number((_0x1b5ed6 == null ? void 0 : _0x1b5ed6[_0x20836d(495)]) || 0) || null, "cause": _0x1b5ed6 });
  } finally {
    if (_0x4c6fce) clearTimeout(_0x4c6fce);
  }
}
async function request(_0x5ef7ee, _0x249abb) {
  const _0x1afe4a = _0x1138, _0x25e7b9 = normalizeDomain$1(_0x5ef7ee), _0x5e9b2d = buildInflightKey(_0x25e7b9, _0x249abb == null ? void 0 : _0x249abb[_0x1afe4a(410)], _0x249abb == null ? void 0 : _0x249abb[_0x1afe4a(425)], (_0x249abb == null ? void 0 : _0x249abb["method"]) || "GET");
  if ((_0x249abb == null ? void 0 : _0x249abb[_0x1afe4a(399)]) && inflightByKey[_0x1afe4a(447)](_0x5e9b2d)) return inflightByKey[_0x1afe4a(414)](_0x5e9b2d);
  const _0x5f44a7 = doRequest(_0x25e7b9, _0x249abb || {})["finally"](() => {
    inflightByKey["delete"](_0x5e9b2d);
  });
  return (_0x249abb == null ? void 0 : _0x249abb[_0x1afe4a(399)]) && inflightByKey["set"](_0x5e9b2d, _0x5f44a7), _0x5f44a7;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x428c21) {
  const _0xb130bd = _0x1138, _0x2cf03a = _0x428c21 == null ? void 0 : _0x428c21[_0xb130bd(470)];
  STATE[_0xb130bd(455)][_0xb130bd(472)] = (_0x2cf03a == null ? void 0 : _0x2cf03a["companyId"]) ?? null, STATE[_0xb130bd(455)][_0xb130bd(432)] = (_0x2cf03a == null ? void 0 : _0x2cf03a[_0xb130bd(432)]) ?? null, STATE["auth"][_0xb130bd(496)] = (_0x2cf03a == null ? void 0 : _0x2cf03a[_0xb130bd(496)]) ?? null, STATE[_0xb130bd(455)][_0xb130bd(461)] = (_0x2cf03a == null ? void 0 : _0x2cf03a[_0xb130bd(461)]) ?? null, STATE[_0xb130bd(455)]["loaded"] = !![];
  const _0x416545 = _0x428c21 == null ? void 0 : _0x428c21["levelInfo"];
  STATE[_0xb130bd(484)][_0xb130bd(467)] = (_0x416545 == null ? void 0 : _0x416545["level"]) ?? null, STATE["levelInfo"][_0xb130bd(469)] = (_0x416545 == null ? void 0 : _0x416545[_0xb130bd(469)]) ?? null, STATE[_0xb130bd(484)][_0xb130bd(440)] = (_0x416545 == null ? void 0 : _0x416545[_0xb130bd(440)]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x4899d8 = _0x1138;
  if (!force && STATE[_0x4899d8(455)][_0x4899d8(423)] || STATE["auth"][_0x4899d8(400)]) return;
  STATE[_0x4899d8(455)]["loading"] = !![], STATE[_0x4899d8(455)]["error"] = null;
  try {
    const _0x30bac0 = await request("auth", { "url": _0x4899d8(482), "credentials": "include", "responseType": _0x4899d8(480), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x30bac0);
  } catch (_0x13f38b) {
    STATE["auth"][_0x4899d8(438)] = String((_0x13f38b == null ? void 0 : _0x13f38b[_0x4899d8(465)]) || _0x13f38b);
  } finally {
    STATE[_0x4899d8(455)][_0x4899d8(400)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x5dec67(409), _0x5dec67(408), "global"]);
function normalizeScopeMode(_0x5aa8a4) {
  const _0x77a4bd = _0x5dec67;
  if (VALID_SCOPE_MODES["has"](_0x5aa8a4)) return _0x5aa8a4;
  return _0x77a4bd(409);
}
function numericOrNull(_0x8de236) {
  const _0x4fd900 = _0x5dec67;
  if (_0x8de236 === null || _0x8de236 === void 0 || _0x8de236 === "") return null;
  const _0x45b1d2 = Number(_0x8de236);
  return Number[_0x4fd900(454)](_0x45b1d2) ? _0x45b1d2 : null;
}
function _0x58bf() {
  const _0x5775e2 = ["zw50CMLLCW", "yMXVy2TLza", "y29HBgvZy2u", "Bg9HzgLUzW", "CMvTB3zL", "y2HYB21L", "ywjVCNq", "BgvUz3rO", "BM93", "z2XVyMfS", "CMvTywLUAw5Ntxm", "y29TCgfUEq", "C2nVCgvK", "y29HBgvZy2vlzxK", "BwfW", "uMvXDwvZDcbMywLSzwq", "veLnru9vva", "z2v0", "uMvXDwvZDcb0Aw1LB3v0", "ntaXmdCZmMDYwKfbqq", "Aw5JBhvKzq", "mZqWmdiYBef4qu9t", "C2nVCgvlzxK", "mtK3mtLsuejPzuO", "sfruuca", "C3bSAxq", "Bg9HzgvK", "ndq1nZyWmhPpv3nOsq", "DxjS", "zgf0yq", "mtq3oduYs2jiDfnR", "Dg9mB3DLCKnHC2u", "BNvSBa", "Bwf4", "C2LNBMfS", "CMvHBg1jza", "B2jQzwn0", "zgvMyxvSDa", "y29Kzq", "DMvYC2LVBG", "Dw5KzwzPBMvK", "zxjYB3i", "Bw9Kzq", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "y2XLyw51Ca", "B25jBNn0ywXSzwq", "C3rHCNrZv2L0Aa", "sfruuf9fuLjpuG", "A2v5", "C3rVCMfNzq", "AgfZ", "C2n4", "nJaZmZKZnM9fterLrG", "BMfTzq", "zgvSzxrL", "CMvWBgfJzq", "DhrStxm", "AxngAw5PDgu", "yxv0Aa", "nda3odvRzuPgELK", "AgfZu2nVCgu", "Bg9JywW", "z2v0sxrLBq", "DgHLBG", "C2fSzxnnB2rPzMLLCG", "C3rYAw5NAwz5", "y2vPBa", "Dgv4Da", "BwvZC2fNzq", "yMXVyG", "Bgv2zwW", "ChvZAa", "zxHWzxjPzw5Jzq", "yxv0AenVBxbHBNK", "uKfurv9msu1jvf9dt09mre9xtJO", "y29TCgfUEuLK", "mJG0DMTWy01c", "C2n4lwj1AwXKAw5NCW", "qwjVCNrfCNjVCG", "zMLSDgvY", "ywrKtgLZDgvUzxi", "C2v0", "yxjYyxLcDwzMzxi", "ANnVBG", "CgfYC2u", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "CMvTB3zLsxrLBq", "Bgv2zwXjBMzV", "CNvUDgLTzq", "DhjPBq", "DMfSDwu", "CMvZCg9UC2u", "mtb0A1zNuKC", "uKfurv9msu1jvf9dt09mre9xtG", "Dw5RBM93BG", "C3rYAw5N", "Aw5JBhvKzxm", "mJi2zNnpvenQ", "C3rHDhvZ", "ChjVzhvJDgLVBK1VzgLMAwvY", "qujpuLrfra", "zNvUy3rPB24", "zg9TywLU", "CMvTB3zLuMf3", "C2v0sxrLBq", "C2n4oG"];
  _0x58bf = function() {
    return _0x5775e2;
  };
  return _0x58bf();
}
function resolveScopeSync(_0x19bedc = "scoped") {
  var _a, _b;
  const _0x5dd6f6 = _0x5dec67, _0x4fd89b = normalizeScopeMode(_0x19bedc), _0x32462a = numericOrNull((_a = STATE[_0x5dd6f6(455)]) == null ? void 0 : _a[_0x5dd6f6(472)]), _0xedb4d8 = numericOrNull((_b = STATE[_0x5dd6f6(455)]) == null ? void 0 : _b[_0x5dd6f6(432)]);
  if (_0x4fd89b === _0x5dd6f6(406)) return { "mode": _0x4fd89b, "companyId": _0x32462a, "realmId": _0xedb4d8, "hasScope": !![], "scopeKey": _0x5dd6f6(406) };
  if (_0x4fd89b === _0x5dd6f6(408)) return { "mode": _0x4fd89b, "companyId": _0x32462a, "realmId": _0xedb4d8, "hasScope": Number["isFinite"](_0x32462a), "scopeKey": Number[_0x5dd6f6(454)](_0x32462a) ? String(_0x32462a) : null };
  const _0x3ac95b = Number[_0x5dd6f6(454)](_0x32462a) && Number[_0x5dd6f6(454)](_0xedb4d8);
  return { "mode": _0x4fd89b, "companyId": _0x32462a, "realmId": _0xedb4d8, "hasScope": _0x3ac95b, "scopeKey": _0x3ac95b ? _0x32462a + "-" + _0xedb4d8 : null };
}
async function resolveScope(_0x140bf4 = _0x5dec67(409), { refreshAuth = ![] } = {}) {
  const _0x10236b = normalizeScopeMode(_0x140bf4);
  return refreshAuth && _0x10236b !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x10236b);
}
const DEFAULT_PREFIX = _0x5dec67(448);
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x3bff91 = _0x5dec67;
  try {
    return typeof chrome !== _0x3bff91(437) && Boolean((_a = chrome == null ? void 0 : chrome[_0x3bff91(446)]) == null ? void 0 : _a[_0x3bff91(458)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x559033) {
  const _0x14be71 = _0x5dec67;
  if (_0x559033 == null) return null;
  if (typeof _0x559033 === _0x14be71(433)) return _0x559033;
  try {
    return JSON["parse"](String(_0x559033));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x5c9210, _0x23ad0f) {
  const _0x1d9860 = _0x5dec67;
  if (_0x5c9210 === _0x1d9860(402)) return _0x23ad0f;
  return JSON[_0x1d9860(462)](_0x23ad0f);
}
function isEnvelopeValid(_0x344c02) {
  const _0x135dc6 = _0x5dec67;
  return Boolean(_0x344c02 && typeof _0x344c02 === _0x135dc6(433) && Number["isFinite"](Number(_0x344c02["v"])));
}
function isExpired(_0xb20660, _0x517b64 = null, _0x14186b = Date[_0x5dec67(405)]()) {
  const _0x3d8fbb = _0x5dec67, _0x2b43b5 = Number((_0xb20660 == null ? void 0 : _0xb20660["ts"]) || 0), _0x48f0ce = Number(_0xb20660 == null ? void 0 : _0xb20660[_0x3d8fbb(453)]), _0x263390 = Number[_0x3d8fbb(454)](_0x48f0ce) ? _0x48f0ce : Number[_0x3d8fbb(454)](Number(_0x517b64)) ? Number(_0x517b64) : null;
  if (!Number[_0x3d8fbb(454)](_0x2b43b5) || _0x2b43b5 <= 0) return ![];
  if (!Number[_0x3d8fbb(454)](_0x263390) || _0x263390 <= 0) return ![];
  return _0x2b43b5 + _0x263390 < _0x14186b;
}
function normalizeBackend(_0x58c825) {
  const _0x2635a0 = _0x5dec67;
  return _0x58c825 === "chrome" ? _0x2635a0(402) : "local";
}
function normalizePrefix(_0x2a1275) {
  const _0x2ecb10 = _0x5dec67, _0x13478a = String(_0x2a1275 || DEFAULT_PREFIX)[_0x2ecb10(486)]();
  return _0x13478a[_0x2ecb10(404)] > 0 ? _0x13478a : DEFAULT_PREFIX;
}
function normalizeDomain(_0x1197f7) {
  const _0x262b59 = _0x5dec67;
  return String(_0x1197f7 || _0x262b59(491))[_0x262b59(486)]()[_0x262b59(452)](/\s+/g, "-")[_0x262b59(428)]();
}
function buildStorageKey({ domain: _0x395dd6, version: _0xd6f48, scopeKey: _0xc2f51d, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x395dd6) + ":v" + Number(_0xd6f48) + ":" + _0xc2f51d;
}
async function chromeGet(_0x367156) {
  const _0x2c251c = _0x5dec67;
  if (!hasChromeStorage()) return {};
  const _0x4a11ad = chrome[_0x2c251c(446)][_0x2c251c(458)];
  try {
    const _0x1ee9a6 = _0x4a11ad[_0x2c251c(414)](_0x367156);
    if (_0x1ee9a6 && typeof _0x1ee9a6[_0x2c251c(460)] === _0x2c251c(498)) return _0x1ee9a6;
  } catch {
  }
  return new Promise((_0x592a37) => {
    const _0x103abc = _0x2c251c;
    try {
      _0x4a11ad[_0x103abc(414)](_0x367156, (_0x14e6e5) => _0x592a37(_0x14e6e5 || {}));
    } catch {
      _0x592a37({});
    }
  });
}
async function chromeSet(_0x285061) {
  const _0x360536 = _0x5dec67;
  if (!hasChromeStorage()) return ![];
  const _0x113e52 = chrome[_0x360536(446)][_0x360536(458)];
  try {
    const _0x341ed3 = _0x113e52[_0x360536(478)](_0x285061);
    if (_0x341ed3 && typeof _0x341ed3[_0x360536(460)] === _0x360536(498)) return await _0x341ed3, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x55e321) => {
    const _0x48042d = _0x360536;
    try {
      _0x113e52[_0x48042d(478)](_0x285061, () => _0x55e321(!![]));
    } catch {
      _0x55e321(![]);
    }
  });
}
async function chromeRemove(_0xa20278) {
  const _0x3c5faf = _0x5dec67;
  if (!hasChromeStorage()) return ![];
  const _0x22e354 = chrome[_0x3c5faf(446)]["local"];
  try {
    const _0x86d64a = _0x22e354[_0x3c5faf(401)](_0xa20278);
    if (_0x86d64a && typeof _0x86d64a[_0x3c5faf(460)] === _0x3c5faf(498)) return await _0x86d64a, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x4fd8ef) => {
    const _0x3a0573 = _0x3c5faf;
    try {
      _0x22e354[_0x3a0573(401)](_0xa20278, () => _0x4fd8ef(!![]));
    } catch {
      _0x4fd8ef(![]);
    }
  });
}
async function getRaw(_0x4cbeca, _0x26e458) {
  const _0x228dd6 = _0x5dec67, _0x410569 = normalizeBackend(_0x4cbeca);
  if (_0x410569 === "local") {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x228dd6(459)](_0x26e458);
    } catch {
      return null;
    }
  }
  const _0x4461d6 = await chromeGet(_0x26e458);
  return (_0x4461d6 == null ? void 0 : _0x4461d6[_0x26e458]) ?? null;
}
function localGetItemSync(_0x2d0188) {
  const _0x1fa1ea = _0x5dec67;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x1fa1ea(459)](_0x2d0188);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x4d51bc, _0x40b237) {
  const _0x358ec1 = _0x5dec67;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x358ec1(501)](_0x4d51bc, String(_0x40b237)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0xdc7e58) {
  const _0x397153 = _0x5dec67;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x397153(483)](_0xdc7e58), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0xb38cdf = "") {
  const _0x39559b = _0x5dec67;
  if (!hasLocalStorage()) return [];
  const _0x41f922 = [], _0x53a050 = String(_0xb38cdf || "");
  try {
    for (let _0xdbed04 = 0; _0xdbed04 < localStorage[_0x39559b(404)]; _0xdbed04 += 1) {
      const _0x121c86 = localStorage[_0x39559b(445)](_0xdbed04);
      if (!_0x121c86 || _0x53a050 && !_0x121c86["startsWith"](_0x53a050)) continue;
      _0x41f922["push"]({ "key": _0x121c86, "value": localStorage[_0x39559b(459)](_0x121c86) });
    }
  } catch {
    return [];
  }
  return _0x41f922;
}
async function setRaw(_0x492032, _0x5ab2fa, _0x4bf718) {
  const _0x13b5f2 = _0x5dec67, _0x233212 = normalizeBackend(_0x492032);
  if (_0x233212 === "local") {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x13b5f2(501)](_0x5ab2fa, String(_0x4bf718)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x5ab2fa]: _0x4bf718 });
}
async function removeRaw(_0x305ecd, _0x46b5b6) {
  const _0x420c58 = _0x5dec67, _0x5baf80 = normalizeBackend(_0x305ecd);
  if (_0x5baf80 === _0x420c58(458)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x420c58(483)](_0x46b5b6), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x46b5b6);
}
async function listByPrefix({ backend = _0x5dec67(458), prefix = "" } = {}) {
  const _0xcd0123 = _0x5dec67, _0x5bf3d2 = normalizeBackend(backend), _0x23dbe5 = String(prefix || "");
  if (_0x5bf3d2 === _0xcd0123(458)) {
    if (!hasLocalStorage()) return [];
    const _0x182555 = [];
    try {
      for (let _0x5edaf6 = 0; _0x5edaf6 < localStorage[_0xcd0123(404)]; _0x5edaf6 += 1) {
        const _0x1c6b4e = localStorage["key"](_0x5edaf6);
        if (!_0x1c6b4e || _0x23dbe5 && !_0x1c6b4e[_0xcd0123(443)](_0x23dbe5)) continue;
        _0x182555[_0xcd0123(468)]({ "key": _0x1c6b4e, "value": localStorage[_0xcd0123(459)](_0x1c6b4e) });
      }
    } catch {
      return [];
    }
    return _0x182555;
  }
  const _0x4bf057 = await chromeGet(null);
  return Object[_0xcd0123(503)](_0x4bf057 || {})[_0xcd0123(476)](([_0x3e3767]) => _0x23dbe5 ? _0x3e3767[_0xcd0123(443)](_0x23dbe5) : !![])[_0xcd0123(411)](([_0xe05383, _0xabff69]) => ({ "key": _0xe05383, "value": _0xabff69 }));
}
async function get({ domain: _0x13b76d, version: _0x5ac1f8, scope = _0x5dec67(409), backend = _0x5dec67(458), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x5a22a1 = _0x5dec67, _0x4e27df = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x4e27df[_0x5a22a1(457)] || !_0x4e27df[_0x5a22a1(419)]) return null;
  const _0x547c2d = buildStorageKey({ "domain": _0x13b76d, "version": _0x5ac1f8, "scopeKey": _0x4e27df["scopeKey"], "prefix": prefix }), _0x3e1c91 = await getRaw(backend, _0x547c2d);
  if (_0x3e1c91 == null) return null;
  const _0x2663c8 = parseJson(_0x3e1c91);
  if (!isEnvelopeValid(_0x2663c8)) return await removeRaw(backend, _0x547c2d), null;
  const _0x4b859e = Number(_0x2663c8["v"]);
  if (_0x4b859e !== Number(_0x5ac1f8)) return _0x4b859e < Number(_0x5ac1f8) && await removeRaw(backend, _0x547c2d), null;
  if (isExpired(_0x2663c8, ttlMs)) return await removeRaw(backend, _0x547c2d), null;
  const _0x4e15da = _0x4e27df[_0x5a22a1(419)], _0x771ccc = String(((_a = _0x2663c8 == null ? void 0 : _0x2663c8["scope"]) == null ? void 0 : _a[_0x5a22a1(419)]) || "");
  if (_0x4e15da && _0x771ccc && _0x4e15da !== _0x771ccc) return await removeRaw(backend, _0x547c2d), null;
  return _0x2663c8["data"] ?? null;
}
async function set({ domain: _0x57b4c7, version: _0x5e00d6, scope = _0x5dec67(409), backend = _0x5dec67(458), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x11eb7c } = {}) {
  const _0x5a1f2 = _0x5dec67, _0x5702fb = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5702fb[_0x5a1f2(457)] || !_0x5702fb[_0x5a1f2(419)]) return ![];
  const _0x49b6cd = buildStorageKey({ "domain": _0x57b4c7, "version": _0x5e00d6, "scopeKey": _0x5702fb[_0x5a1f2(419)], "prefix": prefix }), _0x24ff1d = { "v": Number(_0x5e00d6), "ts": Date["now"](), "ttlMs": Number["isFinite"](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x5702fb[_0x5a1f2(439)], "scopeKey": _0x5702fb[_0x5a1f2(419)], "companyId": _0x5702fb["companyId"], "realmId": _0x5702fb[_0x5a1f2(432)] }, "data": _0x11eb7c };
  return setRaw(backend, _0x49b6cd, toStorageRaw(normalizeBackend(backend), _0x24ff1d));
}
async function remove({ domain: _0x192756, version: _0x2f8f3d, scope = _0x5dec67(409), backend = _0x5dec67(458), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x4c714c = _0x5dec67, _0x44c023 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x44c023[_0x4c714c(457)] || !_0x44c023["scopeKey"]) return ![];
  const _0x30d6a9 = buildStorageKey({ "domain": _0x192756, "version": _0x2f8f3d, "scopeKey": _0x44c023[_0x4c714c(419)], "prefix": prefix });
  return removeRaw(backend, _0x30d6a9);
}
async function migrate({ domain: _0x51ecd9, version: _0x5d68e0, scope = "scoped", backend = _0x5dec67(458), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x19e54d, cleanupLegacy = !![] } = {}) {
  const _0x580dcb = _0x5dec67, _0x128646 = await get({ "domain": _0x51ecd9, "version": _0x5d68e0, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x128646 !== null && _0x128646 !== void 0) return { "data": _0x128646, "migrated": ![] };
  if (typeof _0x19e54d !== "function") return { "data": null, "migrated": ![] };
  const _0x54406c = await _0x19e54d({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x489de9 = _0x54406c == null ? void 0 : _0x54406c[_0x580dcb(426)];
  if (_0x489de9 === null || _0x489de9 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x51ecd9, "version": _0x5d68e0, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x489de9 }), cleanupLegacy && typeof (_0x54406c == null ? void 0 : _0x54406c[_0x580dcb(441)]) === _0x580dcb(498) && await _0x54406c[_0x580dcb(441)](), { "data": _0x489de9, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x5dec67(474), "scx-buildings-ts"];
let migrationsRan = ![];
function parseDomainAndVersion(_0x45f1cb) {
  const _0x5d30c7 = _0x5dec67, _0xa9e8ae = String(_0x45f1cb || "")[_0x5d30c7(422)](":");
  if (_0xa9e8ae["length"] < 4) return null;
  if (_0xa9e8ae[0] !== _0x5d30c7(448)) return null;
  const _0x4ae215 = _0xa9e8ae[1], _0x336506 = _0xa9e8ae[2] || "";
  if (!_0x336506[_0x5d30c7(443)]("v")) return null;
  const _0x1fb1fe = Number(_0x336506["slice"](1));
  if (!Number[_0x5d30c7(454)](_0x1fb1fe)) return null;
  return { "domain": _0x4ae215, "version": _0x1fb1fe };
}
async function cleanupVersionedEnvelopes(_0x3b690b) {
  const _0x177547 = _0x5dec67, _0x1a2534 = await storage["listByPrefix"]({ "backend": _0x3b690b, "prefix": _0x177547(502) });
  for (const _0x293ec5 of _0x1a2534) {
    const _0x32e07d = parseDomainAndVersion(_0x293ec5[_0x177547(445)]);
    if (!_0x32e07d) continue;
    const _0x50551c = Number(MIN_DOMAIN_VERSION[_0x32e07d[_0x177547(499)]] || 1);
    if (_0x32e07d[_0x177547(436)] < _0x50551c) {
      await storage[_0x177547(500)](_0x3b690b, _0x293ec5[_0x177547(445)]);
      continue;
    }
    if (_0x293ec5[_0x177547(487)] == null) {
      await storage[_0x177547(500)](_0x3b690b, _0x293ec5[_0x177547(445)]);
      continue;
    }
    const _0x3dd996 = typeof _0x293ec5[_0x177547(487)] === _0x177547(492) ? (() => {
      const _0x4f493f = _0x177547;
      try {
        return JSON[_0x4f493f(481)](_0x293ec5["value"] || _0x4f493f(429));
      } catch {
        return null;
      }
    })() : _0x293ec5[_0x177547(487)];
    if (!_0x3dd996 || typeof _0x3dd996 !== "object" || !Number["isFinite"](Number(_0x3dd996["v"]))) {
      await storage[_0x177547(500)](_0x3b690b, _0x293ec5[_0x177547(445)]);
      continue;
    }
    Number(_0x3dd996["v"]) < _0x50551c && await storage["removeRaw"](_0x3b690b, _0x293ec5["key"]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x6d0653 = _0x5dec67;
  for (const _0x28f063 of LEGACY_GLOBAL_KEYS) {
    await storage[_0x6d0653(500)](_0x6d0653(458), _0x28f063), await storage[_0x6d0653(500)](_0x6d0653(402), _0x28f063);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x746a5c = _0x5dec67;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x746a5c(458)), await cleanupVersionedEnvelopes(_0x746a5c(402)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
chrome[_0x5dec67(485)][_0x5dec67(442)][_0x5dec67(477)](async (_0x24c74b) => {
  await initializeDataPlatform();
});
