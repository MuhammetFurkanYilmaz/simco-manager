import { s as storage } from "../content.js";
const GITHUB_API_URL = "https://api.github.com/repos/MuhammetFurkanYilmaz/simco-manager/releases/latest";
const CHECK_INTERVAL_MS = 4 * 60 * 60 * 1e3;
function compareVersions(v1, v2) {
  const parts1 = v1.replace(/^v/, "").split(".").map(Number);
  const parts2 = v2.replace(/^v/, "").split(".").map(Number);
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }
  return 0;
}
async function checkForUpdates() {
  try {
    const lastCheck = await storage.get({
      domain: "update-checker",
      version: 1,
      scope: "global",
      backend: "local"
    });
    const now = Date.now();
    if (lastCheck && lastCheck.timestamp && now - lastCheck.timestamp < CHECK_INTERVAL_MS) {
      if (lastCheck.hasUpdate) {
        return lastCheck.releaseInfo;
      }
      return null;
    }
    const response = await fetch(GITHUB_API_URL);
    if (!response.ok) {
      return null;
    }
    const data = await response.json();
    const latestVersion = data.tag_name;
    const currentVersion = chrome.runtime.getManifest().version;
    const hasUpdate = compareVersions(latestVersion, currentVersion) > 0;
    const releaseInfo = hasUpdate ? { version: latestVersion, url: data.html_url } : null;
    await storage.set({
      domain: "update-checker",
      version: 1,
      scope: "global",
      backend: "local",
      data: {
        timestamp: now,
        hasUpdate,
        releaseInfo
      }
    });
    return releaseInfo;
  } catch (error) {
    console.warn("SimCo Manager Update Check Failed:", error);
    return null;
  }
}
export {
  checkForUpdates
};
//# sourceMappingURL=update_checker-B8tGIXvW.js.map
