const inflightByKey = /* @__PURE__ */ new Map();
const rateLimitByDomain = /* @__PURE__ */ new Map();
const rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function normalizeDomain$1(domain) {
  return String(domain || "default").trim().toLowerCase();
}
function makeError(message, extra = {}) {
  const err = new Error(message);
  Object.assign(err, extra);
  return err;
}
function buildInflightKey(domain, coalesceKey, url, method) {
  if (coalesceKey) return `${domain}:${coalesceKey}`;
  return `${domain}:${method}:${url}`;
}
function getRateLimitStatus(domain = "default") {
  const d = normalizeDomain$1(domain);
  const blockedUntil = Number(rateLimitByDomain.get(d) || 0);
  const remainingMs = Math.max(0, blockedUntil - Date.now());
  return {
    blocked: remainingMs > 0,
    remainingMs,
    blockedUntil
  };
}
async function parseResponse(res, responseType) {
  if (responseType === "response") return res;
  if (responseType === "text") return res.text();
  if (responseType === "blob") return res.blob();
  if (responseType === "arrayBuffer") return res.arrayBuffer();
  return res.json();
}
async function doRequest(domain, spec, attempt = 0) {
  const {
    url,
    method = "GET",
    headers,
    body,
    credentials = "include",
    signal,
    responseType = "json",
    retries = 0,
    retryDelayMs = 0,
    retryStatuses = [408, 425, 429, 500, 502, 503, 504],
    rateLimitCooldownMs = 0,
    timeoutMs = 0
  } = spec;
  const rate = getRateLimitStatus(domain);
  if (rate.blocked) {
    throw makeError(`RATE_LIMIT_COOLDOWN:${Math.ceil(rate.remainingMs / 1e3)}`, {
      code: "RATE_LIMIT_COOLDOWN",
      domain,
      remainingMs: rate.remainingMs,
      status: 429
    });
  }
  const controller = timeoutMs > 0 ? new AbortController() : null;
  const timeoutId = controller && timeoutMs > 0 ? setTimeout(
    () => controller.abort(makeError("Request timeout", { code: "TIMEOUT", domain })),
    timeoutMs
  ) : null;
  const mergedSignal = controller ? controller.signal : signal;
  try {
    const res = await fetch(url, {
      method,
      headers,
      body,
      credentials,
      signal: mergedSignal
    });
    if (res.status === 429 && rateLimitCooldownMs > 0) {
      const hits = (rateLimitHitCount.get(domain) || 0) + 1;
      rateLimitHitCount.set(domain, hits);
      const cooldown = hits <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain.set(domain, Date.now() + cooldown);
    }
    if (!res.ok) {
      const canRetry = attempt < retries && retryStatuses.includes(res.status);
      if (canRetry) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(domain, spec, attempt + 1);
      }
      throw makeError(`HTTP ${res.status}`, {
        code: "HTTP_ERROR",
        domain,
        status: res.status
      });
    }
    rateLimitHitCount.delete(domain);
    return parseResponse(res, responseType);
  } catch (error) {
    const isAbort = (error == null ? void 0 : error.name) === "AbortError";
    const canRetry = !isAbort && attempt < retries;
    if (canRetry) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(domain, spec, attempt + 1);
    }
    if (error instanceof Error && error.code) throw error;
    throw makeError(String((error == null ? void 0 : error.message) || error || "Request failed"), {
      code: isAbort ? "ABORTED" : "NETWORK_ERROR",
      domain,
      status: Number((error == null ? void 0 : error.status) || 0) || null,
      cause: error
    });
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}
async function request(domain, spec) {
  const d = normalizeDomain$1(domain);
  const inflightKey = buildInflightKey(d, spec == null ? void 0 : spec.coalesceKey, spec == null ? void 0 : spec.url, (spec == null ? void 0 : spec.method) || "GET");
  if ((spec == null ? void 0 : spec.coalesce) && inflightByKey.has(inflightKey)) {
    return inflightByKey.get(inflightKey);
  }
  const p = doRequest(d, spec || {}).finally(() => {
    inflightByKey.delete(inflightKey);
  });
  if (spec == null ? void 0 : spec.coalesce) {
    inflightByKey.set(inflightKey, p);
  }
  return p;
}
const STATE = {
  // auth
  auth: {
    companyId: null,
    realmId: null,
    productionModifier: null,
    salesModifier: null,
    loaded: false,
    loading: false,
    error: null
  },
  // level info (from auth-data)
  levelInfo: {
    level: null,
    experience: null,
    experienceToNextLevel: null
  }
};
function applyAuthData(data) {
  const c = data == null ? void 0 : data.authCompany;
  STATE.auth.companyId = (c == null ? void 0 : c.companyId) ?? null;
  STATE.auth.realmId = (c == null ? void 0 : c.realmId) ?? null;
  STATE.auth.productionModifier = (c == null ? void 0 : c.productionModifier) ?? null;
  STATE.auth.salesModifier = (c == null ? void 0 : c.salesModifier) ?? null;
  STATE.auth.loaded = true;
  const li = data == null ? void 0 : data.levelInfo;
  STATE.levelInfo.level = (li == null ? void 0 : li.level) ?? null;
  STATE.levelInfo.experience = (li == null ? void 0 : li.experience) ?? null;
  STATE.levelInfo.experienceToNextLevel = (li == null ? void 0 : li.experienceToNextLevel) ?? null;
}
async function loadAuthDataOnce({ force = false } = {}) {
  if (!force && STATE.auth.loaded || STATE.auth.loading) {
    return;
  }
  STATE.auth.loading = true;
  STATE.auth.error = null;
  try {
    const data = await request("auth", {
      url: "https://www.simcompanies.com/api/v3/companies/auth-data/",
      credentials: "include",
      responseType: "json",
      retries: 1,
      retryDelayMs: 250
    });
    applyAuthData(data);
  } catch (e) {
    STATE.auth.error = String((e == null ? void 0 : e.message) || e);
  } finally {
    STATE.auth.loading = false;
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set(["scoped", "company", "global"]);
function normalizeScopeMode(scopeMode) {
  if (VALID_SCOPE_MODES.has(scopeMode)) return scopeMode;
  return "scoped";
}
function numericOrNull(value) {
  if (value === null || value === void 0 || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
function resolveScopeSync(scopeMode = "scoped") {
  var _a, _b;
  const mode = normalizeScopeMode(scopeMode);
  const companyId = numericOrNull((_a = STATE.auth) == null ? void 0 : _a.companyId);
  const realmId = numericOrNull((_b = STATE.auth) == null ? void 0 : _b.realmId);
  if (mode === "global") {
    return {
      mode,
      companyId,
      realmId,
      hasScope: true,
      scopeKey: "global"
    };
  }
  if (mode === "company") {
    return {
      mode,
      companyId,
      realmId,
      hasScope: Number.isFinite(companyId),
      scopeKey: Number.isFinite(companyId) ? String(companyId) : null
    };
  }
  const hasScope = Number.isFinite(companyId) && Number.isFinite(realmId);
  return {
    mode,
    companyId,
    realmId,
    hasScope,
    scopeKey: hasScope ? `${companyId}-${realmId}` : null
  };
}
async function resolveScope(scopeMode = "scoped", { refreshAuth = false } = {}) {
  const mode = normalizeScopeMode(scopeMode);
  if (refreshAuth && mode !== "global") {
    await loadAuthDataOnce();
  }
  return resolveScopeSync(mode);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return false;
  }
}
function hasChromeStorage() {
  var _a;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome.storage) == null ? void 0 : _a.local);
  } catch {
    return false;
  }
}
function parseJson(raw) {
  if (raw == null) return null;
  if (typeof raw === "object") return raw;
  try {
    return JSON.parse(String(raw));
  } catch {
    return null;
  }
}
function toStorageRaw(backend, value) {
  if (backend === "chrome") return value;
  return JSON.stringify(value);
}
function isEnvelopeValid(envelope) {
  return Boolean(envelope && typeof envelope === "object" && Number.isFinite(Number(envelope.v)));
}
function isExpired(envelope, ttlOverrideMs = null, now = Date.now()) {
  const ts = Number((envelope == null ? void 0 : envelope.ts) || 0);
  const ttlFromEnvelope = Number(envelope == null ? void 0 : envelope.ttlMs);
  const ttl = Number.isFinite(ttlFromEnvelope) ? ttlFromEnvelope : Number.isFinite(Number(ttlOverrideMs)) ? Number(ttlOverrideMs) : null;
  if (!Number.isFinite(ts) || ts <= 0) return false;
  if (!Number.isFinite(ttl) || ttl <= 0) return false;
  return ts + ttl < now;
}
function normalizeBackend(backend) {
  return backend === "chrome" ? "chrome" : "local";
}
function normalizePrefix(prefix) {
  const p = String(prefix || DEFAULT_PREFIX).trim();
  return p.length > 0 ? p : DEFAULT_PREFIX;
}
function normalizeDomain(domain) {
  return String(domain || "unknown").trim().replace(/\s+/g, "-").toLowerCase();
}
function buildStorageKey({ domain, version, scopeKey, prefix = DEFAULT_PREFIX }) {
  return `${normalizePrefix(prefix)}:${normalizeDomain(domain)}:v${Number(version)}:${scopeKey}`;
}
async function chromeGet(keys) {
  if (!hasChromeStorage()) return {};
  const api = chrome.storage.local;
  try {
    const result = api.get(keys);
    if (result && typeof result.then === "function") {
      return result;
    }
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.get(keys, (items) => resolve(items || {}));
    } catch {
      resolve({});
    }
  });
}
async function chromeSet(items) {
  if (!hasChromeStorage()) return false;
  const api = chrome.storage.local;
  try {
    const result = api.set(items);
    if (result && typeof result.then === "function") {
      await result;
      return true;
    }
    return true;
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.set(items, () => resolve(true));
    } catch {
      resolve(false);
    }
  });
}
async function chromeRemove(keys) {
  if (!hasChromeStorage()) return false;
  const api = chrome.storage.local;
  try {
    const result = api.remove(keys);
    if (result && typeof result.then === "function") {
      await result;
      return true;
    }
    return true;
  } catch {
  }
  return new Promise((resolve) => {
    try {
      api.remove(keys, () => resolve(true));
    } catch {
      resolve(false);
    }
  });
}
async function getRaw(backend, key) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }
  const data = await chromeGet(key);
  return (data == null ? void 0 : data[key]) ?? null;
}
function localGetItemSync(key) {
  if (!hasLocalStorage()) return null;
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function localSetItemSync(key, value) {
  if (!hasLocalStorage()) return false;
  try {
    localStorage.setItem(key, String(value));
    return true;
  } catch {
    return false;
  }
}
function localRemoveItemSync(key) {
  if (!hasLocalStorage()) return false;
  try {
    localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
function localListByPrefixSync(prefix = "") {
  if (!hasLocalStorage()) return [];
  const out = [];
  const p = String(prefix || "");
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (!key || p && !key.startsWith(p)) continue;
      out.push({ key, value: localStorage.getItem(key) });
    }
  } catch {
    return [];
  }
  return out;
}
async function setRaw(backend, key, value) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return false;
    try {
      localStorage.setItem(key, String(value));
      return true;
    } catch {
      return false;
    }
  }
  return chromeSet({ [key]: value });
}
async function removeRaw(backend, key) {
  const b = normalizeBackend(backend);
  if (b === "local") {
    if (!hasLocalStorage()) return false;
    try {
      localStorage.removeItem(key);
      return true;
    } catch {
      return false;
    }
  }
  return chromeRemove(key);
}
async function listByPrefix({ backend = "local", prefix = "" } = {}) {
  const b = normalizeBackend(backend);
  const p = String(prefix || "");
  if (b === "local") {
    if (!hasLocalStorage()) return [];
    const out = [];
    try {
      for (let i = 0; i < localStorage.length; i += 1) {
        const key = localStorage.key(i);
        if (!key || p && !key.startsWith(p)) continue;
        out.push({ key, value: localStorage.getItem(key) });
      }
    } catch {
      return [];
    }
    return out;
  }
  const all = await chromeGet(null);
  return Object.entries(all || {}).filter(([key]) => p ? key.startsWith(p) : true).map(([key, value]) => ({ key, value }));
}
async function get({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true
} = {}) {
  var _a;
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return null;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  const raw = await getRaw(backend, key);
  if (raw == null) return null;
  const envelope = parseJson(raw);
  if (!isEnvelopeValid(envelope)) {
    await removeRaw(backend, key);
    return null;
  }
  const envVersion = Number(envelope.v);
  if (envVersion !== Number(version)) {
    if (envVersion < Number(version)) {
      await removeRaw(backend, key);
    }
    return null;
  }
  if (isExpired(envelope, ttlMs)) {
    await removeRaw(backend, key);
    return null;
  }
  const expectedScopeKey = scopeInfo.scopeKey;
  const actualScopeKey = String(((_a = envelope == null ? void 0 : envelope.scope) == null ? void 0 : _a.scopeKey) || "");
  if (expectedScopeKey && actualScopeKey && expectedScopeKey !== actualScopeKey) {
    await removeRaw(backend, key);
    return null;
  }
  return envelope.data ?? null;
}
async function set({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true,
  data
} = {}) {
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return false;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  const envelope = {
    v: Number(version),
    ts: Date.now(),
    ttlMs: Number.isFinite(Number(ttlMs)) ? Number(ttlMs) : null,
    scope: {
      mode: scopeInfo.mode,
      scopeKey: scopeInfo.scopeKey,
      companyId: scopeInfo.companyId,
      realmId: scopeInfo.realmId
    },
    data
  };
  return setRaw(backend, key, toStorageRaw(normalizeBackend(backend), envelope));
}
async function remove({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  refreshAuth = true
} = {}) {
  const scopeInfo = await resolveScope(scope, { refreshAuth });
  if (!scopeInfo.hasScope || !scopeInfo.scopeKey) return false;
  const key = buildStorageKey({ domain, version, scopeKey: scopeInfo.scopeKey, prefix });
  return removeRaw(backend, key);
}
async function migrate({
  domain,
  version,
  scope = "scoped",
  backend = "local",
  prefix = DEFAULT_PREFIX,
  ttlMs = null,
  refreshAuth = true,
  readLegacy,
  cleanupLegacy = true
} = {}) {
  const existing = await get({
    domain,
    version,
    scope,
    backend,
    prefix,
    ttlMs,
    refreshAuth
  });
  if (existing !== null && existing !== void 0) {
    return { data: existing, migrated: false };
  }
  if (typeof readLegacy !== "function") {
    return { data: null, migrated: false };
  }
  const legacy = await readLegacy({ getRaw, setRaw, removeRaw, listByPrefix, parseJson });
  const legacyData = legacy == null ? void 0 : legacy.data;
  if (legacyData === null || legacyData === void 0) {
    return { data: null, migrated: false };
  }
  await set({
    domain,
    version,
    scope,
    backend,
    prefix,
    ttlMs,
    refreshAuth,
    data: legacyData
  });
  if (cleanupLegacy && typeof (legacy == null ? void 0 : legacy.cleanup) === "function") {
    await legacy.cleanup();
  }
  return { data: legacyData, migrated: true };
}
const storage = {
  get,
  set,
  remove,
  listByPrefix,
  migrate,
  buildStorageKey,
  getRaw,
  setRaw,
  removeRaw,
  localSync: {
    getItem: localGetItemSync,
    setItem: localSetItemSync,
    removeItem: localRemoveItemSync,
    listByPrefix: localListByPrefixSync
  }
};
const MIN_DOMAIN_VERSION = {
  "cashflow-finance": 2,
  "buildings-cache": 1,
  "market-alerts": 1,
  "whats-new": 1,
  "xp-widget-visible": 1,
  "contract-discount": 1,
  "upgrade-discount": 1,
  "upgrade-multiplier": 1
};
const LEGACY_GLOBAL_KEYS = ["scx-buildings", "scx-buildings-ts"];
let migrationsRan = false;
function parseDomainAndVersion(key) {
  const parts = String(key || "").split(":");
  if (parts.length < 4) return null;
  if (parts[0] !== "scx") return null;
  const domain = parts[1];
  const versionPart = parts[2] || "";
  if (!versionPart.startsWith("v")) return null;
  const v = Number(versionPart.slice(1));
  if (!Number.isFinite(v)) return null;
  return { domain, version: v };
}
async function cleanupVersionedEnvelopes(backend) {
  const items = await storage.listByPrefix({ backend, prefix: "scx:" });
  for (const item of items) {
    const parsedKey = parseDomainAndVersion(item.key);
    if (!parsedKey) continue;
    const minV = Number(MIN_DOMAIN_VERSION[parsedKey.domain] || 1);
    if (parsedKey.version < minV) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    if (item.value == null) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    const envelope = typeof item.value === "string" ? (() => {
      try {
        return JSON.parse(item.value || "null");
      } catch {
        return null;
      }
    })() : item.value;
    if (!envelope || typeof envelope !== "object" || !Number.isFinite(Number(envelope.v))) {
      await storage.removeRaw(backend, item.key);
      continue;
    }
    if (Number(envelope.v) < minV) {
      await storage.removeRaw(backend, item.key);
    }
  }
}
async function cleanupLegacyGlobalKeys() {
  for (const key of LEGACY_GLOBAL_KEYS) {
    await storage.removeRaw("local", key);
    await storage.removeRaw("chrome", key);
  }
}
async function runDataMigrations({ force = false } = {}) {
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes("local");
  await cleanupVersionedEnvelopes("chrome");
  await cleanupLegacyGlobalKeys();
  migrationsRan = true;
}
let initialized = false;
async function initializeDataPlatform({ force = false } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ force });
  initialized = true;
}
chrome.runtime.onInstalled.addListener(async (details) => {
  await initializeDataPlatform();
});
//# sourceMappingURL=background.js.map
