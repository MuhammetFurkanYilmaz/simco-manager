var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var require_background = __commonJS({
  "background.js"(exports) {
    const _0x240096 = _0x1300;
    (function(_0x2685bf, _0x53b19e) {
      const _0x373058 = _0x1300, _0x87a692 = _0x2685bf();
      while (!![]) {
        try {
          const _0x5efb80 = -parseInt(_0x373058(303)) / 1 + -parseInt(_0x373058(264)) / 2 * (parseInt(_0x373058(304)) / 3) + -parseInt(_0x373058(332)) / 4 * (-parseInt(_0x373058(266)) / 5) + parseInt(_0x373058(260)) / 6 + -parseInt(_0x373058(298)) / 7 * (parseInt(_0x373058(256)) / 8) + parseInt(_0x373058(294)) / 9 + parseInt(_0x373058(255)) / 10 * (parseInt(_0x373058(288)) / 11);
          if (_0x5efb80 === _0x53b19e) break;
          else _0x87a692["push"](_0x87a692["shift"]());
        } catch (_0x4255ef) {
          _0x87a692["push"](_0x87a692["shift"]());
        }
      }
    })(_0x2fbf, 401656);
    const _0x3eb9f8 = /* @__PURE__ */ function() {
      let _0x1c6ea7 = !![];
      return function(_0x5e91ba, _0x53a57a) {
        const _0x2f0820 = _0x1c6ea7 ? function() {
          const _0x4de6a6 = _0x1300;
          if (_0x53a57a) {
            const _0x971690 = _0x53a57a[_0x4de6a6(268)](_0x5e91ba, arguments);
            return _0x53a57a = null, _0x971690;
          }
        } : function() {
        };
        return _0x1c6ea7 = ![], _0x2f0820;
      };
    }(), _0x7dbf3a = _0x3eb9f8(exports, function() {
      const _0x5318cb = _0x1300;
      let _0x199be9;
      try {
        const _0x5df81b = Function(_0x5318cb(333) + '{}.constructor("return this")( ));');
        _0x199be9 = _0x5df81b();
      } catch (_0x1a41d4) {
        _0x199be9 = window;
      }
      const _0x6dc354 = _0x199be9["console"] = _0x199be9[_0x5318cb(330)] || {}, _0x24988a = [_0x5318cb(329), _0x5318cb(261), _0x5318cb(347), "error", _0x5318cb(310), _0x5318cb(274), _0x5318cb(281)];
      for (let _0x5d797d = 0; _0x5d797d < _0x24988a[_0x5318cb(318)]; _0x5d797d++) {
        const _0x672f4c = _0x3eb9f8["constructor"][_0x5318cb(327)][_0x5318cb(348)](_0x3eb9f8), _0x445239 = _0x24988a[_0x5d797d], _0x5961cc = _0x6dc354[_0x445239] || _0x672f4c;
        _0x672f4c["__proto__"] = _0x3eb9f8[_0x5318cb(348)](_0x3eb9f8), _0x672f4c[_0x5318cb(301)] = _0x5961cc[_0x5318cb(301)][_0x5318cb(348)](_0x5961cc), _0x6dc354[_0x445239] = _0x672f4c;
      }
    });
    _0x7dbf3a();
    const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
    function wait(_0x2c46b9) {
      return new Promise((_0x547227) => setTimeout(_0x547227, _0x2c46b9));
    }
    function normalizeDomain$1(_0x396370) {
      const _0x3196f2 = _0x1300;
      return String(_0x396370 || "default")[_0x3196f2(305)]()[_0x3196f2(285)]();
    }
    function makeError(_0x2229f4, _0x2b3c4c = {}) {
      const _0x3b4e52 = _0x1300, _0x37081c = new Error(_0x2229f4);
      return Object[_0x3b4e52(284)](_0x37081c, _0x2b3c4c), _0x37081c;
    }
    function buildInflightKey(_0x45c790, _0x38c0a0, _0x1e8119, _0x183865) {
      if (_0x38c0a0) return _0x45c790 + ":" + _0x38c0a0;
      return _0x45c790 + ":" + _0x183865 + ":" + _0x1e8119;
    }
    function getRateLimitStatus(_0x463409 = _0x240096(253)) {
      const _0x14305d = _0x240096, _0x404aba = normalizeDomain$1(_0x463409), _0x531300 = Number(rateLimitByDomain[_0x14305d(270)](_0x404aba) || 0), _0x4ded89 = Math[_0x14305d(254)](0, _0x531300 - Date[_0x14305d(308)]());
      return { "blocked": _0x4ded89 > 0, "remainingMs": _0x4ded89, "blockedUntil": _0x531300 };
    }
    async function parseResponse(_0x3fe4d6, _0x148a3b) {
      const _0x33b146 = _0x240096;
      if (_0x148a3b === _0x33b146(258)) return _0x3fe4d6;
      if (_0x148a3b === _0x33b146(296)) return _0x3fe4d6[_0x33b146(296)]();
      if (_0x148a3b === _0x33b146(339)) return _0x3fe4d6[_0x33b146(339)]();
      if (_0x148a3b === _0x33b146(325)) return _0x3fe4d6[_0x33b146(325)]();
      return _0x3fe4d6[_0x33b146(340)]();
    }
    async function doRequest(_0x15a5fd, _0x3cb853, _0x256b79 = 0) {
      const _0x335c8f = _0x240096, { url: _0x4222ec, method = _0x335c8f(311), headers: _0x5b74f3, body: _0x8b38b2, credentials = _0x335c8f(293), signal: _0x40a1a6, responseType = _0x335c8f(340), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x3cb853, _0xb14a45 = getRateLimitStatus(_0x15a5fd);
      if (_0xb14a45[_0x335c8f(276)]) throw makeError("RATE_LIMIT_COOLDOWN:" + Math[_0x335c8f(257)](_0xb14a45[_0x335c8f(341)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x15a5fd, "remainingMs": _0xb14a45[_0x335c8f(341)], "status": 429 });
      const _0x441991 = timeoutMs > 0 ? new AbortController() : null, _0x35c5c4 = _0x441991 && timeoutMs > 0 ? setTimeout(() => _0x441991["abort"](makeError(_0x335c8f(271), { "code": _0x335c8f(315), "domain": _0x15a5fd })), timeoutMs) : null, _0x3f1f14 = _0x441991 ? _0x441991[_0x335c8f(349)] : _0x40a1a6;
      try {
        const _0x20afef = await fetch(_0x4222ec, { "method": method, "headers": _0x5b74f3, "body": _0x8b38b2, "credentials": credentials, "signal": _0x3f1f14 });
        if (_0x20afef[_0x335c8f(292)] === 429 && rateLimitCooldownMs > 0) {
          const _0x458fd3 = (rateLimitHitCount[_0x335c8f(270)](_0x15a5fd) || 0) + 1;
          rateLimitHitCount["set"](_0x15a5fd, _0x458fd3);
          const _0x528d17 = _0x458fd3 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
          rateLimitByDomain["set"](_0x15a5fd, Date[_0x335c8f(308)]() + _0x528d17);
        }
        if (!_0x20afef["ok"]) {
          const _0x2a1a54 = _0x256b79 < retries && retryStatuses["includes"](_0x20afef[_0x335c8f(292)]);
          if (_0x2a1a54) {
            if (retryDelayMs > 0) await wait(retryDelayMs);
            return doRequest(_0x15a5fd, _0x3cb853, _0x256b79 + 1);
          }
          throw makeError(_0x335c8f(244) + _0x20afef[_0x335c8f(292)], { "code": _0x335c8f(313), "domain": _0x15a5fd, "status": _0x20afef[_0x335c8f(292)] });
        }
        return rateLimitHitCount["delete"](_0x15a5fd), parseResponse(_0x20afef, responseType);
      } catch (_0x2e0783) {
        const _0x175c29 = (_0x2e0783 == null ? void 0 : _0x2e0783[_0x335c8f(248)]) === "AbortError", _0x142e0c = !_0x175c29 && _0x256b79 < retries;
        if (_0x142e0c) {
          if (retryDelayMs > 0) await wait(retryDelayMs);
          return doRequest(_0x15a5fd, _0x3cb853, _0x256b79 + 1);
        }
        if (_0x2e0783 instanceof Error && _0x2e0783[_0x335c8f(262)]) throw _0x2e0783;
        throw makeError(String((_0x2e0783 == null ? void 0 : _0x2e0783["message"]) || _0x2e0783 || _0x335c8f(307)), { "code": _0x175c29 ? _0x335c8f(342) : _0x335c8f(338), "domain": _0x15a5fd, "status": Number((_0x2e0783 == null ? void 0 : _0x2e0783[_0x335c8f(292)]) || 0) || null, "cause": _0x2e0783 });
      } finally {
        if (_0x35c5c4) clearTimeout(_0x35c5c4);
      }
    }
    async function request(_0x52c559, _0x1427ec) {
      const _0x3a83e2 = _0x240096, _0x27124b = normalizeDomain$1(_0x52c559), _0x32e1bd = buildInflightKey(_0x27124b, _0x1427ec == null ? void 0 : _0x1427ec["coalesceKey"], _0x1427ec == null ? void 0 : _0x1427ec["url"], (_0x1427ec == null ? void 0 : _0x1427ec[_0x3a83e2(320)]) || _0x3a83e2(311));
      if ((_0x1427ec == null ? void 0 : _0x1427ec[_0x3a83e2(280)]) && inflightByKey[_0x3a83e2(316)](_0x32e1bd)) return inflightByKey["get"](_0x32e1bd);
      const _0x2866d7 = doRequest(_0x27124b, _0x1427ec || {})[_0x3a83e2(273)](() => {
        const _0x194ce4 = _0x3a83e2;
        inflightByKey[_0x194ce4(267)](_0x32e1bd);
      });
      return (_0x1427ec == null ? void 0 : _0x1427ec[_0x3a83e2(280)]) && inflightByKey[_0x3a83e2(259)](_0x32e1bd, _0x2866d7), _0x2866d7;
    }
    const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
    function applyAuthData(_0x1ec50d) {
      const _0x4bc61a = _0x240096, _0x202765 = _0x1ec50d == null ? void 0 : _0x1ec50d[_0x4bc61a(300)];
      STATE[_0x4bc61a(275)][_0x4bc61a(283)] = (_0x202765 == null ? void 0 : _0x202765[_0x4bc61a(283)]) ?? null, STATE[_0x4bc61a(275)]["realmId"] = (_0x202765 == null ? void 0 : _0x202765[_0x4bc61a(322)]) ?? null, STATE["auth"][_0x4bc61a(241)] = (_0x202765 == null ? void 0 : _0x202765[_0x4bc61a(241)]) ?? null, STATE[_0x4bc61a(275)][_0x4bc61a(245)] = (_0x202765 == null ? void 0 : _0x202765["salesModifier"]) ?? null, STATE[_0x4bc61a(275)][_0x4bc61a(252)] = !![];
      const _0x4f70d4 = _0x1ec50d == null ? void 0 : _0x1ec50d[_0x4bc61a(243)];
      STATE[_0x4bc61a(243)]["level"] = (_0x4f70d4 == null ? void 0 : _0x4f70d4[_0x4bc61a(317)]) ?? null, STATE[_0x4bc61a(243)][_0x4bc61a(344)] = (_0x4f70d4 == null ? void 0 : _0x4f70d4[_0x4bc61a(344)]) ?? null, STATE["levelInfo"][_0x4bc61a(279)] = (_0x4f70d4 == null ? void 0 : _0x4f70d4[_0x4bc61a(279)]) ?? null;
    }
    async function loadAuthDataOnce({ force = ![] } = {}) {
      const _0x306760 = _0x240096;
      if (!force && STATE[_0x306760(275)][_0x306760(252)] || STATE[_0x306760(275)][_0x306760(336)]) return;
      STATE[_0x306760(275)][_0x306760(336)] = !![], STATE[_0x306760(275)][_0x306760(297)] = null;
      try {
        const _0x326829 = await request(_0x306760(275), { "url": _0x306760(323), "credentials": _0x306760(293), "responseType": _0x306760(340), "retries": 1, "retryDelayMs": 250 });
        applyAuthData(_0x326829);
      } catch (_0x2d3da8) {
        STATE[_0x306760(275)][_0x306760(297)] = String((_0x2d3da8 == null ? void 0 : _0x2d3da8["message"]) || _0x2d3da8);
      } finally {
        STATE[_0x306760(275)]["loading"] = ![];
      }
    }
    const VALID_SCOPE_MODES = /* @__PURE__ */ new Set(["scoped", _0x240096(242), "global"]);
    function normalizeScopeMode(_0x367e5d) {
      const _0x17426b = _0x240096;
      if (VALID_SCOPE_MODES[_0x17426b(316)](_0x367e5d)) return _0x367e5d;
      return _0x17426b(345);
    }
    function numericOrNull(_0x2c0d59) {
      if (_0x2c0d59 === null || _0x2c0d59 === void 0 || _0x2c0d59 === "") return null;
      const _0x2520c9 = Number(_0x2c0d59);
      return Number["isFinite"](_0x2520c9) ? _0x2520c9 : null;
    }
    function resolveScopeSync(_0x231153 = "scoped") {
      var _a, _b;
      const _0x1c36c6 = _0x240096, _0xe75c5f = normalizeScopeMode(_0x231153), _0x2da98c = numericOrNull((_a = STATE["auth"]) == null ? void 0 : _a[_0x1c36c6(283)]), _0xaccdef = numericOrNull((_b = STATE[_0x1c36c6(275)]) == null ? void 0 : _b[_0x1c36c6(322)]);
      if (_0xe75c5f === _0x1c36c6(290)) return { "mode": _0xe75c5f, "companyId": _0x2da98c, "realmId": _0xaccdef, "hasScope": !![], "scopeKey": _0x1c36c6(290) };
      if (_0xe75c5f === _0x1c36c6(242)) return { "mode": _0xe75c5f, "companyId": _0x2da98c, "realmId": _0xaccdef, "hasScope": Number[_0x1c36c6(278)](_0x2da98c), "scopeKey": Number[_0x1c36c6(278)](_0x2da98c) ? String(_0x2da98c) : null };
      const _0x463fc1 = Number[_0x1c36c6(278)](_0x2da98c) && Number[_0x1c36c6(278)](_0xaccdef);
      return { "mode": _0xe75c5f, "companyId": _0x2da98c, "realmId": _0xaccdef, "hasScope": _0x463fc1, "scopeKey": _0x463fc1 ? _0x2da98c + "-" + _0xaccdef : null };
    }
    async function resolveScope(_0x180f1f = _0x240096(345), { refreshAuth = ![] } = {}) {
      const _0x3d1f9b = normalizeScopeMode(_0x180f1f);
      return refreshAuth && _0x3d1f9b !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x3d1f9b);
    }
    const DEFAULT_PREFIX = _0x240096(324);
    function hasLocalStorage() {
      const _0x1022fd = _0x240096;
      try {
        return typeof localStorage !== _0x1022fd(240) && localStorage !== null;
      } catch {
        return ![];
      }
    }
    function hasChromeStorage() {
      var _a;
      const _0x2700b5 = _0x240096;
      try {
        return typeof chrome !== _0x2700b5(240) && Boolean((_a = chrome == null ? void 0 : chrome[_0x2700b5(309)]) == null ? void 0 : _a[_0x2700b5(331)]);
      } catch {
        return ![];
      }
    }
    function parseJson(_0x2f7625) {
      const _0x350366 = _0x240096;
      if (_0x2f7625 == null) return null;
      if (typeof _0x2f7625 === _0x350366(314)) return _0x2f7625;
      try {
        return JSON[_0x350366(337)](String(_0x2f7625));
      } catch {
        return null;
      }
    }
    function toStorageRaw(_0x55d0e8, _0x426302) {
      const _0x185bdd = _0x240096;
      if (_0x55d0e8 === "chrome") return _0x426302;
      return JSON[_0x185bdd(250)](_0x426302);
    }
    function isEnvelopeValid(_0x20b248) {
      const _0x4f35f9 = _0x240096;
      return Boolean(_0x20b248 && typeof _0x20b248 === _0x4f35f9(314) && Number[_0x4f35f9(278)](Number(_0x20b248["v"])));
    }
    function isExpired(_0x20447c, _0x24013b = null, _0x2dde09 = Date["now"]()) {
      const _0x4d71e2 = _0x240096, _0x570819 = Number((_0x20447c == null ? void 0 : _0x20447c["ts"]) || 0), _0x58412f = Number(_0x20447c == null ? void 0 : _0x20447c[_0x4d71e2(321)]), _0x147eca = Number[_0x4d71e2(278)](_0x58412f) ? _0x58412f : Number[_0x4d71e2(278)](Number(_0x24013b)) ? Number(_0x24013b) : null;
      if (!Number["isFinite"](_0x570819) || _0x570819 <= 0) return ![];
      if (!Number["isFinite"](_0x147eca) || _0x147eca <= 0) return ![];
      return _0x570819 + _0x147eca < _0x2dde09;
    }
    function normalizeBackend(_0x4e728f) {
      const _0x3cc1c1 = _0x240096;
      return _0x4e728f === _0x3cc1c1(291) ? _0x3cc1c1(291) : _0x3cc1c1(331);
    }
    function normalizePrefix(_0x57320b) {
      const _0x28078c = _0x240096, _0x339b92 = String(_0x57320b || DEFAULT_PREFIX)[_0x28078c(305)]();
      return _0x339b92[_0x28078c(318)] > 0 ? _0x339b92 : DEFAULT_PREFIX;
    }
    function normalizeDomain(_0x6e8c7e) {
      const _0x2e9592 = _0x240096;
      return String(_0x6e8c7e || _0x2e9592(302))[_0x2e9592(305)]()[_0x2e9592(326)](/\s+/g, "-")[_0x2e9592(285)]();
    }
    function buildStorageKey({ domain: _0x54977a, version: _0x2d83da, scopeKey: _0x27906f, prefix = DEFAULT_PREFIX }) {
      return normalizePrefix(prefix) + ":" + normalizeDomain(_0x54977a) + ":v" + Number(_0x2d83da) + ":" + _0x27906f;
    }
    async function chromeGet(_0x4b4e09) {
      const _0x4f1cb0 = _0x240096;
      if (!hasChromeStorage()) return {};
      const _0x563684 = chrome[_0x4f1cb0(309)][_0x4f1cb0(331)];
      try {
        const _0x43c1bf = _0x563684[_0x4f1cb0(270)](_0x4b4e09);
        if (_0x43c1bf && typeof _0x43c1bf[_0x4f1cb0(335)] === "function") return _0x43c1bf;
      } catch {
      }
      return new Promise((_0x5bbe50) => {
        const _0x566465 = _0x4f1cb0;
        try {
          _0x563684[_0x566465(270)](_0x4b4e09, (_0x4e3eaa) => _0x5bbe50(_0x4e3eaa || {}));
        } catch {
          _0x5bbe50({});
        }
      });
    }
    async function chromeSet(_0x969705) {
      const _0x102d48 = _0x240096;
      if (!hasChromeStorage()) return ![];
      const _0x5e8cc0 = chrome[_0x102d48(309)]["local"];
      try {
        const _0x2b57c5 = _0x5e8cc0["set"](_0x969705);
        if (_0x2b57c5 && typeof _0x2b57c5[_0x102d48(335)] === _0x102d48(346)) return await _0x2b57c5, !![];
        return !![];
      } catch {
      }
      return new Promise((_0xf72816) => {
        const _0x48b0a0 = _0x102d48;
        try {
          _0x5e8cc0[_0x48b0a0(259)](_0x969705, () => _0xf72816(!![]));
        } catch {
          _0xf72816(![]);
        }
      });
    }
    async function chromeRemove(_0x4ddb73) {
      const _0x2ba31a = _0x240096;
      if (!hasChromeStorage()) return ![];
      const _0x39327c = chrome["storage"]["local"];
      try {
        const _0x861515 = _0x39327c["remove"](_0x4ddb73);
        if (_0x861515 && typeof _0x861515["then"] === _0x2ba31a(346)) return await _0x861515, !![];
        return !![];
      } catch {
      }
      return new Promise((_0x24c288) => {
        const _0x2c7a41 = _0x2ba31a;
        try {
          _0x39327c[_0x2c7a41(295)](_0x4ddb73, () => _0x24c288(!![]));
        } catch {
          _0x24c288(![]);
        }
      });
    }
    async function getRaw(_0x59a0b0, _0x479e5a) {
      const _0x25351a = _0x240096, _0x365eeb = normalizeBackend(_0x59a0b0);
      if (_0x365eeb === "local") {
        if (!hasLocalStorage()) return null;
        try {
          return localStorage[_0x25351a(299)](_0x479e5a);
        } catch {
          return null;
        }
      }
      const _0x246840 = await chromeGet(_0x479e5a);
      return (_0x246840 == null ? void 0 : _0x246840[_0x479e5a]) ?? null;
    }
    function localGetItemSync(_0x9ca14e) {
      const _0x37a260 = _0x240096;
      if (!hasLocalStorage()) return null;
      try {
        return localStorage[_0x37a260(299)](_0x9ca14e);
      } catch {
        return null;
      }
    }
    function localSetItemSync(_0x26c41e, _0x358905) {
      const _0x34f68c = _0x240096;
      if (!hasLocalStorage()) return ![];
      try {
        return localStorage[_0x34f68c(251)](_0x26c41e, String(_0x358905)), !![];
      } catch {
        return ![];
      }
    }
    function localRemoveItemSync(_0x32f348) {
      if (!hasLocalStorage()) return ![];
      try {
        return localStorage["removeItem"](_0x32f348), !![];
      } catch {
        return ![];
      }
    }
    function localListByPrefixSync(_0x4da083 = "") {
      const _0x4eb13e = _0x240096;
      if (!hasLocalStorage()) return [];
      const _0x49f0b0 = [], _0x177658 = String(_0x4da083 || "");
      try {
        for (let _0x2ff676 = 0; _0x2ff676 < localStorage["length"]; _0x2ff676 += 1) {
          const _0x9bb731 = localStorage[_0x4eb13e(247)](_0x2ff676);
          if (!_0x9bb731 || _0x177658 && !_0x9bb731["startsWith"](_0x177658)) continue;
          _0x49f0b0["push"]({ "key": _0x9bb731, "value": localStorage[_0x4eb13e(299)](_0x9bb731) });
        }
      } catch {
        return [];
      }
      return _0x49f0b0;
    }
    async function setRaw(_0x26dfd6, _0x34f908, _0x30a4dc) {
      const _0x280c06 = _0x240096, _0xc7679a = normalizeBackend(_0x26dfd6);
      if (_0xc7679a === _0x280c06(331)) {
        if (!hasLocalStorage()) return ![];
        try {
          return localStorage["setItem"](_0x34f908, String(_0x30a4dc)), !![];
        } catch {
          return ![];
        }
      }
      return chromeSet({ [_0x34f908]: _0x30a4dc });
    }
    async function removeRaw(_0x2a9e83, _0x202a04) {
      const _0x5b2fa8 = _0x240096, _0x2542f9 = normalizeBackend(_0x2a9e83);
      if (_0x2542f9 === _0x5b2fa8(331)) {
        if (!hasLocalStorage()) return ![];
        try {
          return localStorage[_0x5b2fa8(328)](_0x202a04), !![];
        } catch {
          return ![];
        }
      }
      return chromeRemove(_0x202a04);
    }
    async function listByPrefix({ backend = _0x240096(331), prefix = "" } = {}) {
      const _0x3f5bcb = _0x240096, _0x1251e2 = normalizeBackend(backend), _0x3feaa0 = String(prefix || "");
      if (_0x1251e2 === _0x3f5bcb(331)) {
        if (!hasLocalStorage()) return [];
        const _0x12bc77 = [];
        try {
          for (let _0x1f8347 = 0; _0x1f8347 < localStorage[_0x3f5bcb(318)]; _0x1f8347 += 1) {
            const _0x692143 = localStorage[_0x3f5bcb(247)](_0x1f8347);
            if (!_0x692143 || _0x3feaa0 && !_0x692143[_0x3f5bcb(277)](_0x3feaa0)) continue;
            _0x12bc77["push"]({ "key": _0x692143, "value": localStorage[_0x3f5bcb(299)](_0x692143) });
          }
        } catch {
          return [];
        }
        return _0x12bc77;
      }
      const _0x1e30e7 = await chromeGet(null);
      return Object[_0x3f5bcb(249)](_0x1e30e7 || {})["filter"](([_0x3b25c0]) => _0x3feaa0 ? _0x3b25c0["startsWith"](_0x3feaa0) : !![])["map"](([_0x17986f, _0x1d098a]) => ({ "key": _0x17986f, "value": _0x1d098a }));
    }
    async function get({ domain: _0x4f8ada, version: _0xe321f7, scope = _0x240096(345), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
      var _a;
      const _0x32f08d = _0x240096, _0x53a0a4 = await resolveScope(scope, { "refreshAuth": refreshAuth });
      if (!_0x53a0a4[_0x32f08d(269)] || !_0x53a0a4["scopeKey"]) return null;
      const _0x22c701 = buildStorageKey({ "domain": _0x4f8ada, "version": _0xe321f7, "scopeKey": _0x53a0a4[_0x32f08d(287)], "prefix": prefix }), _0x788254 = await getRaw(backend, _0x22c701);
      if (_0x788254 == null) return null;
      const _0x573afc = parseJson(_0x788254);
      if (!isEnvelopeValid(_0x573afc)) return await removeRaw(backend, _0x22c701), null;
      const _0x42e4fd = Number(_0x573afc["v"]);
      if (_0x42e4fd !== Number(_0xe321f7)) return _0x42e4fd < Number(_0xe321f7) && await removeRaw(backend, _0x22c701), null;
      if (isExpired(_0x573afc, ttlMs)) return await removeRaw(backend, _0x22c701), null;
      const _0x5a4025 = _0x53a0a4["scopeKey"], _0x159925 = String(((_a = _0x573afc == null ? void 0 : _0x573afc[_0x32f08d(351)]) == null ? void 0 : _a[_0x32f08d(287)]) || "");
      if (_0x5a4025 && _0x159925 && _0x5a4025 !== _0x159925) return await removeRaw(backend, _0x22c701), null;
      return _0x573afc[_0x32f08d(289)] ?? null;
    }
    async function set({ domain: _0x341c59, version: _0x7af8e7, scope = "scoped", backend = _0x240096(331), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x422fed } = {}) {
      const _0x384158 = _0x240096, _0x2a1b10 = await resolveScope(scope, { "refreshAuth": refreshAuth });
      if (!_0x2a1b10[_0x384158(269)] || !_0x2a1b10["scopeKey"]) return ![];
      const _0x4766b4 = buildStorageKey({ "domain": _0x341c59, "version": _0x7af8e7, "scopeKey": _0x2a1b10[_0x384158(287)], "prefix": prefix }), _0x371599 = { "v": Number(_0x7af8e7), "ts": Date[_0x384158(308)](), "ttlMs": Number[_0x384158(278)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x2a1b10["mode"], "scopeKey": _0x2a1b10[_0x384158(287)], "companyId": _0x2a1b10["companyId"], "realmId": _0x2a1b10["realmId"] }, "data": _0x422fed };
      return setRaw(backend, _0x4766b4, toStorageRaw(normalizeBackend(backend), _0x371599));
    }
    async function remove({ domain: _0x3eee42, version: _0x221faa, scope = _0x240096(345), backend = _0x240096(331), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
      const _0xbdbc22 = _0x240096, _0x54e4de = await resolveScope(scope, { "refreshAuth": refreshAuth });
      if (!_0x54e4de[_0xbdbc22(269)] || !_0x54e4de[_0xbdbc22(287)]) return ![];
      const _0x103e4b = buildStorageKey({ "domain": _0x3eee42, "version": _0x221faa, "scopeKey": _0x54e4de[_0xbdbc22(287)], "prefix": prefix });
      return removeRaw(backend, _0x103e4b);
    }
    async function migrate({ domain: _0x64384, version: _0x12be57, scope = _0x240096(345), backend = "local", prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x3714d1, cleanupLegacy = !![] } = {}) {
      const _0x26baef = _0x240096, _0x12bd2c = await get({ "domain": _0x64384, "version": _0x12be57, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
      if (_0x12bd2c !== null && _0x12bd2c !== void 0) return { "data": _0x12bd2c, "migrated": ![] };
      if (typeof _0x3714d1 !== _0x26baef(346)) return { "data": null, "migrated": ![] };
      const _0x482172 = await _0x3714d1({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x4e6c1f = _0x482172 == null ? void 0 : _0x482172["data"];
      if (_0x4e6c1f === null || _0x4e6c1f === void 0) return { "data": null, "migrated": ![] };
      return await set({ "domain": _0x64384, "version": _0x12be57, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x4e6c1f }), cleanupLegacy && typeof (_0x482172 == null ? void 0 : _0x482172["cleanup"]) === _0x26baef(346) && await _0x482172[_0x26baef(334)](), { "data": _0x4e6c1f, "migrated": !![] };
    }
    const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x240096(246), _0x240096(350)];
    let migrationsRan = ![];
    function _0x1300(_0x2901b5, _0x422e2a) {
      _0x2901b5 = _0x2901b5 - 240;
      const _0x462d70 = _0x2fbf();
      let _0x7dbf3a2 = _0x462d70[_0x2901b5];
      if (_0x1300["CjmiVi"] === void 0) {
        var _0x3eb9f82 = function(_0x4899a0) {
          const _0xd4e203 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
          let _0x585419 = "", _0x57758b = "";
          for (let _0xfe3182 = 0, _0x1747b1, _0x1c6ea7, _0x5e91ba = 0; _0x1c6ea7 = _0x4899a0["charAt"](_0x5e91ba++); ~_0x1c6ea7 && (_0x1747b1 = _0xfe3182 % 4 ? _0x1747b1 * 64 + _0x1c6ea7 : _0x1c6ea7, _0xfe3182++ % 4) ? _0x585419 += String["fromCharCode"](255 & _0x1747b1 >> (-2 * _0xfe3182 & 6)) : 0) {
            _0x1c6ea7 = _0xd4e203["indexOf"](_0x1c6ea7);
          }
          for (let _0x53a57a = 0, _0x2f0820 = _0x585419["length"]; _0x53a57a < _0x2f0820; _0x53a57a++) {
            _0x57758b += "%" + ("00" + _0x585419["charCodeAt"](_0x53a57a)["toString"](16))["slice"](-2);
          }
          return decodeURIComponent(_0x57758b);
        };
        _0x1300["qSIQNH"] = _0x3eb9f82, _0x1300["yhZyDX"] = {}, _0x1300["CjmiVi"] = !![];
      }
      const _0x11c0b5 = _0x462d70[0], _0x2fbfb0 = _0x2901b5 + _0x11c0b5, _0x1300a5 = _0x1300["yhZyDX"][_0x2fbfb0];
      return !_0x1300a5 ? (_0x7dbf3a2 = _0x1300["qSIQNH"](_0x7dbf3a2), _0x1300["yhZyDX"][_0x2fbfb0] = _0x7dbf3a2) : _0x7dbf3a2 = _0x1300a5, _0x7dbf3a2;
    }
    function parseDomainAndVersion(_0xcc6b01) {
      const _0x5d0d68 = _0x240096, _0x1d3102 = String(_0xcc6b01 || "")[_0x5d0d68(312)](":");
      if (_0x1d3102["length"] < 4) return null;
      if (_0x1d3102[0] !== _0x5d0d68(324)) return null;
      const _0x43af55 = _0x1d3102[1], _0x45d796 = _0x1d3102[2] || "";
      if (!_0x45d796[_0x5d0d68(277)]("v")) return null;
      const _0x2bcb08 = Number(_0x45d796[_0x5d0d68(272)](1));
      if (!Number["isFinite"](_0x2bcb08)) return null;
      return { "domain": _0x43af55, "version": _0x2bcb08 };
    }
    async function cleanupVersionedEnvelopes(_0x333a44) {
      const _0x41e342 = _0x240096, _0x5ecd9a = await storage["listByPrefix"]({ "backend": _0x333a44, "prefix": _0x41e342(265) });
      for (const _0x36a4d6 of _0x5ecd9a) {
        const _0x22e217 = parseDomainAndVersion(_0x36a4d6[_0x41e342(247)]);
        if (!_0x22e217) continue;
        const _0x4df6e8 = Number(MIN_DOMAIN_VERSION[_0x22e217[_0x41e342(286)]] || 1);
        if (_0x22e217[_0x41e342(306)] < _0x4df6e8) {
          await storage[_0x41e342(343)](_0x333a44, _0x36a4d6[_0x41e342(247)]);
          continue;
        }
        if (_0x36a4d6[_0x41e342(282)] == null) {
          await storage[_0x41e342(343)](_0x333a44, _0x36a4d6[_0x41e342(247)]);
          continue;
        }
        const _0xa3bf6e = typeof _0x36a4d6[_0x41e342(282)] === _0x41e342(319) ? (() => {
          try {
            return JSON["parse"](_0x36a4d6["value"] || "null");
          } catch {
            return null;
          }
        })() : _0x36a4d6[_0x41e342(282)];
        if (!_0xa3bf6e || typeof _0xa3bf6e !== "object" || !Number[_0x41e342(278)](Number(_0xa3bf6e["v"]))) {
          await storage[_0x41e342(343)](_0x333a44, _0x36a4d6[_0x41e342(247)]);
          continue;
        }
        Number(_0xa3bf6e["v"]) < _0x4df6e8 && await storage[_0x41e342(343)](_0x333a44, _0x36a4d6[_0x41e342(247)]);
      }
    }
    async function cleanupLegacyGlobalKeys() {
      const _0x3f6b34 = _0x240096;
      for (const _0x226531 of LEGACY_GLOBAL_KEYS) {
        await storage[_0x3f6b34(343)](_0x3f6b34(331), _0x226531), await storage["removeRaw"](_0x3f6b34(291), _0x226531);
      }
    }
    async function runDataMigrations({ force = ![] } = {}) {
      const _0x1d8e0a = _0x240096;
      if (migrationsRan && !force) return;
      await cleanupVersionedEnvelopes(_0x1d8e0a(331)), await cleanupVersionedEnvelopes(_0x1d8e0a(291)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
    }
    function _0x2fbf() {
      const _0x56879c = ["zw50CMLLCW", "C3rYAw5NAwz5", "C2v0sxrLBq", "Bg9HzgvK", "zgvMyxvSDa", "Bwf4", "mJu4mtqWAvL5ELP6", "mty4oeLqwM5ptq", "y2vPBa", "CMvZCg9UC2u", "C2v0", "mJe3ota5offyzMPLuq", "D2fYBG", "y29Kzq", "ywrKtgLZDgvUzxi", "mte5ntHIswTjEei", "C2n4oG", "nZu0nvfnA3rPzW", "zgvSzxrL", "yxbWBhK", "AgfZu2nVCgu", "z2v0", "uMvXDwvZDcb0Aw1LB3v0", "C2XPy2u", "zMLUywXSEq", "DgfIBgu", "yxv0Aa", "yMXVy2TLza", "C3rHCNrZv2L0Aa", "AxngAw5PDgu", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "y29HBgvZy2u", "DhjHy2u", "DMfSDwu", "y29TCgfUEuLK", "yxnZAwDU", "Dg9mB3DLCKnHC2u", "zg9TywLU", "C2nVCgvlzxK", "mZK2r2fyuMnw", "zgf0yq", "z2XVyMfS", "y2HYB21L", "C3rHDhvZ", "Aw5JBhvKzq", "mZG4odKZnMH1t0fMCW", "CMvTB3zL", "Dgv4Da", "zxjYB3i", "mtK4mdnmEMLmCLO", "z2v0sxrLBq", "yxv0AenVBxbHBNK", "Dg9tDhjPBMC", "Dw5RBM93BG", "mJC3mZm2C29kwKHz", "mJKXueDIC2jp", "DhjPBq", "DMvYC2LVBG", "uMvXDwvZDcbMywLSzwq", "BM93", "C3rVCMfNzq", "zxHJzxb0Aw9U", "r0vu", "C3bSAxq", "sfruuf9fuLjpuG", "B2jQzwn0", "veLnru9vva", "AgfZ", "Bgv2zwW", "BgvUz3rO", "C3rYAw5N", "Bwv0Ag9K", "DhrStxm", "CMvHBg1jza", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "C2n4", "yxjYyxLcDwzMzxi", "CMvWBgfJzq", "ChjVDg90ExbL", "CMvTB3zLsxrLBq", "Bg9N", "y29UC29Szq", "Bg9JywW", "mZq4AfPOsvfM", "CMv0DxjUicHMDw5JDgLVBIGPia", "y2XLyw51Ca", "DgHLBG", "Bg9HzgLUzW", "CgfYC2u", "tKvuv09ss19fuLjpuG", "yMXVyG", "ANnVBG", "CMvTywLUAw5Ntxm", "qujpuLrfra", "CMvTB3zLuMf3", "zxHWzxjPzw5Jzq", "C2nVCgvK", "zNvUy3rPB24", "Aw5MBW", "yMLUza", "C2LNBMfS", "C2n4lwj1AwXKAw5NCY10CW", "C2nVCgu", "Dw5KzwzPBMvK", "ChjVzhvJDgLVBK1VzgLMAwvY", "y29TCgfUEq", "Bgv2zwXjBMzV", "sfruuca", "C2fSzxnnB2rPzMLLCG", "C2n4lwj1AwXKAw5NCW", "A2v5", "BMfTzq"];
      _0x2fbf = function() {
        return _0x56879c;
      };
      return _0x2fbf();
    }
    let initialized = ![];
    async function initializeDataPlatform({ force = ![] } = {}) {
      if (initialized && !force) return;
      await runDataMigrations({ "force": force }), initialized = !![];
    }
    chrome["runtime"]["onInstalled"][_0x240096(263)](async (_0x3648d7) => {
      await initializeDataPlatform();
    });
  }
});
export default require_background();
