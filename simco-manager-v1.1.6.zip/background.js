const _0x5059b6 = _0x26dc;
(function(_0x2d259c, _0x20158b) {
  const _0xf19f6a = _0x26dc, _0x326b45 = _0x2d259c();
  while (!![]) {
    try {
      const _0x3d45eb = parseInt(_0xf19f6a(129)) / 1 + parseInt(_0xf19f6a(143)) / 2 + parseInt(_0xf19f6a(219)) / 3 + parseInt(_0xf19f6a(211)) / 4 * (parseInt(_0xf19f6a(148)) / 5) + -parseInt(_0xf19f6a(194)) / 6 + -parseInt(_0xf19f6a(153)) / 7 + -parseInt(_0xf19f6a(150)) / 8;
      if (_0x3d45eb === _0x20158b) break;
      else _0x326b45["push"](_0x326b45["shift"]());
    } catch (_0x1f2f1d) {
      _0x326b45["push"](_0x326b45["shift"]());
    }
  }
})(_0x1d52, 589630);
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x475305) {
  return new Promise((_0x4a6994) => setTimeout(_0x4a6994, _0x475305));
}
function normalizeDomain$1(_0x4c67f5) {
  const _0x4c96f3 = _0x26dc;
  return String(_0x4c67f5 || "default")[_0x4c96f3(167)]()["toLowerCase"]();
}
function makeError(_0xb5587f, _0x5992d0 = {}) {
  const _0x21682d = _0x26dc, _0x49bafa = new Error(_0xb5587f);
  return Object[_0x21682d(155)](_0x49bafa, _0x5992d0), _0x49bafa;
}
function buildInflightKey(_0x2429ae, _0x2d7c87, _0x1e3827, _0x2bba18) {
  if (_0x2d7c87) return _0x2429ae + ":" + _0x2d7c87;
  return _0x2429ae + ":" + _0x2bba18 + ":" + _0x1e3827;
}
function getRateLimitStatus(_0x5bc79e = _0x5059b6(122)) {
  const _0x22d414 = _0x5059b6, _0x1bb666 = normalizeDomain$1(_0x5bc79e), _0x3a6c22 = Number(rateLimitByDomain[_0x22d414(180)](_0x1bb666) || 0), _0x1eb328 = Math[_0x22d414(169)](0, _0x3a6c22 - Date[_0x22d414(182)]());
  return { "blocked": _0x1eb328 > 0, "remainingMs": _0x1eb328, "blockedUntil": _0x3a6c22 };
}
async function parseResponse(_0x5f276f, _0x27b5a0) {
  const _0x1d3e27 = _0x5059b6;
  if (_0x27b5a0 === "response") return _0x5f276f;
  if (_0x27b5a0 === _0x1d3e27(212)) return _0x5f276f[_0x1d3e27(212)]();
  if (_0x27b5a0 === _0x1d3e27(197)) return _0x5f276f["blob"]();
  if (_0x27b5a0 === _0x1d3e27(224)) return _0x5f276f["arrayBuffer"]();
  return _0x5f276f[_0x1d3e27(130)]();
}
async function doRequest(_0x33dbbb, _0x31f6b8, _0x3d07c9 = 0) {
  const _0x3b0e45 = _0x5059b6, { url: _0x2e7b46, method = _0x3b0e45(207), headers: _0x2a948f, body: _0x5b2643, credentials = "include", signal: _0x4e3b0b, responseType = _0x3b0e45(130), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x31f6b8, _0x27b083 = getRateLimitStatus(_0x33dbbb);
  if (_0x27b083[_0x3b0e45(217)]) throw makeError(_0x3b0e45(203) + Math[_0x3b0e45(163)](_0x27b083[_0x3b0e45(134)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x33dbbb, "remainingMs": _0x27b083["remainingMs"], "status": 429 });
  const _0x59070d = timeoutMs > 0 ? new AbortController() : null, _0x4c4caf = _0x59070d && timeoutMs > 0 ? setTimeout(() => _0x59070d[_0x3b0e45(161)](makeError(_0x3b0e45(170), { "code": _0x3b0e45(125), "domain": _0x33dbbb })), timeoutMs) : null, _0x137f44 = _0x59070d ? _0x59070d[_0x3b0e45(128)] : _0x4e3b0b;
  try {
    const _0x1b3c1b = await fetch(_0x2e7b46, { "method": method, "headers": _0x2a948f, "body": _0x5b2643, "credentials": credentials, "signal": _0x137f44 });
    if (_0x1b3c1b["status"] === 429 && rateLimitCooldownMs > 0) {
      const _0x76a620 = (rateLimitHitCount[_0x3b0e45(180)](_0x33dbbb) || 0) + 1;
      rateLimitHitCount[_0x3b0e45(157)](_0x33dbbb, _0x76a620);
      const _0x3c89bd = _0x76a620 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x3b0e45(157)](_0x33dbbb, Date["now"]() + _0x3c89bd);
    }
    if (!_0x1b3c1b["ok"]) {
      const _0x1b2dd5 = _0x3d07c9 < retries && retryStatuses[_0x3b0e45(177)](_0x1b3c1b[_0x3b0e45(178)]);
      if (_0x1b2dd5) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x33dbbb, _0x31f6b8, _0x3d07c9 + 1);
      }
      throw makeError(_0x3b0e45(138) + _0x1b3c1b[_0x3b0e45(178)], { "code": _0x3b0e45(216), "domain": _0x33dbbb, "status": _0x1b3c1b["status"] });
    }
    return rateLimitHitCount[_0x3b0e45(183)](_0x33dbbb), parseResponse(_0x1b3c1b, responseType);
  } catch (_0x49e8c0) {
    const _0x12a746 = (_0x49e8c0 == null ? void 0 : _0x49e8c0[_0x3b0e45(184)]) === _0x3b0e45(188), _0x25deca = !_0x12a746 && _0x3d07c9 < retries;
    if (_0x25deca) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x33dbbb, _0x31f6b8, _0x3d07c9 + 1);
    }
    if (_0x49e8c0 instanceof Error && _0x49e8c0["code"]) throw _0x49e8c0;
    throw makeError(String((_0x49e8c0 == null ? void 0 : _0x49e8c0[_0x3b0e45(121)]) || _0x49e8c0 || _0x3b0e45(152)), { "code": _0x12a746 ? _0x3b0e45(220) : _0x3b0e45(147), "domain": _0x33dbbb, "status": Number((_0x49e8c0 == null ? void 0 : _0x49e8c0["status"]) || 0) || null, "cause": _0x49e8c0 });
  } finally {
    if (_0x4c4caf) clearTimeout(_0x4c4caf);
  }
}
async function request(_0x5e271b, _0xd2fcdd) {
  const _0x329ddf = _0x5059b6, _0x151a28 = normalizeDomain$1(_0x5e271b), _0x38f98f = buildInflightKey(_0x151a28, _0xd2fcdd == null ? void 0 : _0xd2fcdd[_0x329ddf(139)], _0xd2fcdd == null ? void 0 : _0xd2fcdd[_0x329ddf(141)], (_0xd2fcdd == null ? void 0 : _0xd2fcdd[_0x329ddf(218)]) || "GET");
  if ((_0xd2fcdd == null ? void 0 : _0xd2fcdd[_0x329ddf(202)]) && inflightByKey["has"](_0x38f98f)) return inflightByKey[_0x329ddf(180)](_0x38f98f);
  const _0x3739eb = doRequest(_0x151a28, _0xd2fcdd || {})[_0x329ddf(199)](() => {
    const _0x59e01c = _0x329ddf;
    inflightByKey[_0x59e01c(183)](_0x38f98f);
  });
  return (_0xd2fcdd == null ? void 0 : _0xd2fcdd[_0x329ddf(202)]) && inflightByKey["set"](_0x38f98f, _0x3739eb), _0x3739eb;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x2f9efe) {
  const _0x244ea4 = _0x5059b6, _0x27dbf1 = _0x2f9efe == null ? void 0 : _0x2f9efe[_0x244ea4(144)];
  STATE[_0x244ea4(137)][_0x244ea4(132)] = (_0x27dbf1 == null ? void 0 : _0x27dbf1[_0x244ea4(132)]) ?? null, STATE[_0x244ea4(137)][_0x244ea4(215)] = (_0x27dbf1 == null ? void 0 : _0x27dbf1["realmId"]) ?? null, STATE[_0x244ea4(137)][_0x244ea4(159)] = (_0x27dbf1 == null ? void 0 : _0x27dbf1[_0x244ea4(159)]) ?? null, STATE["auth"][_0x244ea4(140)] = (_0x27dbf1 == null ? void 0 : _0x27dbf1[_0x244ea4(140)]) ?? null, STATE["auth"][_0x244ea4(190)] = !![];
  const _0x2e9a66 = _0x2f9efe == null ? void 0 : _0x2f9efe[_0x244ea4(185)];
  STATE[_0x244ea4(185)]["level"] = (_0x2e9a66 == null ? void 0 : _0x2e9a66[_0x244ea4(162)]) ?? null, STATE[_0x244ea4(185)][_0x244ea4(166)] = (_0x2e9a66 == null ? void 0 : _0x2e9a66[_0x244ea4(166)]) ?? null, STATE[_0x244ea4(185)][_0x244ea4(196)] = (_0x2e9a66 == null ? void 0 : _0x2e9a66["experienceToNextLevel"]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x1afbe2 = _0x5059b6;
  if (!force && STATE[_0x1afbe2(137)][_0x1afbe2(190)] || STATE[_0x1afbe2(137)][_0x1afbe2(201)]) return;
  STATE["auth"][_0x1afbe2(201)] = !![], STATE[_0x1afbe2(137)]["error"] = null;
  try {
    const _0x455588 = await request("auth", { "url": "https://www.simcompanies.com/api/v3/companies/auth-data/", "credentials": _0x1afbe2(151), "responseType": _0x1afbe2(130), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x455588);
  } catch (_0x28feb9) {
    STATE["auth"][_0x1afbe2(198)] = String((_0x28feb9 == null ? void 0 : _0x28feb9["message"]) || _0x28feb9);
  } finally {
    STATE[_0x1afbe2(137)][_0x1afbe2(201)] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x5059b6(223), _0x5059b6(158), "global"]);
function normalizeScopeMode(_0x3e1b55) {
  const _0x2d1af6 = _0x5059b6;
  if (VALID_SCOPE_MODES[_0x2d1af6(205)](_0x3e1b55)) return _0x3e1b55;
  return _0x2d1af6(223);
}
function numericOrNull(_0x43da0b) {
  const _0x132500 = _0x5059b6;
  if (_0x43da0b === null || _0x43da0b === void 0 || _0x43da0b === "") return null;
  const _0x1fad9a = Number(_0x43da0b);
  return Number[_0x132500(171)](_0x1fad9a) ? _0x1fad9a : null;
}
function resolveScopeSync(_0x4d3536 = "scoped") {
  var _a, _b;
  const _0x2db520 = _0x5059b6, _0x9bfb8a = normalizeScopeMode(_0x4d3536), _0x191314 = numericOrNull((_a = STATE[_0x2db520(137)]) == null ? void 0 : _a[_0x2db520(132)]), _0x2e8a65 = numericOrNull((_b = STATE[_0x2db520(137)]) == null ? void 0 : _b[_0x2db520(215)]);
  if (_0x9bfb8a === _0x2db520(146)) return { "mode": _0x9bfb8a, "companyId": _0x191314, "realmId": _0x2e8a65, "hasScope": !![], "scopeKey": _0x2db520(146) };
  if (_0x9bfb8a === _0x2db520(158)) return { "mode": _0x9bfb8a, "companyId": _0x191314, "realmId": _0x2e8a65, "hasScope": Number[_0x2db520(171)](_0x191314), "scopeKey": Number[_0x2db520(171)](_0x191314) ? String(_0x191314) : null };
  const _0x104ac0 = Number[_0x2db520(171)](_0x191314) && Number[_0x2db520(171)](_0x2e8a65);
  return { "mode": _0x9bfb8a, "companyId": _0x191314, "realmId": _0x2e8a65, "hasScope": _0x104ac0, "scopeKey": _0x104ac0 ? _0x191314 + "-" + _0x2e8a65 : null };
}
async function resolveScope(_0x20dfd5 = _0x5059b6(223), { refreshAuth = ![] } = {}) {
  const _0x125b4 = _0x5059b6, _0x2e0e5f = normalizeScopeMode(_0x20dfd5);
  return refreshAuth && _0x2e0e5f !== _0x125b4(146) && await loadAuthDataOnce(), resolveScopeSync(_0x2e0e5f);
}
const DEFAULT_PREFIX = "scx";
function hasLocalStorage() {
  const _0x1fab65 = _0x5059b6;
  try {
    return typeof localStorage !== _0x1fab65(214) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome["storage"]) == null ? void 0 : _a["local"]);
  } catch {
    return ![];
  }
}
function parseJson(_0x4f9875) {
  const _0x21b8f5 = _0x5059b6;
  if (_0x4f9875 == null) return null;
  if (typeof _0x4f9875 === "object") return _0x4f9875;
  try {
    return JSON[_0x21b8f5(208)](String(_0x4f9875));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x29571c, _0x5867b6) {
  const _0x4c8f7d = _0x5059b6;
  if (_0x29571c === _0x4c8f7d(192)) return _0x5867b6;
  return JSON[_0x4c8f7d(133)](_0x5867b6);
}
function _0x1d52() {
  const _0x416633 = ["Bg9HzgLUzW", "y29HBgvZy2u", "uKfurv9msu1jvf9dt09mre9xtJO", "C3rYAw5N", "AgfZ", "Dw5RBM93BG", "r0vu", "CgfYC2u", "BNvSBa", "C2nVCgvlzxK", "nJbNve9nENa", "Dgv4Da", "CNvUDgLTzq", "Dw5KzwzPBMvK", "CMvHBg1jza", "sfruuf9fuLjpuG", "yMXVy2TLza", "Bwv0Ag9K", "mJy5otq5ovbAshziCW", "qujpuLrfra", "C2n4lwj1AwXKAw5NCW", "CMvTB3zLsxrLBq", "C2nVCgvK", "yxjYyxLcDwzMzxi", "BwvZC2fNzq", "zgvMyxvSDa", "DgHLBG", "C2n4lwj1AwXKAw5NCY10CW", "veLnru9vva", "ywrKtgLZDgvUzxi", "DMfSDwu", "C2LNBMfS", "mte0mZC0nLv4vfbzyq", "ANnVBG", "C3rHCNrZv2L0Aa", "y29TCgfUEuLK", "C3rYAw5NAwz5", "CMvTywLUAw5Ntxm", "A2v5", "Bw9Kzq", "yxv0Aa", "sfruuca", "y29HBgvZy2vlzxK", "C2fSzxnnB2rPzMLLCG", "DxjS", "AgfZu2nVCgu", "mJmWmtC3ohnQu1rzvW", "yxv0AenVBxbHBNK", "zNvUy3rPB24", "z2XVyMfS", "tKvuv09ss19fuLjpuG", "mJGXnJy1EMngCe13", "DMvYC2LVBG", "mtq3mJuZmZzJENfHr2G", "Aw5JBhvKzq", "uMvXDwvZDcbMywLSzwq", "nteXmJiYnLfewfjhqG", "Dg9mB3DLCKnHC2u", "yxnZAwDU", "C2v0sxrLBq", "C2v0", "y29TCgfUEq", "ChjVzhvJDgLVBK1VzgLMAwvY", "B2jQzwn0", "ywjVCNq", "Bgv2zwW", "y2vPBa", "C2XPy2u", "CMvTB3zLuMf3", "zxHWzxjPzw5Jzq", "DhjPBq", "C2nVCgu", "Bwf4", "uMvXDwvZDcb0Aw1LB3v0", "AxngAw5PDgu", "z2v0sxrLBq", "zw50CMLLCW", "BgvUz3rO", "CMvTB3zL", "C2n4", "Aw5JBhvKzxm", "C3rHDhvZ", "C3bSAxq", "z2v0", "CMvWBgfJzq", "BM93", "zgvSzxrL", "BMfTzq", "Bgv2zwXjBMzV", "Bg9JywW", "y2XLyw51Ca", "qwjVCNrfCNjVCG", "DhrStxm", "Bg9HzgvK", "C3rVCMfNzq", "y2HYB21L", "zgf0yq", "nti3mZa4ofLRB0HdAG", "zg9TywLU", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "yMXVyG", "zxjYB3i", "zMLUywXSEq", "ChvZAa"];
  _0x1d52 = function() {
    return _0x416633;
  };
  return _0x1d52();
}
function isEnvelopeValid(_0x29f451) {
  const _0x19ca65 = _0x5059b6;
  return Boolean(_0x29f451 && typeof _0x29f451 === _0x19ca65(160) && Number[_0x19ca65(171)](Number(_0x29f451["v"])));
}
function isExpired(_0x91a947, _0x57893e = null, _0x59f9ab = Date[_0x5059b6(182)]()) {
  const _0x3bf2b4 = _0x5059b6, _0x49229c = Number((_0x91a947 == null ? void 0 : _0x91a947["ts"]) || 0), _0x13e7fc = Number(_0x91a947 == null ? void 0 : _0x91a947[_0x3bf2b4(189)]), _0x2fbe85 = Number[_0x3bf2b4(171)](_0x13e7fc) ? _0x13e7fc : Number[_0x3bf2b4(171)](Number(_0x57893e)) ? Number(_0x57893e) : null;
  if (!Number[_0x3bf2b4(171)](_0x49229c) || _0x49229c <= 0) return ![];
  if (!Number["isFinite"](_0x2fbe85) || _0x2fbe85 <= 0) return ![];
  return _0x49229c + _0x2fbe85 < _0x59f9ab;
}
function normalizeBackend(_0x5f06a1) {
  const _0x2648fa = _0x5059b6;
  return _0x5f06a1 === "chrome" ? _0x2648fa(192) : "local";
}
function normalizePrefix(_0x5e8080) {
  const _0x482860 = _0x5059b6, _0x5ff7f5 = String(_0x5e8080 || DEFAULT_PREFIX)[_0x482860(167)]();
  return _0x5ff7f5[_0x482860(174)] > 0 ? _0x5ff7f5 : DEFAULT_PREFIX;
}
function _0x26dc(_0x42ee21, _0x41d10a) {
  _0x42ee21 = _0x42ee21 - 121;
  const _0x1d5273 = _0x1d52();
  let _0x26dc14 = _0x1d5273[_0x42ee21];
  if (_0x26dc["GafXbP"] === void 0) {
    var _0xb7e199 = function(_0xca031d) {
      const _0x184b84 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x475305 = "", _0x4a6994 = "";
      for (let _0x4c67f5 = 0, _0xb5587f, _0x5992d0, _0x49bafa = 0; _0x5992d0 = _0xca031d["charAt"](_0x49bafa++); ~_0x5992d0 && (_0xb5587f = _0x4c67f5 % 4 ? _0xb5587f * 64 + _0x5992d0 : _0x5992d0, _0x4c67f5++ % 4) ? _0x475305 += String["fromCharCode"](255 & _0xb5587f >> (-2 * _0x4c67f5 & 6)) : 0) {
        _0x5992d0 = _0x184b84["indexOf"](_0x5992d0);
      }
      for (let _0x2429ae = 0, _0x2d7c87 = _0x475305["length"]; _0x2429ae < _0x2d7c87; _0x2429ae++) {
        _0x4a6994 += "%" + ("00" + _0x475305["charCodeAt"](_0x2429ae)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x4a6994);
    };
    _0x26dc["pdILGa"] = _0xb7e199, _0x26dc["LekAcn"] = {}, _0x26dc["GafXbP"] = !![];
  }
  const _0xf754f7 = _0x1d5273[0], _0xfb357f = _0x42ee21 + _0xf754f7, _0x187e5f = _0x26dc["LekAcn"][_0xfb357f];
  return !_0x187e5f ? (_0x26dc14 = _0x26dc["pdILGa"](_0x26dc14), _0x26dc["LekAcn"][_0xfb357f] = _0x26dc14) : _0x26dc14 = _0x187e5f, _0x26dc14;
}
function normalizeDomain(_0x4b8077) {
  const _0x322fd9 = _0x5059b6;
  return String(_0x4b8077 || _0x322fd9(206))["trim"]()[_0x322fd9(181)](/\s+/g, "-")[_0x322fd9(154)]();
}
function buildStorageKey({ domain: _0x184475, version: _0x11d911, scopeKey: _0x547b08, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x184475) + ":v" + Number(_0x11d911) + ":" + _0x547b08;
}
async function chromeGet(_0x2e2852) {
  const _0x5c1c5a = _0x5059b6;
  if (!hasChromeStorage()) return {};
  const _0x22cc04 = chrome[_0x5c1c5a(191)]["local"];
  try {
    const _0x27d4e0 = _0x22cc04[_0x5c1c5a(180)](_0x2e2852);
    if (_0x27d4e0 && typeof _0x27d4e0[_0x5c1c5a(123)] === _0x5c1c5a(145)) return _0x27d4e0;
  } catch {
  }
  return new Promise((_0x26aef9) => {
    const _0x12e686 = _0x5c1c5a;
    try {
      _0x22cc04[_0x12e686(180)](_0x2e2852, (_0x326200) => _0x26aef9(_0x326200 || {}));
    } catch {
      _0x26aef9({});
    }
  });
}
async function chromeSet(_0x14cf83) {
  const _0x137a3f = _0x5059b6;
  if (!hasChromeStorage()) return ![];
  const _0x19215a = chrome[_0x137a3f(191)]["local"];
  try {
    const _0x60b956 = _0x19215a[_0x137a3f(157)](_0x14cf83);
    if (_0x60b956 && typeof _0x60b956["then"] === _0x137a3f(145)) return await _0x60b956, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x238624) => {
    try {
      _0x19215a["set"](_0x14cf83, () => _0x238624(!![]));
    } catch {
      _0x238624(![]);
    }
  });
}
async function chromeRemove(_0x37d5b1) {
  const _0x457285 = _0x5059b6;
  if (!hasChromeStorage()) return ![];
  const _0x584c5d = chrome[_0x457285(191)][_0x457285(186)];
  try {
    const _0x5beb22 = _0x584c5d[_0x457285(175)](_0x37d5b1);
    if (_0x5beb22 && typeof _0x5beb22[_0x457285(123)] === _0x457285(145)) return await _0x5beb22, !![];
    return !![];
  } catch {
  }
  return new Promise((_0xe928c0) => {
    const _0x355b15 = _0x457285;
    try {
      _0x584c5d[_0x355b15(175)](_0x37d5b1, () => _0xe928c0(!![]));
    } catch {
      _0xe928c0(![]);
    }
  });
}
async function getRaw(_0x53b275, _0x1add5f) {
  const _0x1ac831 = _0x5059b6, _0x18b6bd = normalizeBackend(_0x53b275);
  if (_0x18b6bd === _0x1ac831(186)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage[_0x1ac831(172)](_0x1add5f);
    } catch {
      return null;
    }
  }
  const _0x1fc47c = await chromeGet(_0x1add5f);
  return (_0x1fc47c == null ? void 0 : _0x1fc47c[_0x1add5f]) ?? null;
}
function localGetItemSync(_0x2ddce7) {
  const _0x3824ff = _0x5059b6;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x3824ff(172)](_0x2ddce7);
  } catch {
    return null;
  }
}
function localSetItemSync(_0xa9e3e0, _0x49fd68) {
  const _0x53cae6 = _0x5059b6;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x53cae6(156)](_0xa9e3e0, String(_0x49fd68)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x3bcb81) {
  const _0x34cf88 = _0x5059b6;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x34cf88(222)](_0x3bcb81), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x384327 = "") {
  const _0x5b9f5a = _0x5059b6;
  if (!hasLocalStorage()) return [];
  const _0x501d4e = [], _0x2918d9 = String(_0x384327 || "");
  try {
    for (let _0x214e79 = 0; _0x214e79 < localStorage[_0x5b9f5a(174)]; _0x214e79 += 1) {
      const _0x7d803a = localStorage[_0x5b9f5a(135)](_0x214e79);
      if (!_0x7d803a || _0x2918d9 && !_0x7d803a["startsWith"](_0x2918d9)) continue;
      _0x501d4e[_0x5b9f5a(200)]({ "key": _0x7d803a, "value": localStorage["getItem"](_0x7d803a) });
    }
  } catch {
    return [];
  }
  return _0x501d4e;
}
async function setRaw(_0xbe8495, _0x2225c5, _0x1e8a20) {
  const _0x227dda = _0x5059b6, _0x200a7a = normalizeBackend(_0xbe8495);
  if (_0x200a7a === _0x227dda(186)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x2225c5, String(_0x1e8a20)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x2225c5]: _0x1e8a20 });
}
async function removeRaw(_0x509c73, _0x27064f) {
  const _0x494202 = _0x5059b6, _0x41a02e = normalizeBackend(_0x509c73);
  if (_0x41a02e === _0x494202(186)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x494202(222)](_0x27064f), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x27064f);
}
async function listByPrefix({ backend = "local", prefix = "" } = {}) {
  const _0x13f619 = _0x5059b6, _0x45ff7e = normalizeBackend(backend), _0x3844a7 = String(prefix || "");
  if (_0x45ff7e === _0x13f619(186)) {
    if (!hasLocalStorage()) return [];
    const _0x4892db = [];
    try {
      for (let _0x507d82 = 0; _0x507d82 < localStorage[_0x13f619(174)]; _0x507d82 += 1) {
        const _0xd07040 = localStorage[_0x13f619(135)](_0x507d82);
        if (!_0xd07040 || _0x3844a7 && !_0xd07040[_0x13f619(131)](_0x3844a7)) continue;
        _0x4892db[_0x13f619(200)]({ "key": _0xd07040, "value": localStorage[_0x13f619(172)](_0xd07040) });
      }
    } catch {
      return [];
    }
    return _0x4892db;
  }
  const _0xf1845 = await chromeGet(null);
  return Object[_0x13f619(173)](_0xf1845 || {})["filter"](([_0x5e1c5a]) => _0x3844a7 ? _0x5e1c5a[_0x13f619(131)](_0x3844a7) : !![])["map"](([_0x5ef9bb, _0x16b140]) => ({ "key": _0x5ef9bb, "value": _0x16b140 }));
}
async function get({ domain: _0x52cc9f, version: _0x25b782, scope = _0x5059b6(223), backend = _0x5059b6(186), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x364758 = _0x5059b6, _0x32d7de = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x32d7de[_0x364758(142)] || !_0x32d7de["scopeKey"]) return null;
  const _0x3b37c8 = buildStorageKey({ "domain": _0x52cc9f, "version": _0x25b782, "scopeKey": _0x32d7de["scopeKey"], "prefix": prefix }), _0x53376e = await getRaw(backend, _0x3b37c8);
  if (_0x53376e == null) return null;
  const _0x5339fb = parseJson(_0x53376e);
  if (!isEnvelopeValid(_0x5339fb)) return await removeRaw(backend, _0x3b37c8), null;
  const _0x3f824d = Number(_0x5339fb["v"]);
  if (_0x3f824d !== Number(_0x25b782)) return _0x3f824d < Number(_0x25b782) && await removeRaw(backend, _0x3b37c8), null;
  if (isExpired(_0x5339fb, ttlMs)) return await removeRaw(backend, _0x3b37c8), null;
  const _0x5652b4 = _0x32d7de["scopeKey"], _0xe4220 = String(((_a = _0x5339fb == null ? void 0 : _0x5339fb[_0x364758(168)]) == null ? void 0 : _a[_0x364758(210)]) || "");
  if (_0x5652b4 && _0xe4220 && _0x5652b4 !== _0xe4220) return await removeRaw(backend, _0x3b37c8), null;
  return _0x5339fb[_0x364758(193)] ?? null;
}
async function set({ domain: _0x56e624, version: _0x5a8bd0, scope = _0x5059b6(223), backend = _0x5059b6(186), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x15b46d } = {}) {
  const _0x24578c = _0x5059b6, _0x4e442d = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x4e442d[_0x24578c(142)] || !_0x4e442d["scopeKey"]) return ![];
  const _0x42f22b = buildStorageKey({ "domain": _0x56e624, "version": _0x5a8bd0, "scopeKey": _0x4e442d[_0x24578c(210)], "prefix": prefix }), _0x4c64fa = { "v": Number(_0x5a8bd0), "ts": Date["now"](), "ttlMs": Number[_0x24578c(171)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x4e442d[_0x24578c(136)], "scopeKey": _0x4e442d[_0x24578c(210)], "companyId": _0x4e442d["companyId"], "realmId": _0x4e442d[_0x24578c(215)] }, "data": _0x15b46d };
  return setRaw(backend, _0x42f22b, toStorageRaw(normalizeBackend(backend), _0x4c64fa));
}
async function remove({ domain: _0x396263, version: _0x32b5ac, scope = _0x5059b6(223), backend = "local", prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x2bad45 = _0x5059b6, _0x11b18f = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x11b18f["hasScope"] || !_0x11b18f["scopeKey"]) return ![];
  const _0x1a9fc1 = buildStorageKey({ "domain": _0x396263, "version": _0x32b5ac, "scopeKey": _0x11b18f[_0x2bad45(210)], "prefix": prefix });
  return removeRaw(backend, _0x1a9fc1);
}
async function migrate({ domain: _0xd626c6, version: _0x146d9f, scope = _0x5059b6(223), backend = _0x5059b6(186), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x12305d, cleanupLegacy = !![] } = {}) {
  const _0x4c1864 = _0x5059b6, _0x12484c = await get({ "domain": _0xd626c6, "version": _0x146d9f, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x12484c !== null && _0x12484c !== void 0) return { "data": _0x12484c, "migrated": ![] };
  if (typeof _0x12305d !== _0x4c1864(145)) return { "data": null, "migrated": ![] };
  const _0x454cdd = await _0x12305d({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x1e6603 = _0x454cdd == null ? void 0 : _0x454cdd[_0x4c1864(193)];
  if (_0x1e6603 === null || _0x1e6603 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0xd626c6, "version": _0x146d9f, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x1e6603 }), cleanupLegacy && typeof (_0x454cdd == null ? void 0 : _0x454cdd["cleanup"]) === "function" && await _0x454cdd[_0x4c1864(187)](), { "data": _0x1e6603, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x5059b6(221), _0x5059b6(124)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x3f3f10) {
  const _0x3c5411 = _0x5059b6, _0x3c52b4 = String(_0x3f3f10 || "")[_0x3c5411(179)](":");
  if (_0x3c52b4[_0x3c5411(174)] < 4) return null;
  if (_0x3c52b4[0] !== _0x3c5411(176)) return null;
  const _0x4b88f9 = _0x3c52b4[1], _0x22b61f = _0x3c52b4[2] || "";
  if (!_0x22b61f[_0x3c5411(131)]("v")) return null;
  const _0x56f5ac = Number(_0x22b61f[_0x3c5411(164)](1));
  if (!Number[_0x3c5411(171)](_0x56f5ac)) return null;
  return { "domain": _0x4b88f9, "version": _0x56f5ac };
}
async function cleanupVersionedEnvelopes(_0xb9f5f0) {
  const _0x23bf6b = _0x5059b6, _0x5c82e4 = await storage["listByPrefix"]({ "backend": _0xb9f5f0, "prefix": "scx:" });
  for (const _0x1b2f5b of _0x5c82e4) {
    const _0x5b81e1 = parseDomainAndVersion(_0x1b2f5b["key"]);
    if (!_0x5b81e1) continue;
    const _0x4e81fd = Number(MIN_DOMAIN_VERSION[_0x5b81e1[_0x23bf6b(195)]] || 1);
    if (_0x5b81e1[_0x23bf6b(149)] < _0x4e81fd) {
      await storage[_0x23bf6b(165)](_0xb9f5f0, _0x1b2f5b[_0x23bf6b(135)]);
      continue;
    }
    if (_0x1b2f5b[_0x23bf6b(127)] == null) {
      await storage[_0x23bf6b(165)](_0xb9f5f0, _0x1b2f5b[_0x23bf6b(135)]);
      continue;
    }
    const _0x2f71d8 = typeof _0x1b2f5b[_0x23bf6b(127)] === _0x23bf6b(204) ? (() => {
      const _0x597d6a = _0x23bf6b;
      try {
        return JSON["parse"](_0x1b2f5b[_0x597d6a(127)] || _0x597d6a(209));
      } catch {
        return null;
      }
    })() : _0x1b2f5b[_0x23bf6b(127)];
    if (!_0x2f71d8 || typeof _0x2f71d8 !== _0x23bf6b(160) || !Number[_0x23bf6b(171)](Number(_0x2f71d8["v"]))) {
      await storage[_0x23bf6b(165)](_0xb9f5f0, _0x1b2f5b[_0x23bf6b(135)]);
      continue;
    }
    Number(_0x2f71d8["v"]) < _0x4e81fd && await storage["removeRaw"](_0xb9f5f0, _0x1b2f5b[_0x23bf6b(135)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x20d296 = _0x5059b6;
  for (const _0x1e2bce of LEGACY_GLOBAL_KEYS) {
    await storage["removeRaw"](_0x20d296(186), _0x1e2bce), await storage[_0x20d296(165)](_0x20d296(192), _0x1e2bce);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0xb608fd = _0x5059b6;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0xb608fd(186)), await cleanupVersionedEnvelopes(_0xb608fd(192)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
chrome[_0x5059b6(213)]["onInstalled"][_0x5059b6(126)](async (_0x5aede6) => {
  await initializeDataPlatform();
});
