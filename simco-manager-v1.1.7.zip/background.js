const _0x46ef4d = _0x1044;
(function(_0xf04552, _0x231029) {
  const _0x425a5b = _0x1044, _0x364265 = _0xf04552();
  while (!![]) {
    try {
      const _0x344c77 = parseInt(_0x425a5b(516)) / 1 + parseInt(_0x425a5b(523)) / 2 * (-parseInt(_0x425a5b(517)) / 3) + parseInt(_0x425a5b(477)) / 4 + parseInt(_0x425a5b(465)) / 5 + -parseInt(_0x425a5b(535)) / 6 * (-parseInt(_0x425a5b(495)) / 7) + -parseInt(_0x425a5b(492)) / 8 + -parseInt(_0x425a5b(464)) / 9 * (parseInt(_0x425a5b(528)) / 10);
      if (_0x344c77 === _0x231029) break;
      else _0x364265["push"](_0x364265["shift"]());
    } catch (_0x2a5b9b) {
      _0x364265["push"](_0x364265["shift"]());
    }
  }
})(_0x9524, 242602);
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x139f65) {
  return new Promise((_0x1653fb) => setTimeout(_0x1653fb, _0x139f65));
}
function normalizeDomain$1(_0x39b84b) {
  const _0xabd68b = _0x1044;
  return String(_0x39b84b || _0xabd68b(472))[_0xabd68b(447)]()[_0xabd68b(451)]();
}
function makeError(_0x14f422, _0x1ef05e = {}) {
  const _0x4d4390 = new Error(_0x14f422);
  return Object["assign"](_0x4d4390, _0x1ef05e), _0x4d4390;
}
function buildInflightKey(_0x54e852, _0x3f0d89, _0x387381, _0x509c68) {
  if (_0x3f0d89) return _0x54e852 + ":" + _0x3f0d89;
  return _0x54e852 + ":" + _0x509c68 + ":" + _0x387381;
}
function getRateLimitStatus(_0x32068e = "default") {
  const _0x396e70 = _0x1044, _0x180e5e = normalizeDomain$1(_0x32068e), _0xe42c4b = Number(rateLimitByDomain[_0x396e70(549)](_0x180e5e) || 0), _0x3bf8ef = Math[_0x396e70(544)](0, _0xe42c4b - Date["now"]());
  return { "blocked": _0x3bf8ef > 0, "remainingMs": _0x3bf8ef, "blockedUntil": _0xe42c4b };
}
async function parseResponse(_0x4a65e8, _0x1b2186) {
  const _0x35295d = _0x1044;
  if (_0x1b2186 === _0x35295d(541)) return _0x4a65e8;
  if (_0x1b2186 === _0x35295d(509)) return _0x4a65e8["text"]();
  if (_0x1b2186 === _0x35295d(522)) return _0x4a65e8[_0x35295d(522)]();
  if (_0x1b2186 === _0x35295d(482)) return _0x4a65e8["arrayBuffer"]();
  return _0x4a65e8[_0x35295d(514)]();
}
async function doRequest(_0x1eb7d4, _0x570148, _0x4bfe0e = 0) {
  const _0x569be8 = _0x1044, { url: _0x5a3c75, method = "GET", headers: _0x2f2407, body: _0x203869, credentials = _0x569be8(551), signal: _0x942b20, responseType = _0x569be8(514), retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x570148, _0x18f668 = getRateLimitStatus(_0x1eb7d4);
  if (_0x18f668[_0x569be8(520)]) throw makeError(_0x569be8(487) + Math[_0x569be8(446)](_0x18f668[_0x569be8(458)] / 1e3), { "code": _0x569be8(462), "domain": _0x1eb7d4, "remainingMs": _0x18f668["remainingMs"], "status": 429 });
  const _0x2dcae4 = timeoutMs > 0 ? new AbortController() : null, _0x30492a = _0x2dcae4 && timeoutMs > 0 ? setTimeout(() => _0x2dcae4[_0x569be8(530)](makeError(_0x569be8(489), { "code": _0x569be8(486), "domain": _0x1eb7d4 })), timeoutMs) : null, _0x5d0c99 = _0x2dcae4 ? _0x2dcae4[_0x569be8(518)] : _0x942b20;
  try {
    const _0x1dc5cc = await fetch(_0x5a3c75, { "method": method, "headers": _0x2f2407, "body": _0x203869, "credentials": credentials, "signal": _0x5d0c99 });
    if (_0x1dc5cc["status"] === 429 && rateLimitCooldownMs > 0) {
      const _0x44c31e = (rateLimitHitCount[_0x569be8(549)](_0x1eb7d4) || 0) + 1;
      rateLimitHitCount[_0x569be8(552)](_0x1eb7d4, _0x44c31e);
      const _0x227fa0 = _0x44c31e <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain[_0x569be8(552)](_0x1eb7d4, Date[_0x569be8(471)]() + _0x227fa0);
    }
    if (!_0x1dc5cc["ok"]) {
      const _0x215db4 = _0x4bfe0e < retries && retryStatuses[_0x569be8(457)](_0x1dc5cc[_0x569be8(498)]);
      if (_0x215db4) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x1eb7d4, _0x570148, _0x4bfe0e + 1);
      }
      throw makeError(_0x569be8(483) + _0x1dc5cc[_0x569be8(498)], { "code": "HTTP_ERROR", "domain": _0x1eb7d4, "status": _0x1dc5cc["status"] });
    }
    return rateLimitHitCount["delete"](_0x1eb7d4), parseResponse(_0x1dc5cc, responseType);
  } catch (_0x2143ae) {
    const _0x5e88d7 = (_0x2143ae == null ? void 0 : _0x2143ae[_0x569be8(479)]) === "AbortError", _0xf2954b = !_0x5e88d7 && _0x4bfe0e < retries;
    if (_0xf2954b) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x1eb7d4, _0x570148, _0x4bfe0e + 1);
    }
    if (_0x2143ae instanceof Error && _0x2143ae[_0x569be8(459)]) throw _0x2143ae;
    throw makeError(String((_0x2143ae == null ? void 0 : _0x2143ae[_0x569be8(468)]) || _0x2143ae || _0x569be8(499)), { "code": _0x5e88d7 ? _0x569be8(473) : _0x569be8(526), "domain": _0x1eb7d4, "status": Number((_0x2143ae == null ? void 0 : _0x2143ae[_0x569be8(498)]) || 0) || null, "cause": _0x2143ae });
  } finally {
    if (_0x30492a) clearTimeout(_0x30492a);
  }
}
async function request(_0x32a4ae, _0x176171) {
  const _0x56135f = _0x1044, _0x4eb3dd = normalizeDomain$1(_0x32a4ae), _0x4ec95d = buildInflightKey(_0x4eb3dd, _0x176171 == null ? void 0 : _0x176171[_0x56135f(542)], _0x176171 == null ? void 0 : _0x176171[_0x56135f(494)], (_0x176171 == null ? void 0 : _0x176171[_0x56135f(478)]) || _0x56135f(491));
  if ((_0x176171 == null ? void 0 : _0x176171[_0x56135f(550)]) && inflightByKey["has"](_0x4ec95d)) return inflightByKey[_0x56135f(549)](_0x4ec95d);
  const _0x1416b5 = doRequest(_0x4eb3dd, _0x176171 || {})[_0x56135f(548)](() => {
    const _0x55b784 = _0x56135f;
    inflightByKey[_0x55b784(546)](_0x4ec95d);
  });
  return (_0x176171 == null ? void 0 : _0x176171[_0x56135f(550)]) && inflightByKey[_0x56135f(552)](_0x4ec95d, _0x1416b5), _0x1416b5;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x270d92) {
  const _0xc2843b = _0x1044, _0x3631fe = _0x270d92 == null ? void 0 : _0x270d92[_0xc2843b(504)];
  STATE[_0xc2843b(456)][_0xc2843b(475)] = (_0x3631fe == null ? void 0 : _0x3631fe["companyId"]) ?? null, STATE[_0xc2843b(456)][_0xc2843b(540)] = (_0x3631fe == null ? void 0 : _0x3631fe[_0xc2843b(540)]) ?? null, STATE["auth"]["productionModifier"] = (_0x3631fe == null ? void 0 : _0x3631fe["productionModifier"]) ?? null, STATE[_0xc2843b(456)][_0xc2843b(466)] = (_0x3631fe == null ? void 0 : _0x3631fe[_0xc2843b(466)]) ?? null, STATE["auth"][_0xc2843b(527)] = !![];
  const _0x9878c8 = _0x270d92 == null ? void 0 : _0x270d92[_0xc2843b(497)];
  STATE[_0xc2843b(497)][_0xc2843b(503)] = (_0x9878c8 == null ? void 0 : _0x9878c8[_0xc2843b(503)]) ?? null, STATE["levelInfo"][_0xc2843b(496)] = (_0x9878c8 == null ? void 0 : _0x9878c8[_0xc2843b(496)]) ?? null, STATE[_0xc2843b(497)][_0xc2843b(469)] = (_0x9878c8 == null ? void 0 : _0x9878c8["experienceToNextLevel"]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x5822fc = _0x1044;
  if (!force && STATE["auth"][_0x5822fc(527)] || STATE[_0x5822fc(456)][_0x5822fc(474)]) return;
  STATE[_0x5822fc(456)][_0x5822fc(474)] = !![], STATE[_0x5822fc(456)][_0x5822fc(502)] = null;
  try {
    const _0x437e23 = await request(_0x5822fc(456), { "url": _0x5822fc(507), "credentials": "include", "responseType": _0x5822fc(514), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x437e23);
  } catch (_0x36e179) {
    STATE[_0x5822fc(456)]["error"] = String((_0x36e179 == null ? void 0 : _0x36e179[_0x5822fc(468)]) || _0x36e179);
  } finally {
    STATE[_0x5822fc(456)]["loading"] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x46ef4d(519), _0x46ef4d(470), "global"]);
function normalizeScopeMode(_0x2cf256) {
  const _0x323618 = _0x46ef4d;
  if (VALID_SCOPE_MODES[_0x323618(485)](_0x2cf256)) return _0x2cf256;
  return "scoped";
}
function numericOrNull(_0x201f16) {
  const _0x3d4da9 = _0x46ef4d;
  if (_0x201f16 === null || _0x201f16 === void 0 || _0x201f16 === "") return null;
  const _0x357820 = Number(_0x201f16);
  return Number[_0x3d4da9(534)](_0x357820) ? _0x357820 : null;
}
function resolveScopeSync(_0x5b3185 = _0x46ef4d(519)) {
  var _a, _b;
  const _0x396564 = _0x46ef4d, _0x4855de = normalizeScopeMode(_0x5b3185), _0x1e92a5 = numericOrNull((_a = STATE["auth"]) == null ? void 0 : _a[_0x396564(475)]), _0x193960 = numericOrNull((_b = STATE[_0x396564(456)]) == null ? void 0 : _b[_0x396564(540)]);
  if (_0x4855de === _0x396564(531)) return { "mode": _0x4855de, "companyId": _0x1e92a5, "realmId": _0x193960, "hasScope": !![], "scopeKey": _0x396564(531) };
  if (_0x4855de === _0x396564(470)) return { "mode": _0x4855de, "companyId": _0x1e92a5, "realmId": _0x193960, "hasScope": Number[_0x396564(534)](_0x1e92a5), "scopeKey": Number["isFinite"](_0x1e92a5) ? String(_0x1e92a5) : null };
  const _0x2996de = Number[_0x396564(534)](_0x1e92a5) && Number["isFinite"](_0x193960);
  return { "mode": _0x4855de, "companyId": _0x1e92a5, "realmId": _0x193960, "hasScope": _0x2996de, "scopeKey": _0x2996de ? _0x1e92a5 + "-" + _0x193960 : null };
}
async function resolveScope(_0x45b3aa = _0x46ef4d(519), { refreshAuth = ![] } = {}) {
  const _0x1179be = _0x46ef4d, _0x92f55d = normalizeScopeMode(_0x45b3aa);
  return refreshAuth && _0x92f55d !== _0x1179be(531) && await loadAuthDataOnce(), resolveScopeSync(_0x92f55d);
}
const DEFAULT_PREFIX = _0x46ef4d(505);
function hasLocalStorage() {
  try {
    return typeof localStorage !== "undefined" && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x14d522 = _0x46ef4d;
  try {
    return typeof chrome !== "undefined" && Boolean((_a = chrome == null ? void 0 : chrome[_0x14d522(532)]) == null ? void 0 : _a[_0x14d522(453)]);
  } catch {
    return ![];
  }
}
function parseJson(_0x41e222) {
  const _0x2c1496 = _0x46ef4d;
  if (_0x41e222 == null) return null;
  if (typeof _0x41e222 === _0x2c1496(533)) return _0x41e222;
  try {
    return JSON["parse"](String(_0x41e222));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x5e9f85, _0x2f3bcf) {
  const _0x5c0195 = _0x46ef4d;
  if (_0x5e9f85 === "chrome") return _0x2f3bcf;
  return JSON[_0x5c0195(512)](_0x2f3bcf);
}
function isEnvelopeValid(_0x588521) {
  const _0x5cc9c7 = _0x46ef4d;
  return Boolean(_0x588521 && typeof _0x588521 === _0x5cc9c7(533) && Number[_0x5cc9c7(534)](Number(_0x588521["v"])));
}
function isExpired(_0x5db7fe, _0x3f7ff1 = null, _0x3e58c5 = Date[_0x46ef4d(471)]()) {
  const _0x12b85b = _0x46ef4d, _0x56a9fa = Number((_0x5db7fe == null ? void 0 : _0x5db7fe["ts"]) || 0), _0x47a166 = Number(_0x5db7fe == null ? void 0 : _0x5db7fe[_0x12b85b(490)]), _0x2138a5 = Number[_0x12b85b(534)](_0x47a166) ? _0x47a166 : Number[_0x12b85b(534)](Number(_0x3f7ff1)) ? Number(_0x3f7ff1) : null;
  if (!Number[_0x12b85b(534)](_0x56a9fa) || _0x56a9fa <= 0) return ![];
  if (!Number[_0x12b85b(534)](_0x2138a5) || _0x2138a5 <= 0) return ![];
  return _0x56a9fa + _0x2138a5 < _0x3e58c5;
}
function normalizeBackend(_0x53cddc) {
  const _0x484308 = _0x46ef4d;
  return _0x53cddc === _0x484308(508) ? _0x484308(508) : _0x484308(453);
}
function normalizePrefix(_0x218212) {
  const _0x2d1adf = _0x46ef4d, _0x27cd63 = String(_0x218212 || DEFAULT_PREFIX)["trim"]();
  return _0x27cd63[_0x2d1adf(488)] > 0 ? _0x27cd63 : DEFAULT_PREFIX;
}
function normalizeDomain(_0x1f2b39) {
  const _0x5502fe = _0x46ef4d;
  return String(_0x1f2b39 || _0x5502fe(547))[_0x5502fe(447)]()[_0x5502fe(454)](/\s+/g, "-")[_0x5502fe(451)]();
}
function buildStorageKey({ domain: _0x2e88f5, version: _0x11874d, scopeKey: _0x2cbc4f, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x2e88f5) + ":v" + Number(_0x11874d) + ":" + _0x2cbc4f;
}
async function chromeGet(_0x8717a9) {
  const _0x248fbc = _0x46ef4d;
  if (!hasChromeStorage()) return {};
  const _0x3fdd26 = chrome[_0x248fbc(532)][_0x248fbc(453)];
  try {
    const _0x5cfa99 = _0x3fdd26["get"](_0x8717a9);
    if (_0x5cfa99 && typeof _0x5cfa99[_0x248fbc(537)] === "function") return _0x5cfa99;
  } catch {
  }
  return new Promise((_0x1301d4) => {
    const _0x446481 = _0x248fbc;
    try {
      _0x3fdd26[_0x446481(549)](_0x8717a9, (_0x4b206a) => _0x1301d4(_0x4b206a || {}));
    } catch {
      _0x1301d4({});
    }
  });
}
async function chromeSet(_0xae848d) {
  const _0x3455e1 = _0x46ef4d;
  if (!hasChromeStorage()) return ![];
  const _0x131bb7 = chrome[_0x3455e1(532)]["local"];
  try {
    const _0x2680ae = _0x131bb7[_0x3455e1(552)](_0xae848d);
    if (_0x2680ae && typeof _0x2680ae[_0x3455e1(537)] === _0x3455e1(480)) return await _0x2680ae, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x51474c) => {
    try {
      _0x131bb7["set"](_0xae848d, () => _0x51474c(!![]));
    } catch {
      _0x51474c(![]);
    }
  });
}
async function chromeRemove(_0xec044d) {
  const _0x1f5154 = _0x46ef4d;
  if (!hasChromeStorage()) return ![];
  const _0x23502f = chrome[_0x1f5154(532)]["local"];
  try {
    const _0x3d2fc0 = _0x23502f[_0x1f5154(513)](_0xec044d);
    if (_0x3d2fc0 && typeof _0x3d2fc0[_0x1f5154(537)] === "function") return await _0x3d2fc0, !![];
    return !![];
  } catch {
  }
  return new Promise((_0xe81420) => {
    try {
      _0x23502f["remove"](_0xec044d, () => _0xe81420(!![]));
    } catch {
      _0xe81420(![]);
    }
  });
}
function _0x1044(_0x2823e7, _0x20659d) {
  _0x2823e7 = _0x2823e7 - 446;
  const _0x952461 = _0x9524();
  let _0x1044e7 = _0x952461[_0x2823e7];
  if (_0x1044["DZxKkE"] === void 0) {
    var _0x2877bb = function(_0x2644ea) {
      const _0x156555 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x139f65 = "", _0x1653fb = "";
      for (let _0x39b84b = 0, _0x14f422, _0x1ef05e, _0x4d4390 = 0; _0x1ef05e = _0x2644ea["charAt"](_0x4d4390++); ~_0x1ef05e && (_0x14f422 = _0x39b84b % 4 ? _0x14f422 * 64 + _0x1ef05e : _0x1ef05e, _0x39b84b++ % 4) ? _0x139f65 += String["fromCharCode"](255 & _0x14f422 >> (-2 * _0x39b84b & 6)) : 0) {
        _0x1ef05e = _0x156555["indexOf"](_0x1ef05e);
      }
      for (let _0x54e852 = 0, _0x3f0d89 = _0x139f65["length"]; _0x54e852 < _0x3f0d89; _0x54e852++) {
        _0x1653fb += "%" + ("00" + _0x139f65["charCodeAt"](_0x54e852)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x1653fb);
    };
    _0x1044["zAVBkP"] = _0x2877bb, _0x1044["tMEdfG"] = {}, _0x1044["DZxKkE"] = !![];
  }
  const _0x628cb5 = _0x952461[0], _0x155f15 = _0x2823e7 + _0x628cb5, _0x4613ba = _0x1044["tMEdfG"][_0x155f15];
  return !_0x4613ba ? (_0x1044e7 = _0x1044["zAVBkP"](_0x1044e7), _0x1044["tMEdfG"][_0x155f15] = _0x1044e7) : _0x1044e7 = _0x4613ba, _0x1044e7;
}
async function getRaw(_0x3d3327, _0x128e79) {
  const _0x4a585c = _0x46ef4d, _0x467175 = normalizeBackend(_0x3d3327);
  if (_0x467175 === _0x4a585c(453)) {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage["getItem"](_0x128e79);
    } catch {
      return null;
    }
  }
  const _0x5361d3 = await chromeGet(_0x128e79);
  return (_0x5361d3 == null ? void 0 : _0x5361d3[_0x128e79]) ?? null;
}
function localGetItemSync(_0x44f27f) {
  const _0x4072fa = _0x46ef4d;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x4072fa(450)](_0x44f27f);
  } catch {
    return null;
  }
}
function localSetItemSync(_0x228ad4, _0x5a4eb8) {
  const _0x356c4c = _0x46ef4d;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x356c4c(460)](_0x228ad4, String(_0x5a4eb8)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0xccd21a) {
  const _0x169f2a = _0x46ef4d;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x169f2a(506)](_0xccd21a), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x166aef = "") {
  const _0x406d23 = _0x46ef4d;
  if (!hasLocalStorage()) return [];
  const _0x7ae711 = [], _0xd4d535 = String(_0x166aef || "");
  try {
    for (let _0x435838 = 0; _0x435838 < localStorage[_0x406d23(488)]; _0x435838 += 1) {
      const _0x1c042d = localStorage[_0x406d23(448)](_0x435838);
      if (!_0x1c042d || _0xd4d535 && !_0x1c042d[_0x406d23(501)](_0xd4d535)) continue;
      _0x7ae711[_0x406d23(515)]({ "key": _0x1c042d, "value": localStorage["getItem"](_0x1c042d) });
    }
  } catch {
    return [];
  }
  return _0x7ae711;
}
function _0x9524() {
  const _0x45cfa7 = ["DgHLBG", "C2XPy2u", "BgLZDej5uhjLzML4", "CMvHBg1jza", "CMvZCg9UC2u", "y29HBgvZy2vlzxK", "ywrKtgLZDgvUzxi", "Bwf4", "C3rYAw5N", "zgvSzxrL", "Dw5RBM93BG", "zMLUywXSEq", "z2v0", "y29HBgvZy2u", "Aw5JBhvKzq", "C2v0", "y2vPBa", "DhjPBq", "A2v5", "zgf0yq", "z2v0sxrLBq", "Dg9mB3DLCKnHC2u", "C2n4lwj1AwXKAw5NCW", "Bg9JywW", "CMvWBgfJzq", "C2nVCgu", "yxv0Aa", "Aw5JBhvKzxm", "CMvTywLUAw5Ntxm", "y29Kzq", "C2v0sxrLBq", "CMvTB3zLuMf3", "uKfurv9msu1jvf9dt09mre9xtG", "zg9TywLU", "mtG5zufvtNvd", "ntG2mZq1DKDvAxjd", "C2fSzxnnB2rPzMLLCG", "C2n4oG", "BwvZC2fNzq", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "y29TCgfUEq", "BM93", "zgvMyxvSDa", "qujpuLrfra", "Bg9HzgLUzW", "y29TCgfUEuLK", "DMvYC2LVBG", "otu4mtaWCMDfB1Dx", "Bwv0Ag9K", "BMfTzq", "zNvUy3rPB24", "Bw9Kzq", "yxjYyxLcDwzMzxi", "sfruuca", "CNvUDgLTzq", "AgfZ", "veLnru9vva", "uKfurv9msu1jvf9dt09mre9xtJO", "BgvUz3rO", "uMvXDwvZDcb0Aw1LB3v0", "DhrStxm", "r0vu", "mtiYmZe3nLH6tw5vsG", "CgfYC2u", "DxjS", "nda1mdm0vg5MyxLk", "zxHWzxjPzw5Jzq", "Bgv2zwXjBMzV", "C3rHDhvZ", "uMvXDwvZDcbMywLSzwq", "AgfZu2nVCgu", "C3rHCNrZv2L0Aa", "zxjYB3i", "Bgv2zwW", "yxv0AenVBxbHBNK", "C2n4", "CMvTB3zLsxrLBq", "Ahr0Chm6lY93D3CUC2LTy29TCgfUAwvZlMnVBs9HCgKVDJmVy29TCgfUAwvZl2f1DgGTzgf0ys8", "y2HYB21L", "Dgv4Da", "zMLSDgvY", "BwfW", "C3rYAw5NAwz5", "CMvTB3zL", "ANnVBG", "ChvZAa", "ndmXmZaXqwD6zgfp", "mZa4mJa4DK9jA1z0", "C2LNBMfS", "C2nVCgvK", "yMXVy2TLza", "C2nVCgvlzxK", "yMXVyG", "nhP1Ce1dDG", "zw50CMLLCW", "DMfSDwu", "tKvuv09ss19fuLjpuG", "Bg9HzgvK", "mJGXotGWuLbiv01k", "C2n4lwj1AwXKAw5NCY10CW", "ywjVCNq", "z2XVyMfS", "C3rVCMfNzq", "B2jQzwn0", "AxngAw5PDgu", "ndjirvPZywu", "C3bSAxq"];
  _0x9524 = function() {
    return _0x45cfa7;
  };
  return _0x9524();
}
async function setRaw(_0x544e7e, _0x3ee1e6, _0x2c7b83) {
  const _0x40cf87 = _0x46ef4d, _0x23b7bc = normalizeBackend(_0x544e7e);
  if (_0x23b7bc === "local") {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x40cf87(460)](_0x3ee1e6, String(_0x2c7b83)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x3ee1e6]: _0x2c7b83 });
}
async function removeRaw(_0x5e8a37, _0x212450) {
  const _0x311620 = _0x46ef4d, _0x141cdb = normalizeBackend(_0x5e8a37);
  if (_0x141cdb === _0x311620(453)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["removeItem"](_0x212450), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x212450);
}
async function listByPrefix({ backend = _0x46ef4d(453), prefix = "" } = {}) {
  const _0x563e61 = _0x46ef4d, _0x3309bf = normalizeBackend(backend), _0x1f2336 = String(prefix || "");
  if (_0x3309bf === _0x563e61(453)) {
    if (!hasLocalStorage()) return [];
    const _0x50632d = [];
    try {
      for (let _0x12ec01 = 0; _0x12ec01 < localStorage[_0x563e61(488)]; _0x12ec01 += 1) {
        const _0x160415 = localStorage[_0x563e61(448)](_0x12ec01);
        if (!_0x160415 || _0x1f2336 && !_0x160415["startsWith"](_0x1f2336)) continue;
        _0x50632d[_0x563e61(515)]({ "key": _0x160415, "value": localStorage[_0x563e61(450)](_0x160415) });
      }
    } catch {
      return [];
    }
    return _0x50632d;
  }
  const _0x44a518 = await chromeGet(null);
  return Object[_0x563e61(524)](_0x44a518 || {})[_0x563e61(510)](([_0x5c6e06]) => _0x1f2336 ? _0x5c6e06[_0x563e61(501)](_0x1f2336) : !![])[_0x563e61(511)](([_0x325436, _0x2cb9fd]) => ({ "key": _0x325436, "value": _0x2cb9fd }));
}
async function get({ domain: _0x534bb7, version: _0x4d0212, scope = _0x46ef4d(519), backend = _0x46ef4d(453), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x4e272e = _0x46ef4d, _0x235412 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x235412[_0x4e272e(500)] || !_0x235412[_0x4e272e(521)]) return null;
  const _0x44074b = buildStorageKey({ "domain": _0x534bb7, "version": _0x4d0212, "scopeKey": _0x235412[_0x4e272e(521)], "prefix": prefix }), _0x2d8ec1 = await getRaw(backend, _0x44074b);
  if (_0x2d8ec1 == null) return null;
  const _0x3e54f3 = parseJson(_0x2d8ec1);
  if (!isEnvelopeValid(_0x3e54f3)) return await removeRaw(backend, _0x44074b), null;
  const _0x13d6bc = Number(_0x3e54f3["v"]);
  if (_0x13d6bc !== Number(_0x4d0212)) return _0x13d6bc < Number(_0x4d0212) && await removeRaw(backend, _0x44074b), null;
  if (isExpired(_0x3e54f3, ttlMs)) return await removeRaw(backend, _0x44074b), null;
  const _0x193ca5 = _0x235412[_0x4e272e(521)], _0x146941 = String(((_a = _0x3e54f3 == null ? void 0 : _0x3e54f3[_0x4e272e(455)]) == null ? void 0 : _a[_0x4e272e(521)]) || "");
  if (_0x193ca5 && _0x146941 && _0x193ca5 !== _0x146941) return await removeRaw(backend, _0x44074b), null;
  return _0x3e54f3[_0x4e272e(449)] ?? null;
}
async function set({ domain: _0x569b3c, version: _0x59829b, scope = _0x46ef4d(519), backend = _0x46ef4d(453), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x224e3d } = {}) {
  const _0x58b6ab = _0x46ef4d, _0xa3ab4d = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0xa3ab4d[_0x58b6ab(500)] || !_0xa3ab4d[_0x58b6ab(521)]) return ![];
  const _0x4fcf62 = buildStorageKey({ "domain": _0x569b3c, "version": _0x59829b, "scopeKey": _0xa3ab4d[_0x58b6ab(521)], "prefix": prefix }), _0x262475 = { "v": Number(_0x59829b), "ts": Date[_0x58b6ab(471)](), "ttlMs": Number[_0x58b6ab(534)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0xa3ab4d[_0x58b6ab(481)], "scopeKey": _0xa3ab4d[_0x58b6ab(521)], "companyId": _0xa3ab4d["companyId"], "realmId": _0xa3ab4d["realmId"] }, "data": _0x224e3d };
  return setRaw(backend, _0x4fcf62, toStorageRaw(normalizeBackend(backend), _0x262475));
}
async function remove({ domain: _0x551abc, version: _0x172191, scope = "scoped", backend = _0x46ef4d(453), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x320fbf = _0x46ef4d, _0x274e8d = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x274e8d["hasScope"] || !_0x274e8d["scopeKey"]) return ![];
  const _0x182f0a = buildStorageKey({ "domain": _0x551abc, "version": _0x172191, "scopeKey": _0x274e8d[_0x320fbf(521)], "prefix": prefix });
  return removeRaw(backend, _0x182f0a);
}
async function migrate({ domain: _0x1a8638, version: _0x51302b, scope = _0x46ef4d(519), backend = _0x46ef4d(453), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x3106ec, cleanupLegacy = !![] } = {}) {
  const _0x5eb6da = _0x46ef4d, _0x35a45c = await get({ "domain": _0x1a8638, "version": _0x51302b, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x35a45c !== null && _0x35a45c !== void 0) return { "data": _0x35a45c, "migrated": ![] };
  if (typeof _0x3106ec !== _0x5eb6da(480)) return { "data": null, "migrated": ![] };
  const _0x231a29 = await _0x3106ec({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0xdc6e5 = _0x231a29 == null ? void 0 : _0x231a29[_0x5eb6da(449)];
  if (_0xdc6e5 === null || _0xdc6e5 === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x1a8638, "version": _0x51302b, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0xdc6e5 }), cleanupLegacy && typeof (_0x231a29 == null ? void 0 : _0x231a29["cleanup"]) === "function" && await _0x231a29["cleanup"](), { "data": _0xdc6e5, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x46ef4d(452), _0x46ef4d(529)];
let migrationsRan = ![];
function parseDomainAndVersion(_0x53747b) {
  const _0x5a3600 = _0x46ef4d, _0x5562ec = String(_0x53747b || "")[_0x5a3600(536)](":");
  if (_0x5562ec[_0x5a3600(488)] < 4) return null;
  if (_0x5562ec[0] !== "scx") return null;
  const _0x6eca88 = _0x5562ec[1], _0x23d226 = _0x5562ec[2] || "";
  if (!_0x23d226[_0x5a3600(501)]("v")) return null;
  const _0x33b00b = Number(_0x23d226[_0x5a3600(538)](1));
  if (!Number[_0x5a3600(534)](_0x33b00b)) return null;
  return { "domain": _0x6eca88, "version": _0x33b00b };
}
async function cleanupVersionedEnvelopes(_0x23bc8e) {
  const _0x31c65a = _0x46ef4d, _0x4b345d = await storage[_0x31c65a(539)]({ "backend": _0x23bc8e, "prefix": _0x31c65a(467) });
  for (const _0x285e22 of _0x4b345d) {
    const _0x2f4270 = parseDomainAndVersion(_0x285e22[_0x31c65a(448)]);
    if (!_0x2f4270) continue;
    const _0x503387 = Number(MIN_DOMAIN_VERSION[_0x2f4270[_0x31c65a(463)]] || 1);
    if (_0x2f4270[_0x31c65a(476)] < _0x503387) {
      await storage[_0x31c65a(461)](_0x23bc8e, _0x285e22[_0x31c65a(448)]);
      continue;
    }
    if (_0x285e22[_0x31c65a(525)] == null) {
      await storage[_0x31c65a(461)](_0x23bc8e, _0x285e22[_0x31c65a(448)]);
      continue;
    }
    const _0x349f62 = typeof _0x285e22[_0x31c65a(525)] === _0x31c65a(545) ? (() => {
      const _0x3c0842 = _0x31c65a;
      try {
        return JSON[_0x3c0842(493)](_0x285e22[_0x3c0842(525)] || "null");
      } catch {
        return null;
      }
    })() : _0x285e22[_0x31c65a(525)];
    if (!_0x349f62 || typeof _0x349f62 !== "object" || !Number[_0x31c65a(534)](Number(_0x349f62["v"]))) {
      await storage[_0x31c65a(461)](_0x23bc8e, _0x285e22["key"]);
      continue;
    }
    Number(_0x349f62["v"]) < _0x503387 && await storage[_0x31c65a(461)](_0x23bc8e, _0x285e22[_0x31c65a(448)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x20ec9a = _0x46ef4d;
  for (const _0x3e849c of LEGACY_GLOBAL_KEYS) {
    await storage[_0x20ec9a(461)](_0x20ec9a(453), _0x3e849c), await storage[_0x20ec9a(461)]("chrome", _0x3e849c);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x3bf52f = _0x46ef4d;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x3bf52f(453)), await cleanupVersionedEnvelopes("chrome"), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
chrome[_0x46ef4d(484)]["onInstalled"][_0x46ef4d(543)](async (_0x48a859) => {
  await initializeDataPlatform();
});
