const _0x1e023c = _0xfdbf;
(function(_0x2d1340, _0x1e1044) {
  const _0x234438 = _0xfdbf, _0x545d91 = _0x2d1340();
  while (!![]) {
    try {
      const _0x510c9d = parseInt(_0x234438(420)) / 1 * (-parseInt(_0x234438(411)) / 2) + -parseInt(_0x234438(495)) / 3 * (-parseInt(_0x234438(481)) / 4) + -parseInt(_0x234438(414)) / 5 + parseInt(_0x234438(488)) / 6 + -parseInt(_0x234438(509)) / 7 + -parseInt(_0x234438(427)) / 8 * (-parseInt(_0x234438(457)) / 9) + parseInt(_0x234438(505)) / 10;
      if (_0x510c9d === _0x1e1044) break;
      else _0x545d91["push"](_0x545d91["shift"]());
    } catch (_0x19c617) {
      _0x545d91["push"](_0x545d91["shift"]());
    }
  }
})(_0x5127, 392785);
function _0xfdbf(_0x3c8959, _0x3dd1ef) {
  _0x3c8959 = _0x3c8959 - 410;
  const _0x51277b = _0x5127();
  let _0xfdbf7e = _0x51277b[_0x3c8959];
  if (_0xfdbf["LijoLk"] === void 0) {
    var _0x512aa5 = function(_0x570f4a) {
      const _0x55512d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x5be99b = "", _0x3c86ca = "";
      for (let _0x35233b = 0, _0x5a130a, _0x119224, _0x315c7e = 0; _0x119224 = _0x570f4a["charAt"](_0x315c7e++); ~_0x119224 && (_0x5a130a = _0x35233b % 4 ? _0x5a130a * 64 + _0x119224 : _0x119224, _0x35233b++ % 4) ? _0x5be99b += String["fromCharCode"](255 & _0x5a130a >> (-2 * _0x35233b & 6)) : 0) {
        _0x119224 = _0x55512d["indexOf"](_0x119224);
      }
      for (let _0x385c19 = 0, _0x2212f3 = _0x5be99b["length"]; _0x385c19 < _0x2212f3; _0x385c19++) {
        _0x3c86ca += "%" + ("00" + _0x5be99b["charCodeAt"](_0x385c19)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x3c86ca);
    };
    _0xfdbf["MoczOY"] = _0x512aa5, _0xfdbf["gQFaNL"] = {}, _0xfdbf["LijoLk"] = !![];
  }
  const _0x2cfc4a = _0x51277b[0], _0x5a54e2 = _0x3c8959 + _0x2cfc4a, _0x5e140b = _0xfdbf["gQFaNL"][_0x5a54e2];
  return !_0x5e140b ? (_0xfdbf7e = _0xfdbf["MoczOY"](_0xfdbf7e), _0xfdbf["gQFaNL"][_0x5a54e2] = _0xfdbf7e) : _0xfdbf7e = _0x5e140b, _0xfdbf7e;
}
const inflightByKey = /* @__PURE__ */ new Map(), rateLimitByDomain = /* @__PURE__ */ new Map(), rateLimitHitCount = /* @__PURE__ */ new Map();
function wait(_0x5be99b) {
  return new Promise((_0x3c86ca) => setTimeout(_0x3c86ca, _0x5be99b));
}
function normalizeDomain$1(_0x35233b) {
  const _0x5eefa7 = _0xfdbf;
  return String(_0x35233b || "default")[_0x5eefa7(515)]()[_0x5eefa7(484)]();
}
function makeError(_0x5a130a, _0x119224 = {}) {
  const _0x8ad9c0 = _0xfdbf, _0x315c7e = new Error(_0x5a130a);
  return Object[_0x8ad9c0(442)](_0x315c7e, _0x119224), _0x315c7e;
}
function buildInflightKey(_0x385c19, _0x2212f3, _0x59f7ff, _0xab35ab) {
  if (_0x2212f3) return _0x385c19 + ":" + _0x2212f3;
  return _0x385c19 + ":" + _0xab35ab + ":" + _0x59f7ff;
}
function getRateLimitStatus(_0x3a5ac3 = _0x1e023c(503)) {
  const _0x584ebd = _0x1e023c, _0x4392e6 = normalizeDomain$1(_0x3a5ac3), _0x1b0320 = Number(rateLimitByDomain[_0x584ebd(465)](_0x4392e6) || 0), _0x55da77 = Math[_0x584ebd(499)](0, _0x1b0320 - Date[_0x584ebd(460)]());
  return { "blocked": _0x55da77 > 0, "remainingMs": _0x55da77, "blockedUntil": _0x1b0320 };
}
async function parseResponse(_0x20a5dc, _0x2d2d64) {
  const _0x51c796 = _0x1e023c;
  if (_0x2d2d64 === _0x51c796(490)) return _0x20a5dc;
  if (_0x2d2d64 === _0x51c796(500)) return _0x20a5dc[_0x51c796(500)]();
  if (_0x2d2d64 === "blob") return _0x20a5dc[_0x51c796(468)]();
  if (_0x2d2d64 === _0x51c796(482)) return _0x20a5dc["arrayBuffer"]();
  return _0x20a5dc["json"]();
}
async function doRequest(_0x5c3bfa, _0x202322, _0x2d0725 = 0) {
  const _0x42cc2b = _0x1e023c, { url: _0x47bf25, method = _0x42cc2b(423), headers: _0x2866ba, body: _0x3ef43a, credentials = _0x42cc2b(458), signal: _0x3b7443, responseType = "json", retries = 0, retryDelayMs = 0, retryStatuses = [408, 425, 429, 500, 502, 503, 504], rateLimitCooldownMs = 0, timeoutMs = 0 } = _0x202322, _0x16897b = getRateLimitStatus(_0x5c3bfa);
  if (_0x16897b["blocked"]) throw makeError(_0x42cc2b(449) + Math[_0x42cc2b(428)](_0x16897b[_0x42cc2b(438)] / 1e3), { "code": "RATE_LIMIT_COOLDOWN", "domain": _0x5c3bfa, "remainingMs": _0x16897b[_0x42cc2b(438)], "status": 429 });
  const _0x46a918 = timeoutMs > 0 ? new AbortController() : null, _0x2f91c2 = _0x46a918 && timeoutMs > 0 ? setTimeout(() => _0x46a918[_0x42cc2b(491)](makeError(_0x42cc2b(417), { "code": _0x42cc2b(478), "domain": _0x5c3bfa })), timeoutMs) : null, _0x52f37b = _0x46a918 ? _0x46a918[_0x42cc2b(514)] : _0x3b7443;
  try {
    const _0x59c924 = await fetch(_0x47bf25, { "method": method, "headers": _0x2866ba, "body": _0x3ef43a, "credentials": credentials, "signal": _0x52f37b });
    if (_0x59c924[_0x42cc2b(473)] === 429 && rateLimitCooldownMs > 0) {
      const _0x3eb0d1 = (rateLimitHitCount["get"](_0x5c3bfa) || 0) + 1;
      rateLimitHitCount[_0x42cc2b(494)](_0x5c3bfa, _0x3eb0d1);
      const _0x2b7435 = _0x3eb0d1 <= 1 ? rateLimitCooldownMs / 2 : rateLimitCooldownMs;
      rateLimitByDomain["set"](_0x5c3bfa, Date["now"]() + _0x2b7435);
    }
    if (!_0x59c924["ok"]) {
      const _0x4bd33a = _0x2d0725 < retries && retryStatuses[_0x42cc2b(489)](_0x59c924[_0x42cc2b(473)]);
      if (_0x4bd33a) {
        if (retryDelayMs > 0) await wait(retryDelayMs);
        return doRequest(_0x5c3bfa, _0x202322, _0x2d0725 + 1);
      }
      throw makeError(_0x42cc2b(433) + _0x59c924[_0x42cc2b(473)], { "code": "HTTP_ERROR", "domain": _0x5c3bfa, "status": _0x59c924[_0x42cc2b(473)] });
    }
    return rateLimitHitCount[_0x42cc2b(451)](_0x5c3bfa), parseResponse(_0x59c924, responseType);
  } catch (_0x1c72b5) {
    const _0x28034a = (_0x1c72b5 == null ? void 0 : _0x1c72b5["name"]) === _0x42cc2b(463), _0x11e904 = !_0x28034a && _0x2d0725 < retries;
    if (_0x11e904) {
      if (retryDelayMs > 0) await wait(retryDelayMs);
      return doRequest(_0x5c3bfa, _0x202322, _0x2d0725 + 1);
    }
    if (_0x1c72b5 instanceof Error && _0x1c72b5[_0x42cc2b(507)]) throw _0x1c72b5;
    throw makeError(String((_0x1c72b5 == null ? void 0 : _0x1c72b5[_0x42cc2b(415)]) || _0x1c72b5 || _0x42cc2b(513)), { "code": _0x28034a ? _0x42cc2b(504) : _0x42cc2b(474), "domain": _0x5c3bfa, "status": Number((_0x1c72b5 == null ? void 0 : _0x1c72b5[_0x42cc2b(473)]) || 0) || null, "cause": _0x1c72b5 });
  } finally {
    if (_0x2f91c2) clearTimeout(_0x2f91c2);
  }
}
async function request(_0x1ed160, _0x2c883c) {
  const _0x93af53 = _0x1e023c, _0x25f355 = normalizeDomain$1(_0x1ed160), _0x346ec3 = buildInflightKey(_0x25f355, _0x2c883c == null ? void 0 : _0x2c883c[_0x93af53(459)], _0x2c883c == null ? void 0 : _0x2c883c[_0x93af53(426)], (_0x2c883c == null ? void 0 : _0x2c883c[_0x93af53(501)]) || "GET");
  if ((_0x2c883c == null ? void 0 : _0x2c883c[_0x93af53(439)]) && inflightByKey["has"](_0x346ec3)) return inflightByKey["get"](_0x346ec3);
  const _0x13781b = doRequest(_0x25f355, _0x2c883c || {})[_0x93af53(443)](() => {
    const _0xf2ca3 = _0x93af53;
    inflightByKey[_0xf2ca3(451)](_0x346ec3);
  });
  return (_0x2c883c == null ? void 0 : _0x2c883c[_0x93af53(439)]) && inflightByKey[_0x93af53(494)](_0x346ec3, _0x13781b), _0x13781b;
}
const STATE = { "auth": { "companyId": null, "realmId": null, "productionModifier": null, "salesModifier": null, "loaded": ![], "loading": ![], "error": null }, "levelInfo": { "level": null, "experience": null, "experienceToNextLevel": null } };
function applyAuthData(_0x5ed2fd) {
  const _0x242de4 = _0x1e023c, _0x118852 = _0x5ed2fd == null ? void 0 : _0x5ed2fd[_0x242de4(498)];
  STATE[_0x242de4(421)]["companyId"] = (_0x118852 == null ? void 0 : _0x118852[_0x242de4(432)]) ?? null, STATE[_0x242de4(421)][_0x242de4(440)] = (_0x118852 == null ? void 0 : _0x118852[_0x242de4(440)]) ?? null, STATE[_0x242de4(421)][_0x242de4(486)] = (_0x118852 == null ? void 0 : _0x118852[_0x242de4(486)]) ?? null, STATE[_0x242de4(421)][_0x242de4(467)] = (_0x118852 == null ? void 0 : _0x118852[_0x242de4(467)]) ?? null, STATE["auth"][_0x242de4(434)] = !![];
  const _0x4efc38 = _0x5ed2fd == null ? void 0 : _0x5ed2fd[_0x242de4(466)];
  STATE["levelInfo"]["level"] = (_0x4efc38 == null ? void 0 : _0x4efc38[_0x242de4(454)]) ?? null, STATE[_0x242de4(466)][_0x242de4(461)] = (_0x4efc38 == null ? void 0 : _0x4efc38[_0x242de4(461)]) ?? null, STATE[_0x242de4(466)][_0x242de4(493)] = (_0x4efc38 == null ? void 0 : _0x4efc38["experienceToNextLevel"]) ?? null;
}
async function loadAuthDataOnce({ force = ![] } = {}) {
  const _0x30a4e6 = _0x1e023c;
  if (!force && STATE[_0x30a4e6(421)][_0x30a4e6(434)] || STATE[_0x30a4e6(421)][_0x30a4e6(412)]) return;
  STATE[_0x30a4e6(421)][_0x30a4e6(412)] = !![], STATE[_0x30a4e6(421)]["error"] = null;
  try {
    const _0x5c1a78 = await request(_0x30a4e6(421), { "url": "https://www.simcompanies.com/api/v3/companies/auth-data/", "credentials": _0x30a4e6(458), "responseType": _0x30a4e6(431), "retries": 1, "retryDelayMs": 250 });
    applyAuthData(_0x5c1a78);
  } catch (_0x2b7dd2) {
    STATE[_0x30a4e6(421)]["error"] = String((_0x2b7dd2 == null ? void 0 : _0x2b7dd2["message"]) || _0x2b7dd2);
  } finally {
    STATE[_0x30a4e6(421)]["loading"] = ![];
  }
}
const VALID_SCOPE_MODES = /* @__PURE__ */ new Set([_0x1e023c(469), _0x1e023c(453), _0x1e023c(429)]);
function normalizeScopeMode(_0x48cc23) {
  const _0x390380 = _0x1e023c;
  if (VALID_SCOPE_MODES[_0x390380(464)](_0x48cc23)) return _0x48cc23;
  return _0x390380(469);
}
function numericOrNull(_0x1dc1be) {
  if (_0x1dc1be === null || _0x1dc1be === void 0 || _0x1dc1be === "") return null;
  const _0x5e3e18 = Number(_0x1dc1be);
  return Number["isFinite"](_0x5e3e18) ? _0x5e3e18 : null;
}
function resolveScopeSync(_0x5e5e76 = _0x1e023c(469)) {
  var _a, _b;
  const _0x119dba = _0x1e023c, _0x3a8be6 = normalizeScopeMode(_0x5e5e76), _0x58ac3a = numericOrNull((_a = STATE[_0x119dba(421)]) == null ? void 0 : _a[_0x119dba(432)]), _0x3aa1c0 = numericOrNull((_b = STATE[_0x119dba(421)]) == null ? void 0 : _b[_0x119dba(440)]);
  if (_0x3a8be6 === _0x119dba(429)) return { "mode": _0x3a8be6, "companyId": _0x58ac3a, "realmId": _0x3aa1c0, "hasScope": !![], "scopeKey": "global" };
  if (_0x3a8be6 === _0x119dba(453)) return { "mode": _0x3a8be6, "companyId": _0x58ac3a, "realmId": _0x3aa1c0, "hasScope": Number[_0x119dba(462)](_0x58ac3a), "scopeKey": Number["isFinite"](_0x58ac3a) ? String(_0x58ac3a) : null };
  const _0x3c30d3 = Number[_0x119dba(462)](_0x58ac3a) && Number[_0x119dba(462)](_0x3aa1c0);
  return { "mode": _0x3a8be6, "companyId": _0x58ac3a, "realmId": _0x3aa1c0, "hasScope": _0x3c30d3, "scopeKey": _0x3c30d3 ? _0x58ac3a + "-" + _0x3aa1c0 : null };
}
async function resolveScope(_0x59ebb4 = _0x1e023c(469), { refreshAuth = ![] } = {}) {
  const _0x5ca818 = normalizeScopeMode(_0x59ebb4);
  return refreshAuth && _0x5ca818 !== "global" && await loadAuthDataOnce(), resolveScopeSync(_0x5ca818);
}
const DEFAULT_PREFIX = _0x1e023c(450);
function hasLocalStorage() {
  const _0x2f6e45 = _0x1e023c;
  try {
    return typeof localStorage !== _0x2f6e45(455) && localStorage !== null;
  } catch {
    return ![];
  }
}
function hasChromeStorage() {
  var _a;
  const _0x10609c = _0x1e023c;
  try {
    return typeof chrome !== _0x10609c(455) && Boolean((_a = chrome == null ? void 0 : chrome["storage"]) == null ? void 0 : _a["local"]);
  } catch {
    return ![];
  }
}
function parseJson(_0x1e90df) {
  const _0x16dffb = _0x1e023c;
  if (_0x1e90df == null) return null;
  if (typeof _0x1e90df === "object") return _0x1e90df;
  try {
    return JSON[_0x16dffb(422)](String(_0x1e90df));
  } catch {
    return null;
  }
}
function toStorageRaw(_0x3ef009, _0x3d51ee) {
  const _0x3f7914 = _0x1e023c;
  if (_0x3ef009 === _0x3f7914(425)) return _0x3d51ee;
  return JSON["stringify"](_0x3d51ee);
}
function isEnvelopeValid(_0x4e2918) {
  const _0x94409 = _0x1e023c;
  return Boolean(_0x4e2918 && typeof _0x4e2918 === _0x94409(436) && Number[_0x94409(462)](Number(_0x4e2918["v"])));
}
function isExpired(_0x53a5c8, _0xfdda82 = null, _0x29b167 = Date["now"]()) {
  const _0x3a129d = _0x1e023c, _0x4b1025 = Number((_0x53a5c8 == null ? void 0 : _0x53a5c8["ts"]) || 0), _0x3e92e8 = Number(_0x53a5c8 == null ? void 0 : _0x53a5c8[_0x3a129d(437)]), _0x5dc3ca = Number["isFinite"](_0x3e92e8) ? _0x3e92e8 : Number[_0x3a129d(462)](Number(_0xfdda82)) ? Number(_0xfdda82) : null;
  if (!Number[_0x3a129d(462)](_0x4b1025) || _0x4b1025 <= 0) return ![];
  if (!Number[_0x3a129d(462)](_0x5dc3ca) || _0x5dc3ca <= 0) return ![];
  return _0x4b1025 + _0x5dc3ca < _0x29b167;
}
function normalizeBackend(_0x4e41e7) {
  const _0x76973d = _0x1e023c;
  return _0x4e41e7 === _0x76973d(425) ? _0x76973d(425) : _0x76973d(475);
}
function normalizePrefix(_0x5f15a6) {
  const _0x3abbae = _0x1e023c, _0x1a5c7d = String(_0x5f15a6 || DEFAULT_PREFIX)[_0x3abbae(515)]();
  return _0x1a5c7d["length"] > 0 ? _0x1a5c7d : DEFAULT_PREFIX;
}
function normalizeDomain(_0x2c6d3c) {
  const _0x4965b6 = _0x1e023c;
  return String(_0x2c6d3c || _0x4965b6(496))[_0x4965b6(515)]()[_0x4965b6(476)](/\s+/g, "-")[_0x4965b6(484)]();
}
function buildStorageKey({ domain: _0x59de5f, version: _0x3c7a77, scopeKey: _0x56dfb9, prefix = DEFAULT_PREFIX }) {
  return normalizePrefix(prefix) + ":" + normalizeDomain(_0x59de5f) + ":v" + Number(_0x3c7a77) + ":" + _0x56dfb9;
}
async function chromeGet(_0x51de10) {
  const _0x231111 = _0x1e023c;
  if (!hasChromeStorage()) return {};
  const _0xf414e0 = chrome[_0x231111(511)]["local"];
  try {
    const _0x29ff93 = _0xf414e0[_0x231111(465)](_0x51de10);
    if (_0x29ff93 && typeof _0x29ff93[_0x231111(502)] === _0x231111(512)) return _0x29ff93;
  } catch {
  }
  return new Promise((_0x254757) => {
    const _0x834b71 = _0x231111;
    try {
      _0xf414e0[_0x834b71(465)](_0x51de10, (_0x3203ae) => _0x254757(_0x3203ae || {}));
    } catch {
      _0x254757({});
    }
  });
}
async function chromeSet(_0x136b91) {
  const _0x4c8a99 = _0x1e023c;
  if (!hasChromeStorage()) return ![];
  const _0x871c79 = chrome[_0x4c8a99(511)]["local"];
  try {
    const _0x187dfd = _0x871c79[_0x4c8a99(494)](_0x136b91);
    if (_0x187dfd && typeof _0x187dfd["then"] === _0x4c8a99(512)) return await _0x187dfd, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x205682) => {
    try {
      _0x871c79["set"](_0x136b91, () => _0x205682(!![]));
    } catch {
      _0x205682(![]);
    }
  });
}
async function chromeRemove(_0x2a55fa) {
  const _0x5a7a3b = _0x1e023c;
  if (!hasChromeStorage()) return ![];
  const _0x33cdfa = chrome[_0x5a7a3b(511)][_0x5a7a3b(475)];
  try {
    const _0x35a421 = _0x33cdfa[_0x5a7a3b(418)](_0x2a55fa);
    if (_0x35a421 && typeof _0x35a421[_0x5a7a3b(502)] === _0x5a7a3b(512)) return await _0x35a421, !![];
    return !![];
  } catch {
  }
  return new Promise((_0x11dad1) => {
    try {
      _0x33cdfa["remove"](_0x2a55fa, () => _0x11dad1(!![]));
    } catch {
      _0x11dad1(![]);
    }
  });
}
async function getRaw(_0x3c6a18, _0x43b192) {
  const _0x4ac4ca = normalizeBackend(_0x3c6a18);
  if (_0x4ac4ca === "local") {
    if (!hasLocalStorage()) return null;
    try {
      return localStorage["getItem"](_0x43b192);
    } catch {
      return null;
    }
  }
  const _0x118cd8 = await chromeGet(_0x43b192);
  return (_0x118cd8 == null ? void 0 : _0x118cd8[_0x43b192]) ?? null;
}
function localGetItemSync(_0x5552e5) {
  const _0x135e85 = _0x1e023c;
  if (!hasLocalStorage()) return null;
  try {
    return localStorage[_0x135e85(445)](_0x5552e5);
  } catch {
    return null;
  }
}
function localSetItemSync(_0xe3dc7f, _0x482023) {
  const _0x5dc610 = _0x1e023c;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x5dc610(424)](_0xe3dc7f, String(_0x482023)), !![];
  } catch {
    return ![];
  }
}
function localRemoveItemSync(_0x58cb82) {
  const _0x54deeb = _0x1e023c;
  if (!hasLocalStorage()) return ![];
  try {
    return localStorage[_0x54deeb(452)](_0x58cb82), !![];
  } catch {
    return ![];
  }
}
function localListByPrefixSync(_0x31e0c6 = "") {
  const _0x481317 = _0x1e023c;
  if (!hasLocalStorage()) return [];
  const _0x4ea71 = [], _0x18f223 = String(_0x31e0c6 || "");
  try {
    for (let _0x151eb3 = 0; _0x151eb3 < localStorage[_0x481317(471)]; _0x151eb3 += 1) {
      const _0xe569a7 = localStorage[_0x481317(447)](_0x151eb3);
      if (!_0xe569a7 || _0x18f223 && !_0xe569a7[_0x481317(497)](_0x18f223)) continue;
      _0x4ea71[_0x481317(410)]({ "key": _0xe569a7, "value": localStorage[_0x481317(445)](_0xe569a7) });
    }
  } catch {
    return [];
  }
  return _0x4ea71;
}
async function setRaw(_0x4eb690, _0x1f14a2, _0x2c124b) {
  const _0x25384b = _0x1e023c, _0x142781 = normalizeBackend(_0x4eb690);
  if (_0x142781 === _0x25384b(475)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage["setItem"](_0x1f14a2, String(_0x2c124b)), !![];
    } catch {
      return ![];
    }
  }
  return chromeSet({ [_0x1f14a2]: _0x2c124b });
}
async function removeRaw(_0x48b713, _0x28ff05) {
  const _0x41cd9 = _0x1e023c, _0x5490b5 = normalizeBackend(_0x48b713);
  if (_0x5490b5 === _0x41cd9(475)) {
    if (!hasLocalStorage()) return ![];
    try {
      return localStorage[_0x41cd9(452)](_0x28ff05), !![];
    } catch {
      return ![];
    }
  }
  return chromeRemove(_0x28ff05);
}
async function listByPrefix({ backend = _0x1e023c(475), prefix = "" } = {}) {
  const _0x1d3324 = _0x1e023c, _0x54b95b = normalizeBackend(backend), _0x131d06 = String(prefix || "");
  if (_0x54b95b === "local") {
    if (!hasLocalStorage()) return [];
    const _0x44585a = [];
    try {
      for (let _0x2beed9 = 0; _0x2beed9 < localStorage[_0x1d3324(471)]; _0x2beed9 += 1) {
        const _0x422e45 = localStorage[_0x1d3324(447)](_0x2beed9);
        if (!_0x422e45 || _0x131d06 && !_0x422e45[_0x1d3324(497)](_0x131d06)) continue;
        _0x44585a[_0x1d3324(410)]({ "key": _0x422e45, "value": localStorage[_0x1d3324(445)](_0x422e45) });
      }
    } catch {
      return [];
    }
    return _0x44585a;
  }
  const _0x482f81 = await chromeGet(null);
  return Object[_0x1d3324(416)](_0x482f81 || {})[_0x1d3324(477)](([_0x4b1d02]) => _0x131d06 ? _0x4b1d02[_0x1d3324(497)](_0x131d06) : !![])[_0x1d3324(487)](([_0x504322, _0x1f4e26]) => ({ "key": _0x504322, "value": _0x1f4e26 }));
}
async function get({ domain: _0x2d9e21, version: _0xe0e8c6, scope = _0x1e023c(469), backend = _0x1e023c(475), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![] } = {}) {
  var _a;
  const _0x4a2424 = _0x1e023c, _0x5837c0 = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x5837c0[_0x4a2424(506)] || !_0x5837c0[_0x4a2424(435)]) return null;
  const _0x5f4ac2 = buildStorageKey({ "domain": _0x2d9e21, "version": _0xe0e8c6, "scopeKey": _0x5837c0["scopeKey"], "prefix": prefix }), _0x769976 = await getRaw(backend, _0x5f4ac2);
  if (_0x769976 == null) return null;
  const _0x5e77b7 = parseJson(_0x769976);
  if (!isEnvelopeValid(_0x5e77b7)) return await removeRaw(backend, _0x5f4ac2), null;
  const _0x5df417 = Number(_0x5e77b7["v"]);
  if (_0x5df417 !== Number(_0xe0e8c6)) return _0x5df417 < Number(_0xe0e8c6) && await removeRaw(backend, _0x5f4ac2), null;
  if (isExpired(_0x5e77b7, ttlMs)) return await removeRaw(backend, _0x5f4ac2), null;
  const _0x13e032 = _0x5837c0["scopeKey"], _0x4b6f48 = String(((_a = _0x5e77b7 == null ? void 0 : _0x5e77b7[_0x4a2424(470)]) == null ? void 0 : _a["scopeKey"]) || "");
  if (_0x13e032 && _0x4b6f48 && _0x13e032 !== _0x4b6f48) return await removeRaw(backend, _0x5f4ac2), null;
  return _0x5e77b7[_0x4a2424(472)] ?? null;
}
async function set({ domain: _0x53ffc8, version: _0x983941, scope = "scoped", backend = _0x1e023c(475), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], data: _0x1a7060 } = {}) {
  const _0x1d8ad9 = _0x1e023c, _0x3e10ad = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x3e10ad[_0x1d8ad9(506)] || !_0x3e10ad[_0x1d8ad9(435)]) return ![];
  const _0x2be2e3 = buildStorageKey({ "domain": _0x53ffc8, "version": _0x983941, "scopeKey": _0x3e10ad[_0x1d8ad9(435)], "prefix": prefix }), _0x6e68ea = { "v": Number(_0x983941), "ts": Date["now"](), "ttlMs": Number[_0x1d8ad9(462)](Number(ttlMs)) ? Number(ttlMs) : null, "scope": { "mode": _0x3e10ad[_0x1d8ad9(446)], "scopeKey": _0x3e10ad[_0x1d8ad9(435)], "companyId": _0x3e10ad[_0x1d8ad9(432)], "realmId": _0x3e10ad["realmId"] }, "data": _0x1a7060 };
  return setRaw(backend, _0x2be2e3, toStorageRaw(normalizeBackend(backend), _0x6e68ea));
}
async function remove({ domain: _0x390c2d, version: _0x2e88f5, scope = _0x1e023c(469), backend = _0x1e023c(475), prefix = DEFAULT_PREFIX, refreshAuth = !![] } = {}) {
  const _0x3b0a4d = _0x1e023c, _0x2819bc = await resolveScope(scope, { "refreshAuth": refreshAuth });
  if (!_0x2819bc[_0x3b0a4d(506)] || !_0x2819bc[_0x3b0a4d(435)]) return ![];
  const _0x1e6b22 = buildStorageKey({ "domain": _0x390c2d, "version": _0x2e88f5, "scopeKey": _0x2819bc[_0x3b0a4d(435)], "prefix": prefix });
  return removeRaw(backend, _0x1e6b22);
}
async function migrate({ domain: _0x4d0a01, version: _0x3984b6, scope = _0x1e023c(469), backend = _0x1e023c(475), prefix = DEFAULT_PREFIX, ttlMs = null, refreshAuth = !![], readLegacy: _0x2a8457, cleanupLegacy = !![] } = {}) {
  const _0x321238 = _0x1e023c, _0x3f12c9 = await get({ "domain": _0x4d0a01, "version": _0x3984b6, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth });
  if (_0x3f12c9 !== null && _0x3f12c9 !== void 0) return { "data": _0x3f12c9, "migrated": ![] };
  if (typeof _0x2a8457 !== _0x321238(512)) return { "data": null, "migrated": ![] };
  const _0x56f3af = await _0x2a8457({ "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "listByPrefix": listByPrefix, "parseJson": parseJson }), _0x122bbc = _0x56f3af == null ? void 0 : _0x56f3af[_0x321238(472)];
  if (_0x122bbc === null || _0x122bbc === void 0) return { "data": null, "migrated": ![] };
  return await set({ "domain": _0x4d0a01, "version": _0x3984b6, "scope": scope, "backend": backend, "prefix": prefix, "ttlMs": ttlMs, "refreshAuth": refreshAuth, "data": _0x122bbc }), cleanupLegacy && typeof (_0x56f3af == null ? void 0 : _0x56f3af[_0x321238(413)]) === "function" && await _0x56f3af["cleanup"](), { "data": _0x122bbc, "migrated": !![] };
}
const storage = { "get": get, "set": set, "remove": remove, "listByPrefix": listByPrefix, "migrate": migrate, "buildStorageKey": buildStorageKey, "getRaw": getRaw, "setRaw": setRaw, "removeRaw": removeRaw, "localSync": { "getItem": localGetItemSync, "setItem": localSetItemSync, "removeItem": localRemoveItemSync, "listByPrefix": localListByPrefixSync } }, MIN_DOMAIN_VERSION = { "cashflow-finance": 2, "buildings-cache": 1, "market-alerts": 1, "whats-new": 1, "xp-widget-visible": 1, "contract-discount": 1, "upgrade-discount": 1, "upgrade-multiplier": 1 }, LEGACY_GLOBAL_KEYS = [_0x1e023c(485), "scx-buildings-ts"];
function _0x5127() {
  const _0x2c81ac = ["C3bSAxq", "uKfurv9msu1jvf9dt09mre9xtJO", "C2n4", "zgvSzxrL", "CMvTB3zLsxrLBq", "y29TCgfUEq", "Bgv2zwW", "Dw5KzwzPBMvK", "C2XPy2u", "mtuWmJfiC3zHu3q", "Aw5JBhvKzq", "y29HBgvZy2vlzxK", "BM93", "zxHWzxjPzw5Jzq", "AxngAw5PDgu", "qwjVCNrfCNjVCG", "AgfZ", "z2v0", "Bgv2zwXjBMzV", "C2fSzxnnB2rPzMLLCG", "yMXVyG", "C2nVCgvK", "C2nVCgu", "BgvUz3rO", "zgf0yq", "C3rHDhvZ", "tKvuv09ss19fuLjpuG", "Bg9JywW", "CMvWBgfJzq", "zMLSDgvY", "veLnru9vva", "CNvUDgLTzq", "zg9TywLU", "ndy0AgzezgDf", "yxjYyxLcDwzMzxi", "BgLZDej5uhjLzML4", "Dg9mB3DLCKnHC2u", "C2n4lwj1AwXKAw5NCW", "ChjVzhvJDgLVBK1VzgLMAwvY", "BwfW", "ndu0ndu5ogH1BNbhAq", "Aw5JBhvKzxm", "CMvZCg9UC2u", "ywjVCNq", "DMvYC2LVBG", "zxHWzxjPzw5JzvrVtMv4DeXLDMvS", "C2v0", "mJmWn0XLueDfva", "Dw5RBM93BG", "C3rHCNrZv2L0Aa", "yxv0AenVBxbHBNK", "Bwf4", "Dgv4Da", "Bwv0Ag9K", "DgHLBG", "zgvMyxvSDa", "qujpuLrfra", "nte2nZe3mgDRrvvrzG", "AgfZu2nVCgu", "y29Kzq", "DMfSDwu", "mZq5ode1ouzyuKfvCG", "C2n4oG", "C3rVCMfNzq", "zNvUy3rPB24", "uMvXDwvZDcbMywLSzwq", "C2LNBMfS", "DhjPBq", "ChvZAa", "mtC2odjcqwDYCLe", "Bg9HzgLUzW", "y2XLyw51Ca", "nZyYode1qvHfBKLr", "BwvZC2fNzq", "zw50CMLLCW", "uMvXDwvZDcb0Aw1LB3v0", "CMvTB3zL", "ywrKtgLZDgvUzxi", "nZnSDgjIvMO", "yxv0Aa", "CgfYC2u", "r0vu", "C2v0sxrLBq", "y2HYB21L", "DxjS", "mtu2ohLNEM1hvq", "y2vPBa", "z2XVyMfS", "B25jBNn0ywXSzwq", "ANnVBG", "y29TCgfUEuLK", "sfruuca", "Bg9HzgvK", "C2nVCgvlzxK", "B2jQzwn0", "DhrStxm", "CMvTywLUAw5Ntxm", "y29HBgvZy2u", "CMvHBg1jza", "BNvSBa", "yxnZAwDU", "zMLUywXSEq", "CMvTB3zLuMf3", "z2v0sxrLBq", "Bw9Kzq", "A2v5"];
  _0x5127 = function() {
    return _0x2c81ac;
  };
  return _0x5127();
}
let migrationsRan = ![];
function parseDomainAndVersion(_0x2f0708) {
  const _0x226906 = _0x1e023c, _0x1a7fdb = String(_0x2f0708 || "")[_0x226906(448)](":");
  if (_0x1a7fdb["length"] < 4) return null;
  if (_0x1a7fdb[0] !== "scx") return null;
  const _0x1fcc1e = _0x1a7fdb[1], _0x226824 = _0x1a7fdb[2] || "";
  if (!_0x226824[_0x226906(497)]("v")) return null;
  const _0x56cbb7 = Number(_0x226824[_0x226906(456)](1));
  if (!Number[_0x226906(462)](_0x56cbb7)) return null;
  return { "domain": _0x1fcc1e, "version": _0x56cbb7 };
}
async function cleanupVersionedEnvelopes(_0x3cfed3) {
  const _0x21f084 = _0x1e023c, _0x54c42e = await storage[_0x21f084(483)]({ "backend": _0x3cfed3, "prefix": _0x21f084(510) });
  for (const _0x4a6f91 of _0x54c42e) {
    const _0x257409 = parseDomainAndVersion(_0x4a6f91[_0x21f084(447)]);
    if (!_0x257409) continue;
    const _0x26c59c = Number(MIN_DOMAIN_VERSION[_0x257409[_0x21f084(480)]] || 1);
    if (_0x257409[_0x21f084(492)] < _0x26c59c) {
      await storage[_0x21f084(444)](_0x3cfed3, _0x4a6f91["key"]);
      continue;
    }
    if (_0x4a6f91[_0x21f084(508)] == null) {
      await storage[_0x21f084(444)](_0x3cfed3, _0x4a6f91[_0x21f084(447)]);
      continue;
    }
    const _0x75be3d = typeof _0x4a6f91[_0x21f084(508)] === "string" ? (() => {
      const _0x4e6c3a = _0x21f084;
      try {
        return JSON[_0x4e6c3a(422)](_0x4a6f91["value"] || _0x4e6c3a(441));
      } catch {
        return null;
      }
    })() : _0x4a6f91[_0x21f084(508)];
    if (!_0x75be3d || typeof _0x75be3d !== _0x21f084(436) || !Number[_0x21f084(462)](Number(_0x75be3d["v"]))) {
      await storage["removeRaw"](_0x3cfed3, _0x4a6f91[_0x21f084(447)]);
      continue;
    }
    Number(_0x75be3d["v"]) < _0x26c59c && await storage[_0x21f084(444)](_0x3cfed3, _0x4a6f91[_0x21f084(447)]);
  }
}
async function cleanupLegacyGlobalKeys() {
  const _0x10aab4 = _0x1e023c;
  for (const _0xea296d of LEGACY_GLOBAL_KEYS) {
    await storage[_0x10aab4(444)](_0x10aab4(475), _0xea296d), await storage["removeRaw"](_0x10aab4(425), _0xea296d);
  }
}
async function runDataMigrations({ force = ![] } = {}) {
  const _0x5d3e4a = _0x1e023c;
  if (migrationsRan && !force) return;
  await cleanupVersionedEnvelopes(_0x5d3e4a(475)), await cleanupVersionedEnvelopes(_0x5d3e4a(425)), await cleanupLegacyGlobalKeys(), migrationsRan = !![];
}
let initialized = ![];
async function initializeDataPlatform({ force = ![] } = {}) {
  if (initialized && !force) return;
  await runDataMigrations({ "force": force }), initialized = !![];
}
chrome[_0x1e023c(479)][_0x1e023c(430)][_0x1e023c(419)](async (_0x5b8659) => {
  await initializeDataPlatform();
});
